More characters. More cutscenes. More crazy.

What's up, doc? You'd be crazy to miss this new release of the classic Kemco NES game.

Our hero Bugs Bunny needs your help on a daring quest to rescue his main squeeze, Lola Bunny, who's been caught in the clutches of the despicable Witch Hazel. You'll meet twenty-eight Looney Tunes characters along the way. And watch out - those rascals are right on your cotton tail. It's an all-star cast. You never know who you'll run into in the Crazy Castle!

Hop through sixty stages, collecting carrots and other items. It's a crazy chase up creaking stairs, through doorways, and up and down pipes. Collect a boxing glove to throw a rabbit-punch, or knock your enemies out with crates, heavy safes, water buckets, bombs and ten-ton weights. Grab a Magic Potion for temporary invincibility. You might even shrink down to take on smaller enemies. Don't let anything stop you - once you've collected every carrot, you've won!

And if that's not enough for you, the optional included level packs will beef the game up to five times its length. If you're fast enough and clever enough, you'll win every stage and have Bugs and Lola hopping happily together again. On with the show, this is it!

Character lineup:
*Sylvester the Cat, Yosemite Sam, Daffy Duck, Merlin the Magic Mouse
*Tasmanian Devil, Witch Hazel, Leprechaun, Beaky Buzzard
*Foghorn Leghorn, Barnyard Dawg, Porky Pig, Count Bloodcount
*Wile E. Coyote, Road Runner, Gogo Dodo, Mugsy
*Marc Anthony, Instant Martian, K-9, Marvin the Martian
*Pepe Le Pew, Gossamer, Ghost Kid, Elmer Fudd
*Tweety Bird, Henery Hawk, Sylvester Jr., Speedy Gonzales

The first character in each line-up can go in/out doors and up pipes, and is more common. You will see these in multiple colors.

With five new cutscenes, revised graphics and twenty-eight enemy characters (instead of four), this hack is an impressive expansion of the original.

_______________________________


The password to level 60 is YTKX (any level can be accessed from this password). Game Genie code GXETZZEI grants invincibility. ATUSPYSA grants invincibility from skulls (or no carrot signs).

_______________________________


CREDITS:

Garrett Gilchrist (TygerbugGarrett) - Graphics, design, and general ROMhacking.

Bavi_H - Code for CHR graphic/enemy swapping, code analysis for enemy and color assignments.

SpiderDave - Code research for ACME Factory rescue scene, Python coding for cutscene tile compression, intro balloon timing, Game Genie, etc.

Cyneprepou4uk - Original ROM code disassembly and research.

Proveaux and Mottzilla - Original ACME Factory rescue scene coding (from Roger Rabbit hack).

Recommended level packs:
Ultimate level packs (1 2 3) by Mallory P. Maggiore.
Update level pack by Megafield64.

Thanks to - Shiru for NES Screen Tool, Mario_NESRocks for NES Assets Workshop (NAW)

__________________________________________________________________________


The Bugs Bunny Crazy Castle is a game from Kemco-Seika for the Nintendo Entertainment System, released August 1989. It is a port of "Roger Rabbit" for the Famicom Disk System.

This was followed by several sequels on the Game Boy, which expanded the game mechanics and included more characters, most of whom appear here in this hack. There were no NES sequels, but this bridges the gap a bit.

Kemco also released "The Bugs Bunny Birthday Blowout" for NES, which is not quite a Crazy Castle game.

In Japan, the first Game Boy games were released as "Mickey Mouse."

"Roger Rabbit" for the Famicom Disk System (and the "Lucky Rabbit" Famicom bootleg) had an animated ending where Roger rescues Jessica in the ACME Factory. This is not retained in Crazy Castle, although a simpler non-animated version appears in a Proveaux/Mottzilla hack, and is included in this hack as a non-animated scene of Bugs rescuing Lola. I am still hoping to include animation in this scene if the coding can be figured out.

_____________________________________________________________


Many characters are based on existing Game Boy/NES games, but are often redrawn heavily, with additional animation.

Marvin the Martian, Instant Martian, Gossamer, etc. are original to this hack. Witch Hazel, Barnyard Dawg, Porky Pig, Road Runner, Gogo Dodo, Mugsy, Count Bloodcount, Speedy Gonzales, Sylvester Jr., etc., are edited enough to be semi-original to this hack.

In the Tweety Bird levels, a "Bugs Jr." sprite is used, edited from the sprites in the Game Boy Crazy Castle 2.

The original game featured:
*Sylvester the Cat, Yosemite Sam, Daffy Duck, Wile E. Coyote

These are equivalent to the Roger Rabbit (FDS) characters:
*Smartguy Weasel, Gorilla Bouncer, Penguin Waiter, Judge Doom

and the Mickey Mouse (Game Boy) characters:
*Zeke "Big Bad" Wolf, Pete, Vulture, March Hare (or White Rabbit)

One hack nobody's done yet would be to use the graphics/characters from the Mickey Mouse Game Boy games, and other Disney characters. I have no plans to do so at the moment.

A version of the intro and outro were designed with Honey Bunny, based on the graphics in the original games, but Honey was replaced by Lola Bunny, due to popular demand. The ACME Factory ending was only ever designed with Lola.

https://twitter.com/TygerbugGarrett/status/1575339537118609408

Lola Bunny is referenced from Crazy Castle 3 and 4. The pose in both cases is referenced from the back of the Crazy Castle NES box.

__________________________________________________________________________

THINGS I FIXED:

Sylvester's defeat animation was coded to use the incorrect tiles, with the lower tile of his kicking feet swapped between frames.

There was also some extra walking head animation for Yosemite Sam which was unused, as well as unused defeat animation of his arm (lower middle tile).

Daffy's defeat animation was only one tile high, apart from his kicking legs. Blank FF tiles were used on the top row. I freed up a few tiles so that the characters replacing Daffy can have full animation rather than being squashed down to one tile high.

I also added an additional tile to Sylvester's defeat animation (center top, replacing a blank FF tile), because some of the characters replacing him are heftier (like the Tasmanian Devil and Foghorn Leghorn) and were therefore missing a few pixels otherwise. Wile E. Coyote was also missing this tile in the original version.

All of this could be useful to future hackers.

__________________________________________________________________________

FREEING UP TILES:

The blip-out (when an enemy dies) uses six tiles but can be done in two (which is what I did in this hack).

This frees up four tiles, three to give Daffy (etc) the full six tiles in defeat, and one for Sylvester (etc).

You could free up more tiles by mirroring some of the other sprites, like the pipe bulges, or potion. You could also, I suppose, remove "Pause."

I am actually not sure that the sideways/alternate sprites for the heavy safe and water bucket are even used, so that's also an option.

It wouldn't be out of line to free up more space and give the enemies more animation, but this project has probably gone far enough in that respect.

Character animation when walking or going up/down is very fast. This makes it awkward to do much with the animation, especially when going in/out of doors, or up/down pipes. In the Game Boy sequels, these animations were always mirrored, and available to multiple characters. In theory this would free up a few tiles for other enemies to have this type of animation, but you'd also need to slow that animation down.

In this hack, the character heads are generally not mirrored when going up/down, except for Bugs. This is to minimize this effect.

The first (largest) frame of the puff of smoke when an enemy is defeated is mirrored in four directions. Perhaps this could be combined with tiles from the second frame, or more tiles added.

__________________________________________________________________________

UNFINISHED BUSINESS:

*** Most of the enemies are recolored Sylvesters (or the enemies that replace Sylvester), which is left over from Roger Rabbit's weasels, and not great. This could ideally be changed for more variety. Only the Sylvesters can go in doors and up pipes, and only they have animation for this, but a few more tiles could be freed up for this purpose.

*** "Roger Rabbit" for the Famicom Disk System had an animated ending where Roger rescues Jessica in the ACME Factory. This is not retained in Crazy Castle, although a simpler non-animated version appears in a Proveaux/Mottzilla hack, and is included in this hack as a non-animated scene of Bugs rescuing Lola. I am still hoping to include animation in this scene if the coding can be figured out.

*** A hack exists of Crazy Castle which changes its Mapper to MMC5, allowing for more complex coding. This was not considered necessary for this hack.

*** Character possibilities that weren't included:

The Flame
Sam Sheepdog
Baby Bear
Mad Scientist
Penelope Polecat
Tina Russo
Gremlin
Petunia Pig
Claude Cat
Cool Cat
Pete Puma
The Crusher
Granny
Tweety Hyde
Cecil Turtle
Hopper Kangaroo
Draft Board Man
Egghead Jr.
Egghead

Generally these had no existing sprites and would look similar, at this size, to characters already included.

___________________


*** The cutscenes use a rudimentary RLE compression.

 FF xx yy  Output tile xx yy times.
 00-FE     Copy input to output.
 FF FF 00  End of data.  The second byte can be anything, but FF is used.

It is necessary to use this to fit the cutscene nametables in the space provided. I originally did this by hand, but a Python script was written by SpiderDave and used for the star/level screen.

py compression.py "uncompressed.bin" "compressed.bin" -c
________________

EB80 (70EB) Call for ACME Factory rescue
95c0 (b095) ACME Factory rescue
(borrowed from Proveaux/Mottzilla Roger Rabbit NES hack)
https://www.romhacking.net/hacks/1620/

*** Explanation of added ACME Factory rescue scene code (SpiderDave):

0987E 0986E                           ; ending subroutine
095C0 095B0                           org $95b0
095C0 095B0 A5 FF                         lda $ff
095C2 095B2 29 7F                         and #$7f
095C4 095B4 85 FF                         sta $ff
095C6 095B6 A9 00                         lda #$00
095C8 095B8 8D 01 20                      sta $2001   ; ppu mask
095CB 095BB 20 73 99                      jsr $9973   ; clear all sprites
095CE 095BE 20 6E 98                      jsr $986e   ; draw background tiles
095D1 095C1 20 08 99                      jsr $9908   ; draw ground
095D4 095C4 20 38 96                      jsr $9638   ; load palette
095D7 095C7 20 23 99                      jsr $9923   ; load nametable attributes
095DA 095CA 20 95 98                      jsr $9895   ; draw switch
095DD 095CD 20 DF 98                      jsr $98df   ; draw rope
095E0 095D0 20 01 98                      jsr $9801   ; draw bugs
095E3 095D3 20 D7 97                      jsr $97d7   ; draw lola

Lola is an uncompressed metasprite, and the ground is an uncompressed nametable. Bugs uses a grid system and math, as does the background (and its repeating patterns).

We need to write to $7c0 before doing the Bugs routine to change his x position.

Pasted to 9A70: 68 AA 68 A8 A9 *50 8D C0 07 4C 01 98 60 FF FF FF

This moves Bugs rightward. There's free space there until 9C37.

In the Bugs routine there's a LDA $9653,X.

Data 02:9653 (file offset 0x9663) controls where Bugs' tiles are coming from (or what frame of Bugs/Roger is appearing). For example: change the first byte of that to 0c.

989E - brick type for background (alternate lines)

9902- rope length (0D)

Bugs was referenced from Rabbit Rampage SNES, and a four frame walk cycle was planned if the coding could be worked out. Lola would have two nervous frames and one happy frame. A version of this is in the CHR graphics.

___________________


*** Explanation of sprite colors (Bavi_H):

It would be nice to be able to define different colors when different character graphics are loaded. (Level 30 should have green characters, for instance.) However, this is difficult due to how the colors are loaded, and why:

In the disassembly file bank_FF.asm, the table starting at CPU address C68A: (NES file offset 0x00C69A) ("tbl_C68A_palette_spr:") is where sprite palette colors are defined. The following $0F byte and table ("tbl_C69B:") are more sprite palettes that are loaded when a non-Sylvester character is in the stage.

0F	17	10	30	Bugs Bunny (character 0), Gray Sylvester 1 (character 1), Gray Sylvester 2 (character 4), poof clouds and lines, "PAUSE"
0F	1A	29	30	Green Sylvester (character 2), pipe bulges
0F	00	16	30	unused palette
0F	06	26	38	Pink Sylvester (character 3), carrots, no carrot sign, juice, boxing glove, bucket, crate, safe, 10-ton weight, "100", "500", "1000", "1UP"
0F	21	16	37	Yosemite Sam (character 5)
0F	00	37	30	Daffy Duck (character 6)
0F	17	26	30	Wile E. Coyote (character 7)

The game loads the first four palettes into the 4 sprite palettes. If there is a non-Sylvester character in the stage (character 5, 6, or 7), the unused palette is replaced with a palette for the non-Sylvester character. If there are multiple non-Sylvester characters in a stage, they all use the palette for the highest character.

Elsewhere in bank_FF.asm, the place where tbl_C68A_palette_spr is used (CPU address C642:) and the place where tbl_C69B is used (CPU address C7E5:) are potential spots to patch the code to load alternative colors.

Level types that don't have pipes don't need the "Green Sylvester" (who is pink in this version), but this is always loaded.

___________________


*** Here are the characters used in each stage (Bavi_H):

Graphics banks have been assigned to each stage in this hack to make sure that every character appears at least once, and to give a good mix of characters. Characters 1-4 here are Sylvester and his variants.

characters 1-4	character 5	character 6	character 7

original game	Sylvester	Yosemite Sam	Daffy Duck	Wile E. Coyote
Bank 0	Sylvester	Yosemite Sam	Daffy Duck	Merlin the Magic Mouse
Bank 6	Tasmanian Devil	Witch Hazel	Leprechaun	Beaky Buzzard
Bank 7	Foghorn Leghorn   	Barnyard Dawg	Porky Pig	Count Bloodcount
Bank 8	Wile E. Coyote	Road Runner	Gogo Dodo   	Mugsy
Bank 9	Marc Anthony	Instant Martian   	K-9	Marvin the Martian
Bank A   	Pepe Le Pew	Gossamer	Ghost Kid	Elmer Fudd
Bank B	Tweety Bird	Henery Hawk	Sylvester Jr.	Speedy Gonzales

order	stage	c1	c2	c3	c4	c5	c6	c7	Bank
1	01_		1		1				00
2	02_	1	1						0A
3	03_	1	1						07
4	04_	1			1				06
5	05_	1	1			1			08
6	06_		1	1			1		00
7	07_	1	1		1				09
8	08_		1		1			1	0A
9	09_		1	1	1		1		07
10	10_	1			1	1			06
11	11_	1	1			1			00
12	12_	1		1					09
13	13_	1		1	1		1		0B
14	14_		1		1	1			08
15	15_	1	1			1			07
16	16_	1			1				06
17	17_	1	1		1			1	09
18	18_	1	1			1			0B
19	19_	1	1	1		1			0A
20	20_	1	1		1				00
21	21_		1		1				06
22	22_		1		1			1	0B
23	23_		1		1		1		09
24	24_		1		1		1		08
25	25_		1		1	1			07
26	26_	1					1		06
27	27_		1	1		1			00
28	28_	1	1	1					0B
29	29_			1			1		0A
30	30_					1	1	1	09
31	31_			1	1			1	06
32	32_			1	1	1			08
33	33_		1	1	1		1		00
34	34_	1		1		1			0B
35	35_	1	1	1					0A
36	36_		1	1			1		07
37	37_			1	1				08
38	38_		1		1	1			0A
39	39_		1	1				1	00
40	40_	1	1				1		09
41	41_	1	1		1	1			06
42	42_		1	1	1			1	08
43	43_		1		1				0A
44	44_	1			1			1	07
45	45_	1		1		1			00
46	46_	1	1	1	1		1		0B
47	47_	1	1	1					06
48	48_	1	1	1	1				09
49	49_		1			1			08
50	50_		1	1			1		0A
51	51_	1	1		1		1		06
52	52_		1	1	1			1	0B
53	53_	1	1	1	1	1			07
54	54_		1	1	1		1		08
55	55_	1		1	1			1	0A
56	56_	1		1	1				09
57	57_		1	1	1		1		00
58	58_	1		1	1		1		07
59	59_	1	1	1		1			0B
60	60_		1	1	1	1		1	06
61	45_S3		1	1	1	1			0A
62	41_S2		1	1	1	1		1	09
63	60_S4		1	1	1	1		1	06
64	30_S1	1	1		1		1		00


The level CHR table appears at B134 in the ROM. It is called at FFD2.

00 0A 07 06 08 00 09 0A 07 06 00 09 0B 08 07 06 09 0B 0A 00 06 0B 09 08 07 06 00 0B 0A 09 06 08 00 0B 0A 07 08 0A 00 09 06 08 0A 07 00 0B 06 09 08 0A 06 0B 07 08 0A 09 00 07 0B 06 0A 09 06 00

RAM 68 stores the stage number, up to 3C / 60.

___________________

OTHER HACKING NOTES:

https://github.com/cyneprepou4uk/NES-Games-Disassembly/blob/main/Bugs%20Bunny%20Crazy%20Castle/

Title screen nametable at 8597. The individual bricks that fall start at 835D. They are 8 bytes (tiles) long, separated by "04 02." There are palette selections for what's under the bricks at 8325 (all 01 in Crazy Castle).

In this section (PRG Bank 2) the ROM offsets are close to the code offsets -- 8951 in the headered ROM is 8941 in the code (ignoring the header).

Cutscenes do not use the FF tile, using it instead to signify a simple form of compression:

FF ?? 00 - end of nametable
FF FF xx - xx is a counter for FF tile
FF ?? xx - print ?? tile xx times
??       - if bytes start from something other than FF, print those bytes (tiles) until next FF is found

py compression.py "uncompressed.bin" "compressed.bin" -c

84C4 - Table for word balloon tiles on the title screen, called at 849D. Not sure where position is set.

8134 - Word bubble from the title screen, timing. Try changing the cmp #$3d to cmp #$50 or higher to affect its blinking. Also that 1e is how many times to blink before exiting title screen.

8966 - Ending screen with Bugs and Honey Bunny.

8D50 - KEMCO logo and copyrights. In this hack, I've hijacked a subroutine to move this to the free space before 9E10 in the ROM, so that I can draw a more complex screen here.

The color fades in and out here are hardcoded, and originally just used a blue color, rather than the grey seen in this hack.

D7D6 - Level select / Star Menu screen.

The level graphics have 40 duplicate or unused tiles, which are cleaned up here in CadEditor to allow for a forty-tile Bugs face on the Star Menu screen.

Arguably the levels themselves could use more tiles instead, but I don't know if there's block space for that, since some blocks have properties like being a door. You can experiment in CadEditor and find out, I suppose.

____________________________


There was an unofficial FDS to Famicom conversion of "Roger Rabbit" titled "Lucky Rabbit," using an unusual Mapper (#415). This game had an animated ending (ACME Factory Rescue) not present in "The Bugs Bunny Crazy Castle." I am not sure if this Mapper could be corrected to something more normal -- either based on this or the FDS data.

https://www.nesdev.org/wiki/NES_2.0_Mapper_415

The nametable for the ACME Factory ending is visible in Lucky Rabbit's code at 18FDB-193B5. It is followed by the nametable for the final image of Jessica and Roger. It is preceded by a nametable for a version of the brick wall which appears in the opening, and before that by the metasprites from the Factory ending, in a somewhat abbreviated format also used in the game itself.

Before that there is blank space in Lucky Rabbit which ends at 16C50. I'm not sure how long the relevant code is in what follows. It's clear that this bootleg is much looser in how it uses its space than the Crazy Castle ROM.

Changing Lucky Rabbit's (unique) Mapper to 2, in Mesen, causes it to briefly say "loading" before loading a black screen.


____________________________

Code modifications by Bavi_H that change the sprite bank to a specific value for each stage.

1. List of sprite bank numbers for each stage

At NES file offset FFCF:
A6 68 BD *24 *B1 85 33 20 00 ED 20 30 F2 60

The level CHR table is added at B134 in the ROM. It is called at FFD2 (see asterixes)

00 0A 07 06 08 00 09 0A 07 06 00 09 0B 08 07 06 09 0B 0A 00 06 0B 09 08 07 06 00 0B 0A 09 06 08 00 0B 0A 07 08 0A 00 09 06 08 0A 07 00 0B 06 09 08 0A 06 0B 07 08 0A 09 00 07 0B 06 0A 09 06 00

RAM 68 stores the stage number, up to 3C / 60.

2. Hex Editor:
At NES file offset FFCF:
A6 68 BD 71 EB 85 33 20 00 ED 20 30 F2 60

Or in disassembly:
Near the bottom of the file bank_FF.asm, find the lines with these CPU addresses
FFBF:
FFC0:

change_sprite_bank_and_display_stage_num:

LDX ram_stage_id_1                   ;   X = current_stage
LDA sprite_bank_list,X               ; \ 
STA ram_chr_bank_1                   ; / ram_chr_bank_1 = Mem[sprite_bank_list + X]
JSR sub_ED00                         ;   change CHR banks
JSR sub_F230_replace_tiles_with_new  ;   original JSR to change displayed stage number
RTS                                  ;   Return

.byte $FF, $FF, $FF

At the top of the file bank_FF.asm, find the section with the .export lines. In that section, add the following line

.export change_sprite_bank_and_display_stage_num

3. NOP sprite bank number change before pre-stage title card fade in.

Hex Editor:
at NES file offset C05B:
EA EA EA EA

4. Jump to patch code at stage number display (3 bytes modified)
In the file bank_02.asm, find line 02:9375:
JSR change_sprite_bank_and_display_stage_num

Hex Editor:
At NES file offset 9385:
20 BF FF

