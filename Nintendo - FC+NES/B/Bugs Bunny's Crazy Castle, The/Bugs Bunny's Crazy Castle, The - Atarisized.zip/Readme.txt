Thank you for downloading Bugs Bunny Crazy Castle Atarisized, the latest in a series of hacks to change the NES graphics to Atari style graphics.

There are two patches available, a graphics patch and a level patch.  The Graphics Patch contains the Atari style graphics.  The Level patch contains 64 new levels.  