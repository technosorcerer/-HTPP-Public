The Ultimate Bugs Bunny Crazy Castle, �  Frank Maggiore, 2002

Version 1.1

The Bugs Bunny Crazy Castle hack, NES

Contact:  goldenroad155@cs.com
Site:  http://www.geocities.com/plinko50000/hacks.html