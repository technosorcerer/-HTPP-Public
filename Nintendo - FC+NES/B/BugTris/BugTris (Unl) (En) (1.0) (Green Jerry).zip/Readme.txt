Information:
------------

Name: BugTris
Region: Korea
Platform: Nintendo Entertainment System (NES)
Developer: Unknown
Publisher: Game Line
Genre: Puzzle
Player(s): 1/2
Release date: ??/02/1996

Description:
------------

The main objective of BugTris is to capture bugs that are hiding inside blocks. The player finds these bugs by clearing lines with blinking blocks, then catching the bugs with a net. Once all the bugs are captured, the game continues to the next level. The game ends after level 30 is completed.

Source: BootlegGames Wiki (https://bootleggames.fandom.com/wiki/BugTris)

Translation progress:
---------------------

Graphics: 100%
(The only Korean text is the title logo. Everything else is already in English).

Used tools:
-----------

WindHex32: Modifying the title tilemap and editing the title screen palette
YY-CHR: Editing the graphics

About the ROM:
--------------

Name: BugTris (K) (Unl) [!].nes (GoodNES) / BugTris (Korea) (Unl).nes (No-Intro)
File CRC32: D0B23FE9
ROM CRC32: 2E6F1A75
File MD5: FB5276A4EC43E51BA5639D313A6EBCA8
ROM MD5: 2C8274092264605E9F0714F21EC4F484
File SHA1: B0691110BAAC1F93576B2646C85C1C89D380627F
ROM SHA1: C9D2FF99AA02DA462DC38F87A22B6F8819122595

Translation installation:
-------------------------

You can use Lunar IPS (https://fusoya.eludevisibility.org/lips/) or Floating IPS (https://www.smwcentral.net/?p=section&a=details&id=4883). The patch is in the .IPS format. It should be applied to the ROM "BugTris (K) (Unl) [!].nes" (GoodNES), or to the ROM "BugTris (Korea) (Unl).nes" (No-Intro), with CRC32 2E6F1A75 and a size of 40 KB (40,976 bytes).