B-Wings
English Translation V 1.0
Copyright 2010 by The Stardust Crusaders
yojimbo.eludevisibility.org

Table of Contents

1.About B-Wings
2.Patch History
3.Patch Credits
4.Known Issues
5.COntact
------------------------------
1.About B-Wings
------------------------------
I have no idea about this game. I saw a video of its ending on Youtube and since it was in Japanese and looked pretty easy to hack, I did it for fun. Got a savestate from ReyVGM so I didn't have the play the game.
---------------
2.Patch History
---------------


---------------
3.Patch Credits
---------------
Me - Hacking
Unknown friend of ReyVgm - Translation

--------------
4.Known Issues
--------------
None!

--------------
5.Contact
--------------
Comments and questions can be sent to

yojimbogarrett at gmail dot com 

or check out my site at

yojimbo.eludevisibility.org
