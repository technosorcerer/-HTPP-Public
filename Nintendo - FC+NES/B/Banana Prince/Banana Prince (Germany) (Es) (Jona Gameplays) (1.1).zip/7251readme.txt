--Traduccion realizada por Jona Gameplays--
--Banana Prince--NES/FAMICOM

  versión de parche 1.1:
- correción de espacios en uno de los finales del juego.
- traducción de los creditos finales

  versión de parche 1.0:
- traducción de intro, dialogos y finales.
- edición de sprites para cambiar ¨rings¨ por ¨anillos¨.
- edición de sprites para cambiar ¨time¨ por ¨tiempo¨.
- correción de espacios en dialogos.
- traducción de los nombres de los niveles (solo aparecen en la tienda de teletransportación).
- traducción la sección de paswords y pantalla pre-nivel.
- créditos bajo pantalla inicial.

Este juego fue traducido en base a la traduccion realizada por KingMike’s, y se realizo con el parche de restauracion grafica de elbobelo aplicado.
Este parche se puede aplicar con o sin la restauracion grafica de elbobelo, pero si o si debe tener la traducción de KingMike’s, o no funcionara.

traducción inglesa: https://www.romhacking.net/translations/685/

restauración grafica: https://www.romhacking.net/translations/5049/

