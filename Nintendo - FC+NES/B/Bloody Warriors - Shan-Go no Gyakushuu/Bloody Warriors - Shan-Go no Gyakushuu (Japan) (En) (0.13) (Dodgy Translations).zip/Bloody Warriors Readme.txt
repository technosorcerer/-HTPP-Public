
+---------------------+
|   Bloody Warriors   |
|  Translation Patch  |
|    Version 0.13     |
|---------------------|
| Dedicated to Sammi. |
+---------------------+


Whats Done:
-----------
Version 0.13
-More Item Names
-More Monster Names
-Character Names (See Bugs)
-All Menus Done (That I Know of)

Version 0.10
-Entire First Village
-Some Monster Names
-Some Items Names
-Most Menus (see bugs)
-Misc. Dialogue

Bugs:
-----
-Inn prices are only correct for the 1st inn
 (It still isn't fixed, I'll fix it eventually)
-The characters names are just made up at the moment, I just put those names
 because I was sick of looking at the Japanese names.  I'll try to fix those
 in the next release

Contributors:
-------------
Aussie - Hacker/Preliminary Translator
monmon - Translator
Chris Judah - Item Translator
Gil_Galad - Hacking and finding the main menu
Nam_Chops - Beta tester

Thanks:
-------
-Everyone from #romhack helped me out and was there to listen to how EVIL
 the mainmenu is.
-Hightimez for trying to find that accursed menu.
-Karson for being there while I complained about control codes.
-James for being there while I complained about everything else.

Contacting us:
--------------
E-Mail: CKSoftware@Hotmail.com
WWW: http://dodgytrans.darkmazda.com
IRC: #dodgytrans on dal.net