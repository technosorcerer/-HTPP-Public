-----------------------------------------------
-BlackPaladin's Bloody Warriors Addendum Patch-
-----------------------------------------------

***************************************
*Bloody Warriors: Shan-Go Strikes Back*
***************************************

First things first, I want to thank you for downloading and using my eddendum patch.  It's been a very long time since I did anything of this capacity, and I hope this patch made the game a bit more enjoyable.

Second, I want to thank ded302 and snark for working on translating the game in first place.  They did a good job with trying to make this game enjoyable for the English-speaking masses.  However, when I played this game initially, I found some untranslated text that rubbed me the wrong way.  After attempting to contact ded302 and snark about continuing work on their patch, I heard nothing.  I even contacted Dodgy Translations as well, and attempts at reaching that group was fruitless.  Therefore, I decided to fix this myself.

After constructing working table files (one in English and one in Japanese) I went to work.  I had to use DeepL, 10ten, and Google Translate (please don't hold that against me) to fill in the gaps as best as I could.  This may result in a less than accurate translation, but it's the best I could do with what little resources I could gather.

Patching Instructions:

This addendum patch come in four flavors:

Bloody Warriors - Shan-Go Strikes Back (addendum).ips
--This patch requires a pre-patched ROM that already has ded302/snark's patch already applied (IPS Format)
Bloody Warriors - Shan-Go Strikes Back (addendum).bps
--This patch requires a pre-patched ROM that already has ded302/snark's patch already applied (BPS Format)
Bloody Warriors - Shan-Go Strikes Back (full patch).ips
--This patch requires a clean and unaltered ROM (IPS format)
Bloody Warriors - Shan-Go Strikes Back (full patch).bps
--This patch requires a clean and unaltered ROM (BPS format)

I recommend using Lunar IPS for applying the IPS patches.  Flips can be used to apply the IPS or BPS patches.

Be sure to use an NES ROM with a header (262,160 bytes) with a CRC Checksum of 5CB5676F.  Where to find said ROM is up to you.  I cannot tell you where to look for it.


What changes have been done:

-Almost all untranslated text has been translated and inserted
-Many grammatical errors in script fixed
-added the following tiles in font table
--'s
--'t
--il
--li
--ll 
-Menus fixed
--ITem is now Item
--TaLK is now Talk
--FLOOR is now Srch
--Stat is now Inf
--EQUIP is now Eqp
--DrOP is now Rig
-Item names changed
--Troops is now Potion
--Untranslated weapon is now Presden Sword (Sword Icon + Presden)
-Monster names appear in battle menus
-Some monster names has been changed
--Wolf (Green) is now Wulf
--Bee (Orange) is now Hornet
--Snake (Red) is now Viper
--Toad (Green) is now Frog
-Game name's subtitle translated and added to intro screen (Game's title is now "Bloody Warriors: Shan-Go Strikes Back")
-"Dragon Warrior" font applied
-Ending text changed

What has NOT been done:

-Fixed bugs in character naming screen (y & z are still not operational, just like in the original patch)

Special Thanks:
ded302 (Original Hacker)
snark (Original Translator)
Cyneprepou4uk (Helped with Identifying Pointer System)
aqualung (Assisted with Spot Translation)
TaraEmsley (Assisted with Spot Translation)
LostTemplar (Assisted with Spot Translation)
Toei Animation (They made the game in the first place!)
FCE Ultra Team (Used their emulator's hex editor system to edit script)
Mesen Team (Used their emulator's hex editor system to edit script)

All credit to "Bloody Warriors: Shan-Go no Gyakushuu" belong to Toei Animation and their respective creators and programmers.  This patch is mainly used for pure enjoyment for those who cannot enjoy this game.  All rights reserved.  (Please, don't come after me, Toei!)