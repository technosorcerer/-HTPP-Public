Böbl (NES)
Traducción al Español v1.1 (28/09/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
-Traducción adaptada a versión 1.2 del juego

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
bobl-1.2.nes
MD5: cc07f49b62705f6de2c80252cdb00f10
SHA1: 983432405399554f6d1e3dda33ed90acfd460e43
CRC32: 7a2efc9d
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --