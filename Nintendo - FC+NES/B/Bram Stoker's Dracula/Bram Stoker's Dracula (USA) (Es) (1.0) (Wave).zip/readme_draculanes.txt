Bram Stoker's Dracula (NES)
Traducci�n al Espa�ol v1.0 (24/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Bram Stoker's Dracula
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Bram Stoker's Dracula
-----------------
Plataformas basado en la pelicula, bastante logrado identico a la version de GG/SMS (excepto el colorido).

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Bram Stoker's Dracula (U) [!].nes
262.160	bytes
CRC32: f5321963
MD5: 582fe67072d38c52bba7f7efa509bbe7
SHA1: 7619bac804f9be52b6411bd54a0af2528511582a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --