Bram Stoker's Dracula (NES)
Traducción al Español v2.0 (23/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducido "PRESS START" del título
-Añadidos caracteres especiales
-Guión retraducido y ampliado

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bram Stoker's Dracula (USA).nes
MD5: 582fe67072d38c52bba7f7efa509bbe7
SHA1: 7619bac804f9be52b6411bd54a0af2528511582a
CRC32: f5321963
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --