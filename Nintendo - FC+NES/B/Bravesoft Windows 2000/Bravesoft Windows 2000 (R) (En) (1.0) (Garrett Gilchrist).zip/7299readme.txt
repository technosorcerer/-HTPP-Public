Bravesoft Windows 2000 (English Translation) NES / Famicom

Hacked by:

TygerbugGarrett - Graphics and general romhacking
Vinheim3 - Decompression hacking

This is an XDelta patch for Bravesoft Windows 2000 (R)[!].nes (512 kb)
(Oct 2022 version used)
https://github.com/jmacd/xdelta

This ROM attempts to duplicate something of the Windows 95-2000 experience on your NES. It was originally issued in Chinese and Russian, with compressed graphics. Vinheim3 decompressed the graphics routines and I redesigned the graphics and nametables in English, adding some extra graphical fun here and there.

While much of this experience is non-functional, many Applications absolutely work, under Accessories and Games. This includes Gast Word and Excel, Calculator, FBasic, GBasic, Music, Text processing, Background design, Music Board, Typing Test, CD Player, and more.

This ROM requires a Subor Keyboard. The more common Family Basic Keyboard will not suffice in most cases. You can view most of the ROM with your standard gamepad but Applications may not work. It also uses an unusual Mapper (178) so only some emulators will be able to handle it. I suggest FCEUX for full functionality, but the FCEUX hotkeys will cause issues when typing and must be disabled beforehand. Subor Mouse mode doesn't seem to work well with this ROM, which surprised me. I would have expected Subor Mouse functionality, and perhaps this could be fixed somehow, along with the slow cursor speed.

Many graphics are new to this version, including:
- Windows logo
- Flying Toaster screensaver
- Shutdown screens (graphics and text)
- Folder Options
- Private / Media Player (Jennifer Aniston and Matthew Perry)
- Games and Accessories icons

Some of the Russian applications have been translated, like the Music Player and Text Editor.

Apart from the presentation this is a somewhat typical "educational" multicart of the Subor/Dendy variety. There were many such educational carts, which came with a keyboard and attempted to turn the clone Famicom/NES hardware into something like a full 8-bit computer (that could also play Famicom games). Bootlegged versions of Hudson's programmable Family Basic V2 almost always appear, along with music and word processing. The Subor OS was mimicking Windows by the 2000s, although not in the same way as this cart. The Windows experience here is somewhat believable and somewhat functional.

Known Issues:

1) CD Player app is loading wrong graphics (or not loading new graphics). It may be loading data from 471B0 / 471C0. I've added the original graphics at 47640.

2) Highlighting is broken in the Calculator App, loading the wrong sprite graphics -- appears to be loading some nametable data instead.

3) MS-DOS Prompt is not working (has also loaded the wrong graphics)

4) Cursor behavior is odd in Gast Word and Excel, with the cursor splitting in two and leaving bits behind, or just floating upward to the left at all times.

5) Ideally Windows Logo screen (startup) should load a more complete CHR. This is difficult since the graphics are immediately followed by data, but there's blank space not much later in the ROM, and it could be repointed.

6) Highlighting of "Paint" row of start menu should be two tiles to the left instead. Other highlighting should match the text better generally, especially with the new translation, and especially on the Desktop.

7) Ideally more apps could be added to the empty space, and linked to somewhere (Crosspaint Demo? Some NROM games?)

8 ) Cursor speed is slow. Subor Mouse mode doesn't work properly; this was probably not designed for Subor Mouse.

Otherwise this is pretty close.
