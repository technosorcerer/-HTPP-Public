Bee 52 (NES)
Traducci�n al Espa�ol v1.0 (16/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bee 52 (Camerica) [!].nes
MD5: c069c905796a4d1daabad5cdb4dca882
SHA1: b47df8791af3e39ac486b5d09b313109e8aeebcf
CRC32: 77a8486f
65.552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --