o--------------------------o
|     Blaster ReMaster     |  (c) 2012 Remz Lab
o--------------------------o

A complete Blaster Master (NES) level hack that features 
8 new tank levels from the same creator than Super Mario Bros Rebirth.

-------------
Instructions: 
-------------

Apply the patch (blaster_remaster_patch.ips) to your original
Blaster Master ROM file using an application like "Lunar IPS".

---------------------------------------

Download or Play :

http://lab.remz.ca

---------------------------------------

Any questions or comments? info@remz.ca