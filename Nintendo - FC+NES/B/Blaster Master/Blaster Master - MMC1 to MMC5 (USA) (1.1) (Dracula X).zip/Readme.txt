Blaster Master
Mapper Conversion Patch
FROM Mapper 1 (MMC1) TO Mapper 5 (MMC5)
Converted by Dracula X
RELEASE DATE: 1/22/2020
Modified: 5/15/2020

PRG Bankswitch Routine is at $E63C

To switch banks from $C000 - $FFFF, use like so:

LDA bank_number
JSR $E63C
JMP to any location in $8000-$BFFF




CHR Sprite Bankswitch Routine (Left side of PPU) is at $E664

To switch sprite pages, use like so:

LDA page_number
JSR $E664




CHR Background Bankswitch Routine (Right side of PPU) is at $E650

To switch background pages, use like so:

LDA page_number
JSR $E650




Nametable Mapping Routine (one of its uses is mirroring) is at $E678

To change mirroring for instance, use like so:

LDA mirroring_number (#$50 for Horizontal, #$44 for Vertical)
JSR $E678

This patch will not work for:
Chou-Wakusei Senki - MetaFight (Japan)

Hacks supported:
All!

Hacks not Supported:
Blaster Master MMC1 to MMC3 Hack

Use Delta Patcher to patch the xdelta file to the ROM. 
Ignore the checksum and then patch the file.

Changes for this version 1.1
Fixed the PPU Viewer and removed Patch A & B since it's no longer needed
anymore. Now, All hacks are now supported. I also changed something in the MMC5 Setup
so Metroid - Dark Alliance hack can work with my MMC5 hack.

Credits:
Rockman or RetroRain: for info on how to convert the mapper!
Disch: for his mapper docs and a better MMC5 startup!


Non Supported Emulators:
Nintendulator
RockNES
VirtuaNES