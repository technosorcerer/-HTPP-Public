Hello! Thank you for downloading blaster master DX! this was my 1st rom hack,
and it took a bit less than a day to make this, because i made the sprites before,
as i felt like improving the sprites.

The changes i made were: graphics: i changed all overworld sprites for Sophia 3rd, and Kane.
and i have set the lives to infinity.


Utilities used: YYCHR, Floating IPS, FCEUX, and NES CHR ROM editor
, by u/jimmy-m-420 on reddit.



--==CHANGELOG:==--

any changes i make will appear here.


V1.0: blaster master DX has been released!

V1.1: day 1 patch: fixed spritees not appearing correctly in area 2 onwards.

V1.2: Blaster master zero 3 celebration patch:
fixed sprites reverting to original when going to the mutant blocking area 2. 
Now go forth, Blaster master!