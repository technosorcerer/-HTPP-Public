
This patch enables the area select that is built in, but now instead of a demo being played the area is loaded.

The correct bits are also set for which items have been acquired and which bosses have been defeated.
The doors that need the "key" are also unlocked if Area 5 or higher is selected.

Apply "Blaster Master area select with items.ips" to "Blaster Master (U) [!].nes" or "Blaster Master (USA).nes" (MD5 of 9c96408f7a7aa0da2c3b723759699506)

Source code included. Use "snarfblasm" to assemble the IPS patch.

- drk421@gmail.com

