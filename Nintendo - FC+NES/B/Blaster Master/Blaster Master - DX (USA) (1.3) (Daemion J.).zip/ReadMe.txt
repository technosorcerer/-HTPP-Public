Hello! Thank you for downloading blaster master DX! this was my 1st rom hack,
and it took a bit less than a day to make this, because i made the sprites before,
as i felt like improving the sprites.

The changes i made were: graphics: i changed all overworld sprites for Sophia 3rd, and Kane.
and i have set the lives to infinity.


Utilities used: YYCHR, Floating IPS, FCEUX, and NES CHR ROM editor
, by u/jimmy-m-420 on reddit.



--==CHANGELOG:==--

any changes i make will appear here.


V1.0: blaster master DX has been released!

V1.1: day 1 patch: fixed spritees not appearing correctly in area 2 onwards.

V1.2: Blaster master zero 3 celebration patch:
fixed sprites reverting to original when going to the mutant blocking area 2. 
Now go forth, Blaster master!

V1.3 More Graphical improvements have been added, with the cannon connecting to the metal attacker, the font being upgraded, and the number 2 being put back in the font.
Andreia mode had been added: it makes the metal attacker blue. im working on a custom ANDREIA title screen and end screen, and even dive gear from the start, but thats not done yet.
I have also added an optional patch where you can control the use of the "wall 1" powerup, by holding B!
Both optional Patches Should work on a vanilla copy of the game, and all patches work on all rom hacks!