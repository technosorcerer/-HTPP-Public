Blaster Master - Alan Jacobs Version

Alan Jacobs, 2012

(V1.1) 2014
This version gets rid of some graphical issues and I improved enemy
placement.


This is my modified version of Blaster Master. It took me about 2 months 
to complete and I'm very proud of what I have accomplished here. Only the 
level layout and some palettes have been changed. The rest of the game 
(Bosses, Graphics, Power-Ups, Enemies, Upgrades) have not been altered or 
changed in any way. I hope you enjoy this game as much as I enjoyed making
it.


Author's Notes and Tips...

-Every tank and overhead level has been completely redone from scratch.
Other than the Area 2 portal location in Area 1, all of the area portals 
have been relocated into a different area with the exception of one. Be 
sure to explore all around you in every area to have an understanding 
where portals may be located.

-Your progress will be saved with every door you enter. Be aware that 
Area 8 does not contain Screen Scrolling Tunnels. If you can access a 
doorway, enter it to save your progress unless you want to start all the 
way back to the beginning of the area when you lose a life. 


Credit and Thanks go to Snarfblam for the ReMaster 1.0 hack tool.


Thank you and enjoy!




