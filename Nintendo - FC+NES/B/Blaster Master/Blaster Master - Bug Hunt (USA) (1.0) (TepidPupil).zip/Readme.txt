TepidPupil Presents

Blaster Master: The Bug hunt

     Hello all and welcome to another of Tepidpupil's hacks.
This .ips file is intended for the American version of Blaster
Master. It is a simple graphic hack that changes a few level
bosses to bugs. Here's what I did:

- First level creature now has a face. I dub it: Father Brain.
- 2nd and 6th level are now bettles
- The frogs now have eyes that looked stoned at first, but
   when they attack they look evil.
- The 3rd level boss has an eye.


     I know it's not much, but I'm proud of my fledging work. 
it can only get better. Lemme know what you think of the 
graphics.