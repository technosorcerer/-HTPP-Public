This hack will mute the music in BB Car, while keeping most sound effects.

Useful if you want to listen to other music while being able to hear the sound effects.

Note: The collision sound when crashing into other cars will also be muted.

ROM Info
--------
Database match: BB Car (Asia) (En) (Unl)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 94BF70B6FB65EF5451E2E8A1EEFAF2664C177945
File CRC32: 8713DE54
ROM SHA-1: 2306A1A9F7003A446D837F9D7F5AB2E4BF65E0AD
ROM CRC32: 7F9C1DEC