Use with:

(No Intro)
File:               Battle of Olympus, The (USA).nes
BitSize:            1 Mbit
Size (Bytes):       131072
CRC32:              6B53006A
MD5:                FD643D07B01072A1376353BD37B1F8C6
Headerless MD5:		0183F722A8A39DCBE244F4DEDEB74628


Output:

(No Intro) (clymax)
File:               Battle of Olympus, The - Item Randomizer (USA).nes
BitSize:            1 Mbit
Size (Bytes):       131088
CRC32:              36A04172
MD5:                61F167FD82185EEEDCA95B58F5D98F05
Headerless MD5:		DEC6A82273EED6B1593CC54C0FDA166E