The Battle of Olympus - SRAM Saving Edition + Re-balanced

-= Complete hack v1.1 =-
Apply 'Battle of Olympus - SRAM EDITION v1.1.ips' directly to 'Battle of Olympus, The (U) [!].nes - GoodNES 3.14'


Optional Patches:
Battle of Olympus - SRAM EDITION optional patch - extend argolis shore.ips


Battle of Olympus - SRAM EDITION optional patch - revert olives losing half.ips


What this hack does:

This hack attempts to modernize the beloved cult classic The Battle of Olympus by giving it SRAM Saving function plus other various re-balancing adjustments to the game.


-= Complete hack v1.1 =-

Updated and cleaned up the Title and Name Entry screens.

Added 2 optional patches:

Optional Patch 1 (Battle of Olympus - SRAM EDITION optional patch - extend argolis shore.ips

):
Adds blocks that extend the shores of Argolis leading to Phrygia.

Optional Patch 2 (Battle of Olympus - SRAM EDITION optional patch - revert olives losing half.ips):
This optional patch reverts to losing 1/2 of the Olives upon death.


-= Complete hack v1.0 =-

List of features, additions and changes:

1) Added SRAM Saving function! Speaking to the gods will SAVE the game, and pressing START at the password input screen will LOAD the game at an instant!

2) To reduce grinding, the drop rate for Olives has been increased. While the original game was great, the item prices were extremely high and grinding for Olives can take the enjoyment out of the game. Not to mention losing 1/2 of the Olives upon dying, which is why that issue has also been addressed...

3) The player now loses 1/8 of the Olives instead of 1/2 upon dying. This greatly reduced the frustration of losing/grinding Olives in the game, while keeping the overall difficulty. Minimal Olives grinding is still present.

4) Various texts changes and additions.

5) Passwords are still present and usable, so feel free to enter that super code!


Tools and resources used:
FCEUX, Cygnus Hex Editor, neshead tool, http://www.6502.org/tutorials/6502opcodes.html, http://tasvideos.org/GameResources/NES/BattleOfOlympus.html, nestopia, everdrive, and romhacking.net.


Special thanks:
I'd like to give a very special thanks to these individuals @ RHDN: nesrocks, abw, Psyklax, and KingMike
Without these brilliant individuals, I would not have been able to complete this project.
Thank you very much!! :D


Acknowledgements and Credits:
INFINITY for this amazing game.
Broderbund for releasing the game in the US.
Nintendo for licensing the game in the US.

2017.7.30 v1.0 by 8-bit fan / 8.bit.fan / butz
2022.1.2 v1.1 by 8-bit fan / 8.bit.fan / butz