+-------------------------------------+
| Battle of Olympus: Explorer Edition |
+-------------------------------------+

  | Introduction
  +--------------------------------------
    Explore new and exciting routing possibilities not possible in the original game.  Certain game mechanics have been adjusted to reinforce this new focus on exploration.


  | Features
  +--------------------------------------
    - Olive drops increased to 16x.
    - Salamander-skin drops increased to 4x.
    - Blocked seaway from the second shore of Argolis has been opened.
    - Entrance to Tartarus now available from the start of the game.

    For a demonstration of these features, see the video section below.


  | Video
  +--------------------------------------
    https://www.youtube.com/watch?v=wSEgL5-pUsg


  | Development History
  +--------------------------------------
    Romhack created January 1-5, 2020 and submitted to ROMhacking.net on February 20, 2023 as my first romhack.  Note, I have timestamped files and videos of this romhack, stored in the cloud, that can support the creation dates mentioned.  The extended delay between creation and submission is due largely to:
    - Uncertainty surrounding one of the features of this romhack after I discovered an unintended consequence of implementing that feature.
    - Procrastinating on writing a submission and making a video for this romhack.
    - IRL stuff getting in the way.

    I recently finished a second romhack, for a different game.  This incentivized me to submit this romhack to avoid my romhacks being published out of chronological order.

    The first feature I implemented in this romhack is unblocking the seaway from the second shore of Argolis, i.e., the seaway that leads to Phrygia.  However, after implementing this feature, I discovered an unintended consequence in the form of a sequence break of accessing the first Nymph and obtaining the first Fragment of Love in Argolis without needing to first get the Eye of Graeae from defeating the Graeae in Laconia.  Upon this realization, I deemed the enabling of this sequence break as relatively undesirable.  This created uncertainty on my part on whether to move forward with publishing this feature.

    In my opinion, a proper unblocking of the seaway from the second shore of Argolis would entail, for instance, changing the door to the Nymph in Argolis into a special door that is only revealed by activating the Eye of Graeae.  This would unblock the seaway without enabling the sequence break described above.  I have not investigated this idea further to see how much effort in reverse engineering would be needed to accomplish this.

    The second feature I implemented in this romhack is making the conditions more lenient for entering Tartarus.  The game checks to make sure you have all three fragments of love.  Before discovering the sequence break noted above, I had been contemplating whether to make it so that the game only checks that you have the third fragment of love.  This would allow entrance to Tartarus based on only the fragment of love from defeating Minotaur in Crete.

    To resolve the uncertainty surrounding the first feature, I've finally and recently decided to make the sequence break relatively moot by allowing entrance to Tartarus regardless of which fragments of love have been collected.


  | Special Thanks
  +--------------------------------------
    Steve Hicks for his Battle of Olympus Password Generator, which was useful for testing this romhack.
    http://pages.physics.cornell.edu/~shicks/bolympus.html


  | Tools Used
  +--------------------------------------
    - FCEUX
    - TBLater
    - LunarIPS


  | Platform
  +--------------------------------------
    Nintendo Entertainment System (NES)


  | Game Credits
  +--------------------------------------
    - Infinity, developer of the original game.
    - Brøderbund, publisher of the original game.
    - Nintendo, licensor for the original game to be developed and published for the NES.


  | Version History
  +--------------------------------------
    Version 1.0 created January 1-5, 2020 and submitted on February 20, 2023.


  | License
  +--------------------------------------
    MIT License


  | Creator
  +--------------------------------------
    clymax
    https://twitter.com/clymax