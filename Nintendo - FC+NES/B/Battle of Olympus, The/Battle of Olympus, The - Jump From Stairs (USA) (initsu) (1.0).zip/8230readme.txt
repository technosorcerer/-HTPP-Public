The Battle of Olympus - Jump from Stairs v1.0 (2023-11-16)
by initsu

This is a hack to allow the player to jump while climbing stairs.
Additionally, you can hold D-pad down while pressing A (jump) on
stairs to drop down. Left/right velocity is maintained.

The reason I made this hack is that the stair climbing in this classic
game felt rigid (to me) compared to many other platform games.

This is my first ROM hack but I think it turned out very nicely.


Patching
========
Base ROM should be: "Battle of Olympus, The (U) [!]"

Optional step 1: Apply "Battle of Olympus - SRAM EDITION v1.1" if desired.
                 This hack is tested and compatible with this.
                 (v1.1, future versions unknown)

Step 2:          Apply "Battle of Olympus - Jump from Stairs.ips"



License: Public Domain
======================
I release this as public domain. Use this as you want. You may include
it in your own hacks, etc.


Programming notes
=================
First, I moved the existing stair climbing logic to an empty later
part of the ROM. This was to create space to add additional logic. If
jump is not pressed, I go to the old (moved) code. If the jump button
is pressed, I call the existing jump subroutine. (This button check was
previously never done while in the climbing state.) In this case, I
also clear the climbing stairs state bytes. Finally, if D-pad down is
also pressed, I remove any upwards velocity from the jump, and thus
making it into a drop (while still maintaining the in-air state).
