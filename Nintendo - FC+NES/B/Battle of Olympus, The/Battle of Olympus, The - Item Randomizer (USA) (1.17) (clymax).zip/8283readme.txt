+-------------------------------------+
| Battle of Olympus: Item Randomizer  |
+-------------------------------------+

  | Introduction
  +--------------------------------------
    Randomize items for new and exciting gameplay possibilities.  All items are randomized each time in the current build.  Synergizes with the Explorer Edition hack, which is included in the same patch.


  | Features
  +--------------------------------------
    - No external program or web app needed to randomize.
    - Auto mode gives you a different seed on each reset.
    - Manual mode lets you input the seed you want.
    - Quick start puts you at Zeus's Temple with Hermes already summoned.
    - Sandals and Ocarina are granted on start, leading to more routing possibilities.
    - Softlock scenarios have been substantially reduced by a variety of post-release balance updates.

    For a demonstration of these features, see the video below.  For details on what is randomized, see the Version History section below.


  | Video
  +--------------------------------------
    https://www.youtube.com/watch?v=n4Fh21_hAgU


  | Use With
  +--------------------------------------
    (No Intro)
    File:               Battle of Olympus, The (USA).nes
    BitSize:            1 Mbit
    Size (Bytes):       131072
    CRC32:              6B53006A
    MD5:                FD643D07B01072A1376353BD37B1F8C6
    Headerless MD5:     0183F722A8A39DCBE244F4DEDEB74628


  | Tools Used
  +--------------------------------------
    - Mesen2
    - FCEUX
    - TBLater
    - HxD
    - GameHeader
    - FLIPS
    - Advanced NES ROM Utility
    - Nflate


  | References Used
  +--------------------------------------
    - The Battle of Olympus hacking and Latin translation by abw
    - The Battle of Olympus (de)compression suite by abw
    - The Battle of Olympus password generator by Steve Hicks (steve_hacks)
    - Crystalis Randomizer by Steve Hicks (steve_hacks)
    - The Battle of Olympus disassembly by Joel Yliluoma (Bisqwit)
    - Minimal PRNG implementation in 6502 asm by Arlet Ottens (Arlet)
    - Mod and div implementation in 6502 asm by Alex Clemmer (hausdorff)


  | Special Thanks
  +--------------------------------------
    - Steve Hicks (steve_hacks) for personal feedback on different approaches to implementing randomizers, based on his experience in developing a successful randomizer and building a player community around it.
    
    - Gaming Youtuber @HalDanGhor for encouraging me to follow through with my planned work on the hack, for testing in beta and after release, and for feedback on the design from the perspective of a top player of the game.

    - @subledger. on Youtube and for testing in beta and after release and for feedback on the design from the perspective of a top player of the game
    
    - shwank from Retro Achievements for testing in beta and after release and for feedback on the design from the perspective of a top player of the game.

    - Speedrunner Karma_dragoness for feedback on Explorer Edition that paved the way for the Quick Start mechanics in Item Randomizer.
  
  
  | Platform
  +--------------------------------------
    Nintendo Entertainment System (NES)


  | Game Credits
  +--------------------------------------
    - Infinity, developer of the original game.
    - Broderbund, publisher of the original game.
    - Nintendo, licensor for the original game to be developed and published for the NES.


  | Community Discord Server
  +--------------------------------------
    Because the Discord link is not currently permanent, please check the other links in this file for the latest Discord link.


  | Community Links and Issue Tracker
  +--------------------------------------
    https://github.com/cIymax/the-battle-of-olympus-randomizer


  | Version History
  +--------------------------------------
    Version 1.16 stable submitted on December 14, 2023 for release.
    - Fists have been made re-equippable in zero-item starts.
    - Equipped fists will now show a Club.
    - Inventory menu slot for fists will still be blank.

    Version 1.15 nightly entered beta December 13, 2023.
    - New optional starts for auto seeds, now available.
    - Specifically, one-item, zero-item, two-item, and four-item starts are included.

    Version 1.14 nightly entered beta December 13, 2023.
    - Upon information, it appears that a bug in the seeding algorithm was introduced in version 1.10.
    - The bug caused the same randomization to be given each time, regardless of auto or manual mode.
    - The bug has now been fixed.

    Version 1.13 nightly entered beta December 13, 2023.
    - New optional starts for manual seeds, now available.
    - Specifically, two-item and four-item starts are included.

    Version 1.12 nightly entered beta December 13, 2023.
    - Enables off-hand items to be used by Orpheus even when barehanded in a zero-item start.

    Version 1.11 nightly entered beta December 13, 2023.
    - New optional starts for manual seeds, now available.
    - Specifically, one-item and zero-item starts are included.

    Version 1.10 nightly entered beta December 12, 2023.
    - Items dropped by enemies also randomized.
    - Items dropped by backgrounds also randomized.
    - Still present are the graphical glitches that kept these features from being included in version 1.00.

    Version 1.09 nightly entered beta December 12, 2023.
    - Release to confirm stability after quick-start routine was moved from the fixed memory bank to a switched memory bank.

    Version 1.08 nightly entered beta December 11, 2023.
    - Best ending now requires all three hearts to have been obtained.
    - Normal ending is reacheed otherwise.

    Version 1.07 stable submitted on December 11, 2023 for release.
    - Rom size doubled to 256 KB.
    
    Version 1.06 nightly entered beta December 10, 2023.
    - Fixed a bug causing certain bosses to be vulnerable to lesser weapons than swords.
    
    Version 1.05 nightly entered beta December 10, 2023.
    - Fixed a bug causing certain maps to be unreachable following the Harp-destination update.
    - However, this fix also makes the warp destinations farther away from the Sun statues.  This may be addressed in a future patch.
    
    Version 1.04 nightly entered beta December 10, 2023.
    - Made Gaea vulnerable to lesser weapons than swords, to reduce the incidence of softlocking scenarios from inferior seed-RNG.
    
    Version 1.03 nightly entered beta December 10, 2023.
    - Repositioned two of the three Giant Snakes in Phrygia to reduce the incidence of softlocking scenarios from inferior seed-RNG.
    - Disabled the fireballs of one of the Giant Snakes to avoid compounding an existing graphical gltich from the base game.

    Version 1.02 nightly entered beta December 10, 2023.
    - Redesigned the Harp warp-destinations to reduce the incidence of softlocking scenarios from inferior seed-RNG.
    - Specifically, the warp destinations now form a loop among Phthia, Laconia, and Argolis.  Arcadia and Attica have been removed as destinations.
    
    Version 1.01 nightly entered beta December 10, 2023.
    - Fixed a bug causing the item of one of the NPCs to not be randomized (Phrygian ambrosia NPC).

    Version 1.00 stable created Decemnber 2-8, 2023 and submitted on December 8, 2023 for release.
    - Items given by NPCs are randomized.
    - Items dropped by enemies are not currently randomized.  A partial implementation has been made and is being researched further.
    - Items dropped by scenery are not currently randomized.  A partial implementation has been made and is being researched further.
    - The ability to manually enter a desired seed has replaced the ability to continue based on entering Words of God.
    - When entering a manual seed, default names will be given to the hero and heroine, respectively.
    
    - Cutscenes related to fragments of love have been disabled altogether.  The reason is due to minor glitches in and after the cutscene if the cutscene is triggered in a location the game doesn't expect.
    - The fire ability taught by Prometheus is not a physical item per se, so it has not been randomized.
    - The checks involving the fragments of love and the key were generally left intact out of deference to the progression tied to the lore.
    - One exception to this is that the check for the third fragemnt of love has been updated to look for its randomized counterpart.  This was to prevent Minotaur unexpectedly respawning, given that Minotaur was not given its own defeated bitflag for some reason, unlike other bosses in the game.
    - Another exception is Keleos, who is currently looking for the first Nymph's randomized item.  This may be addressed in a future patch.


  | License
  +--------------------------------------
    MIT License


  | Creator
  +--------------------------------------
    clymax
    https://twitter.com/clymax