Batsu & Terry - Makyou no Tetsujin Race (NES)
Traducción al Español v1.0 (05/03/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de Zynk Oxhyde.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batsu & Terry - Makyou no Tetsujin Race (Japan).nes
MD5: e427e36f287874df10150862cdca3e1b
SHA1: f6177c581ed0b1d4625ec478caec3aa5939dc229
CRC32: ca80fa58
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --