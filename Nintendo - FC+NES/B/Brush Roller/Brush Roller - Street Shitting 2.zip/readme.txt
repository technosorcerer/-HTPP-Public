Street shitting 2!

original game: Brush Roller

Pajeet returns for another round of hot, steaming, street coating action. 
Avoid the TP and stop the street sweepers in this fast paced turd flinger!

www.baddesthacks.net