Battle Chess (NES)
Traducci�n al Espa�ol v1.0 (19/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Chess (U) [!].nes
MD5: ee1f928bce67f09bdf17e580c0b31d7e
SHA1: 795bb3e9d5f11fedefcd053999843957856893bd
CRC32: 7dc49898
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --