
BUCKY O'HARE - Svensk �vers�ttning / Version 3.0 (inofficiell) / Uppdaterad av Carl Lord (A.K.A Lordofpixels03), orginal �vers�ttning av The Translators
______________________________________________________________________________________________________________________________________________________
______________________________________________________________________________________________________________________________________________________

HUR MAN PATCHAR

1. �ppna programmet "Lunar IPS" och tryck p� knappen "Apply IPS Patch".

2. V�lj f�rst IPS filen "Bucky O 'Hare swedish".

3. V�lj sedan en amerikansk omodifierad ROM-fil av Bucky O'Hare, som du vill patcha.

4. Patcha filen och st�ng ner Lunar IPS. Klart!
______________________________________________________________________________________________________________________________________________________
______________________________________________________________________________________________________________________________________________________

NYTT I VERSION 3.0

* Bokst�vera �, � och � har h�jts med en pixel

* Vissa ord som hade ett X ist�llet f�r �, � eller � har nu blivit helt fixade

* �vriga sm� stavfel har blivit fixade

* �ndringar har gjorts med en del ord och meningar, b�de f�r att vissa meningar ska l�ta b�ttre och f�r att det ska l�ta mer lik den engelska texten

* Namnen p� banorna st�r nu helt p� engelska, p.g.a kunde ej klura ut hur man skrev om namnen till svenska helt och h�llet

* P� GAME OVER sk�rmen har ordet "END" bytts utt till "AV" (menat som "avsluta" eller "st�nga av")

* Dead-Eye, Willy, "Diktatorn" (Air Marshal) och Buckys rymdskepp (The Righteous Indignation), �r nu kallade f�r sina namn som de hade i den svenska
  dubbningen av Bucky O'Hare (Dead-Eye = En�ga, Willy = Ville, Air Marshal = Generalen, och The Righteous Indignation = R�tta V�gen)

* Mottot "Nu tar vi dem!!!" har blivit �ndrat till "Nu kn�pper vi paddor!", som �r direkt taget fr�n den svenska dubbningen av Bucky O'Hare

* Copyright beskrivningarna som man ser n�r st�nger p� spelet st�r nu p� svenska

* Eftertexterna st�r nu p� svenska

* Ordet "slut" p� "the end sk�rmen" har blivit �ndrat s� att bokst�verna �r i samma storlek som de �r i den engelska versionen av spelet
______________________________________________________________________________________________________________________________________________________    
______________________________________________________________________________________________________________________________________________________

Orginellt �versatt av Bj�rn Norrliden 2001
Uppdaterat av Carl Lord 2019    