Bucky O'Hare
Di terjemahkan oleh Ruenis

Semua teks dialog dalam permainan sudah di terjemahkan semua ke dalam Bahasa Indonesia beserta juga pada bagian graphic.

Terapkan patchnya menggunakan ROM Jepang. Alasan saya menggunakan versi Jepang karena terdapat ruang kosong pada ROM, di mana saya dapat menulis dan memindahkan teks terjemahan dengan mudah ke ruang kosong tersebut.


Cara Patch:
Pilih salah satu format patch antara BPS atau IPS ke dalam ROM image versi Jepang untuk menerapkan filenya

Bucky O'Hare (Japan)
File SHA-1: D7F25AA0B5312FB4D157A74EF336894904F9EBE4
File CRC32: 
C7B289A
