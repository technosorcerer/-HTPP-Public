BUCKY O'HARE FINNISH TRANSLATION
Translator: Marko T. Hämäläinen, marko@mthtek.net
----------------
Apply the .ips patch to europe version of Bucky O'Hare.
ROM size is 262160 bytes.

Versiohistoria:
----------------
v1.0 - Kaikki dialogit käännetty, kaikki tiilet käännetty. "game over" ja muiden välitekstien kanssa ongelmia kääntämisessä.
v1.1 - Oikoluettu ja virheet korjattu.

----------------
Bugit/kääntämättä:
-"Game Over"- ruudusta "Game over" sekä "End"
-Kenttien aloitustekstit kääntämättä
-"center of magma tanker" näkyy "center oä magma tanker"