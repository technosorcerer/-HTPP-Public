Binary Land (NES)
Traducción al Español v1.0 (12/12/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Binary Land (J) [!].nes
MD5: 3dea737e2b9c66b18defd67a2f7688d9
SHA1: 645ecdfc0db328622fde51b6f8907970b66a1c43
CRC32: 7e68abab
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --