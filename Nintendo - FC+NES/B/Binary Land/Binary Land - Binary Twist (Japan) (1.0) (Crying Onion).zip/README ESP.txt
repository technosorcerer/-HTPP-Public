

● Puedes encontrar más hacks del mismo autor en este link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

● También puedes encontrarle en Youtube, mostrando sus trabajos (y los de otros) aquí:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

● Y por supuesto, si quieres seguir de cerca proyectos en curso puedes hacerlo a través de su cuenta de Twitter, donde suele compartir
capturas de pantalla, videos, pensamientos, etc:
@CryingOnion3
           
 

                                    ooo
                               ooo$$$$$$$$$$$oo
                            o$$$$$$$$$$$$$$$$$$$ooo                       #############################################
                          o$$$$$$$$$$$$$$$$$"$$$$$$$oo                    #                                           #
                       o$$$$$$$$$$$$$$$$$$$  o $$$$$$$$$$$$$$oooo         #                                           #
                      o$$$$"""$$$$$$$$$$$$$oooo$$$$$$$$$$$$$"""           #       ::::     BINARY TWIST     ::::      #
                    oo$""      "$$$$$$$$$$$$$$$$$$$$$$$$"                 #                                           #
                   o$$          $$$$$$$$$$$$$$$$$$$$$$"                   #       ::::        ver.1.0       ::::      #
                  o$$            $$$$$$$$$$$$$$$$$$$$                     #                                           #
                o$$$$             $$$$$$$$$$$$$$$$$"                      #                                           #
               o$$$$$$oooooooo "                $"                        #############################################
              $$$$$$$$$$$$$$"                                         
             $$$$$$$$$$$$$$
            o$$$$$$$$$$$$$                         o
           o$$$$$$$$$$$$$                           o                     	1) Introducción
          o$$$$$$$$$$$$$$                            "o
         o$$$$$$$$$$$$$$$                             "o                  	2) Lista de cambios
        o$$$$$$$$$$$$$$$$                              $
       o$$$$$$$$$$$$$$$$"                              "                        3) Como aplicar el parche en 4 pasos
       $$$$$$$$$$$$$$$$$                                $
      o$$$$$$$$$$$$$$$$$                                $                 	4) Curiosidades y agrademimientos
      $$$$$$$$$$$$$$$$$                                 $
     $$$$$$$$$$$$$$$$$$                                 "
     $$$$$$$$$$$$$$$$$                                   $
    $$$$$$$$$$$$$$$$$                                    $
    $$$$$$$$$$$$$$$$"                                    $$
   $$$$$$$$$$$$$$$$$                                      $o
   $$$$$$$$$$$$$$$$$                                      $$
  $$$$$$$$$$$$$$$$$$                                       $
  $$$$$$$$$$$$$$$$$$o                                      $$
 $$$$$$$$$$$$$$$$$$$$o                                     $$
 $$$$$$$$$$$$$$$$$$$$$$o                                   "$
 $$$$$$$$$$$$$$$$$$$$$$$$o                                  $
$$$$$$$$$$$$$$$$$$$$$$$$$$$                                 $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$                                $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                               $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$o                              $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$o                             $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                             $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                             $"
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                            $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                            $"
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                            $
 $$$$$$$$$$$$$$$$$$$$$$$$$$$$$                            o$
 $$$$$$$$$$$$$$$$$$$$$$$$$$$$$                            $"
 $$$$$$$$$$$$$$$$$$$$$$$$$$$$"                            $
 $$$$$$$$$$$$$$$$$$$$$$$$$$$"                             $
  $$$$$$$$$$$$$$$$$$$$$$$$$"                             $$
  $$$$$$$$$$$$$$$$$$$$$$$$"                              $$
  $$$$$$$$$$$$$$$$$$$$$$$                                $$
   $$$$$$$$$$$$$$$$$$$$$                                o$$
   $$$$$$$$$$$$$$$$$$$$                                 $$"
   "$$$$$$$$$$$$$$$$$$                                  $$
    $$$$$$$$$$$$$$$$$                                  o$$
    "$$$$$$$$$$$$$$$"                                  $$
     $$$$$$$$$$$$$$$                                   $$
     "$$$$$$$$$$$$$"                                  o$
      $$$$$$$$$$$$"                                   $$
      $$$$$$$$$$$"                                    $$
       $$$$$$$$$"                                    $$"
       $$$$$$$$$                                     $$
       "$$$$$$$"                                    $$
        $$$$$$$o                                    $"
       o$$$$$$$$                                   $$
       $$$$$$$$$                                   $$
      o$$$$$$$$$                                   $"
      $$$$$$$$$$                                  $$
      "$$$$$$$$$                                o$""
       "$$$$$$$$                          ooooo$$oo
          ""$$$$$o                oooo$$$$$$$$$$$$$$ooo
             "$$$$$$ooooooo     """""""""$$$""""$$o   ""
                                                  "    


http://arteascii.yaia.com/animales.html


______________________________________________________________________________________________________________________________________________


1) Introducción


	Antes que nada, gracias por descargar este Hack. Lo cierto es que en esta ocasión hay poco que decir: Se trata de Binary Land... con
	un giro XD.

	Este clásico de Hudson Soft. llegó a ser muy popular en Japón y publicado en multitud de sistemas: Primero en ordenadores de la época
	(NEC PC-8801, FM-7) y luego, en intervalos de un año, en MSX y Famicom (que a día de hoy son las más recordadas). Sus roms han sido
	preservadas, así que es fácil tener la oportunidad de jugarlas vía emulación. Lo curioso (y lo que dio origen a este Hack) es que
	aunque son muy parecidas, presentan una diferencia notable: En la versión para la consola de Nintendo la pareja protagonista está
	formada por pingüinos y en la de MSX... por humanos. Con esto en mente y solo por diversión (el proyecto no tomó más que un par de
	días en ser completado) nace Binary Twist.

2) Lista de cambios


	Binary Twist ver. 1.0

		● Los pingüinos protagonistas han sido reemplazados por una pareja de chiquillos, usando directamente los sprites de MSX como
		  base

		● La pantalla de título ha sido modificada para ajustarse a la temática del Hack

		● Arreglos menores en los items


3) Como aplicar el parche en 4 pasos

	1) Conseguimos (obviamente) el archivo *.IPS, que puedes encontrar en el siguiente enlace:


	2) Conseguimos una rom limpia de Binary Land. Si tenéis dudas sobre qué versión usar (la gran mayoría de juegos tienen varias en
	   función de la región o número de revisiones), en la misma página donde está el enlace de descarga del parche, hay un apartado
	   llamado ROM/ISO Information.

	3) Conseguimos un programa para aplicar el archivo *.IPS. Uno de los más populares es LunarIPS, que podéis encontrar en el
	   siguiente enlace: https://www.romhacking.net/utilities/240/
	
	4) Por último, ejecutamos LunarIPS, seleccionamos primero el archivo *.IPS y luego nos pedirá la rom limpia, que sobreescribirá ¡y
	   voilá, listo para jugar!
	

4) Curiosidades y agradecimientos

	● El tema principal del juego es un vals, concretamente "Je te veux" de Erik Satie.

	● Cuando completamos un nivel, el tema que se oye es un pequeño fragmento del "Himno de la Alegría", de Ludwig Van Bethoven.

	● Las parejas de pingüinos establecen un vínculo muy especial, siendo fieles de por vida hasta el punto frecuentemente, cuando uno
	  de los dos muere, el otro no tarda en hacerlo también de tristeza.

	● No puedo dejar pasar la ocasión de darle mi agradecimiento a mi bro de Argentina @ProtoPixelArt por sus sugerencias y proponer
	  el título de la versión final dem este Hack.