

● You can find many more hacks from the same author at this link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

● You can also find him on Youtube, showing his work (and that of others) here:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

● And of course, if you want to follow closely his current projects, you can do it through their twitter account, where he usually share
screenshots, videos, thougts, etc:
@CryingOnion3
           
 

                                    ooo
                               ooo$$$$$$$$$$$oo
                            o$$$$$$$$$$$$$$$$$$$ooo                       #############################################
                          o$$$$$$$$$$$$$$$$$"$$$$$$$oo                    #                                           #
                       o$$$$$$$$$$$$$$$$$$$  o $$$$$$$$$$$$$$oooo         #                                           #
                      o$$$$"""$$$$$$$$$$$$$oooo$$$$$$$$$$$$$"""           #       ::::     BINARY TWIST     ::::      #
                    oo$""      "$$$$$$$$$$$$$$$$$$$$$$$$"                 #                                           #
                   o$$          $$$$$$$$$$$$$$$$$$$$$$"                   #       ::::        ver.1.0       ::::      #
                  o$$            $$$$$$$$$$$$$$$$$$$$                     #                                           #
                o$$$$             $$$$$$$$$$$$$$$$$"                      #                                           #
               o$$$$$$oooooooo "                $"                        #############################################
              $$$$$$$$$$$$$$"                                         
             $$$$$$$$$$$$$$
            o$$$$$$$$$$$$$                         o
           o$$$$$$$$$$$$$                           o                     	1) Introduction
          o$$$$$$$$$$$$$$                            "o
         o$$$$$$$$$$$$$$$                             "o                  	2) Features list
        o$$$$$$$$$$$$$$$$                              $
       o$$$$$$$$$$$$$$$$"                              "                        3) How to apply the patch in 4 steps
       $$$$$$$$$$$$$$$$$                                $
      o$$$$$$$$$$$$$$$$$                                $                 	4) Some curiosities and acknowledgments
      $$$$$$$$$$$$$$$$$                                 $
     $$$$$$$$$$$$$$$$$$                                 "
     $$$$$$$$$$$$$$$$$                                   $
    $$$$$$$$$$$$$$$$$                                    $
    $$$$$$$$$$$$$$$$"                                    $$
   $$$$$$$$$$$$$$$$$                                      $o
   $$$$$$$$$$$$$$$$$                                      $$
  $$$$$$$$$$$$$$$$$$                                       $
  $$$$$$$$$$$$$$$$$$o                                      $$
 $$$$$$$$$$$$$$$$$$$$o                                     $$
 $$$$$$$$$$$$$$$$$$$$$$o                                   "$
 $$$$$$$$$$$$$$$$$$$$$$$$o                                  $
$$$$$$$$$$$$$$$$$$$$$$$$$$$                                 $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$                                $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                               $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$o                              $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$o                             $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                             $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                             $"
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                            $$
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                            $"
$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$                            $
 $$$$$$$$$$$$$$$$$$$$$$$$$$$$$                            o$
 $$$$$$$$$$$$$$$$$$$$$$$$$$$$$                            $"
 $$$$$$$$$$$$$$$$$$$$$$$$$$$$"                            $
 $$$$$$$$$$$$$$$$$$$$$$$$$$$"                             $
  $$$$$$$$$$$$$$$$$$$$$$$$$"                             $$
  $$$$$$$$$$$$$$$$$$$$$$$$"                              $$
  $$$$$$$$$$$$$$$$$$$$$$$                                $$
   $$$$$$$$$$$$$$$$$$$$$                                o$$
   $$$$$$$$$$$$$$$$$$$$                                 $$"
   "$$$$$$$$$$$$$$$$$$                                  $$
    $$$$$$$$$$$$$$$$$                                  o$$
    "$$$$$$$$$$$$$$$"                                  $$
     $$$$$$$$$$$$$$$                                   $$
     "$$$$$$$$$$$$$"                                  o$
      $$$$$$$$$$$$"                                   $$
      $$$$$$$$$$$"                                    $$
       $$$$$$$$$"                                    $$"
       $$$$$$$$$                                     $$
       "$$$$$$$"                                    $$
        $$$$$$$o                                    $"
       o$$$$$$$$                                   $$
       $$$$$$$$$                                   $$
      o$$$$$$$$$                                   $"
      $$$$$$$$$$                                  $$
      "$$$$$$$$$                                o$""
       "$$$$$$$$                          ooooo$$oo
          ""$$$$$o                oooo$$$$$$$$$$$$$$ooo
             "$$$$$$ooooooo     """""""""$$$""""$$o   ""
                                                  "    


http://arteascii.yaia.com/animales.html


______________________________________________________________________________________________________________________________________________


1) Introduction


	First of all, thanks for downloading this Hack. Actually, there's not much to explain: This is Binary Land.... with a twist XD.

	This classic from Hudson Soft. was very popular in Japan and published on a multitude of systems: First on computers of the time
	(NEC PC-8801, FM-7) and then, in intervals of one year, on MSX and Famicom (which today are the most lovely remembered). Their roms have
	been preserved, so it is easy to have the chance to play them via emulation. The funny part (and what gave origin to this Hack) is that
	although being very similar, they show a notable difference: In the Nintendo's console version, the main character couple are penguins
	and in the MSX one... kids. So, with this in mind and just for fun (the project didn't take more than a couple of days to be finished),
	Binary Twist has born.


2) Features list


	Binary Twist Ver. 1.0

		● The main protagonist penguins have been replaced by a couple of kids, using directly the MSX sprites as a base.

		● The title screen has been modified to fit with the theme of the Hack.

		● Some minor improvements in the items


	Binary Twist ver. 1.1

		● With the idea of pushing the project a step further, notable changes have been made to provide the hack with a unique personality
		  (always inspired by the MSX version).

		● The baby penguin Power-Up is replaced by... a human baby? In this case by Guron (Gurin's little brother).


3) How to apply the patch in 4 steps


	1) Get (obviously) the *.IPS file, that you can find in the following link:

	2) Get a clean rom of Binary Land. If you have any doubts about which version to use (the vast majority of games have
	   several, depending on the region and number of revisions), on the same page where is the link to download the patch,
	   there's a section called ROM/ISO Information.

	3) Get a program to apply the *.IPS file. One of the most popular ones is LunarIPS, which you can find at the following
	   link: https://www.romhacking.net/utilities/240/

	4) Finally, run LunarIPS. First select the *.IPS file and then it will ask for the clean rom. Overwrite it and "et
	   voilà", ready to play!


4) Some curiosities and acknowledgments


	● The main theme of the game is a waltz, namely "Je te veux" by Erik Satie.

	● When we complete a level, the theme heard is a short fragment of the "Ode to Joy", by Ludwig Van Bethoven.

	● Penguin couples establish a very special bond, being faithful for life to the point often, when one
	  of the two dies, the other soon dies of sadness as well.

	● I can't skip the chance to thank my bro from Argentina @ProtoPixelArt for his suggestions and to propose
	  the title of the final version of this Hack.