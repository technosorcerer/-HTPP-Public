Binary Land is an Action game, developed and published by Hudson, which was released in Japan in 1985.

In this hack I have changed the title screen, and also two small penguins are added in game. The language of the game is English.

New in version 1.1 - changed Love Story mode Logo. Press and hold the A & B buttons on both controllers and press Reset. If done right, the game will change to Love Story mode.

New in version 1.2 - changed "BEST 5" screen. BEST 5: 150000 KIKU, 125000 MEGU, 100000 MADO, 085000 MIWA, 050000 UPA.

Binary Land (J) [!].nes - GOODNES 3.14
CRC32: 7E68ABAB
MD5: 3DEA737E2B9C66B18DEFD67A2F7688D9
SHA-1: 645ECDFC0DB328622FDE51B6F8907970B66A1C43
SHA-256: EB43CEB58859A660A45BDDA5357A878174BFB60543F455BB525AE62792D7C885

My NES hacks: http://famicom.byethost7.com