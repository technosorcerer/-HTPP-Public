Battletoads & Double Dragon 4 players - BTDD4p

Mod/hack adds fourth (and third) player to Battletoads & Double Dragon (NES, U-version) to make possible to play the game with four
	people at the same time.

Also:
New moves, character levels system, enemy multiplier, new mechanics, lives share mode.

To play as it intended, use moded emulator (with extended capacity or "blast processing") with 256_spr rom.
https://www.patreon.com/posts/moded-emulator-34560541
https://www.emu-land.net/forum/index.php/topic,77237.0.html


------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Battletoads & Double Dragon_4_players_-_BTDD4p_2.1		(26.10.18)

Notes:
To use new moves hold Hit button and tap (1 or 2 times) direction.
New moves are gained with character levels (CL) according to the table:
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|	Character \ CL	|	0	|	1	|	2	|	3	|	4	|	5	|
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
|	Rash		|	u	|	2u d	|	f	|	2d	|	b	|	2f	|
|	Zitz		|	u	|	2u d	|	f	|	b	|	2f	|	2d	|
|	Pimple		|	u	|	f	|	2u d	|	2f	|	b	|	2d 2b	|
|	Billy		|	u	|	f   b	|	d	|	2d	|	2f 2b	|	2u	|
|	Jimmy		|	u	|	f	|	d	|	2d	|	b  2u	|	2f	|
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Character levels (CL) are gained through use of different moves.
Activation of additional moves activates new enemy mechanics.
Continue of single player with lives share mode restores lives for all players..

Changes:
Lives share mode (for choise).
Addition of new moves (for choise).
Enemy multiplier (for choise).
Character levels system.
New objects limit.
New mechanics.
Other changes.


Battletoads & Double Dragon_4_players_-_BTDD4p_1.3		(13.03.18)

Changes:
Respawn on sub-level.
Continue screen.
Other changes.


Battletoads & Double Dragon_4_players_-_BTDD4p_1.1		(01.03.18)

Notes:
Press Start to see score.

Changes:
Shuttles at the 4th stage collide regardless of friendly fire mode.
Several players at the same time can hang on one lamp (and similar objects).
Other changes.


------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
In demo-versions for 1.0 / 1.1_256_spr - not all levels available.


For version 1.0:
Supported emulators: fceuxdsp 1.07, nestopia 1.40, jnes 1.1.
There are slowdowns. Characters and enemyes can flicker in the reason of sprites limitation.

For version 1.1_256_spr:
Boosted version. Sprite limitation has been reduced.
	(there is need for special boosted emulator).
	(there is configured one in archive in head of BT4p topic: http://www.emu-land.net/forum/index.php/topic,77237.0.html).	
Supported emulators: Mednafen_Doomday's_edition_0.9.45.1.
Goes well. Characters dont flicker.


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Mod creator: NakeuD2007

Special thanks to: Ti_ 
Thanks to: Doomday


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
A few BTDD4p and BT4p-releated videos, including some glitches from development:
www.youtube.com/channel/UCF3WssHzjr8AZ8Dqi-uXTMQ


-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Donate:
PayPal:			paypal.me/nakeud2007
Patreon:			patreon.com/nakeud2007