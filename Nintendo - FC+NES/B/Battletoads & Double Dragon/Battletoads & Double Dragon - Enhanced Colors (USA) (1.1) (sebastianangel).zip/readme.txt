Battletoads & Double Dragon - The Ultimate Team (Improved Colors)

This patch improves many of the color palettes in this game to make it look more similar to the higher quality versions of SNES and SEGA Genesis, removing strong colors from backgrounds and sprites! The toads are blue, in this version 1.1, another patch 1.1B was added, in which the toads are of original color. Stages 3-1,3-2,3-3,4-1,5-1 were corrected , 6-1 and 7-1

In IPS format, you can use LunarIPS or Floating IPS.

File used:

Battletoads and Double Dragon: The Ultimate Team [U] .Nes

The IPS patch must use on a NES ROM