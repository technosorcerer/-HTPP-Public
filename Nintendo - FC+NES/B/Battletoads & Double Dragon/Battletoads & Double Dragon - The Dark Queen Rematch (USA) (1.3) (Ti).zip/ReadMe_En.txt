========================================================================
BattleToads & Double Dragon - the Dark Queen Rematch [v1.3]
========================================================================
Hack adds 'Dragons' Lee into original BattleToads.
Select Jimmy :  Up+Start  (+5 lives).
+10 lives: additionaly hold A+B.
Second player can also play as Billy, but with yellow shorts.
========================================================================
v1.3
+ fixed player2 bug when jump to boss on last platform in intruder excluder.
+ fixed scores on continue screen.
+ added life power-ups for 'Dragons', also added flies in terra tubes and the revolution.
+ fixed life position when you get it from invaders (was incorrect after scores was expanded).
+ intruder excluder easier: removed 2nd slug and pits, balls from wall more slower, lowered platfroms speed at level end.
+ volkmire's inferno easier: fires and rockets reduced speed and frequency.
+ in turbo tunnel Billy trousers no longer rose.
+ in rat race moved warp to other place.
+ fixed player2 legs while stuck in fan.
+ clinger winger - player no longer lose speed when press by diagonal direction + slighlty more easy in 2pl. mode.
+ for subzone karnath lair - 10.000 instead of 5.000.
+ fixed in terra tubes: was possible while on propeller get hit by shark, jump on propeller again, and stuck forever.
+ fixed Billy legs color swaps in clinger winger.
+ fixed in terra tubes was possible to jump for a wall at level start.
+ yet more easier ice caverns, fixed 'hitbox' of yellow platforms.
+ on many levels added 1-up's.
+ improved 'the revolution': added springs for 2nd player (only in 2pl. game), also many platforms and springs
moved, that not to 'kill player by scrolling', in the end no longer cloud in 2pl.game, increased 'hitbox' of sticks placed in walls.
+ in 'the revolution' also fixed bug, when 'Dragons' can beat out enemies through floor.
+ in turbo tunnel, speed of bikes greater than in v1.2 (but slower than original).
+ in terra tubes removed spike after 2nd water gear; reduced shark's lifes.
+ corrected toad's sprite position on jet's.
========================================================================
v1.2
+ fixed lives adding for 100k points.
+ hit with elbow when under water no more pushback up.
+ fixed bug with falling when you hit level4 ice_cube and miss it with special.
+ improved hitting with a stick.
+ corrected sprite of 'Dragons' when it under background (terra tubes).
+ on level4 'Dragons' now moves when sitting same as toads.
+ added warp-point in a Rat Race.
+ rats in TurboTunnel now falls under ground when 'Dragons' kills them.
========================================================================
v1.1 - fixed critical bug with one of checkpoints at last level.
========================================================================
v1.0
Players don't hit in each other in 2p game.

BUG FIXES:
+ clinger winger 2p bug fixed.
+ bug with killing rat on rat race.
+ bug with sitting with holding object on '2d' levels.
+ left+right no more moves players on '2d' levels.
+ "obj count bug"(level4stick e.t.c.)

Levels changed:
1) Harder, more enemies, a little bit harder boss.
2) Unchanged*
3) Slighlty more enemies, speed on bikes reduced.
4) Added additional platforms, for improve 2p game, some locations easier.
5) Water objects damage reduced. Big Blag can't be locked in a corner.
Added boss music theme.
6) Some spikes removed.
7) At start distance between platforms reduced.
Reduced jets speed, fixed sector with rockets - can't more hide
in a lower left corner, but their speed reduced.
8) Some places changed. Boss changed - no more kills with 3 shots,
bullets don't hit when player lies on ground.
9) Robots and ducks no more kills in one hit. Some hardest places changed.
10) Latest Rat not so fast.
11) Electroball speed reduced. When fight with it, can't lock it in a corner.
12) Same as in Japan version (some platforms not disappear).
13) Unchanged.
* Damage from electroshots reduced (all levels).
========================================================================

Credits:
HACKING: Ti
New sprites for 'Dragons': Dabro
Testing: Pro Igrok

========================================================================

Donate paypal:
bonemage2008@gmail.com

========================================================================

SUPPORTED EMULATORS:
FCEUX
Mednafen
Nestopia
RetroArch
puNES

UNSUPPORTED:
VirtuaNES
NNNesterJ
BizHawk
Nintendulator

This depends on how much rom size emulator allows for AxROM (mapper 007).

========================================================================

ROM to patch:
Battletoads (U) [!].nes   (GoodNes 3.14)
Checksums:
MD5:    BBAFEAD19C25B38A5A129BB8C51AAF8D
SHA-1:  5C3A497A82BE60704DEDF45248B6AD9B32C855AB

Checksums after patching:
MD5:    94344917666B3E5F5B77D4B4C1EF98A2
SHA-1:  CBCC4BC8D2AF4F92EF82C393786CCAA045E68730
BattleToads & Double Dragon - the Dark Queen Rematch [v1.3] (Hack).nes