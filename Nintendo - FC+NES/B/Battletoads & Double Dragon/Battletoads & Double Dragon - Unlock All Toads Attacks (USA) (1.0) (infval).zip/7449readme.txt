﻿--------------------------Info---------------------------
Game name: Battletoads & Double Dragon - The Ultimate Team
Console: Nintendo entertainment system
Game region USA: (U)
----------------------------------------------------------
Original game MD5: 35933222cf8658f7c6679fc7de630aaa
----------------------------------------------------------
--------------------------patch------------------------
The patch set following changes:
 
 Unlock all toads attacks:
  Hanging enemy attack.
  Uppercut in air.

 Mega warp zone activation buttons. (On select character screen)
  Up, Down buttons.

----------------------------------------------------------
Authors by: infval, Mr2.
e-mail: rgcorpsoft@gmail.com
http://rgcorp.ucoz.net/