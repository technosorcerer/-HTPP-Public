﻿--------------------------Info---------------------------
Game name: Battletoads & Double Dragon - The Ultimate Team
Console: Nintendo entertainment system
Game region USA: (U)
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
 Windows: https://romhackplaza.org/utilities/solid-patcher-utility/
 Linux: https://romhackplaza.org/utilities/solid-patcher-utility-2/
 https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
The patch allows to set following parametres:
 
 Unlock all toads attacks:
  Hanging enemy attack.
  Uppercut in air.

 Reset score at maximum value.
  *For a million score you get life and continue.

 Mega warp zone activation buttons. (On select character screen)
  Up, Down buttons.

----------------------------------------------------------
Authors by: infval, JAM, Mr2.
e-mail: rgcorpsoft@gmail.com
https://rgcorp.ucoz.net/