Back to the Future (NES)
Traducción al Español v1.0 (22/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Back to the Future (USA).nes
MD5: 59028c487121086ec85664c01f995323
SHA1: e97ae831c57414cf1c6b95ce591e106429a7361c
CRC32: 7c40d6c6
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --