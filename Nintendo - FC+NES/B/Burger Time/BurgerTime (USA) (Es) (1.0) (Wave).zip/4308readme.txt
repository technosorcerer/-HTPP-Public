BurgerTime (NES)
Traducci�n al Espa�ol v1.0 (12/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
BurgerTime (U) [!].nes
MD5: 924f89aad439db0ada794e23075d649f
SHA1: 98d432fb86fc1dac95c80180fc3ae51198569091
CRC32: 516549f9
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --