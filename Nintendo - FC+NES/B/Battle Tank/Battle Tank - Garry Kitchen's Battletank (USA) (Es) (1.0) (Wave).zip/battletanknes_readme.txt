Battle Tank (NES)
Traducci�n al Espa�ol v1.0 (16/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Battle Tank (U) [!].nes
MD5: e9d60e5f653e47976151748cceab5484
SHA1: 54a09fd17e0ec8d52f7ef46cf9a8cd198fd4c32d
CRC32: 49c9ff12
65.552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --