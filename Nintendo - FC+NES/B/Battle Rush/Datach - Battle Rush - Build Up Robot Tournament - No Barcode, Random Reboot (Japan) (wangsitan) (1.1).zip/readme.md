

Datach - Battle Rush - Build Up Robot Tournament

Hack: No Barcode, Random Robot



# About Mapper

Two patches are provided: mapper 16 and mapper 157. Different emulators/devices may have different support for mappers. If one doesn't work well, you can try the other one.



# Description

In "VS COM" mode of the original version, player need to use barcodes to determine COM's robot data.

In this hack, while waiting for the barcode input, player can press the START key to generate random robot data and skip the process of barcode input.

Before pressing the START key, player can press the arrow keys and the A key to affect random data. For example, you can hold down the UP button for 0.5 seconds and then release it, and hold down the A button for 1 second and then release it. How long you hold each key down affects the final result.

The robot's various levels (attack, defense, speed, recovery) range from 0-7. When pressing START, you can control the level range by combining START with different arrow key:
- UP + START: 6-7
- RIGHT + START: 4-5
- LEFT + START: 2-3
- DOWN + START: 0-1
- START: 0-7




# Contact Information

- Email: wangsitan@aliyun.com



# Personal Page

- RomHacking: https://www.romhacking.net/community/2188
- YouTube: https://www.youtube.com/@wangsitan7
- Patreon: https://www.patreon.com/wangsitan



# Donate

If you would like to donate:
- PayPal: https://paypal.me/wangsitan
- Alipay: wangsitan@aliyun.com

Thank you for your support =)

