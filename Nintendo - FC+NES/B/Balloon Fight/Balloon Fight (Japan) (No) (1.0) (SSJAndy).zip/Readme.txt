
----------A SSJAndy translation-------------
I                                          I
I ROM Name   : Balloon fight               I
I                                          I
I System     : NES                         I
I                                          I
I Translator : SSJAndy                     I
I                                          I
I Finished   : 100%                        I
I                                          I
I Language   : Norwegian                   I
I------------------------------------------I
I              Homepage                    I
I                                          I
I www.geocities.com/Andy_V_B/index.html    I
I                                          I
--------------------------------------------