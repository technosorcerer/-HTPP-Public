﻿Balloon Fight – No birds sound

Does one simple thing
Remove the annoying birds flying sounds

Apply IPS Patch to the USA Version


Database match: Balloon Fight (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: F5E4CD9F287A8233EEE35AD1881B2770D9F2C453
File CRC32: CB8FD7B2
ROM SHA-1: 57F86E49372AE44DA79F269973E7DB4F443D0B98
ROM CRC32: 401349A8

Should also work with:

Database match: Balloon Fight (Japan) (En)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: BE2C30D69B1EBA76EAF1CC259DFA41F0F29B0FB2
File CRC32: A0DABE0A
ROM SHA-1: 0F85A4D325B97D7977177B9C7808F0558239766E
ROM CRC32: 2B462010



-LiQuiDz

http://liquidz.speedpost.net/RetroGamingHDnes/
