Super Mario Balloon v1.0
(Balloon Fight hack)
by Magnus Nilsson

How to use
----------
Apply the ips to Balloon Fight (USA).nes

CRC-32: CB8FD7B2
SHA-1: F5E4CD9F287A8233EEE35AD1881B2770D9F2C453
MD-5: 6E125395CA4F18ADDB8CE6C9152DEA85

Changes
-------
Graphics, text, sound and number of lives.

About
------
This hack changes Balloon Fight into a Mario-themed game.
Players are replaced by Mario and Luigi and enemies are
turned into koopa troopas. Almost every palette in the game
have been changed in order to make it a bit more brighter
and "friendlier" compared to the strange space themed
original. A few bonus lives were added to make it feel
a bit more casual in difficulty. 

One of the worst things with the original was the annoying
high pitched noise that the enemies made. This has been
changed to a more neutral and less stressfull sound
for a much improved playing experience.

This hack came to be when trying to get my girlfriend into
retrogame classics, Balloon Fight (of all games, never mind
stuff like Zelda or Metroid...) was the one she liked the best.
Because of this, I dedicate this hack to her.

(C) Magnus Nilsson 2014
