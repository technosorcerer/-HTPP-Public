**** Balloon Fight - 4 players hack ver.1.1 readme ****
A hack of Balloon Fight (Nintendo) for NES. This is designed for 3 or 4 players only. 
Compatible with both NES Four Score and Famicom 4-player adapter.

Features:
 - The graphics was remastered for sprites 8x16 (instead of 8x8 in original game) to increase number of personages on the screen.
 - Every player has his own lives and points.
 - Two new bots were added. They have increased speed and have to be hit 3 times to pop they balloon. The other bots are usual.
 - Every 50000 pts give a life.
 - taking 20 balloons on bonus stage resurrects dead players.
 - The speed of balloons on bonus stage increased twice if more than one players are alive.
 - "Balloon trip" mode is also remastered for 4 players.

Changes in version 1.1.:
 - Fixed some bugs in collision handling and in displaying points after the bonus.
 - In "balloon trip" mode, after a players crashes, the music turns on again.
 - The "game over" screen displays which player scored the most points
 - Added "cheat menu" with following options:
   - The number of lives from 0 to 15
   - On/off extra enemies
   - On/off the armor of extra enemies (3 hits to pop the balloon)
   - Off/on rebound from the top of the screen (to not allow players to sit out on the top of the screen)