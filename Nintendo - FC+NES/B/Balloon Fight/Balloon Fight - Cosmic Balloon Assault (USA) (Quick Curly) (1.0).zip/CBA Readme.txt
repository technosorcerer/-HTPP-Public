Cosmic Balloon Assault
Balloon Fight (NES) Hack
By Quick Curly
August 5, 2015
-------------------------------------------------------------------------------
Patching

 Unlike my previous hacks which were distributed through the IPS patch format,
Cosmic Balloon Assault is distributed in the BPS patch format, due to NROM-128
to NROM-256 conversion/ROM expansion.

 Download the "beat" utility by byuu from Romhacking.net here:

 http://www.romhacking.net/utilities/893


 Apply the included BPS patch to a copy of your Balloon Fight ROM with the
following common name and checksums, found with the HxD hex editor:

Balloon Fight (U) [!].nes

Checksum-16: 0672
Checksum-32: 00230672
Checksum-64: 0000000000230672
CRC-16: 59E6
MD-5: 6E125395CA4F18ADDB8CE6C9152DEA85
SHA-1: F5E4CD9F287A8233EEE35AD1881B2770D9F2C453
SHA-256: 9710F31E7EE204A69AAAAFB6AF340EFEC89657A245C8D402DEE95DAEA4F8A49F


 When you run "beat", select "Apply Patch".
 First, select the "Cosmic Balloon Assault (v1.0).bps" BPS file.
 Next, select your original, unmodified "Balloon Fight (U) [!].nes" ROM file.
You do not even have to make a copy of the ROM file. "beat" will create a
patched NES ROM file for you!
 You just have to choose the name of the ROM file for the hack. For example,
"Cosmic Balloon Assault (v1.0) (Balloon Fight Hack by Quick Curly).nes".


 After using "beat" to apply the BPS patch to a copy of your Balloon Fight ROM,
the newly expanded hack ROM should have the following checksums:

Cosmic Balloon Assault (v1.0) (Balloon Fight Hack by Quick Curly).nes

Checksum-16: 613E
Checksum-32: 0038613E
Checksum-64: 000000000038613E
CRC-16: 3693
MD-5: B27FFCED3BE38879FCC042AC59E48129
SHA-1: 56EBA71964A57EF507076D1DE191FC5ECE27D21B
SHA-256: AAFD198F81C419C00996636FE02C12AC5BC86F193C221538B0D67914ABA6A75A
-------------------------------------------------------------------------------
Hack Modifications

 Here's a general list of everything that has been changed in this hack:

- 12 brand new Phases
- New title screen
- Starting lives are now 6 instead of 2
- Bonus Phases have been modified: balloon rising speeds, points per balloon,
  and super bonus points rewards
- Some surprise graphical appearances from other games (spoilers for games
  included in "Thank You/Credits" section of readme)
- NROM-128 to NROM-256 conversion/ROM expansion
- Intro music plays at the beginning of every Phase instead of the first of
  every 3 Phases
- Phase designs are revisited starting from Phase 1 instead of Phase 4
- Custom palette code: each Phase and Bonus Phase has its own unique palette;
  the original game had different palettes for every 3 Phases between Bonus
  Phases

 My own documentation of Balloon Fight hacking is also being submitted to
Romhacking.net in the Documents section. This covers the level format, and also
includes and defines some RAM and ROM offsets.
-------------------------------------------------------------------------------
Story

 This time, the balloon fighters find themselves having to conquer new worlds
that they never knew existed.

 Grab a buddy and team up to take on all of those enemy ballooners together in
a 2 player game!
-------------------------------------------------------------------------------
Tools

           beat - For patch creation and application.
    FCEUXD 1.0a - Debugging, direct hex editing, and play testing.
            HxD - Checksum algorithms and direct hex editing.
 Nestopia v1.40 - Play testing.
 Tile Layer Pro - Graphics editing.
      WindHex32 - ROM expansion and direct hex editing.
-------------------------------------------------------------------------------
Thank You/Credits

For games and/or ROM hacking programs/utilities/modifications:

    bbitmaster - For FCEUXD 1.0a.
        Bongo` - For WindHex32.
          byuu - For beat v01.
     Ma�l H�rz - For HxD.
  Martin Freij - For Nestopia v1.40.
      Nintendo - For Balloon Fight, Hello Kitty World, and Super Mario Bros. 3.
       SnowBro - For Tile Layer Pro.
Vicious Poetry - For designing Phase 12 of Cosmic Balloon Assault and beta
                 testing.


People, forums/message boards and/or companies:

My family,  Blazzerdragon,  Board 2, cuberootinbinary,  dougeff,  English1stud,
errijnde, Flotonic, Googie,  Grenade Studios, JcDizon, JMFSpike, Mariomaniac10,
MegaEliteGamers,         metalchains48/GoombaParaKoopa,         Moon in Pieces,
Romhacking.net/RHDN,  SchlossRitter,   Static S,   vhernandez2121,  and Vizzed.


Like many people, I listen to a TON of music, especially while working on ROM
hacking projects.
Thank you to all musical artists, bands, and other audio creators, including
(if it seems like this is taking up room to you, just skip it, but I am very
motivated by and appreciative of the music that I listen to, so this list
exists and will continue to grow):

13 Lashes,  Allan Holdsworth,  Altaria,   Arch Enemy,  Area 51,  Bad Acid Trip,
Black Grape,   Bob & Tom,    Buckethead,   Bush,    Candlebox,   Caption Radio,
Capture the Flag,   Chris Buck,   Concept of God,    Darlahood,   Deadeye Dick,
Death From Above 1979,  Dynamite Boy,  Fastball, Fiftywatthead,  Finger Eleven,
Flybanger/Jar, Four Years Gone,  Full on the Mouth, Gracepoint, Grinder, Haken,
Helmet, Horse the Band, I Mother Earth,  Imminent Sonic Destruction, Institute,
Interpol,  Intruder X,  Jamie Warren,   Jody Raffoul,  John 5,  Kicking Harold,
Kopek,  Led Zeppelin,   Less a Day,  Local H,  LoDown,   Lo-Pro,  Lucerin Blue,
Manchester Orchestra,   Marc Rizzo,   Master,   Maximum the Hormone,   Menthol,
Metallica,   Moist,  Mr. Obvious,   Mt. Helium/The Apex Theory,   Next to None,
Nirvana,    Nonpoint,   One Man's Opinion,    Protest the Hero,    Pulse Ultra,
Radio Holiday,  Rammstein,   Red Hot Chili Peppers,  Rush,   Sam Sly,  Seether,
Sethian,   Shaun Ryder,    Shawn Lane,   Silverchair,    Soundgarden,   Sponge,
Stabbing Westward,  Stone Temple Pilots,  Superjoint Ritual,  System of a Down,
Taking Back Sunday, Tetema,  The Butts,  The Culls,  The Dead Kings, The Fluid,
The Marble Index,  Three Days Grace,  Thrice,  Tiles,  Tool,  U.K.,  Van Halen,
Witchcraft, and Within Shadows.
-------------------------------------------------------------------------------
Change Log

 Here is where any notes will  be documented for any potential future updates.

------------
Version 1.00
- Initial public release.
------------

-------------------------------------------------------------------------------
Contacts

------------
Quick Curly:

Board 2
http://acmlm.no-ip.org/board/profile.php?id=1121

Jul
http://jul.rustedlogic.net/profile.php?id=1111

Kafuka
http://board.kafuka.org/profile.php?id=111

Romhacking.net
http://www.romhacking.net/community/1051/
http://www.romhacking.net/forum/index.php?action=profile;
  u=3816

YouTube
http://www.youtube.com/user/Qu1ckCur1y

Email: quickcurly[at]yahoo[dot]ca
------------

------------
Intruder X:

CD Baby
http://www.cdbaby.com/Artist/IntruderX

MySpace
http://www.myspace.com/intruderxmusic

YouTube
http://www.youtube.com/user/intruderxmusic

  GRENADE STUDIOS - Musical instruction/instrument repair/
         recording studio.
  Email: livegrenade[at]sympatico[dot]ca
------------

------------
Moon in Pieces:

DeviantArt
http://mooninpieces.deviantart.com/

Etsy
https://www.etsy.com/shop/mooninpieces

Facebook
https://www.facebook.com/mooninpieces

Instagram
https://instagram.com/mooninpieces/

Spoonflower
http://www.spoonflower.com/profiles/mooninpieces

Storenvy
http://mooninpieces.storenvy.com/

Tumblr
http://mooninpiecesstudio.tumblr.com/

  (Previously:)
  http://moon-in-pieces.tumblr.com/

Twitter
https://twitter.com/mooninpieces

Email: mooninpieces[at]yahoo[dot]com
------------

------------
Within Shadows:

Facebook
https://www.facebook.com/WithinShadowsOfficial

Twitter
https://twitter.com/WShadowsBAND

  (Previously:)
  https://twitter.com/TheCulls_

Email: pickerilas[at]gmail[dot]com
------------