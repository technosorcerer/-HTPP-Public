Board Fight
Balloon Fight (NES) Hack
By Quick Curly & A Bunch of Folks
December 9, 2015
-------------------------------------------------------------------------------
Patching

 Board Fight is distributed in the BPS patch format, due to NROM-128 to
NROM-256 conversion/ROM expansion.

 Download the "beat" utility by byuu from Romhacking.net here:

 http://www.romhacking.net/utilities/893/


 Apply the included BPS patch to a copy of your Balloon Fight ROM with the
following common name and checksums, found with the HxD hex editor:

Balloon Fight (U) [!].nes

Checksum-16: 0672
Checksum-32: 00230672
Checksum-64: 0000000000230672
CRC-16: 59E6
CRC-32: CB8FD7B2
MD-5: 6E125395CA4F18ADDB8CE6C9152DEA85
SHA-1: F5E4CD9F287A8233EEE35AD1881B2770D9F2C453
SHA-256: 9710F31E7EE204A69AAAAFB6AF340EFEC89657A245C8D402DEE95DAEA4F8A49F


 When you run "beat", select "Apply Patch".
 First, select the "Board Fight (v1.0).bps" BPS file.
 Next, select your original, unmodified "Balloon Fight (U) [!].nes" ROM file.
You do not even have to make a copy of the ROM file. "beat" will create a
patched NES ROM file for you!
 You just have to choose the name of the ROM file for the hack. For example,
"Board Fight (v1.0) (Balloon Fight Hack by Quick Curly).nes".


 After using "beat" to apply the BPS patch to a copy of your Balloon Fight ROM,
the newly expanded hack ROM should have the following checksums:

Board Fight (v1.0) (Balloon Fight Hack by Quick Curly).nes

Checksum-16: FEFA
Checksum-32: 003EFEFA
Checksum-64: 00000000003EFEFA
CRC-16: 4693
CRC-32: 842858EE
MD-5: F5620D884A4E84D85AE31AB4C6AB7DB9
SHA-1: 489217554D0B3E2827B22A4E305A38517BA821D8
SHA-256: EB711547E2A3252535A62D9E807A0195C76DD443A596D00F27BC6DB9ED00D4B9
-------------------------------------------------------------------------------
Hack Information & Reflection

 This hack initially came about as an attempted Board 2 collaborative hack.
However, unfortunately, not many people truly contributed to it, with only a
few people taking the time to contribute some drawn level designs, with me
implementing them and managing the majority of the ROM hack coming together.
The whole idea for a Board 2 collaborative hack was not originally my idea in
this specific instance, but I believed that it was a possibility and tried my
best to encourage members to help produce what would hopefully finally be a
Board 2 collaborative production.

 However, considering that I and Mattrizzle were the only people who actually
dealt with the ROM directly in a hex editor, I don't really believe that it was
much of a true "collaborative" effort, and not what I believe was possible from
people who were really enthusiastic about and invested in even the idea of a
collaboration, let alone actually putting forth the time and effort to see it
through. Despite specific details that I won't really go further into here, I
do still believe that a collaborative effort can still work out, against all
logic and evidence that has proven the opposite for all these years. Meanwhile,
if it wasn't for the idea coming about at all, this hack likely wouldn't have
come about. The initial development still took place through Board 2, even
though the majority of the physical time and effort was done away from it, and
not all contributions came directly through Board 2.

 I am greatly appreciative of the efforts made by the people who took their
time to design some levels with the grid template that I provided for the
Balloon Fight format, and would like to thank Mattrizzle for his interest and
efforts in proving and establishing that the "Balloon Fight Level Hacking"
documentation provided effective guidance to be successful for those who are
willing and driven enough to edit games without the need for a game-specific,
visually friendly utility.

 The level designs were submitted through Board 2, emails, and Romhacking.net
in the following order: MegaEliteGamers, Zieldak, Static S, Vicious Poetry,
mrrichard999, and Thermoptic.

 Here are the detailed credits and contributions for this Balloon Fight ROM
hack:

Quick Curly     - Hacking - Main Hacking & Coordination
Mattrizzle      - Hacking - Designed Title Screen & Inserted Phase 04
MegaEliteGamers - Levels  - Designed Phases 02 & 15
mrrichard999    - Levels  - Designed Phase 12
Static S        - Levels  - Designed Phases 05 & 13
Thermoptic      - Levels  - Designed Phases 07 & 14
Vicious Poetry  - Levels  - Designed Phases 06 & 08
Zieldak         - Levels  - Designed Phase 04

 In addition, back when I released my first Balloon Fight level hack, Cosmic
Balloon Assault, I received an email from Thermoptic about the hack, and he
provided a very creative suggestion: To allow the ability to play the hack
without the Bonus Phases interrupting the normal flow of game-play.

 So, that idea has already been applied to the *standard* game-play flow of
this new hack. The normal version of this release contains 16 brand new Phase
designs - more than the count of 12 in the original game - and there are no
Bonus Phases. Now, this presents a unique new challenge. Normally, after the
players complete a Bonus Phase, they begin the next regular Phase with 2
balloons in tact. However, now that there are no longer any Bonus Phase
intermissions, the balloon fighters will face the ultimate survival challenge!
However, to account for this situation, the balloon fighters both start out
with 20 extra lives instead of the usual 2! Still, though, don't lose focus!
Pop the balloons on those enemy fighters before they can get you!

 There is an additional bonus patch included that can be applied to the
unmodified "Balloon Fight (U) [!].nes" ROM to disable the Bonus Phases in the
original Balloon Fight game as well.

 Hopefully, I'll get around to updating the Cosmic Balloon Assault RAR to
feature a patch without the Bonus Phases soon enough. 
-------------------------------------------------------------------------------
Tools

           beat - For patch creation and application.
    FCEUXD 1.0a - Debugging, direct hex editing, and play testing.
            HxD - Checksum algorithms and direct hex editing.
 Nestopia v1.40 - Play testing.
 Tile Layer Pro - Graphics editing.
      WindHex32 - ROM expansion and direct hex editing.
-------------------------------------------------------------------------------
Thank You/Credits

For games and/or ROM hacking programs/utilities/modifications:

     bbitmaster - For FCEUXD 1.0a.
         Bongo` - For WindHex32.
           byuu - For beat v01.
      Ma�l H�rz - For HxD.
   Martin Freij - For Nestopia v1.40.
     Mattrizzle - For designing an early title screen placeholder (and the
                  current design of "Fight") and inserting Phase 04.
MegaEliteGamers - For designing Phases 02 & 15.
   mrrichard999 - For designing Phase 12 and suggesting Blaster Master graphics
                  be used.
       Nintendo - For Balloon Fight and Zelda II: The Adventure of Link.
        SnowBro - For Tile Layer Pro.
       Static S - For designing Phases 05 & 13.
        Sunsoft - For Blaster Master.
     Thermoptic - For designing Phases 07 & 14 and beta testing.
 Vicious Poetry - For designing Phases 06 & 08 and beta testing.
        Zieldak - For designing Phase 04.


People, forums/message boards and/or companies:

My family,  Blazzerdragon,  blackhole89,  Board 2,  cuberootinbinary,  dougeff,
English1stud, errijnde, Flotonic,  Googie,  Grenade Studios, JcDizon, JMFSpike,
Mariomaniac10, MegaEliteGamers,  metalchains48/GoombaParaKoopa, Moon in Pieces,
Romhacking.net/RHDN,  SchlossRitter,   Static S,   vhernandez2121,  and Vizzed.


Like many people, I listen to a TON of music, especially while working on ROM
hacking projects.
Thank you to all musical artists, bands, and other audio creators, including:

13 Engines,    13 Lashes,   Allan Holdsworth,    Anderson Bruford Wakeman Howe,
Arch Enemy, Area 51,  Bad Acid Trip, Black Grape, Bob & Tom,  Buckethead, Bush,
Caption Radio,  Capture the Flag,  Chain Reaction, Chris Buck,  Classroom Zero,
Concept of God,  Darlahood, Deadeye Dick, Death From Above 1979,  Dynamite Boy,
Fastball,   Fiftywatthead,   Finger Eleven,   Flybanger/Jar,   Four Years Gone,
Full on the Mouth,  Funkoars,  Gadfly,   Gracepoint,  Grinder,  Haken,  Helmet,
Horse the Band,    I Mother Earth,    Imminent Sonic Destruction,    Institute,
Interpol,  Intruder X,  Jamie Warren,   Jody Raffoul,  John 5,  Kicking Harold,
Kopek,   Led Zeppelin,   Less a Day,   Lifeline,   Local H,   LoDown,   Lo-Pro,
Lucerin Blue,  Manchester Orchestra,  Marc Rizzo, Master,  Maximum the Hormone,
Menthol,  Metallica,  Mr. Obvious,   Mt. Helium/The Apex Theory,  Next to None,
Nirvana,  Nonpoint,   One Man's Opinion,  Paris Grim,   Paw,  Protest the Hero,
Pulse Ultra, Radio Holiday, Rammstein, Red Hot Chili Peppers, Rumble in Rhodos,
Rush, Sam Sly, Seether, Sethian, Shaun Ryder, Shawn Lane, Silverchair, Similar,
Sonovox,    Soundgarden,   Sponge,   Stabbing Westward,    Stone Temple Pilots,
Superjoint Ritual,  System of a Down,  Taking Back Sunday,  Tetema,  The Butts,
The Culls,   The Dead Kings,  The Fluid,  The Marble Index,   Three Days Grace,
Thrice, Tiles, Tool, U.K., Van Halen, Witchcraft, and Within Shadows.
-------------------------------------------------------------------------------
Change Log

 Here is where any notes will  be documented for any potential future updates.

------------
Version 1.00
- Initial public release.
------------

-------------------------------------------------------------------------------
Contacts

------------
Quick Curly:

Board 2
http://acmlm.no-ip.org/board/profile.php?id=1121

Jul
http://jul.rustedlogic.net/profile.php?id=1111

Kafuka
http://board.kafuka.org/profile.php?id=111

Romhacking.net
http://www.romhacking.net/community/1051/
http://www.romhacking.net/forum/index.php?action=profile;u=3816

YouTube
https://www.youtube.com/user/Qu1ckCur1y

Email: quickcurly[at]yahoo[dot]ca
------------

------------
Intruder X:

CD Baby
http://www.cdbaby.com/Artist/IntruderX

MySpace
http://www.myspace.com/intruderxmusic

YouTube
https://www.youtube.com/user/intruderxmusic

  GRENADE STUDIOS - Musical instruction/instrument repair/recording studio.
  Email: livegrenade[at]sympatico[dot]ca
------------

------------
Mattrizzle:

Board 2
http://acmlm.kafuka.org/board/profile.php?id=407

Email: m.grassman87[at]gmail[dot]com
------------

------------
MegaEliteGamers:

Board 2
http://acmlm.kafuka.org/board/profile.php?id=3482

YouTube
https://www.youtube.com/user/MegaEliteGamers
------------

------------
Moon in Pieces:

DeviantArt
http://mooninpieces.deviantart.com/

Etsy
https://www.etsy.com/shop/mooninpieces

Facebook
https://www.facebook.com/mooninpieces

Instagram
https://instagram.com/mooninpieces/

Spoonflower
http://www.spoonflower.com/profiles/mooninpieces

Storenvy
http://mooninpieces.storenvy.com/

Tumblr
http://mooninpiecesstudio.tumblr.com/

Twitter
https://twitter.com/mooninpieces

Email: mooninpieces[at]yahoo[dot]com
------------

------------
mrrichard999:

Board 2
http://acmlm.kafuka.org/board/profile.php?id=3139

Romhacking.net
http://www.romhacking.net/community/131/
http://www.romhacking.net/forum/index.php?action=profile;u=15175
------------

------------
Thermoptic:

Subretro
https://subretro.wordpress.com/
------------

------------
Within Shadows:

Facebook
https://www.facebook.com/WithinShadowsOfficial

Twitter
https://twitter.com/WShadowsBAND

YouTube
https://www.youtube.com/user/Stat1cS

Email: pickerilas[at]gmail[dot]com
------------

------------
Zieldak:

Board 2
http://acmlm.kafuka.org/board/profile.php?id=2734

Romhacking.net
http://www.romhacking.net/community/1905/
http://www.romhacking.net/forum/index.php?action=profile;u=13074

YouTube
https://www.youtube.com/user/Zieldak

Zieldak's Domain
https://sites.google.com/site/zieldak/

Email: zieldakmail[at]gmail[dot]com
------------