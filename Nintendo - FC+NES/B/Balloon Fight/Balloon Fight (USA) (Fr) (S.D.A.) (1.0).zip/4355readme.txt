BALLOON FIGHT (FR)

Ceci est une traduction fran�aise compl�te de "Balloon Fight" pour la NES au format IPS.
Si vous voyez des bugs, signalez-les sur RomHacking.net.
J'ai traduit presque tout, je pense. Eh bien, amusez-vous quand m�me!

-S.D.A.