The Blues Brothers (NES)
Traducci�n al Espa�ol v1.0 (23/12/2018)
(C) 2018 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Blues Brothers, The (U) [!].nes
MD5: 820642cece4d2fd3d029a38a37ca561a
SHA1: 6e93b3bdbb67b014b68b982a99b597158fca8e4b
CRC32: ac273c14
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --