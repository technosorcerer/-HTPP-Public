Bonk's Adventure (NES)
Traducci�n al Espa�ol v1.1 (20/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado game over

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bonk's Adventure (U) [!].nes
MD5: 377d49dbdeb4046b178fa6bcd707ceb1
SHA1: 776c8db58d968ffacec93006c5471787a716eb2a
CRC32: 6b53d59a
393232 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --