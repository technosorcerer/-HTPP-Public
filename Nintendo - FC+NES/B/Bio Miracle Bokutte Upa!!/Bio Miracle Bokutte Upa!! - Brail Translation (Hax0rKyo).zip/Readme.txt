
=====How to play BIO MIRACLE BOKUTTE UPA BRAIL TRANSLATION======
1) Download this translation patch 
2) Download Bio Miracle Bokutte Upa.nes ROM (use Google)
3) Download Lunar IPS (use Google)
4) Use Lunar IPS to Patch the Translation .ips file to the .nes ROM (It's a shitload easier than it sounds)
5) launch the translation in any NES emulator ( I recommend FCEUX)

I believe the blind have been robbed of thier ability to play video games for too long! Now that I have translated this game into braille, the blind will have no problem at all playing this game. 







====Credits=====
Hax0rKyo - Translator
You - The Player