"Bio Miracle Bokutte Upa"
"Bio Milagro Beb� Upa"
Traducci�n al Espa�ol Ver. 1.0 (27/12/2019)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
Upa es el pr�ncipe de un reino m�gico y el m�s reciente en una l�nea de luchadores valientes. Sin embargo, un d�a, rompi� una urna que contiene el esp�ritu de Zai, un demonio caprino incre�blemente malvado que toma la fuerza vital de los adultos del reino y secuestra a todos los beb�s, excepto a Upa, a quien un hada le da un sonajero m�gico. atrapado en la urna junto con Zai.

Desarrollado: Konami
Publicado:    Konami
Lanzamiento:  26/02/1993 (JAP)
---------------------------------------------------
Acerca del proyecto:
Se tradujo todos los textos.
El parche con el nombre "Bio Milagro Beb� Upa" tambi�n traduce
el tit�lo del men�.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Bio Miracle Bokutte Upa (Japan).nes
File Size     256 KB
File MD5      3DCC2204E2E593CA1DF2008FD7017DFD        
File SHA-1    B5DDC652BEAF37E4B8E7409C774C2A42AE77FDA3
File CRC32    E50AD737