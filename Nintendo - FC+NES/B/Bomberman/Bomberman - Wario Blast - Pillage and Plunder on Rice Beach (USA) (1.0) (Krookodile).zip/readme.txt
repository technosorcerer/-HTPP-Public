==================
    How To Use
==================

This IPS patch is meant to be applied to the Bomberman (USA) rom file.
 
In order to use this patch, you'll need Lunar IPS and a rom of Bomberman (USA). Google is your friend here. Once you obtain both of the aforementioned, you should
be able to open the patch file, and choose a ROM to apply it to. Make sure that you apply it to an unmodified ROM, or else there will be issues. Once you've
done that, you should be able to play the hack in an emulator of your choice. I'd personally recommened FCEUX, but most emulators should get the job done.
I'd recommend avoiding Nestopia though, as it seems to have issues with palettes.

==================
     Credits
==================

All of the people who have made FCEUX what it is today. This wouldn't have been possible without their work.
Snowbro for his Tile Editting utility.
My friend, Brandon, for doing some last minute testing of the hack for me. I appreciate it.
Nintendo and Hudson for the Wario and Bomberman franchises. (You'll be missed, Hudson.)

==================
     Contact
==================

If you have any questions or comments, feel free to PM me at the site, or contact me via my YouTube channel. I check the latter more than the former, though.

YouTube: Krookodile



12/22/2012
