Dungeons of Hyrule (v1.0)

I. Main changes

Graphic Changes -

New Enemy graphics:

Stalfos = formerly Valcom

Gibdo  = formerly O'Neal

LikeLike = formerly Dahl

Ghini = formerly Doria

Rope = formerly Minvo

Keese = formerly Pontan

Darknut = formerly Pass



Altered Power-ups:

Plume of Smoke = formerly the "fire smiley"

Bomb = same with new design

"Magic Book" = allows Link to denotate bomb with 'B' button

"Speedy Boot" = formerly the rollerskates

"Winged Boot" = allows Link to pass through walls

"Speedy Boot over Bomb" = allows Link to pass over bombs

"Magic Shield" = temporary invincibility from bomb blasts


Shorter level playing area:

As with my "Bomberman Rev" hack, I shortened the playing area by one-third. This should make the game a little easier to find the exit in time! :)

II. Completion(?) - 

I consider this game to be *technically* complete. Upon QA testing, I have found a minor color glitch that occurs with some graphics (mainly the power-up icons, the exit, and the floor tile). This hack seems to work well for FCEUX, but the color glitch appears on Nestopia. Also, I originally wanted to switch the music with the theme(s) of LoZ, but I was unable to make it happen. If you're able to change the music of this game successfully, please be my guess in "upgrading" this hack.

III. Note - 

A US version of Bomberman was used in the making of this hack.
