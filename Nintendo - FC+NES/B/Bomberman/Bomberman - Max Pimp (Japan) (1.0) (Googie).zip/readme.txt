Max Pimp - Googie's 5th Bomberman hack

--------------------------------------

Max, Bomberman's rival accidently traveld back in time, and the crew of creatures went back in time to kill him, will the creatures kill Max in the Past? Or will Max kill the creatures in a act of revenge? 

--------------------------------------

Q: Where'd you get the graphics?

A: I got them from Bomberman Quest, and a version of a GBC game with Max as the pimp! :D

--------------------------------------

email me at GoogieToons @ gmail .com if you like the hack, enjoy. ;) 