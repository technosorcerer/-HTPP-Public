M-Tee's Box-Art Bomberman
Released 02-19-2013
www.MTeeGFX.com

The purpose of this modification is to produce a game and manual that would more accurately meet the expectations of a lone spaceman blasting his way through an abysmal future brought upon by the original NES cover art.

Apply the IPS patch to the BOMBERMAN (USA) rom with patching program of your choice. LunarIPS was used to create the patch.

For further information, refer to the included BoxArtBombermanual.pdf file.

To contact M-Tee, use the CONTACT link available through the aforementioned site. 
 