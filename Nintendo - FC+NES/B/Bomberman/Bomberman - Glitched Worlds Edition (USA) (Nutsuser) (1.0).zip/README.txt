* Title: Bomberman � Glitched Worlds Edition
* Version: 1.0
* Author: extr1m (registered on romhacking.net as Nutsuser)
* Game: Bomberman (Japan, NES)
* Release date: 05.04.2025

Description:

* This is a special ROM hack of the Japanese version of Bomberman (NES).
* The main palette of the character has been redesigned, giving Bomberman a fresh and unique look.
* Several bonus item sprites were altered for a more fitting visual style.
* The floor colors in levels were changed to better match the new character palette.
* The key feature of this hack is the Glitched Worlds � unintended �abandoned� stages hidden within the game�s code, now made accessible and playable.
* These mysterious glitch stages add a strange and eerie atmosphere, offering players a completely new challenge beyond the original design.
* A new level select menu was added under �Enter Secret Code,� making it possible to start from any stage.
* Passwords are no longer needed � access to all worlds is available directly through the menu.

* Patch is intended for: Bomberman (J) (NES)