-----------------------------------------------------

		Bomberman co-op [v1.01]

-----------------------------------------------------

changes:
	- fixed some bugs
	- char can steal from another char's life

-----------------------------------------------------

		Bomberman co-op [v1.0]

-----------------------------------------------------

changes:
	- added second player
	- added options menu

-----------------------------------------------------

ROM 100% working at FCEUX v2.2.2 , Nestopia v1.40 and Mednafen v0.9.38.7 http://www.emu-land.net/consoles/dendy/emuls/windows

-----------------------------------------------------

hacking by:
	Corpse Grinder
	Doomday

special thanks to:
	Stremix

-----------------------------------------------------

email: corpse___grinder@mail.ru

-----------------------------------------------------

donate - Z190738311801, R255509614819

-----------------------------------------------------