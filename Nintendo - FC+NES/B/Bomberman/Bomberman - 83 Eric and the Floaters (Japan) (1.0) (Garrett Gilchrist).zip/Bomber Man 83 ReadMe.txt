
Bomber Man 83: Eric and the Floaters

RomHack by Garrett Gilchrist (graphics)

Most people first encountered Hudson Soft's Bomberman in his 1985 NES/Famicom game. But there was an earlier, forgotten version of Bomber Man for home computers in 1983. The MSX and ZX Spectrum versions were localized in Europe as Eric and the Floaters, due to concerns over the title of the game being associated with terrorisn. This was followed by a first-person sequel, 3D Bomberman, in 1984.

These versions looked very different, with 1-bit sprites. Eric is a man in suspenders and a feathered hat. There is only one enemy, a balloon who has several different facial expressions, and will become agitated and unpredictable. Exits can be destroyed, causing four more enemies to appear. The game is endless.

For the NES/Famicom, Bomberman was redesigned to resemble an enemy from Hudson's popular Famicom/NES version of Lode Runner. In NES Bomberman's ending, he transforms into the Mario-inspired Lode Runner character, with a plug for that game.

The NES Bomberman -apparently coded in one 72-hour session- has some gameplay differences from the 1983 Bomber Man, but it's certainly an iteration on the same game.

This ROMhack is a demake, restoring the earlier artwork and characters from the 1983 and 1984 MSX games. The player character is once again Eric, in his suspenders and hat. The different enemies are now all variations on the Floater enemies, with the different faces the Floaters had originally.

The exits and rare collectible treasures are from the MSX games. The font is the 1983 font, and the fancy new title screen is based closely on 1984's 3D Bomberman.

The character graphics are nearly unchanged from MSX, albeit with some tweaks. Walking animations for Eric and the Floaters are three frames here instead of two, so there's some extra animation. Death scenes are one frame shorter. Eric has slightly less colors, and the Floaters have more, with white eye/teeth highlights and a dark outline.

Background tiles and explosions are unchanged, but have different color palettes.

(I'd planned to use more palettes for Eric on the title screen, but the attribute table is drawn with just two short commands around 1EFA-1F07. This is very limiting and I didn't have a solution for it at press time.)

THE GAME:

You play a man who is trapped inside a maze. Place your time bombs wisely to defeat the balloon monsters. If the balloon monsters get caught up in an exploding time bomb, they will pop and disappear. Don't let them get you, and don't blow yourself up. You can break down weaker walls with your time bombs. These walls can hide treasures and exit doors. Pick up treasure to receive bonus points. Defeat all the monsters on the screen and find the exit to proceed to the next stage.

Bomber Man 1983 originally released on:
PC-8801, PC-6001mkII, MZ-700, MZ-2000, Sharp X1, FM-7, MSX, ZX Spectrum

Setting RAM address $94 to a non-zero value before entering a level will cause the game to render hidden tiles (doors and powerups) as red half-destroyed walls until they are revealed. 

RARE BONUS ITEMS:

You have about eight and a half seconds to find and grab an item before it disappears.

3D Bomberman Doll
Points: 10,000
Method: Reveal the exit and walk over it before killing any enemies.
Stages: 6, 8, 14, 16, 22, 24, 30, 32, 38, 40, 46, 48

Money Bag
Points: 20,000
Method: Circle the outer ring of the level after killing every enemy in the stage.
Stages: 1, 7, 9, 15, 17, 23, 25, 31, 33, 39, 41, 47, 49

Treasure Chest
Points: 30,000
Method: Reveal the exit, walk over it, and continue to walk in any direction (do not let go of the D-Pad) for approximately 15 seconds before killing any enemies.
Stages: 4, 12, 20, 28, 36, 44

Mixed Drink
Points: 500,000
Method: Kill every enemy, then create 248 chain reactions with your bombs (one chain reaction = one bomb detonating another).
Stages: 3, 11, 19, 27, 35, 43

Penny-Farthing
Points: 10,000,000
Method: Kill every enemy without destroying a single wall.
Stages: 2, 10, 18, 26, 34, 42, 50

Model T
Points: 20,000,000
Method: Destroy every wall and bomb the exit three times without killing any enemies (including those that come out of the door).
Stages: 5, 13, 21, 29, 37, 45


NMIHPPBPCAFHABDPCPCH - Level 01
HIJDIJFJDLHFLOPDJDJN - Level 02
BAJDINANMJGGCPOOLOLG - Level 03
DJOLBGLGKGJAHIEMNMNN - Level 04
NMKGDDONMHLCGKKGKGKJ - Level 05
ABGKKBPHILHFLOPCPCPC - Level 06
FEBABGLEFLHFLOPCPCPA - Level 07
HIFEMIIABJGGCPOBABAN - Level 08
NMEFPHCMNJGGCPOBABAF - Level 09
JDGKKBPHILHFLOPGKGKL - Level 10
HIPCOHCMNLHFLOPEFEFG - Level 11
ABJDIFJKGGJAHIEPCPCN - Level 12
JDBABANOLJGGCPODJDJF - Level 13
ABNMKNAIHFAJNMMKGKGF - Level 14
ABIHPGLEFCNNJDBEFEFN - Level 15
ABABEMKJDAFHABDCPPCN - Level 16
JDDJOIIOLCNNJDBABOLH - Level 17
JDNMKLGHILHFLOPGKEFH - Level 18
DJABEKMPCFAJNMMOLFEL - Level 19
FEGKKJFNMAFHABDABOLN - Level 20
NMKGDDOIHJGGCPONMIHN - Level 21
NMCPIIIOLFAJNMMGKEFF - Level 22
NMPCOIIOLCNNJDBBAHIJ - Level 23
NMGKKEEHILHFLOPPCGKL - Level 24
HIKGDODCPGJAHIEPCGKJ - Level 25
ABHIMGLBANCLFEINMIHH - Level 26
MNGKKDOOLGJAHIEKGCPC - Level 27
OLDJOIIKGLHFLOPEFLOL - Level 28
IHJDIKMEFNCLFEINMIHF - Level 29
IHDJOIIKGLHFLOPMNJDA - Level 30
DJJDIDOOLFAJNMMEFLOC - Level 31
IHIHPBPCPNCBOLIHIJDH - Level 32
OLFEMANMNFADDJMABFEF - Level 33
MNDJOODJDHLPPCKBAMNA - Level 34
DJABEMKMNNCMIHIMNDJC - Level 35
BADJOIIIHAFDDJDIHOLA - Level 36
DJFEMPBPCGJKEFEEFBAC - Level 37
DJKGDIIIHJGBOLOABFEH - Level 38
DJCPIODFECNOBABABFEN - Level 39
IHEFPPBGKFAIMNMOLKGJ - Level 40
IHLOEHCMNNCMIHIIHOLJ - Level 41
DJEFPHCMNJGBOLOABFEH - Level 42
MNGKKIIOLGJKEFEKGPCJ - Level 43
BAPCOMKDJJGBOLODJIHJ - Level 44
OLNMKDOIHFAIMNMGKLOF - Level 45
OLIHPMKNMFAIMNMABFEH - Level 46
OLABEMKNMCNOBABPCEFL - Level 47
OLOLBFJGKGJKEFEFEPCL - Level 48
OLFEMFJGKLHPPCPLOMNL - Level 49
NMABEKMKGNCLFEIIHFEL - Level 50

BOFEDJJDDJGKEFOLFMIH - Level 74
NMIHPLGKGJDJDJDJDJDH - Begin with maximum Blast Radius / 4,500 points.

