Gangsta Bomberman - Googie's 3rd Bomberman hack
-----------------------------------------------

Q: What's this, bro?

A: It's a graphical upgrade to the original Bomberman, also with a new font, whee! 

Q: Where'd you get the graphics?

A: I got the graphics from the GBC game called Bomberman Quest, I bumped into this game by accident! >:D
-----------------------------------------------

If you like emailin' me, reach me at GoogieToons @ gmail . com

See ya's... ;)
 