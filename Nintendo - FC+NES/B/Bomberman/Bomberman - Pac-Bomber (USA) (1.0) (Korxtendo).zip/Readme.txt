Pac-Bomber by Korxtendo
Version 1.0

Description:
Pac-Bomber is hack of Bomberman for NES,
Sprite Replaces Bomberman and Enemies with Pac-Man and Ghosts.

How to play:
Apply Patch to Bomberman (USA version) not Japanese version Use LunarIPS or IpsXP.  
and play NES your Emulator FCEUX or Nestopia, BizHawk, NES Emulator app for Android, NES Classic/SNES Classic (via hakchi2) etc.
or Real NES Hardware your On Cart like EverDrive N8 or PowerPak etc.

Changelog:
v1.0
- White Bomberman is replaced with Pac-Man.
- All Enemies is replaced with Ghosts.
- New Font from SMB2J: Lost Levels.
- Pac-Man Image from Gameboy version of Pac-Man's Multiplayer in Title Screen. 
- Pac-Man Logo was title PAC-BOMBER from Super Pac-Man Arcade in Title Screen.
- Changed Text START to GAME and CONTINUE to PASSWORD.
- Bonus Icons is replaced with Foods and Galaxian, Key from NES version of Pac-Man in Bonus Item.
- Door is replaced with EXIT.
- Lode Runner is replaced with Dig Dug in Ending (clear the stage 50).

Credit thanks to:
- Tile Layer Pro by Kent Hansen for editing sprite and new font
- FCUEX's Hex Editor for Text and Tile for Title Screen, Palette changed.
- NES version of Pac-Man for Sprite and SMB2J: Lost Levels for Font

Contact Me:
Email: don't have email, just a private.
Twitter: @eorx_roa
RHDN: Korxroa/Korxtendo
Board2: Korxroa

Bomberman � Hudson Soft and Konami
Pac-Man � Bandai Namco
� 2018 Korxtendo