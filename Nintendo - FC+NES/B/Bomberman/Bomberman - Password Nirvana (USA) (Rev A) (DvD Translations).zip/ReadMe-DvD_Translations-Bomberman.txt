-------------------------------------------------------------------------------

ReadMe-DvD_Translations-Bomberman.txt
 
This file should be viewed using a mono-spaced font like "Courier".
Use a font size where 79 columns are visible.

Please don't distribute the ROM file in patched form.
Please don't distribute the DvD_Bomberman_revA.ips file without this file.
Thanks.

-------------------------------------------------------------------------------
                                   BOMBERMAN
		     
                               (Password Nirvana)

                     for the Nintendo Entertainment System
                  Copyright 1985/1987 by Momo and Hudson Soft

                 Enhancement Copyright 2020 by DvD Translations
              Patch Version: Rev A    Release Date: April 26, 2020

                                DvD Translations
                      dvdtranslations.eludevisibility.org

                                      GAME

                           Code Editing: DvD
                       Graphics Editing: DvD
                                Testing: DvD

                                 ReadMe: DvD

----------------------------------- CONTENTS ----------------------------------

INFO 

(1)  Bomberman Game Series
(2)  If You Read Anything, Read This
(3)  The Hidden Power

USING THE PATCH

(4)  Patching the ROM File
(5)  Playing the Game on a Flash Cart or Emulator

ENHANCEMENT DETAILS

(6)  Why DvD Chose to Enhance THIS Game
(7)  Why YOU Should Bother Playing THIS Game
(8)  DvD's Hacking Comments
(9)  Project Timeline
(10) Software Used In This Enhancement

------------------------------------- INFO ------------------------------------

(1)------------------------- Bomberman Game Series ----------------------------

"Bomberman" is the largest game series made by Hudson Soft.

"Bomberman" is the first game in the series, although it is remake of a number
of other similar games Hudson Soft had previously made for other systems.
Hudson Soft released the original "Bomberman" for the NEC PC-8801.  This was
quickly ported to the Spectrum and MSX.

The original Japanese version of "Bomberman" was released for the Famicom on
December 19th, 1985.  "Bomberman" was localized for the USA NES in sometime in
1987.  This and all other "Bomberman" games released for the Famicom/Nintendo
Entertainment System (NES) were by Hudson Soft.  The Japanese version of
"Bomberman" was finally ported to the Famicom Disk System as a Disk Writer
exclusive game on April 2, 1990.

The original Japanese version of "Bomber King" was released for the Famicom in
August 7th, 1987.  "Bomber King" was localized for the North American NES as
"Robo Warrior" in December of 1988.  "Robo Warrior" was ported to the European
NES on September 27th, 1989.

The original Japanese version of "Bomberman II" was released for the Famicom on
the 28th of June, 1991.  This is the first game in the series to allow multiple
players.  This game allowed 3 simultaneous players if the 3rd player used an
external joy-pad.  "Bomberman II" was quickly localized as "Dynablaster" for
the European NES sometime in 1991, which utilized the NES 4-Score for 3 player
simultaneous play.  But, for some reason, Hudson Soft took 2 years to port
"Bomberman II" to the North American NES in February of 1993.  With such a late
release date, the game sold poorly and now "Bomberman II" is one of the most
valuable NES cartridges on the market.

After "Bomberman" was released and up through today Hudson Soft and other
companies have released numerous Bomberman games on every major platform
including the:

* Nintendo Game Boy
* NEC PC Engine / TurboGrafx 16
* Sharp X68000
* Commodore Amiga
* Atari ST
* Super Nintendo Entertainment System
* Sega Genesis
* Nintendo Virtual Boy
* Sega Saturn
* PC
* Nintendo 64
* Nintendo Game Boy Color
* Sony PlayStation
* Game Boy Advance
* Sony PlayStation 2
* Nintendo GameCube
* Sony PSP
* Nintendo DS
* Microsoft Xbox 360
* Nintendo Wii
* Sony PlayStation 3
* Nintendo Switch
* Sony PlayStation 4

and various mobile phones and arcade cabinets

(2)-------------------- If You Read Anything, Read This -----------------------

DvD Translations enhanced version of "Bomberman" features:

* Continuing the game without having to re-type the horribly long password each
  time!!
  (Simply press the Select button on the Continue/Password Entry screen)

* The ability to retype any character of the password if a mistake is made!
  (Simply press Left.  Choosing a password character is now done by pressing
   Up and Down instead of any pressing any direction.)
  
* The ability to correct your password if it is not valid without starting over
  again!
  (Instead of being erased it's highlighted in red and any character can be
   moved to by pressing the A Button or Left.)
   
* To make the high score useful, and to make getting a high score an actual
  challenge whenever continuing, your score always starts at zero when you
  continue.
  
* Additionally, the password now stores your high score instead of your score
  so that your high score is saved when the NES is turned off!

* All passwords are fully compatible with the unmodified NES and Famicom game.

* Restored Famicom title screen

* Demo screen fully functional while still allowing the player to continue

Don't buy repro carts!  They are expensive.  They don't support bug fixes for
patches because they can't be modified in the future.  If they aren't built
from scratch they destroy a real cart.  Every time a donor cart is used to make
a repro, it raises the scarcity and price of that real cart.  If you still want
to spend your money on a multiple repro carts, instead of buying a single flash
cart, buy them from a vendor who only makes carts from scratch with new boards,
chips, and housings.

(3)------------------------ Bomberman's Hidden Power --------------------------

The game has 9 power-ups, but only 8 can actually be obtained in the game:

+----- Obtainable
| +--- Saved 
| | +- Bomberman keeps Power-up when he Dies
| | |
X X X 1) Bomb Quantity             1 to 10
X X X 2) Explosion Size            1 to  5
X X X 3) Bomberman Moves Fast
X X   4) Bomberman can Walk through Bricks
X X   5) Bomberman can detonate Bombs via Remote Control by pressing B
X     6) Bomberman can Walk through Bombs
X X   7) Bomberman is Immune to Explosions
X     8) Bomberman is Temporarily Invincible to both Enemies and Explosions
  X X 9) Bomberman has X-Ray Vision

As you can see, "Bomberman" passwords actually save a power-up that you can
never find in the game.  This power-up acts like X-Ray vision telling the
player exactly where the power up and the exit for the stage is.  Obviously,
playing with this power-up makes the game so easy that it isn't really fun to
play.  Since the indicators for the door and power-up are simply partially
exploded walls, and not unique graphics, this power-up was never completed.
There's a good chance that this was only made for the game test team to test
the game more efficiently.

Password for starting the game from the beginning with X-Ray Vision Turned On:

                            BAHIM NJDJN MNMNM NJDJF

Each stage has a specific power up.  It's a good idea to get a password on each
of the stages with the best power ups that disappear when Bomberman dies as
indicated below with asterisks.

                          +------ Stage        +------ Stage
                          |    +- Power-Up     |    +- Power-Up
                          |    |               |    |
                          1    2              26    8
                          2    1              27    2
                          3    5*             28    1
                          4    3              29    5***
                          5    1              30    7**
                          6    1              31    4
                          7    2              32    1
                          8    5*             33    5
                          9    6              34    8
                         10    4*             35    6
                         11    1              36    7***
                         12    1              37    5
                         13    5*             38    2
                         14    6              39    4
                         15    2              40    8
                         16    4*             41    5
                         17    1              42    4
                         18    6              43    6
                         19    1              44    5
                         20    5*             45    8
                         21    6              46    4
                         22    5              47    6
                         23    1              48    5
                         24    5*             49    7
                         25    6              50    8

------------------------------- USING THE PATCH -------------------------------

(4)------------------------- Patching the ROM File ----------------------------

How to patch the ROM file:

You need:

1) A NES file.  The file needs to include the standard 16 byte iNES header
   followed by the program disk image data.  With header, the ROM file is
   24,592 bytes in size.

   The header should be as follows:

       4E 45 53 1A  08 00 21 00  00 00 00 00  00 00 00 00

   You must have a 16 byte header for this patch, but even if your header
   is wrong, this patch will fix it because it replaces the whole thing.  So,
   if you have a file without a header, you can just insert 16 of any byte at
   the start of the file.
   
   I'm not telling you how to get the NES file, but once you do, call it
   "Bomberman+.nes".
   
   ROM CRC32:  0xdb9dcf89

3) Patch File: DvD_Bomberman_revA.ips

4) An IPS patching program
   Remember to patch the file only AFTER it has a header.

   Recommended IPS patching program for IBM PC:  Lunar IPS.exe by FuSoYa
   Recommended IPS patching program for Mac:     UIPS          by Lucas Newman
   
   Using Lunar IPS / UIPS:

   a) Double-click "Lunar IPS" / "UIPS"
   b) Click  "Apply IPS Patch" / "Apply Patch"
   c) Choose "DvD_Bomberman_revA.ips"
   e) Choose "Bomberman+.nes"

(5)------------- Playing the Game on a Flash Cart or Emulator ----------------

All emulators and flash carts that can play the original Famicom file can play
the enhanced game.  

The PowerPak flash cart emulates it perfectly.

Games designed for the original Famicom/NES hardware have one or two 16k
program banks and one 8k character bank.  Later, all games made for the NES
used special mapper chips to expand the size of the addressable ROM beyond
these limitations.  Some even included RAM for the character bank, instead of
ROM.  This game is one of the smallest NES games ever made.  The last 4k of
the single PROM bank is filled with unidentified unused data.

Game file size: 1 x 16 kBytes of Program   ROM
                1 x  8 kBytes of Character ROM
                    24 kBytes
              = 24,576  Bytes
              +      4  Byte Header
              = 24,592  Bytes
		  
This game uses mapper 0, since it has no special mapper chip.  It uses vertical
mirroring because the scrolling playfield scrolls 2 screens horizontally.

----------------------------- ENHANCEMENT DETAILS -----------------------------

(6)------------------- Why DvD Chose to Enhance THIS Game ---------------------

I've owned this game for over 30 years, but I never passed it.  Why?  Because
the password was ridiculously difficult to work with.  What's wrong with it?

1) You have to type it in from scratch EVERY time you have to Continue after
   dying.  WHY?!  THE HUMANITY!  This also means that you have to write down
   the giant password every time you pass a stage!  
   
2) It's 20 characters long selected from a list of 16 characters.  Why does it
   need to be this long to save the following?:
   - Stage
   - Bomb strength
   - Bomb quantity
   - Whether Bomberman is fast or not
   It could have easily been done with a 4 character + 3 character checksum
   password.  It's like the game has a 4 character password and 16 character
   checksum.  It's insane.  To be fair it also uses 7 characters to save the
   score.  But who has ever heard of a password that saves your score?  In
   reality the game is also saving power-ups that are also zeroed out each time
   you die so it seems like it doesn't save them, although it doesn't save all
   of them.  Why?  I have no idea.  The password is actually 16 scrambled data
   characters plus a 4 character checksum.  It's actually a pretty tough
   password to crack, although it had been mostly done before I worked on this.

3) If you make ONE mistake, you have to start over, and this can only easily be
   done by pressing Reset.  There is no way to go back and edit what you've
   typed.

4) If you make typo while typing the password, it instantly erases the entire
   thing and makes you start over.  What fun.

5) Even the direction you push the controller to select the next or previous
   character seems to have been designed to drive you crazy.  Pressing right
   advances the character forward and left in reverse.  But, for no logical
   reason both pushing up and down also advances the character in reverse.

So, to summarize, the original experience continuing when you die is a complete
pain in the ass.

(7)---------------- Why YOU Should Bother Playing THIS Game -------------------

Once all of the flaws with the password are fixed, Bomberman is actually a lot
of fun to play.  Go read section 2.

(8)------------------------- DvD's Hacking Comments ---------------------------

Each of the saved parameters (listed in section 3) takes up one character in
the password and the stage takes up two characters.
	   
I purposely DID NOT WANT TO CHANGE ANY OF THIS.  I wanted the game experience
to be the same.  I just wanted to be able to have a pleasurable experience
continuing and saving.

The first thing I did was make it so hitting Start on the Continue screen would
continue the game without having to type the password.  But, since you have to
press Start to go to this screen, it's too easy to double hit the button.  So,
I changed it to Select.

I then made it so pressing left allowed you to highlight a previous character
for editing.  This is much harder than it looks since as soon as the letters
are typed in, they are scrambled based on a look up table.  Fortunately, there
is a reverse look up table used when generating the password that I was able
to utilize.

The next thing that I got working was allowing you to retype the entire
password if it was wrong.  I first was going to have it play a sound when the
password was wrong.  I did this, but it sounded boring.  So, I decided red text
would look good.  I ended up changing the text highlight color instead of
foreground color to red and I decided it looked great, so I left it.

I really didn't like that the score was not set to zero every time I continued.
I mean, what's the point of a finite number of lives, if continues also keep
your score?  But, I didn't want to force this on everyone.  So, I made it so
that holding the B button while pressing Select would erase your score, but
otherwise it would not.

I chose to bring back the original Japanese title screen mainly because most of
it was already there.  They just simply made the tiles blank.  But, I also
think the Japanese title screen is just looks much more impressive with the
letter shadows in black.  I did have to make the top and bottom rows which I
did through an crazy amount of trickery to find the bytes I needed to do this.

By the way, since I can't identify any of the data from the last 4 MBits,
F000 through FFF8, I made a rule that I would not modify it.  If anyone out
there can prove what it is used for, I'd really like to know.  FCEUX for some
reason marks it a PCM audio.  I saw no code to play this area as audio, but
just for kicks I found a way to play this entire area as though it were audio
and it just doesn't sound interesting enough to be this.

This was my Alpha 2 version.

The problem with this version is that I forgot about the Demo mode.  When I
took a break from playing the game the demo started.  When I tried to start
up the game again a number of my power-ups had changed.  I could no longer
continue correctly by pressing Select.  So, now I had to figure out what to do
since I didn't have a lot of bytes left.  I decided to disable the Demo mode
after you played one level.

I fixed this for my Alpha 4 version.

But, later I figured out that I had written over bytes F000 to F004.  This
really bugged me; I had to fix it.

I knew there was no way for me to find any more free bytes and it seemed a
shame that the Hi-Score score couldn't be saved even though there was a giant
password that could easily save it.  The original password also saves 7 bytes
for the current score, up to 999,999,900, but I preferred zeroing out my score
anyway.  The last two digit are not saved since they are always zero anyway. 
So, I decided the best thing to do to save memory was to remove the ability to
toggle whether the Score was zeroed or not, which now freed up the password to
save the Hi-Score.  I changed the password to simply save the same 7 digits of
the Hi-Score.  The passwords are fully interchangeable, it's just that the
passwords from the original game simply set the high score to achieved score,
which was probably same anyway when the password was made since the score never
was zeroed out.

This became my Alpha 5 version, which became the final version.

(9)----------------------- Project Timeline Highlights ------------------------

Mar  1 2020 - Project started
            - Disassembly begins

Mar 24 2020 - Continue via Select functioning
            - Press Left to move cursor

Mar 26 2020 - ReEnter password working

Mar 27 2020 - 2nd Alpha Version testing started

Mar 28 2020 - last 4k of ROM tested as PCM audio
            - 4th Alpha Version testing started

Mar 31 2020 - 5th Alpha -> Final version testing started

Apr  4 2020 - Final version testing completed

Apr 26 2020 - FDS enhancement released along with Demonic Castle Dracula and
              Nekketsu Fighting Lengend

(10)------------- Software & Hardware Used In This Enhancement ----------------

* Emulator

  FCEUX 2.2.2	(FCEUX 2.2.3 has too many problems)
   by zeromus, adelikat

* Disassembler, Table Dumper

  Table Dumper Pro (version 18.03.25)
   by DvD

* Hex Editors

  Beyond Compare 4.3.4
   by Scooter Software

* Tile Editors
  
  Tile Layer Pro 1.0
   by Kent Hansen
  
* Disassembled code manipulation, script editing, & ReadMe creation

  Notepad++
   by Don Ho and the rest of the Notepad++ team

* IPS Patch File Creator

   Lunar IPS
    by FuSoYa

* Testing on a real NES

   PowerPak
    by retroUSB

-------------------------------------------------------------------------------
987654321098765432109876543210987654321 123456789012345678901234567890123456789