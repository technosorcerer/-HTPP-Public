Bomberman: 35th Anniversary Edition information guide

This is a ROM hack of the original Bomberman for the NES that makes several improvements to the game, and as its name would suggest, was made as a 
(slightly late) celebration of the 35th anniversary of the game being released in the US. More information below, as well as a guide on how to play it.

How to Play:
To play this hack, you'll need an NES emulator, such as FCEUX or Nestopia, as well as a ROM patcher, such as Flips.
If you have an emulator and a ROM patcher (and know how to use them), you're good to go!

Differences:
Bomberman's sprites have been completely redone
Enemy sprites have been altered drastically
The explosion sound has been fixed
Miscellaneous graphical improvements
Minor grammar fixes

Version 1.1
Changelog:
Added updated enemy sprites
Tweked Bomberman's sprites slightly

Notes:
This hack comes with a secondary patch that replaces Bomberman and the enemies' revamped sprites with updated versions of their original sprites. 
Make sure to apply this patch on top of the main patch.

Total development time: about 5 hours

Bomberman is a former property of Hudson Soft and is currently a property of Konami. This hack and its creator are not affiliated with them in any way.
Please don't steal this hack and claim it to be your own.