Link in The Bomb Factory - Googie's 4th Bomberman hack
------------------------------------------------------

Remember my Binary Land hack called Link's Desert Escape? Well, link and Marin finally escaped the desert, only to be beamed up by a UFO! O'NOES! The aliens wanna probe Marin, so it's Link's job to kill all the aliens and save her, awwww shi... >:D

------------------------------------------------------

email me at GoogieToons @ gmail .com for any feedback, enjoy. :D

- Googie

Special tanks to NESDraug, he helped me clean up the title screen in a few places, what a guy, he's the man!  