Bionic Commando (NES)
Traducción al Español v1.0 (21/08/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Bionic Commando (USA).nes
MD5: 61179c6adf36a6c056ab384b03c53404
SHA1: 8f2f7d70ab38fa203651972c7bd4a0cca3638162
CRC32: 83be000c
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --