"Bionic Commando: Hal Hack 1"
by Hal

..WHAT IS IT?..
This is a hack that changes some graphics in the NES game Bionic Commando.

Date created: March 31, 2002

Info: Easter 2002, my first day ever trying my hand at hacking. This is the 
result. I was just messing around so it's real lame and sloppy. Some trucks 
on the map slide off the screen (sometimes your helicopter too!) (thanks to 
The Almighty Guru for this trick). Apart from that, some of the graphics 
are screwed with. 

Storyline: (note: the text hasn't been changed.. this storyline is just for 
fun.. use your imagination.) After blowing up the Nazi base and just barely 
escaping, there was much rejoicing on the good guys' side. Unfortunately, 
the blast from the explosion hideously disfigured many soldiers. Even our 
hero, Rad, was horribly burned on his face. Now more bad news, as the Nazis 
have regrouped and are trying the whole project over again! Plus, military 
spending cutbacks are hurting our heroes. For instance, instead of high-tech 
communicators, they have to use old telephones! Instead of top-of-the-line 
flares, they have to use a candle! But one good thing they have is their 
new Helijet, a helicopter that has the ability to turn itself into a jet! 
Not all of the bugs have been worked out yet, however. Also, some of the 
Nazi truck drivers have become alcoholics, so their driving is often erratic.
If you are up to the horrors that await you, play the game!

For more information visit: http://members.cox.net/defgav/hacks.html

(The latest version of the hack can probably be found there as well.. not 
that I'm planning on messing with it any more, but you never know. This 
here version is.. uh, I guess version 1.0)


..HOW TO GET STARTED..
This is NOT a ROM, it's an IPS file; a patch for a ROM. You must already 
have a Bionic Commando ROM. (Please don't ask me for help getting one.. 
you'll need to locate it yourself, sorry.)

To apply the patch, go to any website with ROM hacking utilities 
(www.zophar.net , www.romhacking.org , www.cg-games.net , etc.) 
and grab an IPS patcher. The favorite seems to be SNESTOOL for DOS, 
but there's stuff like WinIPS as well. Just follow the directions 
that come with the program. For SNESTOOL, select "use IPS", navigate 
the directories with the arrow keys, select the patch, then select the 
ROM. Couldn't be simpler. It's easiest to first put the IPS file and 
the original ROM in the SNESTOOL directory. And you may want to back up 
your ROM first.. in case you ever want to play the original again.

If you still need more information, visit: 
http://www.zophar.net/trans/ipsfaq.html


Thanks and enjoy,
-- defgav
[somedont@excite.com]

                       1/16/03
