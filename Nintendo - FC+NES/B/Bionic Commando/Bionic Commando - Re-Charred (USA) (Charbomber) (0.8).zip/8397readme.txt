================================================================
  ____  _____       ____ _   _    _    ____  ____  _____ ____  
 |  _ \| ____|     / ___| | | |  / \  |  _ \|  _ \| ____|  _ \ 
 | |_) |  _| _____| |   | |_| | / _ \ | |_) | |_) |  _| | | | |
 |  _ <| |__|_____| |___|  _  |/ ___ \|  _ <|  _ <| |___| |_| |
 |_| \_\_____|     \____|_| |_/_/   \_\_| \_\_| \_\_____|____/ 
                                                               
================================================================

Thank you for downloading this rom-hack!

This romhack (Bionic Commando Re-Charred) is a romhack made by me (Charbomber) in attempt to
make the game more difficult and change the palettes a bit to make it more interesting.

This romhack was not in-fact made with the general populace in-mind, but to placate me and only me
as this romhack was just designed as a harder version of the original game, as I had gotten bored
of the original game's difficulty.

Do not fret, though, you start with many more lives than normal, so you can theoretically just go at it
until you beat it and you won't see the Game Over screen.

This romhack is incredibly buggy and weird and glitchy and that is fine becase as I said earlier this was
just to make the game harder for me and also because it was fun to make. If you find yourself
softlocked or there's graphical errors then sorry but them's the breaks.

If you wish to contact me for some reason after playing this hack (perhaps if you want to yell at me
or tell me to remove this romhack from the website), you can find me at charbomber12@gmail.com.

Happy grappling!