===BIONIC COMMANDO ITA===
Traduzione amatoriale di GiAnMMV.

==Informazioni sulla ROM.
Database match: Bionic Commando (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)
File SHA-1: 8F2F7D70AB38FA203651972C7BD4A0CCA3638162
File CRC32: 83BE000C
ROM SHA-1: C82E29639E2DFFA2754149025C6784EB2587B09D
ROM CRC32: D2574720

==Cronologia delle versioni.
v1.0 - 19 feb 2024: Launch.

==Strumenti usati.
- "YY-CHR" by YY
- "Mesen"
- "WindHex32" by Bongo`
- "Bionic Commando Text Editor" by GiAnMMV (me!)

==Collegamenti usati.
- http://www.thealmightyguru.com/Reviews/BionicCommando/Index2.html
- https://tcrf.net/Bionic_Commando_(NES)

Nel caso riscontraste un qualunque errore, non esitate a contattarmi!