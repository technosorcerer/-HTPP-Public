"Bionic Hippy Commando"
by Hal

WHAT IS IT?
A hack that changes some graphics in the NES game Bionic Commando.

Date created: April 2002

Info: My second hack attempt, Bionic Hippy Commando is still very sloppy. 
Lots of graphic changes. Lowercased the text.

Storyline: (note: the text hasn't been changed.. this storyline is just for 
fun.. use your imagination.) The year is 2001. Much time has past since the 
first adventure. Rad has left the battlefield and become a commanding 
general. There is now a new Bionic Commando, he is Starbeam Moonchild: the 
Bionic Hippy Commando. His groovy ways may not jive with his fellow 
soldiers, but damn it-- he gets results! He's got a turbo charged gun 
[thanks to state-of-the-art TAG engineering], and a hi-tech new bionic arm. 
He's gonna have his work cut out for him, however, because the Nazis are 
attempting another comeback. Things are a little different this time around. 
And something's very wrong with Super Joe. Can he be trusted?? No time to 
worry about that now, the free world needs saving!

For more information visit: http://members.cox.net/defgav/hacks.html

(The latest version of the hack can probably be found there as well.. not 
that I'm planning on messing with it any more, but you never know. This 
here version is.. uh, I guess version 1.0)


..HOW TO GET STARTED..
This is NOT a ROM, it's an IPS file; a patch for a ROM. You must already 
have a Bionic Commando ROM. (Please don't ask me for help getting one.. 
you'll need to locate it yourself, sorry.)

To apply the patch, go to any website with ROM hacking utilities 
(www.zophar.net , www.romhacking.org , www.cg-games.net , etc.) 
and grab an IPS patcher. The favorite seems to be SNESTOOL for DOS, 
but there's stuff like WinIPS as well. Just follow the directions 
that come with the program. For SNESTOOL, select "use IPS", navigate 
the directories with the arrow keys, select the patch, then select the 
ROM. Couldn't be simpler. It's easiest to first put the IPS file and 
the original ROM in the SNESTOOL directory. And you may want to back up 
your ROM first.. in case you ever want to play the original again.

If you still need more information, visit: 
http://www.zophar.net/trans/ipsfaq.html


Thanks and enjoy,
-- defgav
[somedont@excite.com]

                       1/16/03
