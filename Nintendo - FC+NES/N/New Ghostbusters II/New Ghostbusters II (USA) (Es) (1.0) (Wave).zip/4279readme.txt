New Ghostbusters II (NES)
Traducci�n al Espa�ol v1.0 (24/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
New Ghostbusters II (E) [!].nes
MD5: 8009cdf7ef0e79251388c1ddcb2dd506
SHA1: 1e1cca1663aca0dd0d3372e842eaac8fcd245802
CRC32: 9d72b9d1
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --