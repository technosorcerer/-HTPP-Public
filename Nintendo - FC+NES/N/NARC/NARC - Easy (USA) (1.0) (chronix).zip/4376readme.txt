NARC Easy (NES)

Hacked by Andrei Vdovin a.k.a. Chronix
chronix@bk.ru

* Start with 6 lives.

Original ROM:
-----------------------
NARC (U) [!].nes
File size: 131 088

 PRG ROM:    8 x 16KiB
 CHR ROM:    0 x  8KiB
 ROM CRC32:  0x0537322a
 ROM MD5:  0x8fe1db994026ede8c0993b6f4b9af408
 Mapper #:  7
 Mapper name: ANROM
 Mirroring: Horizontal
 Battery-backed: No
 Trained: No