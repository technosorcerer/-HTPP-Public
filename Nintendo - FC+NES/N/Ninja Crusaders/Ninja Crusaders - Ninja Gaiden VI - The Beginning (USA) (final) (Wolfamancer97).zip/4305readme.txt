Edited some graphics, text,text font and a lot of colors. Hope you like it. \m/
-wolfamancer97(MVH).