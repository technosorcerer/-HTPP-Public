Noah's Ark (NES)
Traducción al Español v1.0 (17/06/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Noah's Ark (Europe).nes
MD5: 8e50d7bf115e0339e539579a07a03966
SHA1: 8caa31edf6b2998d93803c5fa0e964502477d3b3
CRC32: ab21ab5f
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --