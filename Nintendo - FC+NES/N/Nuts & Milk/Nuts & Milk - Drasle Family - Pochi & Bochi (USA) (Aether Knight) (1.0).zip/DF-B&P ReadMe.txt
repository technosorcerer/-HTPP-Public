Drasle Family - Pochi & Bochi
©1985 Nintendo
2009 - 2025 Aether Knight

--------------------------
INTRODUCTION
--------------------------

Thank you for downloading the IPS patch "Drasle Family - Pochi & Bochi" for the NES. This patch contains reconstructed levels for all 50 rounds of Nuts & Milk for the Famicom (NES)

----------------------------------
PATCHING THE ROM
----------------------------------

First you will need a patching tool. This can be found at zopharsdomain.net or through
a search at google.com for "IPS Patching". Please apply this patch to one of the following...

Nuts & Milk (J)

--------------------------------------------------------------
ABOUT DRASLE FAMILY - POCHI & BOCHI
--------------------------------------------------------------

This hack was started way, WAY back in mid/late 2009. It's been on ice for an extended amount of time only to be thawed in 2025 where roughly 60% of the game was finished in a span of a just a few months.

All 50 Rounds have been changed as well as all the original artwork. The game is based off the monster character "Pochi" from Falcom's Dragonslayer IV Drasle Family for the Famicom. (aka Legacy of the Wizard for the NES)

-----------------------
KNOWN BUGS
-----------------------

Sometimes the font for "Bonus Round/No Bonus/Game Over" may be hard to read. Other than that, no bugs in this that the original Nuts & Milk didn't already have.

----------------
VERSIONS
----------------

v1.0 - 	Initial release

----------------------------
SPECIAL THANKS
----------------------------

- smkdan, author of the N&M 0.1 editor.
- Hex Workshop
- Yy, author of YY-CHR.

Character "Pochi" is a ™ of Falcom/Namcot ©1987 & ©1988 Broderbund Software.
