Nuts & Milk (NES)
Traducción al Español v1.0 (31/10/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nuts & Milk (Japan).nes
MD5: 8315cb720233bfd42b145b271e0189b8
SHA1: cca97fba72ca56809dd216618f5962eb6ea2f1aa
CRC32: 11879fe8
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --