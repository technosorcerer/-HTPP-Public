Hacks vs Hacks
This patch replaces the known characters with your own characters (Hacks and Torito),
changes many color palettes and replaces sprites and tiles, enables the complete level editor
that was hidden in the game, created by (Kevin2020) 