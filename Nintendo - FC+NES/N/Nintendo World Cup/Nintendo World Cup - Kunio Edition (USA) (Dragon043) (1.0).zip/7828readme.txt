This hack was Made by Dragon043
Credit also goes to Dacicus for the hacking helper chart.

-Nintendo World Cup Kunio Edition-
This hack was made because of Technos's love to translate their 
awesome games but change the Main Character each time. What this hack seeks out to do 
is change the first character of Team USA to Technos's Unofficial mascot, Kunio.

Kunio will replace Tony for Team USA but will be called different things for the
different teams just like the other characters.