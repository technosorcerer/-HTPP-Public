Ikari III - The Rescue (NES)
Traducci�n al Espa�ol v1.0 (12/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ikari III - The Rescue (U) [!].nes
MD5: b87c88386ee99f4954bca7a0abb04d58
SHA1: 32de21c5f5b309d9317b2252dfebb50c5f96b7ee
CRC32: 3bcd370e
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --