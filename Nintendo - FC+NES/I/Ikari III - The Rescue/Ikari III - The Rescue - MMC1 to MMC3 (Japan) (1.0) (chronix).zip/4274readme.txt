Ikari III MMC1 to MMC3 (NES)

Hacked by Andrei Vdovin a.k.a. Chronix
Email me if you find any glitches in my hack.
Thanks in advance!
chronix@bk.ru

Changes:

* This patch converts Ikari III (J) mapper from MMC1 to MMC3.

Original ROM:
-----------------------
Ikari III (J).nes
File size: 262 160

 PRG ROM:    8 x 16KiB
 CHR ROM:   16 x  8KiB
 ROM CRC32:  0xf7d20181
 ROM MD5:  0xcfbbafbecf01867d270a09a12f607372
 Mapper #:  1
 Mapper name: MMC1
 Mirroring: Horizontal
 Battery-backed: No
 Trained: No
