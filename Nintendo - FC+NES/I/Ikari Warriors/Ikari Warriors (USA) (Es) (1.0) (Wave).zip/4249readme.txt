Ikari Warriors (NES)
Traducci�n al Espa�ol v1.0 (12/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ikari Warriors (U) (PRG1) [!].nes
MD5: 2871c67f35a88bc33efe139d935bb34e
SHA1: 68a41caad8e2bf83b59a9337dc849d944a13c192
CRC32: eed05076
131.088 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --