Ikari Warriors II - Victory Road (NES)
Traducci�n al Espa�ol v1.1 (15/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Quitado el parche de velocidad de texto porque corromp�a la m�sica.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ikari Warriors II - Victory Road (U) [!].nes
MD5: c02cbb2f78e4acfd4844d7973262de2f
SHA1: 2a43aefd2768874e211b6eba74441bf295c64ba6
CRC32: 1eaf333c
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --