______________________________________________________________________

This is a simple graphic hack that replaces the Team Poland with Team Finland. Also, some color tweaks have been made to better match the team official colors and to be nicer for the eyes.

I've been playing this game with friends for over 30 years and it always bugged me that Poland was in, being a very very small hockey force compared to Finland. I hope my finnish friends will like being represented, at last!
______________________________________________________________________

 -OdinEleven
______________________________________________________________________
