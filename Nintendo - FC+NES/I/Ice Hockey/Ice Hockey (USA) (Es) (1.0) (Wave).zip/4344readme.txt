Ice Hockey (NES)
Traducci�n al Espa�ol v1.0 (28/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ice Hockey (U) [!].nes
MD5: a1052168d54635930bf124440f7afa57
SHA1: eea6f7f80fe966969a71209bfe9bbcdb0bbde394
CRC32: 4916d0a9
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --