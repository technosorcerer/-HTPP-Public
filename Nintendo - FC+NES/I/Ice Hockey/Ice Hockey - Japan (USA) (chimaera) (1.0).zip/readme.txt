Ice Hockey Japan
v1.0 2024-07-07
by chimaera
---------------------------------------------------------------------------

This patch changes the original EU/US Ice Hockey to the japanese FDS version.

Changes were made to:
* The hidden screen
* Teams (Japan instead of Sweden)
* Music

I also added the text JAPANESE 2024 to the title screen.

All Changes are described in: https://tcrf.net/Ice_Hockey_(NES,_Famicom_Disk_System)


How to patch:

Use your IPS patcher of choice to patch:
NTSC version: Ice Hockey (Japan) (NTSC).ips to Ice Hockey (USA).nes
PAL version:  Ice Hockey (Japan) (PAL).ips  to Ice Hockey (Europe).nes

.nes versions are standard NO-INTRO versions of ROMs



