Insector X (NES)
Traducci�n al Espa�ol v1.0 (03/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Insector X (J).nes
MD5: 26e5ada9fbac3137a94096bd5b0638ca
SHA1: 9648bd6e381673e52e76c1476d30df063d51b076
CRC32: 7dab812d
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.
Sensenic - Mensaje final en japon�s.

-- FIN --