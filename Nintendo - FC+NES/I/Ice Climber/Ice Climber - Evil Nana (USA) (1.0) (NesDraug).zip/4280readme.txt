_______________________________________________
ICE CLIMBER - EVIL NANA
By NesDraug
_______________________________________________

Contains two versions 

Ice Climber - Evil Nana
  - Player 2 can kill Player 1 by touch*
  - 2X Speed
  - Controllable jumps
  - Starting with 6 lives
  - Skipped intro
  - More time bonus
  - Altered colors 


Ice Climber - Evil Nana (Expert Levels)
  - Player2 can kill Player1 by touch*
  - 2X Speed
  - Controllable jumps
  - Starting with 6 lives
  - Skipped intro
  - More time bonus
  - Altered colors
  - Expert levels
  - Constant icicles  

*Player 1 (Popo) can only kill Player 2 (Nana) with the hammer while jumping.
This has to be done very exact and Popo is probably better off running for his life. 

ROM: [NES] - GoodNES V3.23b , Ice Climber (UE) [!]
Use Multipatch or Lunar IPS to patch rom

_______________________________________________
 Cred to nensondubois for the game genie codes
_______________________________________________

