Climb out of the depths of Hell to reclaim your Halloween candy!

Patch to Ice Climber (USA, Europe).nes