Urban Champion (NES)
Traducci�n al Espa�ol v1.0 (06/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Urban Champion (W) [!].nes
MD5: 5ae932ac36faad83d3500cb017605734
SHA1: 26623b69661011af701b5beb23c37f9bf80d52f1
CRC32: 0770cdaa
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --