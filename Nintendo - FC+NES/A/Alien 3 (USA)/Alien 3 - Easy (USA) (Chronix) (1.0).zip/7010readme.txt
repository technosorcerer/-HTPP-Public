Alien 3 Easy (NES)

* No timer
* Centered camera
* Buttons swapped (B-shot, A-jump)

Made by Andrei Vdovin a.k.a. Chronix.
Email me if you find glitches in this game.
Thanks in advance!
chronix@bk.ru

Original ROM:
-----------------------
Alien 3 (U) [!].nes
File size: 262 160

 PRG ROM:    8 x 16KiB
 CHR ROM:   16 x  8KiB
 ROM CRC32:  0xc527c297
 ROM MD5:  0x76e7bc449ae572c68a9fc4f397901924
 Mapper #:  4
 Mapper name: MMC3
 Mirroring: Horizontal
 Battery-backed: No
 Trained: No
