* Title: Alien 3 � Visual Update
* Author: extr1m (registered on romhacking.net as Nutsuser)
* Game: Alien 3 (NES)
* Release date: 2025

* Description:

* Alien 3 � Visual Update is a simple yet effective ROM hack of the NES game Alien 3.
* The main focus is on refreshing the overall visuals and atmosphere.
* The color palette has been changed across all levels to provide a more balanced and immersive look.
* Ripley�s sprite palette has also been updated for better character distinction.
* A long-lasting radar has been added, giving players more time to explore and strategize.

* Patch is intended for: Alien 3 (U) [!].
