             Alien 3 Plus V 1.0 / hack by The Jabu 
          ------------------------------------------------
       This is a hack for the game Alien 3 for the NES, that improve a few
   things to make the game more fun to play.




     Changes:


        - Swap the B and A buttons.

        - Twice the time to finish the levels.
    
        - Fixed the scroll problems  when you walk.

        - Redesign sprite for Ripley and the aliens.

        - Changed the palettes of the levels.

        - Stronger Aliens.

        - Changed a little bit the ending.







   Apply the IPS file to "Alien 3 (U).nes" and have fun!!!



  note : sorry for my english, but english is not my native language. 
