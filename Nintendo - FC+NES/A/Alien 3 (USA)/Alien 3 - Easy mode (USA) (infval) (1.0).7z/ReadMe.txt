﻿--------------------------Info---------------------------
Game name: Alien 3
Console: Nintendo entertainment system
Game region USA: (U)
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
 Windows: https://romhackplaza.org/utilities/solid-patcher-utility/
 Linux: https://romhackplaza.org/utilities/solid-patcher-utility-2/
 https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
The patch adds the following changes:
 
 Swap the B and A buttons.
 Skip intro screens with any button.
 Additional platform for climbing and picking up items at the end of level 1-1.
 Disable Timer.

----------------------------------------------------------
Online Alien 3 patcher:
https://rgcorp.ucoz.net/misc_site_pages/Alien3-Fixes_Timer_Editor.html

----------------------------------------------------------
Authors by: infval, the jabu.