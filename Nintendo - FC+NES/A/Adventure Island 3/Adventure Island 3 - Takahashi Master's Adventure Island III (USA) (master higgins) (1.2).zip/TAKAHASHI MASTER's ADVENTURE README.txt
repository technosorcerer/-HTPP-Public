This hack applies to Adventure Island 3 (headered rom)
but also you can try applying to Takahashi Meijin no
Bouken Jima 3 if you don't mind the Title Screen being
somewhat garbled. Use your favorite IPS program
to patch the rom.

All levels are modified with level screen sequence and
enemy data. Level names are changed too

Please send any feedback to @robothell on twitter
or send an e-mail to sigmavirus[at]gmail.com or
so I can fix possible bugs or cheap deaths.

Thanks for your support!

master higgins on romhacking.net
A.K.A @15KHz on Youtube
A.K.A @robothell on twitter
A.K.A megaman_exe on other sites

Release Notes:
=============

1.0: 
First Release

1.1:
Level redesign, which includes:
- Fixing misleading info like bottomless pit 
and then going into a underground water level 
or otherwise (shaft of darkness and then 
going to a lava cave)
- Wipe out many of the cloud platforms, only
use when needed (like pits or to reach some items)
- Rearranged some palettes and music so both
of them fit the theme (like a dark beach with
a lava gorge/dark woods music)
- Fixed firey lava rocks to ONLY be spit out
by volcanos (they were spit on lava pools
previously)
- Also rearranged some enemies which shouldn't
be on a level using some common sense (I read
complaints that kangaroos and ostriches shouldn't
be on forest levels, but now they're gone)
- Felt like giving lots of pet items and lots
of rocks with 1-ups because the difficulty
curve is high, but manageable.
- I couldn't fix some of the 1-up giving rocks
to show correct gfx but I consider they just
accomplish what they do, give a precious 1-up
in a harder hack of this game.

1.2
- Fixes some difficulty issues in many levels
(enemy and level data)
- Changed music assigned to levels
- Changed the intro

The CRC of the rom is BFBFD25D (Adventure Island III USA)
but you can feel free to apply to the Japanese ROM, that
is "Takahashi Meijin no Bouken Jima III"
