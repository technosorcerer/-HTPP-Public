BASE ROM


Adventure Island 3 (USA).nes		No-Intro iNES1.0
Adventure Island III (U) [!].nes	GoodNES

File SHA-1: 9F8D51762125DF0C1A6AB6EFF41FBF7D0E65D465
File CRC32: 952CDACF
ROM SHA-1: F77EB86932844A92834EF12C059A3F5B815DAC07
ROM CRC32: BFBFD25D


Changes:

all levels changed
every boss have double hp (life)
color of master Higgins
There are still some minor graphic mistakes, and sometimes the game difficulty may jump to very hard.

Hack Difficulty: Hard.

Demo Video: https://www.youtube.com/watch?v=IhI9wdZPOHQ

Version 1.1 new adds:

time won�t decrease by itself
you start with 5 lives and 2 axes