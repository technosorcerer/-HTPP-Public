CRC32: CD89D386
MD5: 4F25CE5A283D902694C52FB1152F891A
SHA-1: 47E103D8398CF5B9CBB42B95DF3A3C270291163B
SHA-256: 2ADA8919688087BE70A6A48CACE8F877ADD60C45D2E5D04E2442FAA55BE62A49


Adventure Island 3 - Googie Edition
-----------------------------------

All the main levels have been changed, along with some minor graphic changes.
This hack will test your gaming skills, since there's no bonus levels whatsoever.
But you do get either a hammer or a boomerang in each level, and you also start with two crystals in your inventory in the beginning of the game. 
-----------------------------------

Thanks my beta testers

Danger X
pacnsacdave
tettsui77
-----------------------------------

I hope you all enjoy this hack, now back to working on my other projects...

- Googie  