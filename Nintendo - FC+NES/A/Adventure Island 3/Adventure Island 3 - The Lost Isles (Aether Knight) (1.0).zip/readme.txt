BASE ROM

Adventure Island 3 (USA).nes		No-Intro iNES1.0
Adventure Island III (U) [!].nes	GoodNES

File SHA-1: 9F8D51762125DF0C1A6AB6EFF41FBF7D0E65D465
File CRC32: 952CDACF
ROM SHA-1: F77EB86932844A92834EF12C059A3F5B815DAC07
ROM CRC32: BFBFD25D



Adventure Island 3 ; The Lost Isles
1992 Hudson Soft
2007,2008 Aether Knight Hacks

--------------------------
INTRODUCTION
--------------------------

Thank you for downloading the IPS patch "Adventure Island 3 ; The Lost Isles" for the NES. This patch contains "reconstructed" levels for all 8 worlds of Adventure Island III.

----------------------------------
PATCHING THE ROM
----------------------------------

First you will need a patching tool. This can be found at zopharsdomain.net or through
a search at google.com for "IPS Patching". Please apply this patch to the "Hudson's Adventure Island 3 (U)" ROM.

----------------------------------------------------
ABOUT "THE LOST ISLES" PATCH
----------------------------------------------------

This hack was started back in December 2007. Most of the levels were finished by mid February. The title screen was ripped from the translated NES ROM "Adventure Island 4". Since I am an amateur ROM hacker (is there a professional ROM Hacker?) in every sense of the word, this took much longer to edit than someone with more experience and abilities. Also you'll notice that the palette on the title screen is a little off :P

All 8 worlds and 8 levels each have been altered. (with the exception of world 4-4 although most enemies have been changed) This is not meant to be a "hardtype" hack but later levels can be very challenging. All levels can be completed without any enhancments. (hammer, dinosaur etc.) However it is recommended that you save your items for later levels.

I've tested this patch thoroughly but there is always a chance I missed something somewhere. If you do find a glitch, I'd like to know about it so drop me a line at aetherknight2k@aol.com

----------------------------
SPECIAL THANKS
----------------------------

The following made this patch possible...

- master higgins (Agave utility)

- bpsoft.com (Hex Workshop)

- Kent Hanson (TLP)

- NeoDemiforce (for the "Island" logo from Adventure Island 4)
