Disclaimer
This hack has been altered with Zynk's permission mostly because of guidelines of romhacking.net, that don't
allow translations of romhacks to other languages besides English. I sent PM asking for permission to
translate the game using his patch as base and we decided to release both the original and this hack
translated here.
If you're looking for the original Tina hack you can find at:
https://www.romhacking.net/hacks/4795/
This readme is bundled because it contains contact info from Zynk, but I'll be adding on the portuguese
readme file. Thanks again Zynk!
;)

patryckpo
patryckpo.com
-----------------------------------------------------------------------------------------
(Content below is from original readme)

Tina's Adventure Island III
Hacked by Zynk Oxhyde
2019

--------------
Date Released:
--------------
v1.0 November 16, 2019

------------
Description:
------------
This is a player sprite hack of Adventure Island III for the NES.

This hack changes Master Higgins' player sprites into his girlfriend Tina.

There are 2 patches for each region release: US and JP.

--------
Changes:
--------
v1.0 (11/16/2019) - initial release
* Master Higgins' player sprites are changed into his girlfriend Tina
	- her palette affects other green colored sprites, like fruits and enemies
	- some major rearrangement of sprites were done (i.e. axing, jumping, swimming, skateboarding)
	- Tina riding on the pterodactyl has her whole body riding it (rather than her with only her head sticking out of its back like riding in a biplane)
* Ending Tina is replaced with Master Higgins
* Some palettes are changed to the right colors
* Bugfixes include:
	* The water dino's left facing idle sprite animation is fixed

------
Story:
------
After Beelzebuff's defeat, our heroine Tina, together with her boyfriend Master Higgins, returned to their peaceful island.
However, aliens from outer space have invaded and kidnapped Master Higgins! Again! Now Tina, together with the help of her dinosaur friends, 
starts their adventure to defeat the alien invaders and save Master Higgins. Again!!

---------
ZIP file:
---------
* TINASADVENTUREISLAND3 Folder
  * TINA3-US.ips
  * TINA3-JP.ips
  * This Readme file

----------------
ROM Information:
----------------
Database match: Adventure Island 3 (USA)
Database: No-Intro: Nintendo Entertainment System (v. 20180803-121122)
File SHA-1: 9F8D51762125DF0C1A6AB6EFF41FBF7D0E65D465
File CRC32: 952CDACF
ROM SHA-1: F77EB86932844A92834EF12C059A3F5B815DAC07
ROM CRC32: BFBFD25D

Database match: Takahashi Meijin no Bouken-jima III (Japan)
Database: No-Intro: Nintendo Entertainment System (v. 20180803-121122)
File SHA-1: 9187234F1F8CC7E4AE325BA1B3D53B1B35438644
File CRC32: 48F9B5DB
ROM SHA-1: 5CBF93FF75E0A997EEC79E254AFEAB50F99F97CE
ROM CRC32: 626ABD49

--------
Credits:
--------
Zynk Oxhyde - Hacking and Sprites

----------
Utilities:
----------
YY-CHR ROM graphics editor by YY
FCEUX 2.2.3 NES emulator debuggers
Corrupster by Disch

---------------
Special Thanks:
---------------
Romhacking.net - for hosting the patch

--------
Contact:
--------
Email: zynkoxhyde@yahoo.com

----------------------------
Disclaimer and Terms of Use:
----------------------------
* Zynk Oxhyde is not related or affiliated with Nintendo and the publisher of the original game.
* Do not sell this patch and the contents with it.
* Do not sell the pre-patched ROM into reproduction cartridges.
* You may distribute or host this patch provided that all files that come with it are intact.