(Melhor visualizado no bloco de notas ou similar, fonte Consolas/Courier/Lucida Console/Fixedsys ou similar)
LEIA-ME
---- --

Introdu��o
----------
Se voc� est� doido(a) para testar esta tradu��o pe�o que leia mais abaixo para entender como aplicar esta tradu��o, que cont�m mais de um patch. Recomendo o Lunar IPS que pode ser obtido em:
fusoya.eludevisibility.org/lips/

Sobre (jogo normal)
-----
Nome do jogo: Higgins em Adventure Island III
ROM utilizada: Adventure Island III (U) [!].nes/Takahashi Meijin no Bouken Shima III (J) [!].nes
CRC32 (antes do patch): 952CDACF/48F9B5DB
CRC32 (depois do patch): 8C80390F/D3103DCA
G�nero: Plataforma
Console: Nintendo Entertainment System (NES)/Family Computer (Famicom)
Lan�amento: 1992
Produtora: Hudson Soft
Distribuidora: Hudson Soft
Jogadores: 1

Tradu��o feita por: Patryck Padilha de Oliveira
ROMHacking: Patryck Padilha de Oliveira
Lan�amento da tradu��o: 21/09/2021

Sobre (hack)
-----
Nome do jogo: Tina em Adventure Island III
ROM utilizada: Adventure Island III (U) [!].nes/Takahashi Meijin no Bouken Shima III (J) [!].nes
CRC32 (antes do patch): 952CDACF/48F9B5DB
CRC32 (depois do patch): AE13AEB1/74A254BC
G�nero: Plataforma
Console: Nintendo Entertainment System (NES)/Family Computer (Famicom)
Lan�amento: 1992
Produtora: Hudson Soft
Distribuidora: Hudson Soft
Jogadores: 1

Tradu��o feita por: Patryck Padilha de Oliveira
ROMHacking: Patryck Padilha de Oliveira
Lan�amento da tradu��o: 21/09/2021

Progresso
---------
Gr�ficos: 100% (t�tulo meio que inalterado)
Acentos: 100%
Textos gerais: 100% (cr�ditos inalterados)

Progresso geral: 100%

Como aplicar o patch
--------------------
Ver� que existem duas pastas no zip, uma para a vers�o U e outra para a vers�o J, aplique na respectiva regi�o os patches para os efeitos respectivos:
Higgins em Adventure Island III para a vers�o normal;
Tina em Adventure Island III para a hack com a Tina no lugar do Mestre Higgins.

Sinopse
-------
Seja controlando Higgins ou Tina, lute contra os destemidos animais deste arquip�lago composto de 8 ilhas, e tente alcan�ar a nave que abduziu a seu/sua companheiro(a).

Coment�rios do tradutor
----------- -- --------
Antes de tudo s� tenho a agradecer ao usu�rio Zynk Oxhyde pela hack da "Tina em Adventure Island III", se estiverem curiosos para ver mais trabalhos deste usu�rio procurem por "Zynk" no romhacking.net e ver�o mais conte�do!

Se n�o fosse pelo "ajkmetiuk" nem teria visto esta vers�o do NES, j� que traduzi a vers�o do Game Boy, mas pela parceria com Zynk decidi trazer essa tradu��o em 4 patches, mas voc� s� precisa aplicar a que ir� usar, no caso de qualquer d�vida poste um coment�rio no meu site, procure a tradu��o que estar� na se��o Consoles>NES e clique na capa desse jogo.

Informa��es legais
----------- ------
Essa tradu��o foi feita sem fins lucrativos e deve continuar assim, portanto sua venda � proibida, seja ela com ou sem a ROM original. Tamb�m o tradutor n�o se responsabiliza por quaisquer danos que este patch possa provocar em seu computador/console (mesmo ele sendo quase nulo). Se caso esta tradu��o for postada em outro lugar que n�o seja citado no meu blog (link mais abaixo) por favor me avise para que possa postar no meu blog com um link para a mesma. Todos os direitos reservados �s empresas respectivas que criaram/distribu�ram o jogo e o console nos quais foram projetados originalmente para serem jogados.

Contato
-------
Estou dispon�vel no F�rum Unificado de Tradu��o (patryckpo), Twitter (@patryckpo), no YouTube (youtube.com/c/patryckpo), no meu blog (ab-gamesinc-br.blogspot.com.br), no GitHub (github.com/patryckpo) e por a� afora na Internet (por nome de patryckpo/patryckslasher ou pelo meu nome completo)

Final
-----
Espero que se divirta com essa tradu��o, e d� uma olhada tanto no meu site quanto no Portal Brasileiro de ROMHacking e Emula��o (PO.B.R.E.) para mais tradu��es, os links est�o mais embaixo:
romhacking.net (em Ingl�s)
patryckpo.com (meu site)
romhackers.org (PO.B.R.E.)
romhacking.net.br (F�rum Unificado de Tradu��o)