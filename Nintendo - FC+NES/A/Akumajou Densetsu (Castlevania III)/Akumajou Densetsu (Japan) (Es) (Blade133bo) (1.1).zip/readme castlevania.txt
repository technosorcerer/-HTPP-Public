Aunque ya hay una version en castellano, y como me habia metido con el Castlevania 4 me parecio una buena idea.
habia cosas que crei que podia mejorar, recalcular punteros y la pantalla del titulo, a pesar de que modificar los endings no fue moco de pavo. XD
La version Usa es mas completa, y quiza algun dia lo traduzca... quiza.

El parche esta basado en la versiones:
http://www.romhacking.net/translations/730/
Pantalla del titulo rehecho
http://www.romhacking.net/hacks/1983/
Nueva apariencia de Alucard
http://www.romhacking.net/hacks/3463/
Y saltos mas controlables
http://www.romhacking.net/hacks/3596/

Necesitaran el rom:
    Akumajou Densetsu (J).nes
    CRC32: 2E93CE72
    MD5: 91FA26986B6C07C39FADBFAC61ADABD6
    SHA-1: A0F3B31D4E3B0D2CA2E8A34F91F14AD99A5AD11F

Cualquier error en la traduccion, no duden en comentarmelo.
blade133bo@gmail.com

