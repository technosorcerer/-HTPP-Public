Difference from the original:

1. Redrawn and new graphics added
2. Redrawn characters, enemies and level leaders
3. Branches have been removed, all levels are now available
4. The Japanese version of the game was taken as the basis, in which the title screen was changed and the localization was redone into English
5. Changed the color palette
6. Changed the location of all blocks, doors, stairs on the levels
7. Quick transition through the door (in the original it was much slower), as well as quick switching between characters
8. Slightly corrected difficulty (but it does not differ much from Japanese)
9. At the last level, the music has been changed
10. The font, the game interface, as well as the icons of two characters have been corrected.
(Done by Newman)

11. Small patch added to rotate all characters when pressing select. (Done by bogaabogaa)

Cons, bugs in the game:
1. A serious bug regarding the level - Sunken City (Sunken City), the bug is in the leader of this level. It is highly recommended not to fight this leader with the homing orbs and fire that Sypha Belnades possesses , as this may cause the water-fill script to fail when hit. As for freezing, this bug was not noticed during the battle with the leader.
2. Some emulators, for example ( Mednafen, Fceux) do not support dark colors, such as dark gray (perhaps I don’t know something in this regard, or most likely an adjustment is needed in the emulator settings), but there are emulators that support these colors, for example, the emulator is FCE Ultra (will be attached to this topic);
3. In the last location on the Main Hall level , there is a small bug, in general it is not noticeable when passing (the bug touches in an invisible block), it can only be noticeable if you play as Alucard and turns into a bat, then you may encounter invisible block. 

The author of this hack is Newman.

Good luck playing and stay healthy!