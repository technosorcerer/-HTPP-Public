~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Akumajou Densetsu 
  Legend of the Demon Castle: Castlevania III
  English Translation Patch
  Version 1.0

  Created by Vice Translations
   part of   Kitsune's Den
             http://vice.parodius.com/
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CREDITS
-----------------
  Kitsune Sniper
   Game hacking, font insertion, preliminary translation and
   graphic insertion.
   Email: kitsune [at] parodius [dot] com

  shiroi
   Main translation support
   http://www.otaku-universe.net/~shiroi/translation/index.htm

  Kitty, tetsuo
   Partial translation support

  BMF54123
   Hacked title screen! Go thank him, and play Blob Bros. 2 too!
    http://bmf.rustedmagick.com/


Project History:
-----------------

June 6, 2003
  This is the file date that my first table has. So I'm assuming that
  I started the project then.

  Uh, I didn't really keep a history this time around. So I'll just
  say that thanks to shiroi, I was able to finish this. Now, can
  anyone donate a title screen? 'Cause that's all that's left, as far
  as I know! ^^;;

Version History:
-----------------
  Version 1.0,    October 12, 2003 [7,443 bytes]
   Shiny new title screen by BMF54123. Thanks! It's finally done!

  Version 0.99a,  October 11, 2003 [5,031 bytes]
   I uh, wrote a wrong name in one of the endings. Instead of Trevor...
   I wrote Simon. This was in the Simon + Grant Ending. Anyway. Thanks
   to Joseph Tek Fox for the heads up.

  Version 0.99,  October 2, 2003 [5,031 bytes]
   Done. Go. Play. NOW.


What's left:
-----------------
  Nothing, as far as I know. Other than the title.


Game Notes:
-----------------
  Read a Castlevania III FAQ. :P

  There are some gameplay differences, most notably in Grant, who throws his
  dagger by default, unlike CVIII. That and most of the script is different.
  I had to edit some things out. 714 bytes of space wasn't enough by a long
  shot. >_<
  
  And most importantly, you CAN NOT upload a pre-patched rom to your website.
  Vimm can bite my furry two-tailed ass. Bitch.

  And, since Colin Moriarty refuses to believe this, Sypha Belenades / Belmundes
  IS FEMALE. The US version of the game describes HER as female. The Japanese
  version of the game describes HER as female. So nyah. I don't think he'll ever
  update the FAQ, though. I guess he retired. *shrugs*


Copyrights
-----------------
  Akumajou Densetsu, Castlevania, and all other names are trademarked to
  Konami of Japan.


Disclaimer
-----------------
  There is no videogame company or any other company associated with
  Kitsune Sniper. In no event shall Kitsune be liable or responsible for
  any damages that may occur from direct, indirect or consequential results
  of the ability or disability to use or misuse any material it provides.

  In other words, you'd better own the cart for the rom that you're patching,
  and if something goes wrong, don't blame me!
