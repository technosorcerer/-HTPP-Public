~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Akumajou Densetsu 
  (Castlevania III - Dracula's Curse)
  Localization - Title Screen Patch
  Version 5.0
	http://www.romhacking.net/hacks/1983/

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

  Title Screen and Localization by ShadowOne333
	http://www.romhacking.net/forum/index.php?action=profile;u=14879
  Co-helper: Vanya
	http://www.romhacking.net/forum/index.php?action=profile;u=3436

  Original hack by Vice Translations
   part of   Kitsune's Den
             http://vice.parodius.com/

      Kitsune Sniper
        Game hacking, font insertion, preliminary translation and
        graphic insertion.
        Email: kitsune [at] parodius [dot] com

      shiroi
        Main translation support
        http://www.otaku-universe.net/~shiroi/translation/index.htm

      Kitty, tetsuo
        Partial translation support

      BMF54123
        Hacked title screen! Go thank him, and play Blob Bros. 2 too!
         http://bmf.rustedmagick.com/
  
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~


An Akumajou Densetsu Translation hack originally made by Vice Translations.

The previous hack was edited to create a new custom title screen to have the USA name of the game. Original graphics created by user Vanya.

Also, this hack changes the name from the previous hack from "Ralph Belmondo" to Trevor Belmont, to make it as closely related to it's USA counterpart.


Changelog:
-----------------
  v1.0 - Initial release.

  v1.1 - Moved the subtitle text "Dracula's Curse" a little bit to the right so it is more centered and balanced.

  v1.2 - Standarized the title screen color palette. This solves the issue in which the letters "D" and "E" of the subtitle had a slightly blue-ish color than the rest of the letters.

  v2.0 - Major changes to title screen. 
Konami logo is now smaller and the  subtitle  has been finally changed to a blood-red color.

  v2.1 - Bug fix. The title screen loaded for the introduction sequence is different from the Main Title Screen, resulting in wrong palettes loaded in the introduction.

  v3.0 - MAJOR bug fixes. This fixes bugs carried over from Vice Translations'
 project, in which the ending sequences for Sypha, Alucard and Trevor had
 misplaced text when the words scroll upwards.
 Other changes include:

	1) Main Title Screen, including Introduction sequence and Ending sequence
	now have the same palette and sprites.
	2) All characters have been localized for North American audiences.
	This means Grant Danusty is now Grant DaNasty and Sypha is now a Belnades.
	Same goes for Ralph Belmondo to Trevor Belmont in the ending sequence
	(forgot to change that one),
	3) Subtitle font changed to match that of the ending credits.
	4) Quotation marks missing from the ending sequence. This was an issue 
	regarding to the size of the name entry conflicting with the quotation marks.


  v4.0 - Sprites for Zombies and Imps updated.

  v5.0 - Updated Imp jumping sprite to appear like further incarnations and match the rest of the franchise.

  v6.0 - Updated the title screen subtitle / blood splash and the Konami logo. The Konami logo is now closer to the original
and the title screen subtitle "DRACULA'S CURSE" has been given two shades of red for better contrast. It is now
much more pleasant to the eyes instead of the bare red tone.


Copyrights
-----------------
  Akumajou Densetsu, Castlevania, and all other names are trademarked to
  Konami of Japan.
