
          _                          _              
    /\   | |                        (_)             
   /  \  | | ___   _ _ __ ___   __ _ _  ___  _   _  
  / /\ \ | |/ / | | | '_ ` _ \ / _` | |/ _ \| | | | 
 / ____ \|   <| |_| | | | | | | (_| | | (_) | |_| | 
/_/    \_\_|\_\\__,_|_| |_| |_|\__,_| |\___/ \__,_| 
                                   _/ |                                                       
                                  |__/                                                        
     _____                      _             
    |  __ \                    | |            
    | |  | | ___ _ __  ___  ___| |_ ___ _   _ 
    | |  | |/ _ \ '_ \/ __|/ _ \ __/ __| | | |
    | |__| |  __/ | | \__ \  __/ |_\__ \ |_| |
    |_____/ \___|_| |_|___/\___|\__|___/\__,_|
	
      * * * * * * * * * * * * * * * * * * *
      *  Akumajou Densetsu Arabic Project *
      *         Version Beta 0.99         *
      * * * * * * * * * * * * * * * * * * *
				 
								 Project by:
                           #                          
                          # #   ##### #    # #####  # 
                         #   #    #   #    # #    # # 
                        #     #   #   ###### #####  # 
                        #######   #   #    # #    # # 
                        #     #   #   #    # #    # # 
                        #     #   #   #    # #####  # 
        
           ###    ##        ######  ##     ## ##       ##    ## ##     ## 
          ## ##   ##       ##    ## ##     ## ##        ##  ##  ##     ## 
         ##   ##  ##       ##       ##     ## ##         ####   ##     ## 
        ##     ## ##        ######  ######### ##          ##    ######### 
        ######### ##             ## ##     ## ##          ##    ##     ## 
        ##     ## ##       ##    ## ##     ## ##          ##    ##     ## 
        ##     ## ########  ######  ##     ## ########    ##    ##     ## 
		
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
  Akumajou Densetsu (Castlevania III: Dracula's Curse)
  For Nintendo Entertainment System (NES)
  Arabic Translation Patch
  Version Beta 0.99
  My site: https://sites.google.com/view/athbistudio/
  My Twitter: https://twitter.com/tff9q
  MY Paypal Support us: https://t.co/67jzIrXZ5H
  
  Created by Athbi Alshlyh: Full Translation and ASM Hacking. feel free to send me feedback: q8fft8@gmail.com
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
******** This translation is not for sale or rent. ***************
**************** هذه الترجمة ليست للبيع او التأجير. **************************
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

CREDITS to:
-----------------
   Big Thanks for Supporting - أكبر تحية وشكر إلى:	
   + Nawaf Bahadur in patreon
   
   Thanks for - أشكر:
   + Mansour Lagaffe
   
   Thanks to - الشكر إلى:
   + A7med Bamatraf: محول الحروف , http://www.romhacking.net/utilities/1012/
   + Windhex
   + Romhacking.net
   + Kruptar 7
   + And You
   
Project History - تاريخ بداية المشروع:
-----------------
بصراحة لا اذكر متى كان بداية المشروع
لنا هذا المشروع اخذ اقوى اهمال من بين المشاريع.
لعدة أسباب طبعاً...
نهاية المشروع : 9\6\2019

What's left - ما الذي تبقى:
-----------------
  ترجمة الاجزاء المهمة من اللعبة
  وهي قابلة للعب بشكل جميل...
  طبعا هذه النسخة اليابانية.
  
Game Notes - ملاحظات:
-----------------
  لايوجد
  
Installing Patch - تنصيب الباتش:
-----------------
اولا: احصل على نسخة روم من اللعبة بـ اسم، (أبحث في جوجل.)ـ
ROM not found in Database: No-Intro
File SHA-1: 1D4755F8E8B047E469895860ED6FD51E1B3B438E
ROM SHA-1: 935B89C881FB2AD148A957CD0FFCF3D1FF191F32
ROM CRC32    9B8D543F


ثانيا: تحتاج إلى برنامج Lunar IPS لتطبيق الباتش:
https://www.romhacking.net/utilities/240/

ثالثاً: طبق الباتش على اللعبة.
شغل برنامج
Lunar IPS.exe
بعدها في الخانة الاولى حدد اللعبة أيزو
الخانة الثانية حدد الباتش او الرقعه
Akumajou Densetsu_Arabic_X.XX
بعدها اضغط على زر
Apply

وبس، وأوقات طيبه لك.

Copyrights - حقوق النشر
-----------------
  Akumajou Densetsu, and all other names are trademarked to
  Square Enix of Japan.


Disclaimer - إخلاء مسؤولية
-----------------
  There is no videogame company or any other company associated with
  Athbi Alshlyh. In no event shall Athbi Alshlyh be liable or responsible for
  any damages that may occur from direct, indirect or consequential results
  of the ability or disability to use or misuse any material it provides.

  In other words, you'd better own the cart for the rom that you're patching,
  and if something goes wrong, don't blame me!