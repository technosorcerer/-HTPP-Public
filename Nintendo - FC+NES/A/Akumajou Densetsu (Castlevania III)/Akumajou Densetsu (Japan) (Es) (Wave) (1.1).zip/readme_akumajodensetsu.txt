Akumajou Densetsu
Traducci�n al Espa�ol v1.1 (15/10/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Akumajou Densetsu
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Akumajou Densetsu
-----------------
Tercera parte de Castlevania, saga clasica.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking esta basado en el de Vice Translations.
v1.1: Arreglado final con Sypha.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Akumajou Densetsu (J).nes
393.232	bytes
CRC32: 2e93ce72
MD5: 91fa26986b6c07c39fadbfac61adabd6
SHA1: a0f3b31d4e3b0d2ca2e8a34f91f14ad99a5ad11f

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n al espa�ol.

Original:
CREDITS
-----------------
  Kitsune Sniper
   Game hacking, font insertion, preliminary translation and
   graphic insertion.
   Email: kitsune [at] parodius [dot] com

  shiroi
   Main translation support
   http://www.otaku-universe.net/~shiroi/translation/index.htm

  Kitty, tetsuo
   Partial translation support

  BMF54123
   Hacked title screen! Go thank him, and play Blob Bros. 2 too!
    http://bmf.rustedmagick.com/

-- END OF README --