  *******************************************
*** Akumaju Densetsu to 50 Hz PAL fix patch ***
  *******************************************

By Bregalad, 11th march 2010

*** What is this patch ***

Konami already released Castlevania III in PAL teritories (and yes, I do have it in my game collection). However this version was based on the North American version of the game, which is very different from the japanese version of the game (Akumaju Densestu, it's called). The main differences is the music, the font and the japanese language, but there is also a lot of graphical and difficulty differences. I don't think one version is definitely supperior to the other, but a device called the Power Pak allows you to play NES ROMs on a real console. One of it's key features was to also support extra sound if you soldered an extra resistor on the bottom of your NES.

Of course I did that and immediately tried Akumaju Densetsu, but I was terribly disapointed because the game was designed for 60 Hz NTSC, and altough most games are playable in 50 Hz, there was so many glitches is wasn't even playable. So I hacked the games so that it becomes playable on a 50Hz PAL NES with a Power Pak. Warning : This hack never meant to provide a completely glitch-free setup, I just coarse-tuned scanline effects so that it will become close to what was supposed and become playable. As there is QUITE a lot of scanline effects in the game, I might have forgot to fix a few of them, but I think I got all of them.

This hack also fix the music pitch so that it don't become lower (as it happens when playing a NTSC game on a PAL NES).

Now I can play either the official PAL version or the Japanese version on my NES depending on the mood :p

These patches does NOT fix the following points (and never will because it this would require entiere rewrites of some parts of the game engine) :
- Music tempo would still be 5/6 slower
- Gameplay, animation speed 5/6 slower
- Maybe I missed uncommon raster effects ? (if you find any please contact me)

*** Technical notes about the patches ***

This hack apply to Akumajo Densetsu (J) only.

*** APPLYING THE PATCH ***

Apply the patch with your favourite ips patcher, some are availales arround the internet. You can use emulators to automatically patch the game when running it, but if you want to get the data on a real cart you must apply the patch with a patcher, downloading it isn't enough.
I used samIPS to make my patches.

Note that after patching the ROM, it will likely NOT work any longer in emulators that emulate a 60 Hz NTSC NES.

**** Versions ***

1.0 11th sept 2010
First release

eof