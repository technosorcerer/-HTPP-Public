(Leia com o Bloco de Notas maximizado.)

Oi, eu sou Redarts, e voc� acaba de baixar meu primeiro jogo a ser traduzido 100%! Valeu mesmo! Eu me diverti pra caramba
traduzindo esse jogo. Vou procurar algum outro jogo pra traduzir, quando eu puder. Eu devo focar em jogos de NES.


Sobre o jogo:

Archon: The Light and the Dark(Ou "Archon: A Luz e as Trevas") � um jogo de estrat�gia bem conhecido(N�o no Brasil), e saiu
para v�rias outras plataformas, como o DOS, o Amiga, e o Commodore 64. O jogo tem uma tem�tica parecida com a do Xadrez, com
casas diferentes, pe�as diferentes, movimentos diferentes... Bom, � interessante aprender ele. Apesar de parecer na primeira
vez que voc� v� o jogo, n�o � t�o dif�cil! E mesmo que voc� n�o conhe�a muito do jogo, eu coloquei um guia pro jogo no mesmo
arquivo que voc� baixou(Voc� j� deve ter visto ele l� te esperando).


Sobre a tradu��o:

Eu tava procurando um jogo pra traduzir(Primeira vez � complicado n�), e acabei batendo nesse jogo a� sem querer. Joguei, e
gostei! Nunca tinha ouvido falar dele antes, provavelmente por terem v�rios outros jogos de estrat�gia mais populares(Fire
Emblem, Final Fantasy Tactics, entre outros). Bom, eu sou apaixonado pelo NES, ent�o eu decidi aceitar o desafio, e aprender
a hackear textos! Tive muitas dificuldades(E a dificuldade era tudo o que faltava pra terminar a tradu��o, pouca coisa!).
Ainda assim valeu muito a pena no final.


Progresso da Tradu��o:

Acentos: 100%
Textos: 100%(N�o vi necessidade de traduzir o come�o do jogo, ent�o dou 100% mesmo.)
Menus: 100%(Foi tenso fazer os menus no come�o.)


Como usar o IPS:

Primeiro, voc� baixa o Lunar IPS(LIPS). Voc� acha ele nesse link aqui: https://www.romhacking.net/utilities/240/ s� copiar e
colar no seu navegador. Depois, arrume uma ROM de Archon. N�o posso distribuir links de ROMS, � errado, ent�o voc� vai ter 
que procurar sozinho(Pesquise algo como "Archon usa nes", que deve aparecer). Depois de extrair a ROM que voc� baixou, abra
o LIPS, e clique em "Apply IPS Patch". Vai aparecer uma janela, e nela, voc� acha o IPS(O que veio junto com isso aqui que
voc� t� lendo, se ainda n�o extraiu, melhor extrair). Feito isso, outra janela aparece, e voc� tem que selecionar a ROM n�o
modificada dessa vez(A que voc� baixou em algum site externo de confian�a). Pronto, voc� j� pode jogar o jogo! S� abrir num
emulador(Se ainda n�o tiver um emulador de NES, eu recomendo o FCEUX, ou o NEStopia).


Contatos(Caso ache algum erro/bug, ou caso tenha alguma d�vida, pode falar comigo por esses a�):
Discord -> Neko_Player#6091 (Pode adicionar se quiser!)
Gmail -> anaclaudia50901@gmail.com (J� respondendo logo, n�o sou mulher. A conta da minha m�e se misturou com a minha, de 
algum jeito.)

Novamente, obrigado por baixar o IPS! Espero que se divirta com o jogo!