Archon (NES)
Traducción al Español v1.0 (22/06/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Archon (U) [!].nes
MD5: 4777689bfc7ad9e36136235fc774a36d
SHA1: a0a7008f1fb953cf436c47fe814be10f8fc3ba77
CRC32: c00d228d
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --