
 Aladdin (BUTTON FIX + improvement) V 2.1  / hack by The Jabu    
 ----------------------------------------------

This is a hack for the game "Aladdin (Unl).nes"(pirate),that fix the configuration 
of the buttons in the game and made some improvement to make the game more 
enjoyable to play.

changes:


  V 1.0

- now with the "B" button you throw apples, and with the "A" button you jump.

- fixed the jump ( you don't need to run to make a decent jump anymore).

- now to use the rug press "UP".

- now when you glide in the air with the rug, you can glide more
  instead of just falling slowly.

- you start with 5 hearts , and you may obtain a maximum of 10 hearts.

- you start with 2 lives instead of 7 lives.


  V 1.1


- fixed a little bit more the jump, to avoid completely the useless "short jump".

- adjust the speed of aladdin, because the control was too sensitive after 
  the changes.

- now the max number of lives you can have is 10.



  V 2.0

- jump 100% fixed.

- fixed the walking/stop speed of aladdin.



  v 2.1

- Fixed genie's palette on stage 4-1.

- Minor change of palettes on some levels.



 Apply the IPS file to  "Aladdin (Unl).nes" or "Aladdin(Unl)[p1][hM04].nes", 
 and have fun!!!


note 1: sorry for my english , but english is not my native language. 

note 2: this patch is 100% compatible with the patch "Aladdin 4 Music Replacement"
released By Gigasoft ( http://www.romhacking.net/hacks/2107/ )

