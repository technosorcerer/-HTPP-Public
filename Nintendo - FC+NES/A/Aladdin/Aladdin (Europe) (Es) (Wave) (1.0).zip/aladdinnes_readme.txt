Aladdin
Traducci�n al Espa�ol v1.0 (13/01/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Aladdin
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Aladdin
-----------------
Excelente plataformas basado en la pelicula, port de la versi�n de megadrive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Aladdin (E) [!].nes
262.160	bytes
CRC32: dcd55bec
MD5: 3485bb2308e405dd6a4e4c299e8c8606
SHA1: 3c15a0e5d3d6f03bc9c864981fca47c5bc2d9478

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --