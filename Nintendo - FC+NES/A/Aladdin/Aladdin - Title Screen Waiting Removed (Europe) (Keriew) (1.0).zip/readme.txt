Disney's Aladdin (Europe) (NES) waiting timer removal.

The patch removes the 20 second waiting timer that happens at the start of the game and whenever player loses all continues.

Made by Keriew.

Original ROM info:
-----------------------
File SHA1	3C15A0E5D3D6F03BC9C864981FCA47C5BC2D9478
ROM SHA1	F1FFBECBC99558EEF25E8C6DB1EEB9C408E2F33E
File MD5	3485BB2308E405DD6A4E4C299E8C8606
ROM MD5	0A4152A81309D82A58D8782E41E5D103
File CRC32	DCD55BEC
ROM CRC32	41D32FD7