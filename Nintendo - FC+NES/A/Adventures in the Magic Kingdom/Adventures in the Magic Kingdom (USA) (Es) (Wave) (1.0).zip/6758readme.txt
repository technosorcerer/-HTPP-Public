Adventures in the Magic Kingdom (NES)
Traducción al Español v1.0 (02/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventures in the Magic Kingdom (USA).nes
MD5: 8839403a475c128e5bb0b1f1a5059352
SHA1: cc8cb9eebaae9c695be7ee965e3c8d7cf82c6d18
CRC32: 300e41b7
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --