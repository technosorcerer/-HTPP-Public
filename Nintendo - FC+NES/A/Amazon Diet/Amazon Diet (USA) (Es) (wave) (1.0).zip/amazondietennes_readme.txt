Amazon Diet (NES)
Traducción al Español v1.0 (01/05/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
amazon_diet_EN.nes
MD5: 230901a7f26a77cf8cc2f097cb3d2370
SHA1: 9e5fc7b94ffb216c69ee5e75674d22a95fe20c59
CRC32: 4db6acdd
524304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --