Nude hack for Minnade Mamotte Knight (Ja) or Gotta Protectors (W).
-Weretindo