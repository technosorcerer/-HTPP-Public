There's a falling frame where the bottom of one boob is missing a black line.
For either Minnade Mamotte Knight (Ja) or Gotta Protectors (W).
-Weretindo