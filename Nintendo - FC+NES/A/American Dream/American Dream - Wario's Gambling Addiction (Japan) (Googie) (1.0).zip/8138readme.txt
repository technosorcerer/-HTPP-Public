Wario's Gambling Addiction - a hack of American Dream by Googie & Friends
-------------------------------------------------------------------------

Arcade-Elite pitched the idea last year to put Wario in the game, so I started with some gfx editing and minor text changes to fit the Wario Theme of him getting all the money. This is the world's first hack of American Dream, so you better enjoy it! ;)
----------------------------------------------------------------------------

To the fellas who helped me make this hack possible...

Dr. Floppy for expanding the ROM to add an extra tile so Wario can be full without him looking funny 

Zynk Oxhyde for his graphic editing and making a kick ass title screen

pacnsacdave for editing the palettes on the title screen

Arcade-Elite for beta testing the hack
--------------------------------------

any feedback you can rech out to me at googietoons(REMOVE THIS)@gmail.com

Feel free to check me out on social media, I'm very active on there

https://beacons.ai/googietoons

See ya's

- Googie

