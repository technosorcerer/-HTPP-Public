"Attack of the killer tomatoes"
Traducci�n al Espa�ol v1.0 (22/03/2017)
 POR JONYVILLA2088

---------------------------
1. Sobre Attack of the killer tomatoes
2. Notas del Proyecto
3. Fallos
4. Instrucciones de Parcheo
5. Derechos
---------------------------

---------------------
1. Sobre Attack of the killer tomatoes
---------------------
"Attack of the killer tomatoes" fue unjuego hecho por THQ en 1991. en la ciudad de San Zucchini es invadido por tomates mutantes liberado por el malvado 
cientifico llamado Dr. Putrid T. Gangreen y su tomate del dia del juicio final.
El protagonista es un ni�o llamado Chad Finletter que esta en busqueda de detener los planes del Dr. Putrid T. Gangreen, pero tendr� que hacerlo solo 
ya que los ciudadanos tienen miedo a los tomates mutantes.
Hay varios jefes para asumir como Zoltan, Beefstake, Mummato, Fang, Ketchuck y Tomacho.
---------------------
2. Notas del Proyecto
---------------------
ESte juego fue traducido al Espa�ol (al menos mediante tablas). 
--------------------------------------------
3. Fallos Conocidos
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a jonathanjavier208@gmail.com 

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Debes utilizar el rom:

killtomt.nes recomiendo buscarla en la p�gina: https://www.freeroms.com
-----------
5. Derechos
-----------
Attack of the killer tomatoes NES es propiedad de THQ (c) 1991.
Traducci�n al espa�ol por JONYVILLA2088.
Licencia de Nintendo de Am�rica INC.
No distribuir la rom y el parche unidos.

Saludos y que disfruten del juego.

