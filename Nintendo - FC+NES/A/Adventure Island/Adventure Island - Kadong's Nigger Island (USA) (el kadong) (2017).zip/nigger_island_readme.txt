"nigger island"
with the longer name "kadong's nigger island"

look, all I did was change some text, palettes, and the title graphics.

you're not paying me for this so i'm not giving you more.

this is the official first romhack of 2017, go fuck yourself rhdn

-el kadong 2 turbo
for 2017 you niggas
