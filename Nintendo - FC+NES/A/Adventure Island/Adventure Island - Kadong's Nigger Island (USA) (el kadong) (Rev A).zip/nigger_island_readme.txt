Kadong's NIGGER ISLAND (Revision A)
a hack of "Hudson's Adventure Island (USA) [!].nes"
by el kadong for baddesthacks.net
---------------------------------------------------

flimsy excuse for a "story"
---------------------------
nigger island is full of niggers
also you are one, and your girlfriend has been stolen by someone who likes
dressing up in various retarded masks.

NIGGER! nigger nigger nigger nigger nigger nigger double nigger fran tarkenton

according to the title screen, these are the credits
----------------------------------------------------
hacking by "nigger soft"
publication and licening by "niggeroo of america, inc."

rom hack changes
----------------
- some graphic changes
- some palette changes
- some text changes
- some nametable changes (but not many)
- start with 5 lives instead of 3
- continue option is always available (hold d-pad and press start)
- title screen attract mode timer shortened from 8 sequences to 6.
  now the demo starts slightly after the song ends.

enemies
-------
- motherfucking rocks
- some fucking snail
- lazy cunts not putting out their fires
- some fucking fire-shooting snake
- some fucking rolling boulders
- some fucking spiders
- icicle spike fuckers
- jim crows
- fucking faggot frogs

the boss is some fucknut that nobody cares about
all he does is change masks.

RAM shit
--------
0x0008 = P1 input
0x0009 = P2 input
0x0037 = current area number
0x0038 = current round number
0x0039 = current section/checkpoint number
0x003F = number of lives
0x0040 = demo playback?
0x006D = current weapon (0=none, 1=hammer, 2 and up=fireball)
0x0076 = health
0x053D = related to continue variable; set to 0xFF to allow continues
