--------------------------Info---------------------------
Game name: Adventure Island
Console: Nintendo entertainment system
Game region USA: (U)
Patcher: Cheat Patcher v1.2 or higher.
----------------------------------------------------------
--------------------------patch------------------------
The patch allows to set following parametres:
 
 Players lives.
 Time does not decrease energy.
 Default run.
 Continues enabled.
  *Press Start button at Game Over screen.
  *Start + direction button, return at title screen.

--------------------Cheat Patcher------------------
Download link:
http://www.romhacking.net/utilities/1112/
----------------------------------------------------------
Author by: Mr2.
e-mail: fsocp@land.ru
http://rgcorp.ucoz.net/