Grave of the Fireflies (V0.99)
by Supergamerguy


Table of Contents:
1. How to patch
2. Changelog
3. Known Limitations and Bugs
4. Background Info
5. Tools Used
6. Explanation of changes






How to patch:
1. Download a patching program like Lunar IPS
2. Download Hudson's Adventure Island (USA).nes
3. Use patching program to apply "Grave of the Fireflies (V0.99).ips" to your
Adventure Island NES ROM
4. Rename new file to whatever you want (Example: Grave of the Fireflies - Adventure Island hack)
5. Use a NES emulator like FCEUX or the FCEUMM core in Retroarch to play!






Changelog:

Version 0.99:
- Finished all sprite edits and replaced most graphics




Known Limitations and Bugs:

- The colors for the boss rooms are off and require a great deal of NES coding knowledge to change, 
so they remain unedited (for now).





Background Info:
This hack was a "quick" break from working on my Howl's Moving Castle hack, 
and popped into my mind after I watched the movie for a second time. I felt 
that a game like Adventure Island, with it's forested, island-like setting, 
would work perfectly with the characters and environment of Grave of the Fireflies 
(with a little bit of creative license thrown in, of course).






Tools Used:
- FCEUX (NES emulator - used to test game and edit color pallettes)
- YY-CHR.NET (used to edit most of the sprites and sprite layouts)
- Tile Layer Pro (used to edit the Title Screen)





Explanations of changes:

Here's some clarifications of what characters, enemies, items, and environmental 
pieces are changed and what they currently represent.


Characters:
- Master Higgins: Seita
- Tina: Setsuko
- Evil Witch Doctor Bosses: Angry Farmer (Rhino replacement), Uncle (Owl replacement), 
Aunt (Cyclops replacement), Soldier (Sabertooth replacement), Doctor (Tiger replacement), 
Bandaged Mom (Oni replacement), Janitor (Kappa replacement), Really Angry Soldier (Jaguar replacement)


Enemies: 
- Snail: Guy pulling a cart
- Bird: Seagull
- Frog: (same, but without spots to be more realistic)
- Snake: Sniper
- Spider: Firebomb
- Bat: (same)
- Skull enemy: Anchor enemy
- Coyote: Farmer (the abusive one in the movie)
- Pig: Sailor
- Octopus: Giant Jellyfish
- Sword Fish: Submarine


Items:
- Stone Hammer: Orange Umbrella (tattered with holes)
- Skateboard: Cargo Cart
- Fireball (powerup): Stones
- Apple: Fruit Drop Can
- Banana: Rice Balls
- Orange: Dirty Fruit Drop Can
- Carrot: Mother's Ring
- Green Melon: Watermelon
- Powerup Egg: Water Canteen
- Invincibility Fairy: Fireflies
- Pot: Jar of Dried Plums
- Bee: Flashlight
- Eggplant: Daikon Radish
- Milk Bottle: Setsuko's Doll
- Key: Seita's Comb
- Ruby Ring: Mother's Kimonos
- Extra Life Doll: Seita
- Flower: Sunflower
- Famicom Controller: Purse
- Background Flower: Summersicle Radish Plant
- Boss Fireball Attack: Rice Cooker


Enviromental Pieces:
- Totem Poles: Telephone Poles
- Ice Statues: Broken and Cracked Ice Walls
- Castle Boss Area: Bomb Shelter
- Castle Candles: Cracked Wooden Planks
- Castle Pillars: Wooden Beams