Ben Roethlisberger's Big Adventure (In Milledgeville, Georgia)

A ROM hack of Hudson's Adventure Island by Assendo.

For info on how to patch the .ips file to a ROM check the FAQ on Badderhacks.net

Take Big Ben on an adventure through the bars and streets and ladies' rooms of Milledgeville Georgia in the quest to find some ass.  Also make sure to keep pounding those beers to keep the buzz going.

Enjoy the game.

Special thanks to:

The Badderhacks.net gang, I'm too lazy to name you all individually but you all know who you are
Dimi Glivver for creating the original Badhacks.net
Ben Roethlisberger for being awesome
and Roger Goodell for giving Ben the most bullshit suspension for a dropped charge, prompting the creation of this game

The following programs were used when making this:

Nesticle
Windhex
Lunar IPS
DirectEd Tile Editor
VirtuaNES


Send questions, comments, hate mail, viruses, death threats, spam mail, and marriage proposals to Assendo2099@yahoo.com



