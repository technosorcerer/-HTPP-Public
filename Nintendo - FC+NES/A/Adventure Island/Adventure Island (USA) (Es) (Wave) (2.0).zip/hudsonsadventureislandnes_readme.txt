Hudson's Adventure Island (NES)
Traducción al Español v2.0 (20/05/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Traducidos gráficos S-G
-Añadidos ¡ÉÓ
-Cambiado BOTE por JARRÓN
-Traducido GAME OVER

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hudson's Adventure Island (USA).nes
MD5: be07098de1de3dc2512b6aa93f23ae3a
SHA1: 22ee75b82f4a6412aa6bb940e109704975b95185
CRC32: b78c09a2
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --