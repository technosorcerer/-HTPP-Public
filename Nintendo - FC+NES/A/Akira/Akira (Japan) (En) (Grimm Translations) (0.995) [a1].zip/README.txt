AKIRA
Patch Version: 0.995 BETA

*Fixed a script error that rendered the game unwinnable.


How to patch:
Obtain a copy of the game. I won't suggest sources, but the file name should be "Akira (J).nes". Note that this is NOT the "Akira (J) [hM04]" floating around.

Once obtained, place the ROM in the same directory as "ROM Expander Pro.exe" and "ROM Expander Pro.txt", and run ROM Expenader Pro.

Select "Expand and Add/Replace Header", and, if your ROM is named "Akira (J).nes", the program will do its magic.

If it gives you an error, then you've obtained the wrong ROM. Keep looking.

Once your Japanese ROM is successfully expanded, you'll want to apply the patch. Using Lunar IPS or something similar, apply the Akira.ips to your newly created Akira.nes.

Ta-da, enjoy the game in English.



Credits:
Major thanks to Pennywise for all his help.
Thanks to Niahak for his hard work translating this monster.
Thanks to the betatesters and to RedComet for his original help.



Akira NES. 2012, a Danktrans Production.