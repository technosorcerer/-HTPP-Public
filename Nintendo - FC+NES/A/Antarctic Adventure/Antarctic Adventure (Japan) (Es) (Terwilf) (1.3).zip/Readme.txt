File ROM      Antarctic Adventure (J) [!].nes

------------------------------------------------------
File MD5      CA098CA3F459F12C830736B95D44503B
File SHA-1    24A1FA7E71F141BA633F12D2EDD419F539F322CB
File CRC32    4CD93A4C
------------------------------------------------------

ROM MD5       68B14B719CD45A06C8DD4F7B5F84D8B8
ROM SHA-1     D8087E7D98E1878DC8828B66A392B296873008EA
ROM CRC32     C745A456

------------------------------------------------------
Changelog
------------------------------------------------------
1.0
Traducci�n del juego con reposicionamiento de punteros y centrado de textos.
Optimizaci�n del primer conjunto de gr�ficos (CHR).

1.1
Traducci�n de la pantalla de t�tulo.
Optimizaci�n del segundo conjunto de gr�ficos (CHR).

1.2
Se incluye un backup que revierte la pantalla de t�tulo a la versi�n original.
El acento que faltaba en la pantalla de t�tulo se agrega.

1.4
El HUD se realinea / El termino "SPEED" se reemplaza por "PRISA" como en la traducci�n de Wave.
Se incluye una versi�n alternativa con el t�rmino "VELOCIDAD", aunque no me gusta y no la recomiendo.

----------------------------------
Contacts |Errors |Bugs |Proposals!
----------------------------------
deviantart.com/terwilf
spriters-resource.com/submitter/Terwilf
twitter.com/ssicosomatic
youtube.com/user/ssicosomatico

------------------------------------------------------
Note 1: It is recommended to use this hack as a basis for future translations, as at the time of publication it is the most complete translation, without drastic modifications of the game.




