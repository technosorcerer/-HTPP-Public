Adan y Eva (NES)
Traducción al Español v1.0 (30/10/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adan y Eva (Spain) (Gluk Video) (Unl).nes
MD5: 262ca833b2b205e0034381a36af5859d
SHA1: 485ef0c7c51d8bb749426c88b70b32040506108a
CRC32: 2c50bf14
65552 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --