"Amagon"
Traducci�n al Espa�ol v1.0 (25/02/2018)
 POR JONYVILLA2088

1. Sobre Amagon
2. Notas del Proyecto
3. Fallos
4. Instrucciones de Parcheo
5. Derechos

---------------------
1. Sobre Amagon
---------------------
"amagon" en japones Totsuzen! Machoman.Es un juego de plataformas de acci�n side-scrolling de la nes. Un infante de marina llamado amagon qued� atrapado en una isla despu�s de que su avi�n se estrellara.
deber� recorrer varios obst�culos hasta llegar al bote de rescate que est� al otro lado de la isla.Se topar� con varios enemigos  y Amagon s�lo dispone de una metralladora.
Amagon tiene la habilidad de transformarse a una forma m�s grande llamada "Megagon" que puede disparar ondas de energ�a de su cuerpo. 
---------------------
2. Notas del Proyecto
---------------------
Este juego fue traducido al menos en tabla(Hexadecimal) a lo mejor posible,aunque no tuve dificultad para traducirlo.
Los signos de admiracion y de interrogacion no se pudo poner en signo � y �. 

--------------------------------------------
3. Fallos Conocidos
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a jonathanjavier208@gmail.com 

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Debes utilizar el rom:

amagon.nes recomiendo buscarla en la p�gina: https://www.freeroms.com

-----------
5. Derechos
-----------
Amagon NES es propiedad de Aicom y American Sammy (c) 1988.
Traducci�n al espa�ol por JONYVILLA2088.
Licencia de Nintendo de Am�rica INC.
No distribuir la rom y el parche unidos.