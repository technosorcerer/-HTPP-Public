Amagon (NES)
Traducción al Español v1.0 (12/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Amagon (USA).nes
MD5: 07cf64f91db3a32e3525f3bec1115c71
SHA1: b38f511063e51d109ed5475b73deb68bf1adab98
CRC32: d1bde95c
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --