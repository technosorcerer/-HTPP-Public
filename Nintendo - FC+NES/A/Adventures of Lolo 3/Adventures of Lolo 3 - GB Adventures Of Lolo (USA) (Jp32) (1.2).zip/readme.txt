-Hack itself-
'Gb Adventures Of lolo' is hack of 'Adventures of lolo 3', made by J^P, Version f1.2.
----


-Patching-
Patch .IPS to "Adventures of Lolo 3 (U) [!].nes" from goodnes 3.14.
---


-background info-
~7 years ago I started to make my lolo hack, called Adventures of lolo gb remix, 
basic idea was to "port" levels from 'Adventures of lolo' on Game boy to lolo 2,
because gb lolo is horribly slow, has terrible music(for most part), looks worse
and its just not fun to play.

And because differences between gb and nes versions, I had to make some changes 
to puzzles to be able to finish them, because of that some levels are bit wider 
or gives you 'extra' bridges or hammers, and that's only because exit in gb 
version can be anywhere in borders(top, bottom, left or right) or touching chest 
ends level, but in nes versions it has to be at the top row, otherwise it just 
doesnt open or work correctly and that was only workaround to the problem and
I didnt want to cut more levels, especially later ones.
---

I've tested this hack this on;
>Virtuanes
>nestopia
>nesticle
>vNes
>Pocketnes
>fce ultra GX
>retro arc
>BizHawk 1.x.x
And everything seems to be working fine, and ALL puzzles are beatable, but if doesnt work
for whatever reason, install gentoo.
---

-Version history-
Version f1.2 (4.7.2015):
>Puzzle 17-2 is now fixed, it was impossible to beat due two water currents missing
and no way to exit after getting to the chest, sorry about that.


Version f1.1 (21.05.2014):
>Fixes some issues on title-screen and intro, instead of just removing "III" from
directly editing graphics, this time around I edited "III" out via hex-editor,
this is to fix issues with intro, as before it was messed-up, but now its
identical to original game.

>Edited order of "HACK BY.." text to make more sense.

Version f1.0 (02.02.2014):
>First public/final release.
---

-Know issues-
>Tutorial rooms demo (go there as lala, press select and choose "Give up") is fucked-up
due changes to their layout, since its currently unknow how it work and nobody knows
how to change them, they will remain bugged.

>On last level, you can get killed by don medusa if you stay on half-way into heart-frame, though
this is issue/bug with game itself how it handles having multiple sprites per row.

>Some levels might require either frame-perfect momentum, save-states OR just being lucky
due leepers/almas/rockys AI being different between GB and NES versions, however all levels
are beatable and I've tested all of them multiple times.
---

-Fun fact-
This hack has exactly:
>144 Snakeys
>134 Medusas
>10  Rockys
>68  Almas
>96  Gols
>27  Leepers
>0   Mobies 
>69  Skulls
>40  Don medusas
...And 588 monsters in total.

For comparison, original lolo3 has:
>184 Snakeys
>228 Medusas
>19  Rockys
>32  Almas
>83  Gols
>43  Leepers
>51  Mobies
>68  Skulls
>45  Don medusas
...And 753 monsters in total.

And finally, Japanese lolo2 has:
>195 Snakeys
>234 Medusas
>23  Rockys
>34  Almas
>84  Gols
>38  Leepers
>43  Mobies
>56  Skulls
>100 Don medusas
...And 807 monsters in total.
---


-Other stuff-
Feel free to play and share this hack, BUT do not sell it any way, or claim it as your own,
or make reproduction of it or shit like that.
---