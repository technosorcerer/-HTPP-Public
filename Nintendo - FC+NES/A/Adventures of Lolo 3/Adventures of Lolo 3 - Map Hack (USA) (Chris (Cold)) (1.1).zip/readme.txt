The Adventures of Lolo 3 : Hack
Version 1.1
November 6, 2010

-----------------------------------------------------
Contents
-----------------------------------------------------
1. Credits
2. Introduction
3. Updates
4. Instructions (How to Use)

-----------------------------------------------------
1. Credits
-----------------------------------------------------
Created the hack : Chris (Cold)
HAL : For creating the game

-----------------------------------------------------
2. Introduction
-----------------------------------------------------
This is the first hack of The Adventures of Lolo 3. It's a small hack that features a few modified levels;
levels A-1 ~ A-5 (tutorial) and 1-1 ~ 3-10. Levels 1-X are quite simple to handle. Levelx 2-X are a little more difficult to manage. Lastly, levels 3-X are the most difficult, with the exception of a few levels I've thrown in there, to deal with. Overall, the hack should not take that long to complete. The rest of the levels after that remain original.

-----------------------------------------------------
3. Updates
-----------------------------------------------------

Version 1.1 - Nov 6, 2010.
- Fixed a few issues with levels. 2-5 was slightly incomplete, there was no way of finishing that map.
- Level 3-4 was also slightly incomplete as well. It would be impossible for players to finish that map.

Version 1.0 - Nov. 6, 2010.
- Hack release.

-----------------------------------------------------
4. Instructions (How to Use)
-----------------------------------------------------
As you can see, in this folder is not only the readme.txt, but also a Lunar .ips file as well. You'll need to find the original ROM someplace, along with the Lunar IPS patcher so that you can patch the ROM. Once that is done, you can play the hack. Good luck, and have fun!

