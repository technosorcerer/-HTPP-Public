Adventures of lolo 3 QoL Improvements
Hack made by JP32
Version 1.0 [06.05.2023]
---

This hack does following:
-Heart frames that contains magic shots are in a different color(green)
-Water currents are now animated and has their own graphics tiles
---

This is intended for the USA version/rom, there is separate patch for the JPN version!
And again PAL is completely untested.
Hacks should work, assuming they dont edit same things I did, just patch QoL hack first, then any other hack,
I've only quickly tested my "GB adventures of lolo" hack.
---

"Water stream" graphics are ripped(edited to fit 8x8, original used three tiles each) from "New ghostbusters 2" nes, also made by HAL too.
---

Patch to following:
USA version:
Adventures of Lolo 3 (USA).nes (NO-intro)
CRC32	E06A060B
MD5	3DC676F6A0D1E400BB4E1BF908E4C46A
SHA-1	FD8551F8B02323D31DCC38DCD69545725D6C0538

Japanese version:
Adventures of Lolo 2 (Japan).nes (No-intro)
CRC32	870A1DD5
MD5	694A1BFA61AF8A29DCCBCDABD68CAA84
SHA-1	FB9DE0A713A4D0CAAFA9935062DE6AD861CB2804

In case you are wondering why JPN is 2 and USA is 3, reason is that USA/EUR had lolo 1, 2 and 3,
but in JPN they only had 1 and 2, but USA/EUR lolo 1 had no JPN release, so they skipped it.
So basically..
USA/EUR		JPN
lolo 1	->	N/A
lolo 2	->	lolo 1
lolo 3	->	lolo 2

Confused yet? Dont get me started on the eggerland games...
---