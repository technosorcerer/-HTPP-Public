Adventures of Lala 2
Hack made by JP32
Version 1.0 [21.05.2023]
---

This hack swaps Lolo and Lala around, and edits palettes&text accordingly.

There are two versions, one for each region. Im too lazy to make another patch for PAL lol.
---

If you want to add my QoL patch too, then patch that first and then patch this one on top of that.
---

Patch to following:
USA version:
Adventures of Lolo 2 (USA).nes (NO-intro)
CRC32	862AB1E5
MD5	0F8EAC497ADC07858685B8E84E59A56B
SHA-1	47D217722BC2375163EBB4B0821DD6EB3ACB38FF

Japanese version:
Adventures of Lolo (Japan).nes (NO-intro)
CRC32	D9C4CBF7
MD5	72A5692523AD5AB51CF2272A06D669D0
SHA-1	355E2A11E6E585DAB55635766C43BC4C0E5D6968

Yes, Lolo 2 USA/EUR is just "Lolo" in japan.
---