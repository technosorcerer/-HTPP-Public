BASE ROM

Adventures of Lolo 2 (USA).nes		No-Intro iNES1.0
Adventures of Lolo 2 (U) [!].nes	GoodNES

Database: No-Intro: Nintendo Entertainment System (v. 20180803-121122)
File SHA-1: 47D217722BC2375163EBB4B0821DD6EB3ACB38FF
File CRC32: 862AB1E5
ROM SHA-1: FD88715A94381179834EEC298F78EC3B51FE43FE
ROM CRC32: 1992D163


This is CSTutor89's hack of the Adventures Of Lolo 2.  The 50 rooms have been changed 
to be more difficult from the original games.  PRO stages are changed [Thanks to Data 
Crystal for pointing out where the data is located].  It starts out fairly simple and 
gets complicated by Level 5.  All of the levels are solveable (done so several times).


If you have any questions let me know here [I will try to get back to you ASAP]:
 - On my Youtube account: www.youtube.com/cstutor89 (best)
 - On my Gmail account: cstutor89@gmail.com  
 - On my Twitter account: www.twitter.com/cstutor89


The last thing I would like to say is, thank you to the following people:
 - bbitmaster for creating Neptune, it is awesome.  
 - Drac Sivak for creating the first hacks for the Adventures Of Lolo 1 & 2, great job
 - Dark_X for writing up a Newbie NES Palette Tutorial.  
 - Nesticle, an old application that really helped find the colors.  
 - Hexpose, a good hex editor.  
 - Inverse who created a General Rom and Title Screen Hacking, it was very inciteful. 
 - OpenSearch which found some of the words in the title screen.
 - Data Crystal's site for providing some data ranges for the PRO levels.
 - And my testers who e-mailed some likes/dislikes about the levels (Thanks!)




*Note* - Try the puzzles, if you have problems with the rooms, comments, or questions, 
let me know.  I can make solution videos or give hints if you really need them.  If 
something is wrong I will try to fix it ASAP.


Update 1.0 (8/14/10):
 - First release of the game.
Update 1.1 (8/22/10):
 - PRO Stages ARE now changed.  Be prepared for a real challenge!
 - PRO Stages have been tested 3 or more times each, there shouldn't be a problem with 
   them.
 - I'm pretty much done with the hack (maybe some minor problems that I don't know of, 
   but it's pretty good).
Update 1.2 (8/23/10):
 - Updated a few of the levels.  Some of the rooms were a little broken (many thanks 
   to one of my testers).
 - Anyone who has been in the tutorial part of the game, can now be spared of seeing 
   2 Rockies.
Update 1.3 (9/5/10):
 - Updated one of the PRO Levels as it had too many shots.  Thanks one of my testers.


I hope you enjoy the puzzles!
 - CSTutor89