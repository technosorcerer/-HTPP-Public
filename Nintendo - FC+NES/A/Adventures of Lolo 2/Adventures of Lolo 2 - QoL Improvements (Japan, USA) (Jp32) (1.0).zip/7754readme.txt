Adventures of lolo 2 QoL Improvements
Hack made by JP32
Version 1.0 [30.04.2023]
---

This hack does following:
-Heart frames that contains magic shots are in a different color(green)
-Water currents are now animated and has their own graphics tiles
---

This is intended for the USA version/rom, there is separate patch for the JPN version!
And again PAL is completely untested.
---

Special thanks to Bbitmaster for the Neptune('s source code), so that I didn't have to hunt for some rom addresses myself.
"Water stream" graphics are ripped(edited to fit 8x8, original used three tiles each) from "New ghostbusters 2" nes, also made by HAL too.
---

Patch to following:
USA version:
Adventures of Lolo 2 (USA).nes (NO-intro)
CRC32	862AB1E5
MD5	0F8EAC497ADC07858685B8E84E59A56B
SHA-1	47D217722BC2375163EBB4B0821DD6EB3ACB38FF

Japanese version:
Adventures of Lolo (Japan).nes (No-intro)
CRC32	D9C4CBF7
MD5	72A5692523AD5AB51CF2272A06D669D0
SHA-1	355E2A11E6E585DAB55635766C43BC4C0E5D6968

In case you are wondering, yes the Japanese version is just "lolo", the USA/EUR lolo 1 had no Japanse version,
and then they made the sequel, which is "lolo 2" in USA/EUR, and then they decided to bring that to Japan too,
and just called that just "lolo" and made brand new levels for it, interestingly you can see the JPN levels in
the USA box's for some reason, and the JPN version has the "2" title screen graphics inside the rom still.

And the USA/EUR lolo 3 is "lolo 2" in Japan, confused yet?
---