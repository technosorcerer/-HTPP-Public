Addams Family nes version hack (version 1.01)

First of all thank you for downloading this ips file. It means a lot to me, because it's my very first project, I'm not a pro, and also because it was a project that I wanted to do for a long time and now with a little more knowledge (and time) I managed to do it.
If you want to complete the game, remember that it is important to collect as much money as you can and that in order to climb some "vertical surfaces" you have to press the up arrow key (not the B button). If you want more detailed information about the game, remember that you can find the game manual online.

For patching the game you can use Lunar IPS.
Remember to do a copy of the original rom before applying this patch.
I have applied the patch on the US version of the game.


What I have done in this hack:

-Changed all the big pictures of the main characters with their "licensed" faces;
-Improved the gallery portraits to resemble more like the original actors;
-Fixed the granny' eyes movement in the gallery;
-Fixed the sprite of Thing in the master bedroom;
-Fixed various tiles in the house like: all the chairs, some shelfs, a crack on the right stair in the lobby, seaweeds in the pond, the moon in a room further in the game;
-Little fix on the sprite of Tully(?), in partricular his eyes. Unfortunately my lack in programming skill it prevented me from being able to insert the lower part of his face (that was originally broken, though);
-Little change on the sprite of the penguin in the freezer level;
-Little changes on the sprite of Fester;
-Improved the sprites of Morticia and Pugsley to be more coherent with the change of their faces;
-Refined the Addams Family logo;
-Improved the faces of the rescued family members in the sub menu, to be more coherent with the changes;

---------------------------------------
Version 1.01

-Added censored crosses in the garden
---------------------------------------


DISCLAIMER
-----------------------------------------------------------------------
This patch may be freely distributed, as long as:
 - The patch remains unmodified
 - This readme file accompanies the patch
 - The ROM image is not distributed with this patch already applied

This patch is not for sale, and is not to be exchanged for money,
goods, or services of any kind.

I won't be held accountable for any damage or undesirable side-effects
this patch may create. Use it at your own risk.
-----------------------------------------------------------------------

Thanks for read it all!

Fray