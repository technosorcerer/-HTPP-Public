Addams Family Easy (NES)

Hacked by Andrei Vdovin a.k.a. Chronix
chronix@bk.ru

* Start with 9 lives.

Original ROM:
-----------------------
Addams Family, The (U) [!].nes
File size: 262 160

 PRG ROM:    8 x 16KiB
 CHR ROM:   16 x  8KiB
 ROM CRC32:  0x65518eae
 ROM MD5:  0x4891ff6840da3f608618c100bc064bba
 Mapper #:  1
 Mapper name: MMC1
 Mirroring: Horizontal
 Battery-backed: No
 Trained: No
