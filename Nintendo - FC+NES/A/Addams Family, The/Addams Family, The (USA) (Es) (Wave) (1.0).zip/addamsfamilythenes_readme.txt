The Addams Family (NES)
Traducción al Español v1.0 (05/12/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Addams Family, The (USA).nes
MD5: 186023fd956cb560706817a96b7bdfa4
SHA1: c831410a86a9b759a1e5ec53e8e1ee6789c79569
CRC32: 08e2af80
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --