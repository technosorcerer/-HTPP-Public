"El Misterio de Atlantis" o "Atlantis no Nazo"
Traducci�n al Espa�ol Ver. 1.0 (07/12/2019)
por Max1323 (maxmuruchi@gmail.com)
---------------------------------------------------
Descripci�n:
El Misterio de Atlantis fue desarrollado por Sunsoft y fue lanzado solo
en Jap�n, se ten�a pensado traerlo a Occidente pero al final se cancel�.
El protagonista es Wynn, un aventurero novato, cuyo objetivo es salvar a
su maestro que esta atrapado en la ultima zona. 

Desarrollado: SunSoft
Publicado:    SunSoft
Lanzamiento:  17/04/1986 (JAP)
                           
---------------------------------------------------
Acerca del proyecto:
Se tradujo los textos y el men�.
Hay dos parches uno con la pantalla del men� traducido y 
el otro contiene la pantalla original.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS

Atlantis no Nazo (J).nes
File Size     48 KB
File MD5      14207AEB5B0AC4D2BC8DB09313403E37        
File SHA-1    B3119ACC91D558C24A8412FF6FD03C40CA9715D1
File CRC32    DCCBE3AE                                

