Arkanoid II Password
Hacked by Andrei Vdovin a.k.a. Chronix
Email me if you find any glitches in my hack.
Thanks in advance!
chronix@bk.ru

Changes:
* Password system (use D-pad to enter password)
* 4 lives instead of 3
* Unlimited continues
* Reduced ball speed acceleration

Now this game is more easy and enjoyable!!! ;))

Original ROM:
------------------
Arkanoid II (J) [!].nes
File size: 262 160

 PRG ROM:    8 x 16KiB
 CHR ROM:   16 x  8KiB
 ROM CRC32:  0x20f98f2a
 ROM MD5:  0x4ac7435428cf3a9478309326cb668081
 Mapper #:  152
 Mapper name: 
 Mirroring: Horizontal
 Battery-backed: No
 Trained: No
