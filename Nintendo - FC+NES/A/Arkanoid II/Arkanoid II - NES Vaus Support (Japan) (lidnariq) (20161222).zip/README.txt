GoodNES 3.14 "Arkanoid II (J) [!].nes"
crc32 c7db2710
md5sum ba64eee98a020760999e43a3650ce0f3
sha256sum 57ee30b96763d9371b9f5f0991c62ea24b4af1c39b5e28e877c72d61a20d8467


Adds support for the NES Vaus controller when playing the Famicom-only Arkanoid 2

(The game already supported it, it just treated it as player 2 which was only usable in PvP Vs mode)

To play with the Vaus instead of the joypad you must start the game using the button on the Vaus controller.