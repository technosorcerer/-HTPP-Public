The Adventures of Captain Comic
Music Correction, Restoration, and Expansion Patch (v1.0)

Hacking and music programming by P. Fredericks

Released:      2020-03-19
Format:        IPS patch
Target ROM:    Adventures of Captain Comic, The (U) [!].nes
CRC32:         9357A157

--------------------------------------------------------------------------------

****************************
I.  ABOUT THE GAME
****************************

The Adventures of Captain Comic was originally released in 1988 for DOS, where it was well-received (and was followed by a sequel in 1990). In 1989, it was ported to the NES and released by the infamous unlicensed publisher Color Dreams.

While most of Color Dreams's games are considered to be poor, Captain Comic is an exception, with solid platforming controls and very decent graphics. Though the gameplay is fairly repetitive, with endless streams of enemy grunts and no boss fights, the game's non-linear structure and light puzzle-solving elements help to keep things fresh.

****************************
II.  ABOUT THE MUSIC
****************************

The original DOS release had minimal sounds and music, but the NES version adds an extensive soundtrack that's entirely made up of pieces of classical music, ranging from the famous (J. S. Bach's Toccata and Fugue, Grieg's In the Hall of the Mountain King) to the relatively obscure (little-known keyboard works by Handel and W. F. Bach).

The game's simple music engine allows for a two-part texture, with one pulse wave channel for the melody and the triangle wave for the bass. Judye Pistole is credited as the game's sound designer, and presumably its music programmer.

Research by scholar William Gibbons has revealed that four of the more obscure pieces in Captain Comic were taken directly from a 1960 book of sheet music called More Easy Classics to Moderns, compiled by Denes Agay and arranged for beginning pianists.

(See Gibbons's article "Blip, Bloop, Bach?" for more information. The music to Captain Comic is also discussed in Dana Plank's article "From the Concert Hall to the Console: Three 8-Bit Translations of the Toccata and Fugue in D Minor".)

The advantages to an all-classical soundtrack are obvious: you don't have to hire a composer per se, since you already have a library of instantly recognizable, public-domain melodies by some of history's most renowned composers. And many of the tunes will already be familiar to players, and by using a compilation meant for beginning pianists, many of the textures have already been simplified. 

However, almost every single piece suffers from serious errors in transcription. Even the most famous pieces have incredibly obvious wrong notes, while some of the more obscure pieces were misread so badly by the transcriber that the entire key signature of the song was ignored, leading to a weird mishmash of two different keys -- or, in another case, of minor and major.

On numerous occasions, the melody and bass get completely out of sync with each other -- most obviously in the Bach Toccata and Fugue, but in several other pieces as well. Many pieces also have bizarre jumps in register, with parts suddenly leaping up or down an octave for no particular reason.

Finally, the sound designer made some strange decisions about where to loop certain melodies, or which parts of the piece to use -- sometimes choosing to end a piece with a measure that's only meant to lead back to the piece's midsection, which can lead to weird discords unintended by the composer.

All in all, while some of the music in Captain Comic is of acceptable quality, a great deal of it is embarrassingly poor, and undermines the presentation of what's otherwise a very solid exploratory action-platformer.

****************************
III.  RESOURCES I USED
****************************

I've wanted to do something about the music in Captain Comic for some time. I'm not a programmer, but can make sense of code if given enough context.

However, my initial attempts at hacking the game in 2018 were futile, and I put the project on hold...

...until I discovered that the game's source code -- which had been auctioned on Ebay in 2012 -- was uploaded to Archive.org in November 2019. Having the source code made it infinitely easier to understand the game's music engine and to locate the blocks of music code in the Captain Comic NSF. A million thanks to whoever uploaded it.

Four other things were absolutely invaluable in doing this hack:

1. The Captain Comic NSF, which allowed me to focus on understanding the game's music data without having to navigate other things in the ROM. I hacked the NSF first, then applied the changes to the full ROM.

2. A PDF of More Easy Classics to Moderns, which was uploaded to a well-known file sharing site. The person who shared this one has my gratitude: this made it so much easier to identify the melodies and the errors made in programming them.

3. To identify the melodies not found in More Easy Classics to Moderns (and that I didn't otherwise know), I used the old book A Dictionary of Musical Themes. With this, I ID'd a melody by Franz Schubert (which I might have found on my own) and one by François-Joseph Gossec (which probably would have eluded me for years).

4. Finally, the celebrated website IMSLP allowed me to examine the scores to those pieces that weren't taken from More Easy Classics to Moderns. While it stinks that they've added a 15-second delay before allowing you to download, it's still a wonderful resource.

****************************
IV.  ISSUES IN THE MUSIC
****************************

Here's a listing of the pieces in Captain Comic:

NAME (SOURCE CODE)     COMPOSER         REAL TITLE                         M.E.C. TITLE
------------------     --------         ---------------                    ------------

aria/[Title Screen]    Handel, G.F.     Aria (Air) from Suite, HWV 428     Aria
rigd/Forest Music      Handel, G.F.     Gavotte in G major, HWV 491        Rigaudon           
rondo/Lake Music       Mozart, W.A.     Rondo alla Turca, K331/III         n/a
blued/Moon Music       Strauss, J.      The Blue Danube Waltz              n/a
march/Base Music       Schubert, F.     No. 1 of 3 Marches Militaires      n/a
mking/Cave Music       Grieg, E.        In the Hall of the Mountain King   n/a
bmble/Shed Music       Rimsky-Korsakov  Flight of the Bumblebee            n/a
toc/Comp Music         Bach, J.S.       Toccata and Fugue in D minor       n/a
burl/Castle Music      Bach, W.F.       Allegro non troppo Fk 203          Burlesca
ales/[Ending]          Handel, G.F.     Impertinence, HWV 494              Aylesford Piece
super/[Invincibility]  Gossec, F-J.     Gavotte in D major, RH 318         n/a

(Note: the Handel Gavotte is sometimes known as Aylesford Piece No. 6, while Impertinence is also from the Aylesford collection and has been called Gavotte in G minor by a few sources. Confusing!) 

Of these, the only one that needed no fixes was the Gossec. I'd divide the others into five categories:

(1) Minor adjustments: fixing one or two wrong notes, tweaking a rhythm, getting rid of a couple of octave displacements. This was the case for the Handel Aria, the W.F. Bach Burlesca, and the Schubert Marche Militaire (but see Section VI, below).

(2) More substantial fixes, with a bunch of wrong notes or a lot of weird octave displacements fixed, but the basic structure of the song unchanged. I'd put the Mozart and the Grieg in this category.

(3) Large-scale fixes in which the melody and bass drift way out of sync and some rewriting was required, but the basics of the original composition were mostly intact. The Strauss and Rimsky-Korsakov fit this description; both start out OK but later go off the rails.

(4) Pieces that are recognizable, but mangled so badly -- with out-of-sync parts, rhythm errors, and wrong notes -- that it's hard to believe anyone would believe the results were acceptable. That's the Bach Toccata, which includes at least one passage that seems to have been completely made up by the transcriber. 

(5) Cases where the transcriber got the key signature of the song completely wrong, with the result almost becoming a completely new piece (with bunches of questionable notes). The Handel Gavotte and Impertinence were both butchered by this process.

****************************
V.  FIXING THE MUSIC
****************************

My basic attitude toward the fixes was to maintain the character of the game's music as much as possible, while correcting anything that seemed like a clear mistake or misjudgment. In other words, my aim wasn't to second-guess the arrangements, but simply to fix what was obviously wrong, and restore the intent of the original composer while keeping the basic arrangements chosen by the game's sound designer.

However, in some cases I transposed one of the parts up or down an octave, to allow for the original melody to play without weird leaps in register.

Also, in cases like the Handel Gavotte and Impertinence where the transcriber had clearly misread the original sheet music, I opted to restore the original composition. This is a double-edged choice, since I've grown somewhat attached to the wrong-note quirkiness of the first level theme (the Gavotte). The "correct" version is cleaner, but also somewhat less interesting.

Meanwhile, restoring Impertinence meant changing its key from major (albeit a major full of sour notes) back to minor. That means that the game's victory theme is now in a minor key, which is a bit odd, though it has a certain regal stateliness as a result.

Once I understood the game's music engine, the majority of the fixes were relatively easy. The most time-consuming were the Bach Toccata, which required massive rewriting to fix, and the Flight of the Bumblebee, which simply had so many notes that it was a bear to navigate.

In Flight of the Bumblebee, I also think the sound designer and/or music programmer ran out of space, since the melody fills up almost all of the allotted space, leaving very little for the bass line. As a result I wasn't able to restore the original bass part from Rimsky-Korsakov, and had to use a very simplified part instead.

Space limitations also kept me from fixing one or two tiny details in the melody of W. F. Bach's Allegro non troppo (aka Burlesca), as I ran short by a few bytes. If I understood more about pointers, I might be able to redistribute the available space between the melody and bass parts, since there's extra blank space in the bass part -- but I wasn't able to figure it out.

****************************
VI.  ADDING MORE MUSIC
****************************

As I worked on the Schubert Marche Militaire, I found that the music was mostly OK and needed very few fixes, but the tune loops in a really weird place that doesn't make a ton of musical sense. If they'd only gone on a bit longer, they'd have reached a much more natural place to repeat back to the beginning.

I also noticed the section of the ROM with the Schubert piece had a bunch of leftover space.

Hmmm....

Long story short, I've added an additional 20 seconds or so of music, taken directly from the Schubert score, to the game's soundtrack. This allows for a much more natural loop point, and of course has the fringe benefit of making the music take somewhat longer to repeat.

Miraculously, the added music fit -- just barely -- into the available space, though I had to simplify one tiny detail in an earlier section of the melody to scrounge up a few extra free bytes.

****************************
VII.  CONCLUSION
****************************

The sound engine in Captain Comic is so clear-cut, and the changes I've made are so straightforward, that it's hard to imagine anything I've done would impact gameplay. 

Still, just to be sure, I played through the patched version of the game from beginning to end, and encountered no technical problems or other glitches.

I've always had a soft spot for Captain Comic ever since renting it as a kid in the early 1990s. I didn't beat it then, but -- if this gives you some idea of how much it stuck with me -- it was the first video game I ever bought on Ebay, all the way back in 1999. Getting that blue cartridge in the mail was, in a way, my first experience as a retrogamer.

I finally completed Captain Comic shortly afterward. Though I quite enjoyed it, part of me couldn't help but lament the butchered soundtrack. Only in recent years did I realize just how butchered it was: I always knew the Toccata and Mountain King were bad, but I never heard the "real" Handel Gavotte or Impertinence until recently.

I hope that, by clearing out some of the jank and discord in the game's soundtrack, this patch can help players to appreciate Captain Comic a bit more. I still think it's Color Dreams's best game, and a really well-done port from DOS. For me completing this project is a long-held dream, and feels like righting a very old wrong!

Released: 2020-03-18
(README updated 2020-03-19 to correct a few errors)