The Adventures of Captain Comic
Traducci�n al Espa�ol v1.0 (06/07/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Notas del Proyecto
2. Fallos Conocidos (o: Bugs que no son bugs)
3. Instrucciones de Parcheo
4. Cr�ditos del Parche

---------------------
1. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
2. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
3. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Adventures of Captain Comic, The (Color Dreams) [!].nes
131.088	bytes
CRC32: 9357a157
MD5: ccdb987e5f0ded02fd4fe31d81a52f97
SHA1: 8763d97d889e8d2ca4d4f3369f94e5173025580a

----------------------
4. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --