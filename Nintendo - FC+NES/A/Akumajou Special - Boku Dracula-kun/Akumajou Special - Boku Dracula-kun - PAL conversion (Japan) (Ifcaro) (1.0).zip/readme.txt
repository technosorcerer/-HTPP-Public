Akumajou Special - Boku Dracula Kun
NTSC to PAL conversion
Version 1.00
Created by Ifcaro [http://www.ifcaro.net]
------------------------------------------

Adaptation of scanline effects to work on PAL systems. Due to differences in CPUs, some graphical glitches may appear, but it's perfectly playable.

Tested on a PAL NES NESE-001.

Version History:
-----------------
 Version 1.00, April 28, 2024
 First release.