Akumajou Special - Boku Dracula Kun 
Demon Castle Special - I'm Kid Dracula!
Spanish Translation Patch
Version 1.00
------------------------------------------

Hacking and translation by Ifcaro [http://www.ifcaro.net]

Version History:
-----------------
 Version 1.00, July 16, 2015
 First release.
 
------------------------------------------

Based on English versions by Vice Translation & Kalas.

Credits of Vice Translation
-----------------
 Kitsune Sniper
  Game hacking, font insertion and preliminary translation.
  Email: kitsune_sniper [at] hotmail [dot] com

 KingMike
  ASM suggestions [also my personal savior]

 Akujin
  Main Translator

 D-Boy, Ian Kelley, Tomato
  Secondary translation

 Scheurbert [http://www.lvl99.com/]
  Title and ending screen design

Credits of Kalas Translation
-----------------
 Kalas [kalas@bellsouth.net] //Hacker & Translator
 DarkMazda, Faraday          //Translators