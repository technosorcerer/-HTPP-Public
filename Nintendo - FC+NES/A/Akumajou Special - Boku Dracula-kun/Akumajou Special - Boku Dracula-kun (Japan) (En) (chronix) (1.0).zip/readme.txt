Kid Dracula Eng (NES)

Translated by Andrei Vdovin a.k.a. Chronix
chronix@bk.ru

This translation is a mix of previous translations with some nice improvements.

Original ROM:
-----------------------
Akumajou Special - Boku Dracula-kun (J) [!].nes
File size: 262 160

 PRG ROM:    8 x 16KiB
 CHR ROM:   16 x  8KiB
 ROM CRC32:  0xc1fbf659
 ROM MD5:  0x96084e640ed9a02c644b39986c269662
 Mapper #:  23
 Mapper name: Konami VRC2/VRC4 C
 Mirroring: Horizontal
 Battery-backed: No
 Trained: No
