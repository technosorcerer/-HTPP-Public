***PL***
Dzi�kuj� za pobranie tego t�umaczenia gry Hudson's Adventure Island II na NESa!
Cz�� ta jest najbli�sza moim sercu i by� mo�e jedna z moich najulubie�szych gier!
Mam nadziej�, �e i ch�tni spr�bowania AI2 pokochaj� t� cz��.

�eby zainstalowa� t�umaczenie nale�y posiada� tylko program Lunar IPS oraz oryginalny ROM gry (w wersji USA).

Mi�ej zabawy!
~Piotrek1113

***ENG***

Thank you for downloading this translation of Hudson's Adventure Island II for the NES!
This second game in particular is my all-favourite!
I hope that many of you that try this game will fall in love as I did!

To install this translation you need only Lunar IPS and original ROM of the game (USA version).

Have fun!
~Piotrek1113