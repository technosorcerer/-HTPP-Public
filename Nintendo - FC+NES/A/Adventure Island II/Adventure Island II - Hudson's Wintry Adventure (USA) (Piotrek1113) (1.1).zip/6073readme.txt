***PL***
Dzi�kuj� za pobranie tego hacka gry Hudson's Adventure Island II na NESa!
Hack ten podmienia wszystkie palety kolor�w poziom�w na te z czwartej wyspy.
Rodzaje poziom�w nie wyst�puj�ce na lodowej wyspie dosta�y w�asne, oryginalne palety, kt�re odwzorowuj� zimow� atmosfer�.
Natomiast �nie�na ju� wyspa 4 dosta�a w zamian unikatowe barwy.

�eby zainstalowa� hacka nale�y posiada� tylko program Lunar IPS oraz oryginalny ROM gry (w wersji USA).

Mi�ej zabawy!
~Piotrek1113

***ENG***
Thank you for downloading this hack of Hudson's Adventure Island II for the NES!
This hack swaps every stage color palettes to match stages found in World 4.
Other stages not found in World 4 become own, original palettes that give that wintry atmosphere.
But already snowy World 4 got unique colors instead.

To install this translation you need only Lunar IPS and original ROM of the game (USA version).

Have fun!
~Piotrek1113