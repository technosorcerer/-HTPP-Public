Adventures of lolo 1 QoL Improvements
Hack made by JP32
Version 1.0 [30.04.2023]
---

This hack does following:
-Heart frames that contains magic shots are in a different color(green)
-Water currents are now animated and has their own graphics tiles

The "1x3" also adds on top of that:
-Graphics from Lolo 2&3
-Adjusts the purple enemy palette to black&white
---

This is intended for the USA version/rom, PAL is completely untested.
---

Special thanks to Bbitmaster for the Neptune('s source code), so that I didn't have to hunt for some rom addresses myself.
"Water stream" graphics are ripped(edited to fit 8x8, original used three tiles each) from "New ghostbusters 2" nes, also made by HAL too.
---

Patch to following:
Adventures of Lolo (USA).nes (NO-intro)
CRC32	D9C4CBF7
MD5	72A5692523AD5AB51CF2272A06D669D0
SHA-1	355E2A11E6E585DAB55635766C43BC4C0E5D6968
---