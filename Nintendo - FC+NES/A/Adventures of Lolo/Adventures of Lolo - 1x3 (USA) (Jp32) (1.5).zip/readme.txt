Adventures of lolo 1x3 is hack of Adventures of lolo 1, made by J^P. 
This is rather simple graphics hack, it replaces most of lolo 1 graphics from its sequels,
giving it more "modern" look, it was lazy copy&paste job but it did end up look quite nice.
---

Patch it to "Adventures of lolo 1 (U) [!].nes" from goodnes 3.14.
---

I had fun making this and I hope you have too, but dont skip levels if you get stuck,
this first one is rather easy(outside of that one fucking level that gave me nightmares
as kid) and puzzles dont get that hard until last two floors, but if you do use, you should feel bad.
---

This is version 1.5, no know glithes/bugs.
This version fixes palette for Rocky/Alma/Medusa/skull to match their palette on lolo 2/3, and 
replaces some graphics I overlooked to their lolo 2/3 versions, plus I added some uppercase letters
and edited text little, but I only could add ~6 uppercase letters due lack of space, thankfully this
game had some unused tiles so I could at last add some of them..
---

I tested hack this on;
>Virtuanes
>nestopia
>nesticle
>vNes
>Pocketnes
>fce ultra GX
>retro arc
+Syncs with lolo1 TAS made by Baxter & Zugzwang
...and everything seems to be working fine, but if doesnt play for whatever reason, install gentoo.
---

You can use this hack any way you want, BUT do not sell it any way or claim it as your own,
or make reproduction of it and stuff like that.
---