Adventures of lolo 1 QoL Improvements
Hack made by JP32
Version 1.5 [09.05.2023]
---

This hack does following:
-Heart frames that contains magic shots are in a different color(green)
-Water currents are now animated and has their own graphics tiles

The "1x3" also adds on top of that:
-Graphics from Lolo 2&3
-Adjusts the purple enemy palette to black&white
---

There are two patches, one for USA version and another for EUR version.

Fun fact, did you know that HAL typo'd their own company name in the European version? Its "HAL LABORATORY INC" in USA version, but in European version its "HAL LABORATOAY" lol.
I only noticed it when I ported graphics from my "1x3" hack to the European version and double checked title screen as EUR version has some extra tiles USA doesn't ("," and "0")..
---

Version 1.5:
-Included "source code"
-Included PAL version too

Version 1.0:
-Initial release
---

Special thanks to Bbitmaster for the Neptune('s source code), so that I didn't have to hunt for some rom addresses myself.
"Water stream" graphics are ripped(edited to fit 8x8, original used three tiles each) from "New ghostbusters 2" nes, also made by HAL too.
---

Patch to following:
USA:
Adventures of Lolo (USA).nes (NO-intro)
CRC32	D9C4CBF7
MD5	72A5692523AD5AB51CF2272A06D669D0
SHA-1	355E2A11E6E585DAB55635766C43BC4C0E5D6968

EUR:
Adventures of Lolo (Europe).nes (NO-intro)
CRC32	773510BB
MD5	C822D0E86260B195A472EDD06F28667D
SHA-1	D37C8003BF052404248FFACA106F7D32C75C8076
---