Adventures of Lala 1
Hack made by JP32
Version 1.0 [19.05.2023]
---

This hack swaps Lolo and Lala around, and edits palettes&text&title-screen accordingly.

No PAL patch as I already have too many variations of all these damn Lolo games lmao.
---

There are three patches:

Original graphics:
-Least amount of graphical&palette changes
(lala is just an color swap)

1x3:
-Replaces all graphics from lolo 2&3
-Adjusts the purple enemy palette to black&white

1x3 QoL:
-Heart frames that contains magic shots are in a different color(green)
-Water currents are now animated and has their own graphics tiles
---

Patch to following:
Adventures of Lolo (USA).nes (NO-intro)
CRC32	D9C4CBF7
MD5	72A5692523AD5AB51CF2272A06D669D0
SHA-1	355E2A11E6E585DAB55635766C43BC4C0E5D6968
---