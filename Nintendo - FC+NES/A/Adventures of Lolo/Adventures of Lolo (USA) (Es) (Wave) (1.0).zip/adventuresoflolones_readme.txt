Adventures of Lolo (NES)
Traducci�n al Espa�ol v1.0 (27/01/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventures of Lolo (U) [!].nes
MD5: 72a5692523ad5ab51cf2272a06d669d0
SHA1: 355e2a11e6e585dab55635766c43bc4c0e5d6968
CRC32: d9c4cbf7
65.552 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --