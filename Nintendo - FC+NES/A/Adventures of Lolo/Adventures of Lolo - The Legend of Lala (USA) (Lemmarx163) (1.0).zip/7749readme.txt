The Legend of Lala
Hacked by Lemmarx163 
2023


----------------
Description
----------------
This is a sprite hack of The Adventures of Lolo for the NES based on The Legend of Zelda.


----------------
Story
----------------
Lala and Lolo were venturing in Hyrule when Lala eventually got caught by Ganon. Link stepped in to face Ganon and save the princess Lala.


----------------
Zip
----------------
The Legend of Lala.ips
Readme.txt


----------------
Utilities
----------------
Mesen 0.9.8
yychr 20210606
Lunar IPS 1.03