The Legend of Lala  
Hacked by Lemmarx163  
2023  

---  
**Description**

This is a sprite hack of The Adventures of Lolo for the NES based on The Legend of Zelda.  

---
**Story**

Lala and Lolo were venturing in Hyrule when Lala eventually got caught by Ganon. Link stepped in to face Ganon and save the princess Lala.  

---
**Files**

The Legend of Lala.ips  
README.md

---
**ROM / ISO Informations**

Database match: Adventures of Lolo (USA)  
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)  
File SHA-1: 355E2A11E6E585DAB55635766C43BC4C0E5D6968  
File CRC32: D9C4CBF7  
ROM SHA-1: ADFE24B8CFB6411DDEA238058D027EC0458FA3C4  
ROM CRC32: 71BF075F  

---
**Online Patcher**

https://www.romhacking.net/patch/

---
**Utilities**

Mesen 0.9.8  
yychr 20210606  
Lunar IPS 1.03  
