Terima kasih sudah Download!

Ini adalah file patch dari Game NES "Arkanoid"
Ada 2 file di dalamnya, dari versi USA dan Japan...

Progress: 99,8%
Hanya kurang teks "PLAYER 1/2 READY" dan "GAME OVER"
Karena itu termasuk bagian dari teks grafik, jadi
aku belum bisa mengubahnya..

Perbedaan:

Versi USA: 
-ROUND=BABAK
-HIGH SCORE=NILAI TINGGI

Versi Japan: 
-ROUND=RONDE
-HIGH SCORE=SKOR TINGGI


Cara patch: Gunakan aplikasi "Unipatcher.apk" 
atau Rom patcher apa saja untuk mengubah ROM "Arkanoid" yang original menjadi ke "Bahasa Indonesia"

#########################
#########################


Thank you for download!

This is a patch file from the game NES "Arkanoid"
There are 2 files in it, from the USA version and Japan ...

Progress: 99.8%
Only lack text "Player 1/2 Ready" and "Game Over"
Because it includes part of the graph text, so
I can't change it yet ...

Difference:

USA version:
-ROUND=BABAK
-HIGH SCORE=NILAI TINGGI

Japan version:
-ROUND=RONDE
-HIGH SCORE=SKOR TINGGI


How to Patch: Use the "Unipatcher.apk" application
or any Patcher ROM to change the original "Arkanoid" ROM to "Indonesian"


Visit: https://afjackaurevoir.blogspot.com

