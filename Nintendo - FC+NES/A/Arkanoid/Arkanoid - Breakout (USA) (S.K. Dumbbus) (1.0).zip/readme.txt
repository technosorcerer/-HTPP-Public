Breakout is a hack of Arkanoid for the NES


What the patch adds to the game
A new title Screen 
35 altered new levels
Text, gamecode and other Graphic changes


Level hacking was done using Arkalavista version 1.2, 
all hacking was done by Me_Dave, graphics, levels, text, etc.

This release is what I call the easy version "infinite lives Enabled", and 
because some levels are super easy while others are gruling but either way 
all 35 levels have been changed. it will still take you an hour or two to beat 
the game with Infinite lives. in addiction to that there is a new title screen, 
an altered story, and some new graphics.
in this version you are given infinite lives.

in the future there may come a harder version, but maybe not. 
For now this is the only version that is completed.

The Patch Breakout.ips Applys Over Arkanoid (U) [!].nes


Rom ISO Info
Arkanoid (U) [!].nes
CRC32: 32fb0583 
SHA: 230FC31D2C2EB20E78711C82574F29F28117EBA3 
MD5: 0ccc1a2fe5214354c3fd75a6c81550cc

Text, Graphics, Levels, and Code Hacking: Me_Dave

Special Thanks goto
Trax for making Arkalavista if not for it this hack would have never been Finished. 

Tony Hedstrom for his HowtoHackNESROMs Document, used to add infinite lives.

My Apple iBook G4 that helped in running arkalavista.

 

  

  


 