Phantasy Star "?" The Hopeless

Is a hack of Air Fortress for the nes, a game that wishes it was Phantasy Star 
this patch is as close as it'll get to being a Phantasy Star Game, it's called 
hopeless for a reason the concept just doesn't fit with the games engine.

But here it is anyway Air Fortress meets Phantasy Star, with a new title screen, 
altered text, a mostly replaced story, and the end game text has been changed. 
There are 91 different hunks in this patch of only 3kb in size. 

The first and only Phantasy Star that is not an rpg. 

enjoy.. 


Hacking, Dave Augusta
http://meklowner.tripod.com/klownersromhackingpage/

Special Thanks goto
Inverse of zophars domain for his Theory Of Relative Searching, 
although wasn't need for hacking this game it helped with the 
making up of the story from looking at another game were I had used 
relative searching to make a table file for viewing the in game text.

That is all..
 

