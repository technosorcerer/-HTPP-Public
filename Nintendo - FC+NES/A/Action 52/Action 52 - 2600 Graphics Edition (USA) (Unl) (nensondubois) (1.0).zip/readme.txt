Presenting an equally effortless hack, just as the original game was, completely changing all graphics to look how they would if Action 52 was released for the Atari 2600.

Changes - All graphics including the intro screen, game selection screens (including names, you sort of have to remember what games are which as a trade-off for this type of hack.) The intro screen was also changed to be as pure as possible. Palettes were also changed so that sprites are now visible.

Action 52 (unl).nes - This hack was made using REV B as it contains the fewest amount of glitches, and also because it fixed Alfredo and Jigsaw allowing both games to play.

Notes - All games are fully playable.

Action 52 atari 2600 graphics edition v1.0 by nensondubois 2020. 

Please consider supporting my past, present and future projects at patreon.com/nensondubois.

Stay tuend for several more game modifications. :)

eof