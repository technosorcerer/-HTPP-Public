Action 52 (NES)
Traducción al Español v1.0 (17/08/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Action 52 (Active Enterprises) (REVA) [!].nes
MD5: dcd2c8fd954effd36c47440980499261
SHA1: 67af5fc47f5a93485e900f22ce302f6f61b5c709
CRC32: 7fa90614
2097168 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --