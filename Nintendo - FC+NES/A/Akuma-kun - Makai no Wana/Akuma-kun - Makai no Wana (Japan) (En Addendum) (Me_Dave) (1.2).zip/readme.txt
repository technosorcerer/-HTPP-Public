This is a Addendum of my own Translation of Akuma-kun: Makai no Wana.

It is not a update, The main thing this does is makes a old Man
whom will join your party tell you what to do in the game.

it is for a very short part of the game. 
Because after that I do not Know what you are suppose do.

this does fix a few other minor things like the demons in the Game
have Moods and sometimes they get mad at you when you call them and 
will run away. There was a item you already had that you use to on
them to fix their mood. Fixmood is what it is called in this patch..

It also changes a few menu items and is like a Alternative version.

The Patch only applys over a rom that has been prepatched 

with either
Devil Boy - Trap Of Hell [T-eng PATCH].ips 

or
Devil Boy - Trap Of Hell [JAPAN PATCH].ips




   




     