This is a work in progress translation of Akuma-kun - Makai no Wana for the NES.

this is a basic English menu and shops patch with some other misc text fixes, 
I had altered the title screen but removed it because it needs to be reworked, 
and I haven't gotten to doing that yet. So well with this patch you can play the game, 
and tell more of what you are doing in it for the most part. Enjoy.


A lot of work went into this, and hopefully there will be a better patch late in 2014.


Hacking 
Dave Augusta

Main Translation
Tomato

Other Translation
KingMike

Patching Info
Akuma-kun - Makai no Wana (J) [!].nes
CRC32: 2C4421B2
MD5: 53E7AECF 302C3ACB C4460109 3333EDAE
SHA1: 869C2F50 F936C17C B1B13E90 16E44E47 4137A320




