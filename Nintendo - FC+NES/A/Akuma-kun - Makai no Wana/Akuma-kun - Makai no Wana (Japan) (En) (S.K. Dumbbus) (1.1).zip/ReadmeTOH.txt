Well this is an update that changes the Title Screen to include The English Title


DEVIL BOY - TRAP OF HELL


there are 2 patches one that applys of the unaltered Japanese Rom and Another 
That applys over the prepatched dboybeta rom 


Devil Boy - Trap Of Hell [JAPAN PATCH].ips 
applys over  Akuma-kun - Makai no Wana (J) [!].nes
CRC32: 2C4421B2
MD5: 53E7AECF 302C3ACB C4460109 3333EDAE
SHA1: 869C2F50 F936C17C B1B13E90 16E44E47 4137A320


Devil Boy - Trap Of Hell [T-eng PATCH].ips 
applys over Akuma-kun - Makai no Wana (Dboybeta) [!].nes
ROM CRC32: d19e3506
ROM MD5: 59d6ce8d1c3ddfe57e8dddf403fe6653
SHA1: 83BF99430D1EBCEB4C1A89C10EE6AEB24F2B8110  

Hacking 
Dave Augusta [Me_Dave]

Main Translation
Tomato

Other Translation
KingMike



