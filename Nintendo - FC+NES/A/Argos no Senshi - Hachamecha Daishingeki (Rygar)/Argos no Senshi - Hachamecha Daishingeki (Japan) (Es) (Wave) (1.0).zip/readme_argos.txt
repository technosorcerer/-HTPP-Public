Argos no Senshi
Traducci�n al Espa�ol v1.0 (09/12/2016)
(C) 2016 Wave Translations

---
TdC
---

1. Sobre Argos no Senshi
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Argos no Senshi
-----------------
Juego de accion aventura, conocido como rygar, en la version japonesa tiene mejor audio.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking esta basada en una de Toma al ingles.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Argos no Senshi (J).nes
131.088	bytes
CRC32: d2bbb3ee
MD5: b7631eb5ac42543e3cddf6816aae1bf8
SHA1: b172cc8037288f658193cc583d1f0f499c959139

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --