-------------------------------------------------------
-BlackPaladin's The Warrior of Argus translation patch-
-------------------------------------------------------

*****************************************
*Argos no Senshi: Hachamecha Daishingeki*
*****************************************

Argos no Senshi was originally an arcade game in which you control a ressurected warrior who is chosen by the gods to defeat the beat king, Liger.  However, when the game was ported to the Famicom, the game was changed drastically.  Instead, game was changed into an action-adventure game, bordering on being an Role-Playing Action-RPG.  An overworld map was added with several different locations in which you fight to save five Indoras, all of whom can give "The Warrior of Argos" the power to reach the Sky Fortress and defeat the Beast King, Ligar. 

Tecmo did localize this this game in the United States and Europe under the name, "Rygar".  (The arcade game this game based on was also localized as "Rygar.)  However, the music in the Japanese version of the game is different compared to its localized counterparts.

This patch comes in two different flavors...

The Warrior of Argos (English).ips
--English Translation Patch (IPS Format)
The Warrior of Argos (English).bps
--English Translation Patch (BPS Format)

The patch requires the ROM with the following hashes...

File SHA-1: 5E1A2BC557EDA5F5341E27D734B4E857AB6B6F1C
File CRC32: 457C6C32
ROM SHA-1: F110AE847049723DB4AC9213A8EC5BFD23E644F2
ROM CRC32: E1B260DA

Use either the IPS or the BPS patch to get the ROM with the following hashes (Don't use both patches.)

File SHA-1: E9BBBB74A97C629EE3377AB993A629AB8FA68E2D
File CRC32: 21A9B33B
ROM SHA-1: A18C81475E08BC2B778E24E984183AD411E2C61B
ROM CRC32: 8567BFD3

What's done?

Translated Title Screen
All Japanese text translated and inserted
Ending text re-written to be more understandable

v1.0

Initial Release

************
*Known Bugs*
************

If the player presses the start button to get to the pause menu while the player's diskarmor is extended, you can see artifact tiles in the pause menu.  This will occur in the original, unedited ROM.

Special Thanks

FCEUX Team (Used their emulator for testing purposes)
Mesen Team (Used their emulator for testing purposes)
Bunkai (Japanese-to-English translation)
Cyneprepou4uk (Helped with single-spaced text hack)
Ryu (Beta-Testing)

All credits to "The Warrior of Argos" belong to their respective creators and programmers.  This patch is mainly for pure entertainment for those who cannot enjoy the game.  All right reserved.  (Tecmo, please don't come after me!)