The Adventures of Rad Gravity (NES)
Traducción al Español v1.0 (30/10/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Adventures of Rad Gravity, The (USA).nes
MD5: 32afa96f523c8d7322f079abadba2d31
SHA1: 946c7124a2d4774522c2664c75103ef960bc54b9
CRC32: b55d5747
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --