This hack changes some colors,graphics,text and fonts to give it more of the NATSUME feel while playing it. 
Hope you like it. Enjoy!
Wolfamancer97.