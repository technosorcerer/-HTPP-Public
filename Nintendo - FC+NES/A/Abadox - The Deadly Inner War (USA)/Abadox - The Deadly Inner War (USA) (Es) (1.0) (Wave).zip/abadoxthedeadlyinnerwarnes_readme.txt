Abadox - The Deadly Inner War (NES)
Traducci�n al Espa�ol v1.0 (08/07/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Abadox - The Deadly Inner War (U) [!].nes
MD5: c096127c895bb7904c810007119a0225
SHA1: e20d3f4fefa0ad7de198f957563f70b11410af52
CRC32: dc87f63d
262160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --