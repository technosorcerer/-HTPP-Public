This is a hack of Adventure Island. For the first time, all levels have been changed in the game, and Mario has become The main character in the best traditions of Chinese hacks. From mushrooms, The Italian plumber had switch to an egg diet.

Mario always save their princess in story of original Super Mario Bros. Now Mario searching for himself mistress Tina from The Adventure Island universe.

But Mario meets not only the enemies from The First Adventure Island Universe, but meets also the usual for the Mushroom Kingdom of Bloopers, Shigai, Rex and many others classic enemies.

This Hack Features:

- Best Mario sprite in Adventure Island Hacks history.
- Interesting Mixed Level Design
- Faster Gameplay
- New Storyline