A Ressha de Ikou - English Translation Version 0.99

2/10/2021

MODIFICATIONS AND TITLE SCREEN GRAPHIC INSERTION BY MRRICHARD999
ALSO MODIFIED BY PROVEAUX
TRANSLATIONS BY AGENTORANGE & JINK640
CODE WORK ASSISTED BY ROTWANG

This patch will translate all of the text and menus in the game. Also attached is a screenshot of the control pad commands which might be helpful to run along your emulator next to it till the controls are more comfortable.

Apply to the following ROM

A Ressha de Ikou (Japan).nes
CRC32: 58FE5467
MD5: EEF6577471C300C86F8E67BE96BB6F15
SHA-1: FB64047D320C540EEB0CF72D9D7B80D08E2F410C
SHA-256: 719BB23E8D76AA158AE9D0FA83C4AA4E60B2EC51DA6AB321E1C9C7A2441DE297
