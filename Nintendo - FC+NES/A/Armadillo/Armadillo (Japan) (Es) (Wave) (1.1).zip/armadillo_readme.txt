Armadillo
Traducci�n al Espa�ol v1.1 (06/04/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Armadillo
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Armadillo
-----------------
Plataformas en el que te puedes convertir en bola.
v1.1:Arreglado nombre Sheryl a Cheryl

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basado en la traducci�n de Vice Translations.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com
Tambi�n puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Armadillo (J).nes
393.232	bytes
CRC32: ae73e0c2
MD5: 0e75b6acb92fe3925db58941e4983ffe
SHA1: 6d5fb990109f37bc320dff37eb60d06156d7d195

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
juandex - Testing

Original:
Contributor	Type of contribution	Listed credit
Kitsune Sniper (Foxhack)	Hacking	
Haeleth	Translation	Main Translation
Tomato	Translation	Spot Translations
Niahak	Translation	Spot Translations
Ian Kelley	Translation	Spot Translations
Loek van Kooten	Translation	Spot Translations
BMF54123	Hacking	Title Screen Design and Hacking
Skrybe	Production	Additional Information and Materials

-- END OF README --