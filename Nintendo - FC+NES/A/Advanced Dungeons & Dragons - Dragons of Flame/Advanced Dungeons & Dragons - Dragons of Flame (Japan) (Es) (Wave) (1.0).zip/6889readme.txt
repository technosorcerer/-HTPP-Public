Advanced Dungeons & Dragons - Dragons of Flame (NES)
Traducción al Español v1.0 (21/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en la de DvD Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Advanced Dungeons & Dragons - Dragons of Flame (Japan).nes
MD5: b82b665aefbbd5f4c633174df44ca051
SHA1: fba99cd8cfb0d44eaaee300dcd194520b41a92b2
CRC32: 8ba5de24
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --