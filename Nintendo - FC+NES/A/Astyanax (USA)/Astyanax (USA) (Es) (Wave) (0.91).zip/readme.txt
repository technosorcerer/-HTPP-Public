Astyanax
Traducci�n al Espa�ol v0.91 (29/08/2016)
(C) 2016 Traducciones Wave

---
TdC
---

1. Sobre Astyanax
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Astyanax
-----------------
Astyanax, The es un juego de accion con un toque de aventura.
Este parche lo traduce completamente al espa�ol.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Se a�aden minusculas, �, �, acentos y �
v0.91: cambiada rom compatible a version goodnes

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Astyanax (U) [!].nes
262.160 bytes
CRC32: 2fdfbc79
MD5: c20b630cec2ff87f796e9f1004d8bc5e
SHA1: 1787c6235fbf16337bb4789817cfe0b15ab3aad7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --