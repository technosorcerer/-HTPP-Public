Why I made this modification:

When I was a callow youth, Astyanax really appealed to me, such that I rather tended to overlook the various flaws in this game. True, even at the time, the game's cinematics and controls seemed an obvious pale imitation of Ninja Gaiden's. To a lonely and put-upon young boy stuck in a horrific public school and just beginning to develop an interest in girls, however, the idea of leaving school to go rescue the girl of one's dreams in a swords-and-sorcery-style fantasy world with a pretty little fairy companion at one's side did have a certain powerful visceral appeal to it.

Flash forward a couple of decades to now, and lately having my attention drawn to the cantankerous block lettering, the characters' overly passive manner of speaking, and the sloppy grammar and spelling has begun to spoil my fond memories of this game. Clearly, whoever translated and localized it either wasn't a native English speaker, or just didn't care. (If the former, your failures at understanding our admittedly complicated and highly variable language are hereby excused; if the latter, may you spend a small eternity trapped in chat rooms with other lazy dolts who've never bothered to learn their native language.)

In any event, I have therefore undertaken improving and refining the cut scenes. I've always thought that, with a little cautious editing, anybody with a bit of money and even half a brain could adapt this video game into a movie that people might actually pay good money to see and enjoy watching. Though the odds of that ever happening seem increasingly remote with every year that passes (because Hollywood has never yet employed anyone with half a brain to adapt any video game into a movie), I've titled this game accordingly. In addition to reworking the narration and dialogue, players may notice I've also made a few minor tweaks to the artwork.

FAQ:

Q. Is Astyanax's name really from Greek Mythology? How do you pronounce that?

A. As a matter of fact, yes, but that's pretty much the only connection, apart from the protagonist's vaguely Hellenistic-looking armor and some of the architecture (Ryogoku and Telugamn in particular). The Astyanax of Greek Mythology was the Trojan Hector's young son the Greeks threw from a tower to his death so that he would never return to avenge his father and reestablish the royal dynasty. Considering his cruel fate, it's probably a good thing that the only connection the hero of this game has to him is his name. One subject that would definitely be worth exploring if a movie adaptation of this game were to be made would be why Astyanax's parents chose to give their boy such a bizarre and inauspicious name in the first place.

As for the pronunciation, that's Uh-STY-uh-nax, and not "As-tee-an-ax" as I've heard some uneducated people on YouTube pronounce it. Granted, I imagine if anyone were named that now, his friends probably would just call him Asty for short, but the full name should still be pronounced with the same sharp "sty" as in polystyrene and styrofoam.

Q. Speaking of weird names, wasn't Rosebud a sled or something? Who names a little girl Rosebud?

A. Yes, yes, I can see you've been studying your film trivia. As far as I know, this game has absolutely no connection whatsoever to Orson Welles' film Citizen Kane. As for who names a kid Rosebud, children's book author Dawn Apperly, for one (see Princess Rosebud: Perfectly Perfect Princess, for example) and the makers of the feature-length fairy-tale movie adaptation Sleeping Beauty (1987) for another. Also, the playwright George Garrett named the King's daughter this in his play Sir Slob and the Princess. Actually, it's a rather popular name in some circles; so quit being such a provincial snob, wiseguy.

Q. Why did Astyanax originally claim to be a Freshman at high school, and yet later mention he was sixteen? Did he flunk and get held back a grade or something?

A. That apparent inconsistency in the original game is almost certainly a translator's error. In Japan, high school runs exclusively from the 10th to 12th grades. By Japanese standards, Astyanax would therefore be a first-year high school student. The translator apparently picked up on the American term for a first-year high school student being "freshman" but not on the fact that our high schools typically run from the 9th to 12th grades and Astyanax should therefore be in his second year. In this refinement, I've fixed Astyanax's narration accordingly.

Q. Is "ax" or "axe" the proper spelling?

A. Check your dictionary; they're both legitimate spellings. I still prefer the latter, though. Also, a comma really ought to have a space after it.

Q. What was the deal with Astyanax going all wussy and asking "Can you defeat me?" near the end?

A. More dubious translation, and it's an example of that overly passive voice the characters use a lot. In Japanese, asking a guy whether he can beat you in battle, even in a courteous tone, probably does sound like a pretty confident challenge. In English, well, you've got to say what you mean when goading someone into a fight. I've adjusted that line to a much more appropriate challenge in my version as well.

Q. How the %&@* do I get past Marshy (Level 4-1)? That level's %&$@*# impossible! Couldn't you have fixed that?

A. Hey, come on; it's not that difficult! I managed to slog through it way back when I was a kid playing this game on my console and there were no emulators with their cheating save slots to be had. Compared to, say, Level 6 of Ninja Gaiden, Marshy's nothing. A bit of advice that holds especially true on that level, though: don't waste any of that miraculous power clearing the screen when everything around you is constantly respawning. Switch over to the time-stopper instead, as the manual tells you how to do. (You have read the original manual for this game, haven't you? Join the Nintendo Fun Club today, Mac!)

Q. Got any other advice?

A. Believe it or not, all the hacking and slashing in this game does require some strategy, even though it's nowhere near so sophisticated as, say, the swordplay in Zelda 2: The Adventure of Link. I'll leave you with three quick tips:

1. Patience and timing are everything; he who gets frustrated and starts flailing is lost. Take every breather you can so you can build up that power guage and make every stroke count.

2. A lot of the enemy's tactics are more psychological than physical: resist the urge to chase any critter that just sucker-punched you, as this is one of the surest ways to get knocked into a pit.

3. When everyone's either throwing things at you or flying at you, use the Klingon males' classic method for surviving courtship: duck a lot.