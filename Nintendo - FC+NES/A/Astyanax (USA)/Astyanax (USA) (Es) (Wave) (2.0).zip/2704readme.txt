Astyanax (NES)
Traducción al Español v2.0 (21/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Nueva fuente
-Guion reescrito respetando formato de líneas original
-Título acentuado y con licencia traducida

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Astyanax (USA).nes
MD5: c20b630cec2ff87f796e9f1004d8bc5e
SHA1: 1787c6235fbf16337bb4789817cfe0b15ab3aad7
CRC32: 2fdfbc79
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --