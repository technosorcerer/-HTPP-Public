Airball (NES)
Traducción al Español v1.1 (01/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:
-Adaptado a rom de versión final

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Airball (USA) (Aftermarket) (Unl).nes
MD5: 27486b1f6e03590e1f95644320616257
SHA1: afebee3b6f1accd4c8a4fe83013cbe2e3766b9fe
CRC32: 9a535a93
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --