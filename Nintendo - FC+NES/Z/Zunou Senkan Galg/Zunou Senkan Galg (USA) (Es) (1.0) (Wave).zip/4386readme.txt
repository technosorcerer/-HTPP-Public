Zunou Senkan Galg (NES)
Traducci�n al Espa�ol v1.0 (09/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zunou Senkan Galg (Japan).nes
MD5: f14332e7a1fd953d07f3dfcb25026535
SHA1: 1acc22280484a987e0e877a0fd7da8a39c52be24
CRC32: 12d83258
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --