Zelda II: Paracosm version 1.5
April 7th, 2024

This is a romhack designed out of love for Zelda II.  It has always had a dreamlike atmosphere to it, and this new adventure really leans into that aspect.  Work on this hack started in summer of 2021 with the intention of only making a slightly dreamier variant of the original, but it slowly became its own distinct project.  It features new overworlds, towns, dungeons, graphics, and text.  There is custom music in progress, but that will be implemented in a future update!

1.5 updates include new graphics and minor fixes and rebalances.

1.4 updates include multiple new graphics, fixes, and balance tweaks.  Notably, the hammer is no longer usable in the overworld (other than to crush boulders).  The end of Palace 6 has been rebalanced.  Even though I named the 'Sea of Stars' before that was ever someone else's game title, I changed the name to 'Maze of Stars' to reduce potential eye-rolling (but I haven't checked to see if that's also a game title already... oh well).

Thank you so much for checking out this hack!

-Feistygandhi
