*******************************************************
If you like this Rom Hack, consider leaving a review at RomHack Plaza

Subscribe to my e-mail list at okimpala.net and stay informed about my upcoming projects.
*******************************************************

********************************
*Zelda II - Amida's Curse      *
********************************
Game: Zelda II - The Adventure of Link
System: NES

Works with GOODNES: Zelda 2 - The Adventure of Link (U).nes
Header: Yes
File SHA-1: 353489A57F24A429572E76BD455BC51D821F7036
File CRC32: E3C788B0
Size: 262.160 bytes

Patch: Zelda II - Amida's Curse v1.9
Header: Yes				
File SHA-1: 64F6EB82DBA9C4C99FEA47F61D31CED4990214F3
File CRC32: F01A5B55
Size: 262.160 bytes

Producer: Ok Impala!					

Release: v1.0: 27 October 2021
	 v1.1: 28 October 2021 
	 v1.2: 28 October 2021
	 v1.3: 2 November 2021
	 v1.4: 4 November 2021
	 v1.5: 8 November 2021
	 v1.6: 9 November 2021
	 v1.7: 19 November 2021
         v1.8: 28 December 2021
         v1.9: 4 May 2023

� 2021 Ok Impala!
http://okimpala.net
********************************

*************************
*Message from the author*
*************************
Zelda II - The Adventure of Link was one of the first adventure titles I played as a kid. I was mesmerized by its giant world, with all the little secrets. Especially the Temples scratched that adventurous feel with its haunting music and inventive ideas. You remember the first time you realized you could walk through the wall? Sure, the challenge was huge (especially as a kid). I don't know how much time I spend grinding for extra lives. But in the end it was surely worth it!
 
Back then I dreamed of making my own Zelda game. I drew maps of imaginative Temples and created a board game with it. But the true dream, creating a Zelda game for the NES stayed out of reach.

Times sure have changed. Thanks to the efforts of people like Trax, Njosro, Shadowone333 and CFrantz we finally have comprehensive editors and docs at our disposal. Thanks to them, and all the people under "Special Thanks", the dream of that little boy came true. After 18 months of hard work, I proudly present Zelda II - Amida's Curse to the world. For all Zelda fans out there as a reminder to never give up on your childhood dreams!

PS.
A special shoutout to bentglasstube for the amazing soundtrack he created! You can listen to the music of Zelda II - Amida's Curse on his Bandcamp page: https://eatabrick.bandcamp.com/album/amidas-curse
You can also listen to the soundtrack on Spotify: https://open.spotify.com/album/5XA6eVX9jtkxEe8XbiXBu9?si=cbf21a73e7724b3b
Download the NES Box and Cart art here: https://www.okimpala.net/_downloads/af5c832ab99ba056a153a9913498cfe3

*********
*Premise*
*********
One day Link finds a portal to a strange land. 
Curious he starts exploring the magical world of Amida. 
Little does he know, that he's on a brand new adventure that will take him to places he couldn't have imagined. 
Amida has a deep emotional link to our hero. 
Can Link unravel the secrets of Amida and return to his own world?

**********
*Gameplay*
**********
Zelda II - Amida's Curse plays slightly different from vanilla Zelda II. In Amida's Curse the main focus lies on exploration. Therefore, you won't encounter random encounters on the world map. Just like in games as Chrono Trigger, you are free to explore the world map without being disturbed.

The game is overall a bit easier than vanilla Zelda II. I did away with any and all cheap deaths. This doesn't mean Amida's Curse is a cakewalk, so remember to use Shield magic when needed!

Some townsfolk have more to say, so don't be too fast with clicking away the message box, you might miss useful information. Talking about that, almost all people you meet have something useful to say. So, make sure you make a chat and learn about the world!

Contrary to vanilla Zelda II, you can now instantly transform back while in Fairy mode by pressing A. Some puzzles in the game make use of this mechanic, so don't forget to use it!

You can instantly save the game by pressing up+A on the start menu. Be aware though that after pressing "save" or "continue" you will be warped back to the beginning of the game. So only use this option when you want to stop playing or need a quick warp to the starting point of the game.

The lives system got an overhaul. Every life you find will be permanently added to your life counter. So, when you start the game again after a Game Over your extra lives are still in your possession. It is highly recommended to grab every life you manage to find!

Temple Stones now give a fixed amount of EXP. You will no longer be punished for placing a stone just before level up.

Now, go explore! A whole new world is waiting for you!

**********
*Features*
**********
- 9 new Temples to explore (vs 7 in vanilla Zelda II).
- 11 new Towns to visit (vs 8 in vanilla Zelda II).
- New soundtrack.
- Brand new overworld.
- New story.
- New graphics.
- Animated tiles on the overworld.
- Balanced difficulty, no cheap deaths.
- No random encounters on the overworld.
- Loads of gameplay tweaks (building on Zelda II Redux).
- Lives you find are permanent.
- No grinding necessary.
- Save anywhere by pressing up and A on the start menu. Be aware though, that you'll be warped back to the starting point of the game. So, only use this option when you want to stop playing.
- Enemy rebalancing, no more huge HP pools.
- Press A as a Fairy to instantly return to your normal form.
- Temple stones give fixed EXP.
- Fairy can't fly through doors.
- And so much more...

*********
*Palette*
*********
Every NES emulator uses a different color palette, causing games to look different depending on the emulator used.
To play Zelda II - Amida's Curse as intended, please load the "Zelda2AmidasCurse.pal" file in the video settings of your emulator.

*************
*How to play*
*************
1. You'll need a NES emulator that is able to play Zelda II. Mesen and Nestopia are good choices. You can also play the game on original hardware.
2. Load Zelda2AmidasCurse.pal in the video settings of your emulator. (Optional, for better colors in the game)
3. Download the correct Zelda II ROM (See the start of the ReadME, and use Google)
4. With http://www.romhacking.net/hash/ you can check whether you have the correct ROM.
5. Go to: https://www.romhacking.net/patch/ to patch the ROM. (the .ips file is the patchfile)
6. Rename your patched ROM to Zelda II - Amida's Curse (so your emulator creates a clean savefile when you start the game).
7. Start the patched ROM in your emulator.
8. If you start the game with 3 hearts and 2 magic containers you've done it right. If not, please repeat the above steps.
9. Have fun!

*****************
*Version History*
*****************

v1.0: First release.
V1.1: Fixed a possible key despawn in Desert Tower.
V1.2: Fixed despawning of items caused by corrupted enemy drop table.
V1.3: Added hint for three tiled vertical jumps
      Fixed small graphical errors
      Removed one key and door from the 5th Temple
      Changed central room of 6th Temple
      Fixed potential softlock on elevator in 7th Temple
      Fixed two potential walk on ceiling issues
      Fixed two elevators
      Changed magic cost of Enigma
V1.4: Fixed a bug where upstabbing a Fairy might softlock your game
      Fixed a possible despawn in the cave to the 4th Temple
V1.5: Fixed a possible crash caused by an elevator in the desert
V1.6: Fixed a small typo in the last town
V1.7: Fixed a possible key despawn after the boss fight of the 8th Temple.
      Replaced a monster on the road to the 5th Temple.
      Fixed a rare visual bug with the healer in Berge.
V1.8: Replaced an enemy in Temple 1 to prevent an unfair death.
      Added a shortcut to the overworld.
V1.9: Fixed a rare bug in the 3th Temple that could teleport the player to the wrong room.
      Fixed a missing pixel in Link's sword.
          	
****************
*Special Thanks*
****************
Trax (ASM, beta test and graphics)
bentglasstube (Music and Beta test)
GTM604 (Graphics and Beta test)
Njosro (Creator of Zelda 2 editors)
Shadowone333 (Creator of Zelda 2 Redux)
Revility (Graphics)
Falchion22 (Graphics)
dartvaderx (Graphics)
Tony Hedstrom (GG code to remove random encounters)
Cfrantz (Creator of Z2Edit)
Melchior "McMelchior" Philips (Text editing)
Googie (Concept art)
Ice Penguin (Title screen font and gameplay changes)
Daan (Logo graphics)
Fox Cunning (Beta test)
Random Hero (Trailer Music)
Jeremiah Sun (Trailer Music)
Fishwerks (NES Box art)
Heaven Piercing Man (NES Cart art)

******************************
*Other Projects by Ok Impala!*
******************************
Super Mario Kart - Epic Racers (https://retrohackers.net/hack-details.php?id=5514)
Lufia - Encounter Rate Fix (https://retrohackers.net/hack-details.php?id=7259)
Breath of Fire - Encounter Rate Fix (https://retrohackers.net/hack-details.php?id=7294)
Breath of Fire II - Encounter Rate Fix (https://retrohackers.net/hack-details.php?id=7317)

*********
*Contact*
*********
Bluesky: https://bsky.app/profile/okimpala.bsky.social
Site: http://okimpala.net
Mail: impala@okimpala.net
