This is a patch to the English version of "Zelda II: The Adventure of Link" that restores the animated water from the Famicom Disk System version.

The patch can be applied with a program such as "Floating IPS".

Version 2.0
