/////////////////////////////////////
/                                   /
/  ZELDA II: THE ADVENTURE OF LINK  /
/                                   /
/       Galician translation        /
/                                   /
/////////////////////////////////////


( 1. MAIN INFO
(( 2. VERSION HISTORY
((( 3. HEX TABLE
(((( 4. LINKS



( 1. MAIN INFO
------------------------------
This translation to galician language was made by Manuel Riguera for "RC Translations",
part of "La Retrocaverna".

This patches the original Nintendo NES game rom "ZELDA 2 ADVENTURE OF LINK"
to "ZELDA 2 A AVENTURA DE LINK", with texts and in-game dialogues in galician.



(( 2. VERSION HISTORY
------------------------------
v0.1 (JUL 2014)
Just starting and finding tables and in-game dialogues.

v1.0 (JUL 2014)
Every dialog and menu text is translated, but Game Over screen.

v1.1 (25 JUL 2014)
Main Title graphic adapted to galician language.

v1.12 (21 APR 2019)
Forgotten Game Over screen is finally translated.



((( 3. HEX TABLE
------------------------------
The game seems to have several repeated text tables, but the one I used for this project is the following:

A - da
B - db
C - dc
D - dd
E - de
F - df
G - e0
H - e1
I - e2
J - e3
K - e4
L - e5
M - e6
N - e7
O - e8
P - e9
Q - ea
R - eb
S - ec
T - ed
U - ee
V - ef
W - f0
X - f1
Y - f2
Z - f3

  - f4 (blank space)
- - f6
? - 34
! - 36
. - cf
, - 9c


(((( 4. LINKS
-------------------------------------------------
WEB: http://laretrocaverna.mforos.com
TWITTER: https://twitter.com/laretrocaverna
FACEBOOK: https://www.facebook.com/laretrocaverna
INSTAGRAM: https://www.instagram.com/laretrocaverna
YOUTUBE: https://www.youtube.com/c/laretrocaverna
