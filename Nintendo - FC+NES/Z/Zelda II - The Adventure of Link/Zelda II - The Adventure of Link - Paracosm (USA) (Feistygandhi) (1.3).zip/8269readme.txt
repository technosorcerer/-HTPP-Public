Zelda II: Paracosm version 1.3
December 9, 2023

This is a romhack designed out of love for Zelda II.  It has always had a dreamlike atmosphere to it, and this new adventure really leans into that aspect.  Work on this hack started in summer of 2021 with the intention of only making a slightly dreamier variant of the original, but it slowly became its own distinct project.  It features new overworlds, towns, dungeons, graphics, and text.  There is custom music in progress, but that will be implemented in a future update!

This version's updates include new graphics (especially the overworld) and minor fixes/balance tweaks.

Thank you so much for checking out this hack!

-Feistygandhi
