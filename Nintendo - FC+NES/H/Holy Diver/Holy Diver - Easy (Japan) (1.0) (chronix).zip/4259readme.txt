Holy Diver Easy (NES)

Hacked by Andrei Vdovin a.k.a. Chronix
Email me if you find any glitches in my hack.
Thanks in advance!
chronix@bk.ru

Changes:

* Start with 5 lives and 5 hitpoints

Original ROM:
-----------------------
Holy Diver (J).nes
File size: 262 160

 PRG ROM:    8 x 16KiB
 CHR ROM:   16 x  8KiB
 ROM CRC32:  0xba51ac6f
 ROM MD5:  0x6d71d45c282a7b923497fe59813035ec
 Mapper #:  78
 Mapper name: Irem 74HC161/32
 Mirroring: None (Four-screen)
 Battery-backed: No
 Trained: No

