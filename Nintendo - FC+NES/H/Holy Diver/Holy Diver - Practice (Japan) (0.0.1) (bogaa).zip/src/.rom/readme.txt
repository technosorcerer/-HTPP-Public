Put your NES rom here and name it "Holy Diver (J).nes"
Then double clicking the make.bat will patch the ROM with ASM6f.
