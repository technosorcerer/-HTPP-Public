 .==========================.
( FIERY BALLER DODGE DANPEI )
 '=========================='

Full english translation.
This patch is based on the old translation done by Transgen but provides somes fixes:
-New title screen
-All graphics are translated
-More accurate names (Teams & players)
-Typos fixed or rewritten

This patch must be applied on the NO-INTRO ROM:

Honoo no Toukyuuji - Dodge Danpei (Japan).nes
CRC32: AEA2A320
MD5: 4A30E6C81F124095E905C99FB813E354
SHA-1: 8F47F6F8E5CAB5C1824B146ADBA0D572E6831B9C
SHA-256: 45727C27B7C6FA09CA4A8D339E3C539337B1FE2E362295E53FE4FD24E062497F

Staff:
FlashPV: Hacking, graphic work
Tom: Additional translation
Saito: Initial translation and hacking

Version history:

V 1.0: Final Release