Gracias por estar leyendo el readme, debo aclarar que hice otra traduccion del juego porque tenia
ganas de correjir varios errores que tenia el anterior trabajo que hice, como los nombres de los personajes
y algunos dialogos faltantes, y la pantalla de titulo que sigue siendo pequeña pero intente
lo que pude, aparte que me faltaba tiempo, disfruta de esta mejor traduccion, gracias!

Rockymitsu 2024