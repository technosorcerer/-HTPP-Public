Home Alone (RUS) (NES)

Translated by Andrei Vdovin a.k.a. Chronix
chronix@bk.ru

Original ROM:
-----------------------
Home Alone (U) (REV0) [!].nes
File size: 262 160

 PRG ROM:    8 x 16KiB
 CHR ROM:   16 x  8KiB
 ROM CRC32:  0xca5edbfc
 ROM MD5:  0xb1759492f6c18682f43d465e831f1419
 Mapper #:  4
 Mapper name: MMC3
 Mirroring: Horizontal
 Battery-backed: No
 Trained: No