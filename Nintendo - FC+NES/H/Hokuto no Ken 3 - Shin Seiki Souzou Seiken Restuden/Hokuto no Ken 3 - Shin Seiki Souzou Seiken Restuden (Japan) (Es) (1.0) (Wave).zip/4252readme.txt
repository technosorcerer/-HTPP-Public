Hokuto no Ken 3 - Shin Seiki Souzou Seiken Restuden (NES)
Traducci�n al Espa�ol v1.0 (12/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original de hecho, es una traducci�n del japon�s por mi amigo Sensenic, en exclusiva al espa�ol, como no hay mucho espacio, se han utilizado tiles dobles para mejorar el sentido de las frases, adem�s de a�adir todos los caracteres del idioma.
Incluyo una transcripci�n del manual con im�genes de este parche, espero que lo disfruteis.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hokuto no Ken 3 - Shin Seiki Souzou Seiken Restuden (J) [!].nes
MD5: b9628301f0049937976ecf14325477d8
SHA1: c12a27d9100636a94353620a5dc323691f9bda64
CRC32: 12b32580
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking y adaptaci�n de la traducci�n
Sensenic - Traducci�n del japon�s
Jackic - Testing y correcciones

-- FIN --
