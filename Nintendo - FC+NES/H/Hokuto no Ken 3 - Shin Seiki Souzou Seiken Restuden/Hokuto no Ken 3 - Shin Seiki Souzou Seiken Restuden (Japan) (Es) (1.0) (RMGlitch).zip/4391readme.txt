Este archivo contiene 2 parches para traducir la pantalla del t�tulo de Hokuto no Ken 3 de la NES.
Sobra decir que esta modificaci�n no tendr�a cabida sin el trabajo previo de Wave, Sensenic y jackic.

El Parche 1 cambia el t�tulo a la adaptaci�n:
"El Pu�o de la Estrella del Norte: La leyenda del pu�o maldito"
El Parche 2 cambia el t�tulo al m�s literal:
"El Pu�o de la Estrella del Norte: El creador del nuevo siglo - Historia del pu�o maldito"

Ambos solo deben aplicarse a la ROM con la traducci�n de los colegas mencionados ya aplicada y no se
garantiza que funcione con la ROM japonesa original o con alguna hipot�tica traducci�n aparte.
CRC32: 2F7D9614