Huang Di: Zhuo Lu Zhi Zhan

14 May 2013

Patch to fix the infinite jumping "glitch"

For anyone who has played this 8-bit masterpiece, you may notice that you can jump infinitely, which removes all challenge from the game.

This looks like a glitch, but actually it's the debug mode which is enabled if, on startup, the game reads a value of 0 (zero) at address 0100 in RAM. It needs to be a non-zero value to start normally, without the debug mode.

A few emulators correct this, but not all of them. Also NES flashcarts seem hit or miss depending on the firmware.

Chances are you're going to have a problem, so these two patches fix it!

I did a lot of reading on this problem and presented all my information on the RHDN forum and NesDev forum, and two very helpful users assisted in working out the actual programming side of things.

I did the legwork of researching the problem, HEX editing a ROM, and then using LunarIPS to create patches, but full credit for the heavy lifting must go to:

Cyneprepou4uk (RHDN)

and

Dwedit (NesDev)

Both kindly gave permission for me to upload patches based on their hacking.

The two patches included are:

Huang_Di_jump_fix_Cyneprepou4uk.ips
Huang_Di_jump_fix_Dwedit.ips

Use whatever patcher you like. I used LunarIPS.

The two patches function based on different hacks, but both get the job done.


Cyneprepou4uk's hack:
---
At 0x1D391 replace 8D 0F 01 with 20 A3 F7
At 0x1F7B3 replace 00 00 00 00 00 00 00 00 00 with 8D 0F 01 A9 FF 8D 00 01 60
---

And...

Dwedit's hack:
---
The sequence of bytes appears in the .NES file at 1D36E (grab your hex editor): "A9 00 8D 00 20 8D 01 20", then you change it to "A9 01 8D 00 20 8D 00 01".

Or if you prefer Game Genie Codes: 
PASSYLAA + AAVIGLPA + PAVIILAZ
---


Both patches also work with the fan-translation for the game. So now you can play it in English, with the correct jumping mechanics!

It does not matter which order you patch the fix and translation. Just use one jump fix patch - it shouldn't matter which.

Tested in emulators and a PowerPak flash cartridge using v1.11 firmware and v1.34 mappers.
