Hell Fighter (NES)
Traducción al Español v1.0 (05/11/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
Este juego debe ejecutarse con timings PAL y tiene algunos glitches gráficos, es normal.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hell Fighter (Asia) (PAL) (Unl).nes
MD5: 1d5bcda968c796170a3cba1b9b130d16
SHA1: 4b4aab33c9b8beda3f95a0de700b1fc9805ded71
CRC32: de20c40f
327696 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --