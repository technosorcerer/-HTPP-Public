Hogan's Alley (NES)
Traducci�n al Espa�ol v1.0 (05/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Hogan's Alley (W) [!].nes
MD5: aa78965764353f321b4bce9221128909
SHA1: a70f09a3163b8c967c03db8c20005c828836cc4d
CRC32: 9d39585b
24.592 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --