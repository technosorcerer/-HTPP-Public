Hack Name: Badly Drawn Hogan's Alley

A Hack Of: Hogan's Alley

Hacked By: Metal64

Youtube channel: https://www.youtube.com/user/MetalOverlord64

2 Youtube channel: https://www.youtube.com/channel/UCPVhjP2tmdRVpqfD5TOymKA


About the hack

I just redraw all the sprites as badly as I could
