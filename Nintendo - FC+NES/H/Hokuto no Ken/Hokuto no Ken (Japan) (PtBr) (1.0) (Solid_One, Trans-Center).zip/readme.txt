Jogo: Hokuto no Ken
Vers�o: Japonesa
Console: Nintendo
Ano da tradu��o: 2009
Grupo de tradu��o: Trans-Center
Tradutor: Solid_One
MSN: the_solid_one@hotmail.com

-----------------SOBRE O JOGO----------------

O ano � 199X. Devido a uma guerra nuclear generalizada, o mundo inteiro foi destru�do. Os mares secaram. A terra morreu. Quase todas as formas de vidas do planeta foram extintas. No entanto, a humanidade sobreviveu.

Neste mundo desolado e sem lei, onde a viol�ncia reina e a justi�a n�o passa de uma mera fantasia, um homem carrega consigo o poder da mudan�a. Kenshiro � o herdeiro do Hokuto Shinken, uma arte marcial milenar, que consiste no estudo dos pontos de press�o do corpo humano. Pressionando os pontos certos, ele � capaz de curar ferimentos, eliminar a fadiga, devolver a fala e a vis�o a uma pessoa. No entanto, o Hokuto Shinken � uma arte marcial de assassinato e, com um toque de seu dedo, Kenshiro � capaz de fazer o oponente explodir de dentro pra fora. Por ser uma t�cnica perigos�ssima, ela s� admite um �nico herdeiro, e a transmiss�o da arte deve ser feita de pai para filho.

Hokuto no Ken conta a hist�ria de Kenshiro, sua saga para reaver sua amada Yuria, e seu encontro com homens que, assim como ele, queriam mudar o mundo... seja pelo bem, seja pelo mal.

Esse � o primeiro jogo de Hokuto no Ken para NES e � um dos primeiros jogos baseados no anime/mang� que foram lan�ados. � um jogo curto e bem simples, bem parecido com os primeiros jogos do console, que mais lembravam jogos de Atari.

---------------SOBRE A TRADU��O--------------

Logo ap�s eu ter ajudado Arara a editar a tela-t�tulo do Hokuto no Ken 2, vi que o seu antecessor n�o havia sido traduzido. A princ�pio, o Arara n�o quis traduzir por achar o jogo bastante chato e dif�cil, o que n�o tiro a raz�o. Mas no fim decidi me lan�ar a traduzir esse joguinho s� por divers�o, e consegui fazer ele me ajudar, apesar de acabar fazendo quase tudo.

� um jogo bastante simples e curto. Tem s� 5 fases e nem final direito tem. Tanto que ao passar da quinta, ele simplesmente volta pra primeira, chama-a de fase 6 e aumenta a dificuldade. T�pico dos primeiros jogos de NES. De t�o curto que �, essa acabou sendo mais uma tradu��o passatempo.

Em sua maioria, o jogo s� possui tilemaps (name tables) e alguns gr�ficos pra editar. Os pr�prios textos estavam embebidos em tilemaps. O que complicou mais foi a falta de tiles para alguns gr�ficos e os ponteiros do jogo. Com os gr�ficos, deu pra resolver tudo na base do jeitinho brasileiro, apesar de ter sido um quebra-cabe�a pra resolveri. J� os ponteiros foi o que me fez penar pra entender, mas no final eram mais simples do que eu pensava.

Bom, isso � tudo. Usufruam do privil�gio \o/

--------------STATUS DA TRADU��O-------------

Textos: 100%
(Pouqu�ssimos di�logos.)

Acentos: 100%
(Tudo na gambiarra e no jeitinho brasileiro de fazer as coisas.)

Gr�ficos: 100%
(Pouqu�ssimos gr�ficos.)

---------------AGRADECIMENTOS----------------

-Arara, pelo apoio, ajuda, e por ser um f� monstruoso de Hokuto no Ken
	
------------------HIST�RIA-------------------

Vers�o 1.0 - 09/02/09
 Primeiro lan�amento. Vers�o Japonesa

------------------COR�COR�-------------------

Se voc� encontrou algum erro ortogr�fico, de concord�ncia ou algo parecido, por favor relate a mim por e-mail ou por MSN. Voc� encontra meu MSN no topo do arquivo.