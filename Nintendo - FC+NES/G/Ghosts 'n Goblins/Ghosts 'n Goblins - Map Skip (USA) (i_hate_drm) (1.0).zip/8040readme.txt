DOCUMENTATION

6502 Instruction Set:
https://www.masswerk.at/6502/6502_instruction_set.html

MAME Debugging:
mame nes -cart roms\gng.sfc -debug


AUTO-SET MENU TO CONTINUE:

1C457:						CHANGE:
C447  lda #$00		A9 00		|	C447  jsr $ffe8		20 E8 FF	// When main menu loads, goto $ffe8 (below)
C449  sta $a3		85 A3		|	C44A  nop		EA

1FFF8:						CHANGE:
FFE8  isb $ffff, x	FF FF FF	|	FFE8  lda #$00		A9 00
FFEB  isb $ffff, x	FF FF FF	|	FFEA  sta $a3		85 A3		// $A3 (menu selection) = 00 (first option)
FFEE  isb $ffff, x	FF FF FF	|	FFEC  lda $bb		A5 BB		// $BB == 0 at launch, and FF when you start a new game
FFF1  isb $ffff, x	FF FF FF	|	FFEE  beq $fff9		F0 09
FFF4  isb $ffff, x	FF FF FF	|	| FFF0  lda #$b2	A9 B2
FFF7  isb $ffff, x	FF FF FF	|	| FFF2  sta $0509	8D 09 05	// $0509 (menu selector icon) = B2 (third option)
					|	| FFF5  lda #$02	A9 02
					|	| FFF7  sta $a3		85 A3		// $A3 (menu selection) = 02 (third option)
					|	FFF9  rts		60


DISALLOW SELECTING BLANK THIRD OPTION ON MENU:

1C4C9:						CHANGE:
C4B9  lda $0509		AD 09 05
C4BC  clc		18		|	C4BC  jsr $c8ab		20 AB C8	// When select is pressed on main menu, goto $c8ab (below)
C4BD  adc #$10		69 10		|
C4BF  inc $a3		E6 A3
C4C1  cmp #$c2		C9 C2
C4C3  bcc $c4cb		90 06
| C4C5  lda #$00	A9 00								// IF A == C2:
| C4C7  sta $a3		85 A3								// $A3 (menu selection) = 00 (first option)
| C4C9  lda #$92	A9 92								// $0509 (menu selector icon) = 92 (first option)
C4CB  sta $0509		8D 09 05

1C8BB:						CHANGE:
C8AB  isb $ffff, x	FF FF FF	|	C8AB  clc		18
C8AE  isb $ffff, x	FF FF FF	|	C8AC  adc #$10		69 10
C8B1  isb $ffff, x	FF FF FF	|	C8AE  cmp #$b2		C9 B2
C8B4  isb $ffff, x	FF FF FF	|	C8B0  bcc $c8bc		90 0A		// IF $0509 (menu selector icon) + 10 == B2 (third option)
C8B7  isb $ffff, x	FF FF FF	|	| C8B2  pha		48
C8BA  isb $ffff, x	FF FF FF	|	| C8B3  lda $bb		A5 BB
					|	| C8B5  bne $c8bb	D0 04
					|	| | C8B7  pla		68		// IF $BB == 0:		(i.e. we haven't started playing)
					|	| | C8B8  lda #$c2	A9 C2		// A = C2
					|	| | C8BA  pha		48
					|	| C8BB  pla		68
					|	C8BC  rts		60


AUTO-SKIP MAP CUTSCENE (EXCEPT BETWEEN LEVELS):

1CD9E:						CHANGE:
CD8E  lda $94		A5 94								// $94 == 00 normally, and FF in demo
CD90  bne $cd8d		D0 FB								// Skip Map for demo (default)
CD92  lda $070c		AD 0C 07							// $070C == 00 normally, and FF between levels
CD95  bne $cd9b		D0 04		|	CD95  bne $cd9d		D0 06		// Show Map between levels (default)
CD97  lda $a6		A5 A6								// $A6 == 00 when game starts until first death, then FF
CD99  beq $cd8d		F0 F2								// Skip Map for intro (default)
CD9B  lda #$00		A9 00		|	CD9B  rts, nop		60 EA		// rts to $D0E0 (Skip Map)
CD9D  sta $c000		8D 00 C0	|	CD9D  lda #$00		A9 00
CDA0  sta $c7		85 C7		|	CD9F  sta $c000		8D 00 C0
CDA2  lda #$00		A9 00		|	CDA2  sta $c7		85 C7

If you would prefer to ALWAYS skip the map cutscene, just make $CD8E ($1CD9E) = 60 (rts)