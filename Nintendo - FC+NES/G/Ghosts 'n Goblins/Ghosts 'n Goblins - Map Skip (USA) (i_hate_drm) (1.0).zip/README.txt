Ghosts 'n Goblins - Map Skip

This hack auto-skips the map cutscene (except between levels).
It removes the blank third option from the starting menu.
And it auto-selects "CONTINUE" after Game Over.

This hack is compatible with the USA ROM of Ghosts 'n Goblins.

You can apply this patch using Lunar IPS.

Documentation has been included.

Hope you enjoy.