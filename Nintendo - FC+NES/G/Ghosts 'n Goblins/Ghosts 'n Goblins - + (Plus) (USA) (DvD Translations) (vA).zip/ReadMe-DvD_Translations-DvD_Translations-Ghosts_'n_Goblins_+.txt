-------------------------------------------------------------------------------

ReadMe-DvD_Translations-DvD_Translations-Ghosts_'n_Goblins_+.txt
 
This file should be viewed using a mono-spaced font like "Courier".
Use a font size where 79 columns are visible.

Please don't distribute the ROM file in patched form.
Please don't distribute the DvD_Ghosts_'n_Goblins_+_revA.ips file without this file.
Thanks.

-------------------------------------------------------------------------------
                              GHOSTS 'N GOBLINS +

                     for the Nintendo Entertainment System
                            Copyright 1986 by Capcom

                 Enhancement Copyright 2025 by DvD Translations
            Patch Version: Rev A   Release Date: September 21, 2025

                                DvD Translations
                      dvdtranslations.eludevisibility.org

                           Code Editing: DvD
                       Graphics Editing: DvD
                                Testing: DvD & 1AM

                                 ReadMe: DvD

----------------------------------- CONTENTS ----------------------------------

INFO 

(1)  Ghosts 'n Goblins Game Series
(2)  If You Read Anything, Read This

USING THE PATCH

(3)  Patching the ROM File
(4)  Playing the Game on a Flash Cart or Emulator

ENHANCEMENT DETAILS

(5)  Why DvD Chose to Enhance THIS Game
(6)  Why YOU Should Bother Playing THIS Game
(7)  DvD's Hacking Comments
(8)  Project Timeline
(9)  Software Used In This Enhancement

------------------------------------- INFO ------------------------------------

(1)--------------------- Ghosts 'n Goblins Game Series ------------------------

"Ghosts 'n Goblins" is one of the larger action game series made by Capcom,
currently ranking #12 by number of unit sales.  It is a notoriously difficult
platformer series.  It also spawned a side series called "Gargoyle's Quest",
the first two of which were much easier and contained RPG elements.

"MakaiMura", the original Japanese arcade name of the game, meaning Demon
World Village, is the first game in the series.  The Famicom game is fairly
faithful port of the arcade game.

Ignoring the puzzle and cell phone games, there are currently 5 games in the
Ghosts 'n Goblins series and 3 in the Gargoyle's Quest series.  The home
versions listed are the original versions, but many were ported to other
systems.  Notice that Gargoyle's Quest II is really late NES game that came
out after a Genesis, Gameboy, and Super Famicom game came out.  In Japan it
was later ported to the Gameboy.

                                 Arcade         Home
					   
MakaiMura                        Sep     1985   Famicom         Jun 13, 1986
Ghosts 'n Goblins                Sep 19, 1985   NES             Nov     1986

Dai MakaiMura                    Dec     1988   Mega Drive      Aug  3, 1989
Ghouls 'n Ghosts                         1988   Genesis                 1989

Red Areemer: MakaiMura Gaiden                   Gameboy         May  2, 1990
Gargoyle's Quest                                                Jul     1990

Chou-MakaiMura                                  Super Famicom   Oct  4, 1991	 
Super Ghouls 'n Ghosts                          Super Nintendo  Nov     1991

Red Areemer II                                  Famicom         Jul 17, 1992
Gargoyle's Quest II                             NES             Oct     1992

Demon's Blazon: MakaiMura Monshou Hen           Super Famicom   Oct 10, 1994	
Demon's Crest                                   Super Nintendo  Nov     1994

Goku MakaiMura                                  PSP             Aug 13, 2006
Ultimate Ghosts 'n Goblins                                      Aug 29, 2006

Kaettekita MakaiMura                            Switch          Feb 25, 2021
Ghosts 'n Goblins Resurrection                                  Feb 25, 2021

Note: Areemer is a-ri-i-ma-a in Japanese.  In Japanese, the "i" is pronounced
      like a hard e in English and two "a"s in a row sounds like "Ahhh" which
	is typically translated as "er".  You normally see this translated as
	Arremer, but to me that doesn't make me pronounce it correctly.
	
(2)-------------------- If You Read Anything, Read This -----------------------

DvD Translations enhanced version of "Ghosts 'n Goblins" is titled
"Ghost 'n Goblins +".  It felt like a fitting name due to the large number of
features it adds:

1    Issues: Stage Select:
             a) You have to enter a complicated password to activate the
                stage select screen.
             b) Stage select forces you to select a stage EVERY TIME you die!
             c) You can only select Round 1!
             d) You cannot select the weapon you had previously that you want
                to continue with.
             e) Only player 1 chose the stages for both players.
             f) Stage select always allows selecting stages that you would not
                normally be able to continue at.
		 g) The Intro and Map are never shown after selecting a stage.
     Fix:    Stage, Round, and Weapon select is automatically activated
             whenever 1 PLAYER or 2 PLAYERS is selected on the main menu,
             but only activated for each player one time before playing.
             Each player gets to choose on their controller:
             - Any Stage: A and B buttons
             - Round up to 9: Right and Left on the Joypad 
             - Staring Weapon: Up and Down on the Joypad
             - By default only valid stages and weapons for that stage are
               allowed to be selected.  Simply hold down Select and all
               stages that can be started from are allowed and all weapons,
               even those that would be impossible to have for the that Stage
               and Round combination, are allowed to be selected.
             - Press Start when your are done to start the game with all
               choices selected
		 If Stage 1 A is chosen for Round 1 the Intro is shown, otherwise
             the Map is shown.
     Why:    Even with infinite continues, this game is ridiculously hard.
             Even good gamers will usually take days to pass it the first time.
             The original Stage select was basically useless.  Stage, Round,
		 and Weapon select allows you to continue where you left off after
		 you turn off your NES.  After almost 40 years, this will allow
		 average but dedicated gamers to finally pass the game without
		 cheating.  After almost 40 years of playing this game, I finally
		 beat it without cheating and I went from hating this game
             to actually enjoying it.  Now, as for beating it on Round 2...
		 The game can go higher than round 9.  You can easily play round 10
		 by beating Stage 7 of Round 9.  If someone can play through
		 the whole game at Round 9 without cheating and pass it then there
		 is a reason to do this.
		 Since stage select is the only way to start the game, and since
             the Intro is only shown when first starting the game, without this
             the Intro would never be shown.  Additionally, the map is shown
             as that is what would normally happen when continuing.

2    Issues: Ending Credits:
             a) Ending credits are only shown after entering a special code.
             b) The "good" ending is only shown when beating the game on the
                2nd Round.
             c) When winning 2nd round, after the good ending, the player dies.
                When continuing, the player starts at Round 3 Stage 7. Then
                because you always get the bad ending after round 2, once the
                final boss is defeated, you go back to the Stage 1 A of the
                next round without dying. Beating round 4 and higher always 
                gives you the bad ending and takes you to Stage 1 A of the
                next round. So, you never get to play round 3 except for Stage
                7.
		 d) 4 typos were introduced when the game was transferred to the NES  
		 from the arcade game
		    - 1 typo in the bad ending: DEVISUT
		    - 3 typos in the good ending: CONGRATURATION, COURAGEOUR, ARE_
     Fix:    On Round 2, the Ending Credits shown when any button pressed.
             On Round 3 and higher, the good ending is shown and the ending
             credits are always shown.
             After seeing the ending, the game always continues on Stage 1 A
             of the next round.
		 All typos were corrected in both endings to make the ending match
             the arcade game.  Engrish not adjusted, just typos fixed.
     Why:    The player should be rewarded, not punished, for passing any
             round higher than 1.  The Credits screen is nice to see, and
             shouldn't require a password just to view it, but the change
             allows the user to still get the default experience of not
             seeing the screen.  Or, a player can challenge themselves and get
             a fun reward for passing the game a 3rd time.  Players should
             be able to play Round 3!
		 Even though the game always has had a lot of Engrish in the
             endings, the arcade game did not have any typos.

3    Issues: Title Screen Menus:
             a) 1 PLAYER is always selected by default when the Main menu is
                shown.
             b) The 2 player continue menu, shown after selecting CONTINUE
                after playing a 2 player game or a player 2 only game always
                defaults to ONLY 1UP.
		 c) Main menu allows the blank row where CONTINUE is shown after
                dying to be selected before playing the game.
     Fix:    After dying, CONTINUE is selected by default on the Main menu.
             The 2 player continue menu default selection matches whatever was
             previously played.  When CONTINUE is not an option, the row
		 cannot be selected.
     Why:    Most of the time you want to continue after dying playing it the
             same way you did before.  This saves tons of time especially for
             a 2 player game.  Selecting the blank Continue row offers no
		 features; really it was a bug added when the Continue row was
		 added for the Famicom conversion to the NES.  Continuing on
		 the Famicom required entering a special code every time you died!

4    Issues: Map is shown every time you die.
     Fix:    a) The map can be completely bypassed by pressing any button,
                except for Start, on the player's controller.
		 b) While the map is scrolling ANY button pressed will immediately
		    cancel it and start the game.
     Why:    Map is annoying to have to see EVERY TIME you die, but that was
             the intent of the designers.  So, by default it is always shown
		 (when the intro is not shown) but the player can easily bypass it.
		 Note that Start had to be ignored for totally bypassing the Map
		 otherwise pressing Start to select the Stage would have always
		 bypassed the map; this is not an issue as Start is not the normal
		 best button to press to bypass the map anyway.

5    Issues: Player 2 cannot do a lot of things:
             a) pause/un-pause the game
             b) choose anything on the menus
		 c) cancel the demo
     Fix:    Each player can pause and un-pause their game, but not the
		 other players. Either player can control either of the menus and
		 cancel the demo.  
     Why:    Playing a player 2 only game was a pain before because you had to
             constantly switch between controllers.  The issue applied to
		 pausing.  It's clear this was a hold over from the Famicom version
		 of the game since player 2 does not have Start or Select button
		 on a Famicom.

6    Issues: Player Ready Screen
             a) Screen locks up when the player has more than 9 lives.
		 b) Screen doesn't display what round you are playing.
     Fix:    Player Ready Screen now properly displays up thru 99 lives and
             doesn't lock up with any number of lives.  The Round, which was
             never displayed before, is now shown on the Player Ready screen.
		 To keep the change as minimal to the experience as possible, it
		 is only shown on Round 2 and higher.  Rounds above 9 are displayed
		 as letters.
     Why:    Locking up is a game breaking bug... that no one probably ever saw
             because you'd have to be a god to gain enough lives without dying!
		 Never seeing the round was generally as you'd be a fool not to
		 know what round you were playing unless you never turned the game
		 off for years.  But, now that you can select your Round, it really
             helps to see which one you are on, since you might accidentally
             choose the wrong round and no know it.  Also, it is nice to see
             the screen change when you are playing Round 2.

7    Issues: The ONLY 2UP game always starts with showing player 1 dying.
     Fix:    Playing ONLY 2UP doesn't show the player 1 dying.
     Why:    It was lazy programming that just implemented the player 2 only
             game by playing the 2 player game and simply killing player 1
		 right off the bat.

Don't buy repro carts!  They are expensive.  They don't support bug fixes for
patches because they can't be modified in the future.  If they aren't built
from scratch they destroy a real cart.  Every time a donor cart is used to make
a repro, it raises the scarcity and price of that real cart.  If you still want
to spend your money on a multiple repro carts, instead of buying a single flash
cart, buy them from a vendor who only makes carts from scratch with new boards,
chips, and housings.

------------------------------- USING THE PATCH -------------------------------

(3)------------------------- Patching the ROM File ----------------------------

How to patch the ROM file:

You need:

1) A NES file.  The file needs to include the standard 16 byte iNES header
   followed by the program disk image data.  With header, the ROM file is
   131,088 bytes in size.

   The header should be as follows:

       4E 45 53 1A  08 00 21 00  00 00 00 00  00 00 00 00
	 
   You must have a 16 byte header for this patch, but even if your header
   is wrong, this patch will fix it because it replaces the whole thing.  So,
   if you have a file without a header, you can just insert 16 of any byte at
   the start of the file.
   
   I'm not telling you how to get the NES file, but once you do, call it
   "Ghosts 'n Goblins +.nes".
   
   ROM w/ proper header CRC32:  0x87ed54aa

3) Patch File: DvD_Ghosts_'n_Goblins_+_revA.ips

4) An IPS patching program
   Remember to patch the file only AFTER it has a header.

   Recommended IPS patching program for IBM PC:  Lunar IPS.exe by FuSoYa
   Recommended IPS patching program for Mac:     UIPS          by Lucas Newman
   
   Using Lunar IPS / UIPS:

   a) Double-click "Lunar IPS" / "UIPS"
   b) Click  "Apply IPS Patch" / "Apply Patch"
   c) Choose "DvD_Ghosts_'n_Goblins_+_revA.ips"
   e) Choose "Ghosts 'n Goblins +.nes"

(4)------------- Playing the Game on a Flash Cart or Emulator ----------------

All emulators and flash carts that can play the original Famicom file can play
the enhanced game.  

The PowerPak flash cart emulates it perfectly.

Games designed for the original Famicom/NES hardware have one or two 16k
program banks and one 8k character bank.  Later, all games made for the NES
used special mapper chips to expand the size of the addressable ROM beyond
these limitations.  Some even included RAM for the character bank, instead of
ROM.  This game uses very early simple mapper called UNROM that alowed
expanding the program ROM and required on board RAM for character RAM.

Game file size:  8 x 16 kBytes of Program   ROM
                 0 x  8 kBytes of Character ROM
                    128 kBytes
                131,072  Bytes
              +      16  Byte Header
              = 131,088  Bytes

----------------------------- ENHANCEMENT DETAILS -----------------------------

(5)------------------- Why DvD Chose to Enhance THIS Game ---------------------

I've owned a copy of this game for over 30 years, but I never passed it.  Why?
Because it's so damn hard.  And if you collect a bad weapon, you are screwed,
although, it's usually possible to keep playing a level until an enemy drops
the one you want.  Even with this this enhancement it took me over 3 weeks to
pass Round 1.

(6)---------------- Why YOU Should Bother Playing THIS Game -------------------

Once you can "save" the game by using the stage, round and weapon select, the
challenge for Round 1 acceptable.  And you can turn your NES off an play other
games between playing it without having to use the original stage select which
constantly forces you to have to pick the stage you want to play.  It really
transforms the game from the worst thing you've ever been subjected to, to a
reasonable game.  It's still hell fight the Red Areemers, probably the most
random attack pattern enemy ever created, clearly much harder than any boss
in the game, and the ghosts at level 6 that always pop up right on top of you.
I would question why Capcom didn't give this a password save at in the first
place, but it's really not something Capcom generally did.  In fact, the maker
of the arcade game specifically did his best to make it as hard as possible
whenever he saw the beta testers doing well at a certain point in the game.

Before this, some people probably never passed 2 B.  Many others, probably
never passed 3 B with it's hellish amount of Red Areemers.  Still others
might have given up at Stage 5 or 6.  And those that did finally pass the game,
often totally gave up when after beating the first round, when they found that
had to play it all over again on a harder setting, not knowing what sort of
an ending they would see after doing so.  With this stage, round, and weapon
select and an NES flash cart you will finally be able to play levels you've
never played before.  Playing the game this way keeps it extremely challenging
but makes actually somewhat fun to play.  Passing it, without cheating, will
allow you to brag about doing something that few others have done.

(7)------------------------- DvD's Hacking Comments ---------------------------

Like always on these level select hacks, I made this hack for myself.  1AM was
starting on playing Gargoyle's Quest and I wanted him to see the game it came
from.  When seeing how brutal it was, I knew it needed a stage select hack.
At first, I had forgotten about the built in Stage Select feature, but once I
tried it, I remembered why I had forgotten about it: it's terrible in every
sense of the word.  I knew I needed to fix all the issues to make the game
fun.  I'm really proud of how this one turned out.  With all the enhancements,
making the gave experience what it should have always been, the Ghosts 'n
Goblins + named seemed to really fit the end product.

(8)----------------------- Project Timeline Highlights ------------------------

Aug 11 2025 - Project started

Aug 19 2025 - Most of the simpler features added such as preventing the Map
              from showing, each player controlling themselves, stage select
		  automatically working and only showing on the first round
		  (mostly) and the ending credits always working
		  
Aug 26 2025 - Full Stage, Round and Wepon select completed

Aug 28 2025 - Can stop map after it starts to scroll added

              Title screen updated

Sep 12 2025 - Fix and enhancement of the Player Ready screen completed

Sep 20 2025 - New variables added to separate the stage select password entry
              variable from the ending credits password entry variable and
		  to use unique stage select variables for each player finally
		  getting the stage select to properly display at the right
		  times for a 2 player game.
		  
		  Beta testing finally beat all stages of Round 1 with all
		  possible weapons on real hardware.
		  
Sep 21 2025 - ReadMe Written

              Released

(9)-------------- Software & Hardware Used In This Enhancement ----------------

* Emulator

  FCEUX 2.6.6
   by zeromus, adelikat

* Disassembler, Table Dumper, & Relative Searcher

  Table Dumper Pro (version 25.9.3)
   by DvD

* Hex Editor

  Beyond Compare 4.4.2 Licensed Version
   by Scooter Software

* Disassembled code manipulation & ReadMe creation

  Notepad++
   by Don Ho and the rest of the Notepad++ team

* Testing on a real NES

   PowerPak
    by retroUSB

* Tile Editor
  
  Tile Layer Pro 1.0
   by Kent Hansen
  
* IPS Patch File Creator

   Lunar IPS
    by FuSoYa

-------------------------------------------------------------------------------
987654321098765432109876543210987654321 123456789012345678901234567890123456789