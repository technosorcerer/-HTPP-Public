This patch makes shoots faster, it's easier to play, but not in a cheap way.

Oh, i love this game so much!!

@Greyfox