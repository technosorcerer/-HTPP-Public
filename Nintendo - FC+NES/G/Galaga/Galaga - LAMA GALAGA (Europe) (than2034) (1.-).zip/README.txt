Based on the classic Galaga and animated by fans, >>Lama Galaga<< is a space adventure 
where the space invaders are lamas and the player controls a space fighter jet, 
which must dodge bombs and kamikaze attacks. 
(The game is based on this print: https://ibb.co/27V9s2tV)

Enjoy the ROM 🙂!

GU & THAN._

