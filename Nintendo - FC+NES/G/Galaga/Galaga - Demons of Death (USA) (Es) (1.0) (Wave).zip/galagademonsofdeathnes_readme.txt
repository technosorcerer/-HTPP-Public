Galaga - Demons of Death (NES)
Traducci�n al Espa�ol v1.0 (28/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Galaga - Demons of Death (U) [!].nes
MD5: 486bbb76f49dcad3982e63239346f4bc
SHA1: da54c223d79fa59eb95437854b677cf69b5cac8a
CRC32: e36d5991
40.976 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --