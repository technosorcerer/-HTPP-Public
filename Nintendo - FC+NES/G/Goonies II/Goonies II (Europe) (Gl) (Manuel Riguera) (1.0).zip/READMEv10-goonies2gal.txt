/////////////////////////////
/                           /
/      THE GOONIES 2        /
/                           /
/   Galician translation    /
/                           /
/////////////////////////////


( 1. MAIN INFO
(( 2. VERSION HISTORY
((( 3. HEX TABLE
(((( 4. LINKS



( 1. MAIN INFO
------------------------------
This translation to galician language was made by Manuel Riguera for "RC Translations",
part of "La Retrocaverna".

This patches the original Nintendo NES PAL Europe game rom "THE GOONIES 2"
with texts and in-game dialogues in galician.



(( 2. VERSION HISTORY
------------------------------
v0.1 (AUG 2014)
Tables found and begin to translate.

v1.0 (02 SEP 2014)
First complete translation done. Some words like "map" are not translated due to text space issues.
Graphic title on title screen not translated due to difficulty to edit the rom graphics.



((( 3. HEX TABLE
------------------------------
The are two tables. The first one is for the title screen text and maybe some more words.
The second one is for the in-game text.

00=  (blank space)
01=0
02=1
03=2
04=3
05=4
06=5
07=6
08=7
09=8
0A=9
0B=A
0C=B
0D=C
0E=D
0F=E
10=F
11=G
12=H
13=I
14=J
15=K
16=L
17=M
18=N
19=O
1A=P
1B=Q
1C=R
1D=S
1E=T
1F=U
20=V
21=W
22=X
23=Y
24=Z
25=,
26=.
35=�
36=�

00=  (blank space)
01=A
02=B
03=C
04=D
05=E
06=F
07=G
08=H
09=I
0A=J
0B=K
0C=L
0D=M
0E=N
0F=O
10=P
11=Q
12=R
13=S
14=T
15=U
16=V
17=W
18=X
19=Y
1A=Z
1B=0
1C=1
1D=2
1E=3
1F=4
20=5
21=6
22=7
23=8
24=9
25=&
26=>
27=<
28=^
29=v
2A=?
2B=!
2C=-
2D=�
2E=�
2F='
30=,
31=.
32=�
33=�
47=�
48=h



(((( 4. LINKS
-------------------------------------------------
WEB: http://laretrocaverna.mforos.com
TWITTER: https://twitter.com/laretrocaverna
FACEBOOK: https://www.facebook.com/laretrocaverna
INSTAGRAM: https://www.instagram.com/laretrocaverna
YOUTUBE: https://www.youtube.com/c/laretrocaverna
