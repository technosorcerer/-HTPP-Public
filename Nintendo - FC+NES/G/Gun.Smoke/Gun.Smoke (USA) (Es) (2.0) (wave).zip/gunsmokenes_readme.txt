Gun (NES)
Traducción al Español v2.0 (10/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
-V2.0:
-Añadidos Ñ y acentos y LL
-Traducidos gráficos Pow y WANTED
-Revisión de Script

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gun.Smoke (USA).nes
MD5: b7323d5cf56f4049e20d44815ca6c45a
SHA1: 612f2aa339bf1ae54b466f1574752cd753097503
CRC32: 6b8f23e0
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --