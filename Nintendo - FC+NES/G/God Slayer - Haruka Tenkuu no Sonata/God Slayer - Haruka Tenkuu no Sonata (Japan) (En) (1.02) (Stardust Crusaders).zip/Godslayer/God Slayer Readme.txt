========================God Slayer=====================
===============Sonata of the Distant Heavens===========
==========================V1.02========================
Genre: Action RPG

Source language: Japanese

Platform: Famicom

Patch language: English

Author: Pennywise/Tom

E-mail: yojimbogarrett@gmail.com
		
http://yojimbo.eludevisibility.org/
 
======================================================
About God Slayer
======================================================
Background: 

Years back I was curious about the script differences
between God Slayer and Crystalis, so I ripped the scripts
from the game with a little help from Esperknight and
had a another translator look them over. He came to the
conclusion that it was a good enough translation and
so I left it at that.

Fast forward to a few months ago and I hear Tom wants to
retranslate the game, and so here we are. It turned out
that my initial script dump from years back was actually
a little incomplete and with abw's help, I was able to
get a proper rip of the game's scripts. Hacking work then
resumed as Tom continued to translate. This game was
actually pretty easy to hack and I didn't have to do any
super complicated hacks to remove all the limitations
you usually face. Anyway it's complete and I hope
everyone will enjoy the new translation.

======================================================
Version History
======================================================

1.0 - Initial release
1.01 - Minor text update
1.02 - Fixed secret developer messages

======================================================
Game Hints
======================================================

There are several secret messages from the developers
of the game that can only be accessed by doing the
following:

-Enable the cheat mode at start up
-Beat the game
-Reset the game and select Continue from the title screen
-When you go to talk to someone, hold A and the messages
will appear

For more information you can visit this site:

http://cah4e3.shedevr.org.ru/cheatsbase.php#337

======================================================
Tom's Comments
======================================================
I grew up with Crystalis on the NES. The game was fun,
the music was awesome, and the dialogue made sense.
In those days, Engrish was very common, so it was nice
playing a game that seemed to get things right.

However, despite seeming fine at first glance, Crystalis'
script took several departures from the Japanese God Slayer
script. Some of these are mild, and some are substantial,
but most of them occured because of two reasons: censorship
and a lack of space.

(Spoiler Warning!)

The intro of Crystalis was almost entirely made up to avoid
saying anything taboo. Since God Slayer had a lot of words
relating to religion, they cut that out to talk about a
"savage war." However, the Japanese game never specifies war.

It's far more likely, given the plot, that it was scientific
experimentation that caused the Earth's axis to go askew and
nature to run amok. Lightning strikes the land in the intro.
Lightning is not a symbol of war. It's a symbol of divine
retribution against the scientists who were "playing god."
The lightning was changed to an atomic bomb in the American-made
Gameboy Color remake, but I believe they were expanding on
Crystalis' made-up script, only furthering the war misconception.

Of course, the censorship was not just limited to the intro.
The orks (called dwarfs in Crystalis), upon being saved, would
originally worship you as their god... But in Crystalis, they
just said thank you and sent you on your way. There were other
changes throughout the game, as well.

With this hack, there was a lot more space due to the removal
of indented text. This means that the NPCs don't have anything
cut out from their lines for space reasons. We've also
reintroduced name tags, which were removed from the Crystalis script.

I hope the Crystalis fans out there, though our numbers might
be few, appreciate the chance to play an uncensored version
of the game!

======================================================
Patching Instructions
======================================================
The patch is in BPS and Xdelta format.
You can apply it with a frontend such as:

http://www.romhacking.net/utilities/893/
http://www.romhacking.net/utilities/598/

Apply the patch to the original Japanese version of the
ROM:

God Slayer - Haruka Tenkuu no Sonata (Japan).nes

We would be highly grateful, if you find some time to 
contact us with proposals or corrections. Information
on found bugs or corrections would be highly 
appreciated.

P.S.

Support the game industry by buying used games!

Even if the money doesn't go to the developers
directly, as the games become rare and harder
to find, the price goes up, and people become
more inclined to buy new releases "while they can!"

======================================================

Credits go to:

Pennywise - hacking

Tom - translation

abw - script extraction

Esperknight - script extraction help

FlashPV - title screen design

harmony7 - misc spot translation

cccmar - testing

Xanathis - testing


======================================================


Compiled by Pennywise. August 2018.
