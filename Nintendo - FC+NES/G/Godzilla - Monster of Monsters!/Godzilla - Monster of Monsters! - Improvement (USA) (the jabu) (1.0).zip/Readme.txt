       Godzilla - Monster of Monsters! Improvement V 1.0/ hack by The Jabu 
      ---------------------------------------------------------------------
      This hack was made especially to improve Mothra in general and add some 
      extra changes to the game.
      
   

    Changes:
  
   - Mothra's eye beam with more range.

   - Mothra's power attack with more range and speed.

   - For Mothra, press "B" button for eye beam , and press "A" button for power attack.

   - When Mothra get hit, she isn't get knocked down.

   - Redesigned sprite for  Mothra.

   - New title screen.

   - The Title screen has the japanese theme.

   - Mars has a new theme.

   - Now some spaceships can drop power capsules.

   - Moguera's animation doesn't freeze after been hit.



  Apply the IPS file to "Godzilla - Monster of Monsters! (U).nes" and have fun!!!

    

   