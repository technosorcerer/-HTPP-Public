Gatsby (NES)
Traducción al Español v1.0 (16/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gatsby.nes
MD5: 21ffdb24085100ddeca1fccfaf4e71d7
SHA1: 5257df4d2df3cb5b9c560fcbb3d38295dc2f6f05
CRC32: f6b72814
262160 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --