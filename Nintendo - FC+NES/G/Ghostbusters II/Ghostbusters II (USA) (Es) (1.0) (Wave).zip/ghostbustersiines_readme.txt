Ghostbusters II (NES)
Traducci�n al Espa�ol v1.0 (24/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ghostbusters II (U) [!].nes
MD5: 77b95bfa68044501130d0b5c3991f18d
SHA1: 39686592401187d923a7c929bd044dfc97cc9a67
CRC32: 475a574e
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --