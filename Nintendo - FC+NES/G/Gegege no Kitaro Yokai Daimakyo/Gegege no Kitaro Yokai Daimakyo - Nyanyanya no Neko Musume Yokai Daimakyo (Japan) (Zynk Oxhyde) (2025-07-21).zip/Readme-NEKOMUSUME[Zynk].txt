NYANYANYA NO NEKO MUSUME: YOKAI DAIMAKYO
Hacked by Zynk Oxhyde
2025

---------------
Date Released:
---------------
v1.0 June 29, 2025

------------
Description:
------------
This ia a player sprite hack of Gegege no Kitaro: Yokai Daimakyo for the NES where Kitaro is replaced by Neko Musume.

--------
Changes:
--------
(v1.0 - 06/29/2025) - initial release
-Changed the player sprites from Kitaro to Neko Musume.

---------
ZIP file:
---------
1. This readme
2. NEKOMUSUME.ips patch

--------
Contact:
--------
Email: zynkoxhyde@yahoo.com

----------------
ROM Information:
----------------
File SHA-1: FA6EE4BE0352A29E5C00F9511097B742F96CA839
File CRC32: 6A6D9F5A
ROM SHA-1: 80203670B3DFC48BF79083637A7122ECB192B470
ROM CRC32: 25468546
Database match: Gegege no Kitarou - Youkai Daimakyou (Japan)
Database: No-Intro: Nintendo Entertainment System (v. 20210216-231042)

--------
Credits:
--------
Zynk Oxhyde - Hacking and sprites

---------------
Special Thanks:
---------------
Skullio - for commission and introduction to the game and the anime of GeGeGe no Kitaro

--------
Contact:
--------
Email: zynkoxhyde@yahoo.com

---------
Websites:
---------
https://romhacking.net/forum/index.php?action=profile;u=13199
https://www.youtube.com/c/ZynkOxhyde
https://twitter.com/Zynk_Oxhyde
https://facebook.com/zynk.oxhyde
https://deviantart.com/zynkoxhide
https://pixiv.net/en/users/14021789

---------
Donation:
---------
https://ko-fi.com/zynkoxhyde
https://paypal.me/zynkoxhyde0

-----------
Disclaimer:
-----------
* Zynk Oxhyde is not related or affiliated with Nintendo and the publisher of the original game.
* Do not sell this patch and the contents with it.
* Do not sell the pre-patched ROM into reproduction cartridges.
* Do not redistribute this patch and the contents with it on other sites without expressed permission from Zynk Oxhyde.