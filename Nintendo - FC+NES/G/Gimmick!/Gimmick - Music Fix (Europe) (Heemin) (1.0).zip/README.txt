----- Mr. Gimmick - Music Fix -----

This patch fixes several musical problems in the scandinavian release.
The fixes include:

- Tempo fix
- Lion Heart note misplacing fix
- Just Friends restore harmony
- Sophia triangle fix
- Noise tick skipping fix (it's not actually skipping, but as the driver had run one more time in some frames, the tick was almost immediately updated)
- Pitch underflow fix

- IRQ timing fix

Versions:

1.0 - Initial release