This patch modifies the ROM to run on N163 (iNES #19) mapper, with sound conversion included.

**Version 1.0**

- Initial release