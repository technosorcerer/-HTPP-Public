Gimmick! - No More Clock Divider Patch

The original 5B drives the internal PSG core in half clock, so reproduction of the cartridge requires extra circuit for dividing clock if it's not using YM2149F, which contains built-in clock divider.

This patch multiplies the final period value right before sending the value to 5B, meaning everything for 5B is being played in lower octave. No need to add 74'74 on your reproduction circuit, just clock it with M2 directly!

20251230 - Heemin