This is a simple sprite swap Romhack of Gradius 1 (USA) for NES that just replaces the VIC VIPER with Tako (Also simply known as Octopus) from Parodius. that's pretty it. I just made this for fun lol.

Changes:
Vic viper is now Tako.
Tako has his own colors.
Ending graphics aren't changed atm.

Hack by: 15Tails
Gradius is owned/developed by Konami
Parodius is also owned/developed by Konami
Tako/Octopus is also also owned/developed by Konami.

HOW TO APPLY THE PATCH.
1: First get Gradius (USA) for the NES. for legal reasons we do not and cannot provide this file. you are absolutely on your own.

2: Download the patch. (Obviously)
 
3: get a ROM Patcher. ones commonly used is The ROMHack Plaza online patcher and FLIPS. if you are using FLIPS. Click Apply Patch, look for the newly installed patch. click it. look for your unmodified Gradius 1 (USA) rom. apply it. boot the game and it should work...... if you have a Emulator...

4: Get a emulator for NES titles. if you do not have one. look for MESEN (This is what I use), Nestopia UE, puNES, and Ares. or FCEUX. Alternatively if you use Retroarch (Which is what I ALSO use) you can simply get the FCEUX and or MESEN cores for NES Titles.

5: Enjoy and suffer gradius syndrome as a flying octopus in space.