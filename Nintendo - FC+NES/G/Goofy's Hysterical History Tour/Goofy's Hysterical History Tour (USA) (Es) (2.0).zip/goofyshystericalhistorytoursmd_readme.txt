Goofy's Hysterical History Tour (Mega Drive)
Traducción al Español v2.0 (18/05/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres españoles a guion principal
-Traducidos gráficos de POWER, SCORE y PAUSE
-Guion retraducido

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Goofy's Hysterical History Tour (USA).md
MD5: 426471b87024c7b1e688fa8474390624
SHA1: caaeebc269b3b68e2a279864c44d518976d67d8b
CRC32: 4e1cc833
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --