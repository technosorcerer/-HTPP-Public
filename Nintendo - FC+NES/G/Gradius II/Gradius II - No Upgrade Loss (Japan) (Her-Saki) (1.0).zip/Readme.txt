========Gradius II (with upgrades)========

(Bug report to hersakiarc@gmail.com)

===About Gradius II===
Gradius II is the Famicom port for Gradius II: Gofer no Yabou.
You take the control of a spaceship across 7 stages filled with aliens,
moais and floating brains. You can collect items to power up your ship
following a special choice system. However,
---you'll lose ALL of them when you die, no exceptions---.
This is extremely frustrating since there are some areas that can't be
actually beaten without a minimum of upgrades, such as the moai boss. 
This is also a justified reason for giving up the game if you're not 
skilled enough, leaving behind an really, really good shoot'em up.

===This hack===
This hack allows you to save all the upgrades (except for the options, you
must do something for yourself, right?) that you have collected through the 
game. Even if you use a continue, the upgrades'll be right there. The game 
was beaten twice (as a test), and the only known side effect is that, if you 
finish the game with options and play again, the color of the options'll turn 
into blue, and if you collect the fifth option (to change their movement), 
some of them'll turn into the original orange. I don't know the reason, but 
is a nice effect, isn't it?

===Patching===
Apply to a clean Gradius II japanese rom.

===Credits===
I guess it's just me this time ^^'.
And Konami for make this great port.