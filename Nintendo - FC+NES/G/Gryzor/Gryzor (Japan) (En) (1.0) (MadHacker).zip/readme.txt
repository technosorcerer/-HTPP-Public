Gryzor Translation Patch
Version 1.00
A MadHacker release
(Comments welcome at tdennie@hotmail.com)

Yes, it's been a long time coming.  No, that's not my fault.  It's yours.  Don't like the new title screens?  Well, tough shit.  I put out the offer.  If you visit demi's message board you had your chance to design it however the hell you liked.  Now your stuck with what's there.  It's only thanks to toma and Zed that you're not stuck with the static Contra logo for this thing.  I complement them on the nice work they did, and stand behind it.

Enclosed are two patches, Gryzor.ips and Contraj.ips.  What's the difference?  The title screens are different, and two minor text elements are different (words are switched to reflect the title).

IMPORTANT: The patch must be applied to the Japanese Contra ROM.  Neither patch will work with the US version.

Credit where credit is due:
The title screen:
toma: Drawing the Gryzor logo.
Zed: Adding the animated guy in the Gryzor logo.
Everything else (Title screen "reprogramming", taking toma's title from image to reality, transferring the Contra logo by hand into the new game (and all coding changes necessary for it)) were done by The MadHacker.

The kanji attract screen:
Faraday: Translated the text
Coded by... you guessed it, the MadHacker.

The game text:
Midas: Translated the text (thanks go out to Yukelon, TheNed, and ShujinRik for having taken a look at it before him, though.)
Ho-hum... wonder who did the font and text replacement...  Oh, that's right.  The MadHacker.

The Middle Finger Awards:
Normally I don't like to do these things.  But the irony here is so thick that I just don't want to help my self.  And it goes to...
Dum-da-da-dum!
demi
He earns this distinction for what I guess he would call "pulling an SoM2Freak," which is to say he extended help with this project (the title screen), showed enthusiasm, then totally shut out any further contact on the project.  The next things I heard from him were assertions that it wasn't possible to accomplish what I have (want proof, just check out the Contraj patch especially- that title not only fills in the spaces in the original title block, but also goes beyond the confines of the original rectangle.), and that I would fail to deliver as promised.  

Or, to put it another way about demi:
"all while hanging things over our  heads such as  coding techniques and connections  to people  who knew how  to recode parts  of the ROM. 1000 bucks says he'll try [Contraj] again out of spite. Why?  I dunno. He's a sleaze." (Sound familiar?)

So you, demi, get the one hearty "fuck you" associated with this project.

Have a nice day.