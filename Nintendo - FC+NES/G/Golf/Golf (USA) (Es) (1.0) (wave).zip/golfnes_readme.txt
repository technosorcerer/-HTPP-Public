Golf (NES)
Traducción al Español v1.0 (31/05/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Golf (USA).nes
MD5: bd270896269d8c926b543f928fa2d0fe
SHA1: b7128f71125070d5e4009c474d259811d029e8b6
CRC32: 6c4e5a87
24592 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --