Last Updated 11/25/2022
Server link: https://discord.gg/dXkYNjt4cn
Playable on Fightcade 2


Credits:
Streetwize- Lead Hacker
Kosheh- Extra Palettes, Title Screen
RocketToRussia- Fightcade Partner, Tester
Enigami- Additional Hacking
Doomkid- Original Inspiration, Quaternary Colors
Tobemorecrazy, Pipca, KingPepe, Butarou- Special Thanks

Known issues:
The game may lag if both player timers and the game timer are in sync. This was present in the original, but worse. The changes in place that reduce lag may cause issues elsewhere.
The background objects may freak out for a frame from an interrupt during bank-switching. It does not affect gameplay.
Donkey Kong Jr.'s stage has the lifebars share the pillars' palette.

(#A)- # ticks of Attack invincibility
(#P)- # ticks of Projectile invincibility

Mario- Fireball-focused
Pros:
-Overall solid character to start with
-Hard to challenge in neutral
-Fireball has 2 less ticks of cooldown
Cons:
-Both specials leave him airborne
-Rather predictable and linear combos
-TOD requires optimizing
	D, F, P: Fireball
	F, D, P: Uppercut  (3A)
	D, B, K: Flying Kick (10P)
	Neutral Jump, D+K: Bounce Kick

Luigi- Volatile
Pros:
-Simpler inputs for those who prefer tapping
-More mobile specials give better combo leniency
-Fireball sticks out further than Mario's
Cons:
-Muscle memory from Mario won't work
-Slower walk
-Less invincibility on specials; both still airborne
	D, F, P: Fireball
	B, F, P: Uppercut (2A)
	B, B, P: Flying Punch (4P)
	Neutral Jump, D+K: Bounce Punch

Peach- Balanced Rushdown
Pros:
-Twirl is really good for offense and defense
-Fast walkspeed
-Acceptable damage with specials
Cons:
-Low damage with normals
-Twirl is prone to guard cancels
	D, F, P: Fireball
	D, B, K: Elegant Twirl (3A/6P)
	Back+P or B, B, P: Hair Whip

Yoshi- Midrange/Zoner
Pros:
-Tail has extra reach on attacks
-Fireball has 3 less ticks of cooldown
-Unduckable flying attack
Cons:
-Combos are lacking in some situations
-Very little defense with one tick of invuln and reliance on punch to break juggles
	D, F, P: Air Blade
	F, F, P: Tongue Lash
	F, D, K: Tail Dance (1A)

Toad- Defensive
Pros:
-Most damaging reversal in the game
-Great defense and priority on specials
-Can easily capitalize on a hit
Cons:
-Finnicky jump controls due to Flying Kick; best use command normal for forward aerial movement
-Uppercut only works as an anti-air
-Far normals are a bit stubby
	D, F, P: Mushroom Shot
	B, B, P: Uppercut (5A)
	F, U, K: Flying Kick (3A)
	Neutral Jump, D+K: Bounce Kick

DK Jr.- Powerhouse Shoto
Pros:
-Small boost on all attacks
-Reliable reversals
-Projectile can beat non-airborne invincibility
Cons:
-Poor approach
-Specials can easily be ducked
-Stand K is stubby
	D, F, P: Banana Peel
	D, B, K: Air Swing (4A)
	B, D, P: Donkey Lariat (12P)

Koopa- Rushdown/Grappler
Pros:
-Great movement; specials also provide ways to get around attacks
-More throwing opportunities than other characters; can easily combo into throw
Cons:
-No projectile and can only juggle with throw, limiting his combos
-No damage modifier, but low damage overall
	D, B, P: Air Charge
	B, F, K: Shell Spin (4A/12P)
	D, F, P: Dash Grab

Bowser- Pure Powerhouse
Pros:
-Highest damage in the game and no slow normals
-Tail Flop can dodge projectiles
-Extra range on sweep
Cons:
-Slow walk; mobility requires jumping or specials
-No reversals or anti-airs; easy to challenge and pressure
	D, F, P: Fireball
	B, B, K: Charge
	D, D, P: Tail Flop (3P)

Daisy- Grounded Rushdown
Pros:
-Specials have deceptively long range
-Can easily convert any non-juggle hit into dizzy
-Open-ended combo routes
Cons:
-Defense not guaranteed with Barrage Kick
-Lowest damage per hit overall, but can do more than Peach and Koopa in some aspects
-Gets little from juggles and limited anti-air tools
	D, F, P: Fireball
	B, F, K: Barrage Kick (2A)
	B, B, P: Hair Whip


New Features
-Daisy is added, accessible by going into the center from the top or bottom of the wheel. She has a unique special, and her other specials have different properties to them.
-1P mode semi-randomized, now 10 fights with a proper (unplayable) final boss
-Able to select one of 4 palettes depending on the button used to confirm; the 4th is accessible by holding up or down
-In 2P mode, whose stage you play on is randomized between both players instead of only P2; you can also press select to pick whose stage you'll fight on
-The game remembers the last characters players use between matches
-Stages have three extra variations, randomized before each match
-An improved scoring system that allows for far more points, including a proper bonus for perfects, win streaks, and playing on a higher difficulty.
-The AI will now use exploits the player is able to do, making them more challenging while teaching what is possible

Control Improvements
-Players now have separate tick timers from the game itself, letting them respond immediately rather than wait for every 4th frame.
-Added ability to join on the CSS with any button instead of only D-pad.
-Pressing start works on the continue screen.
-Any button can now skip the points tally at the end of a round.
-The game now properly checks the first input of specials upon reset.
-Inputs are now read during hit-pause and other inactionable states, and button presses will not reset special inputs when doing them is impossible.
-Pressing A or B will not reset your special moves on the first direction (e.g. cr P, Fireball).
-You can press a direction and button at the same frame to do specials.
-Crouching no longer stalls actions until the game returns you to standing.
-Fixed inability to stand guard from crouch guard.
-Walking fully accounts for direction and side facing now, no longer moving you the wrong way in certain situations.
-CPU matches can be interrupted with the inactive player pressing start
-In a two-player game, either player can pause, but start needs to be held.

AI improvements
-All improvements without * rely on the RNG slider based on difficulty
-Can attack while recovering in the air
-Will cancel fireball into another special if avoided
-More situations are present for it to be able to block, such as landing, ducking, and walking backwards
-Guard-cancel opportunity after three ticks, with distance taken into consideration
*Can interrupt itself from more actionable states rather than only idle and forward walk
*Randomly does slow or fast fireball
*OTG Fireballs if close enough

Bugs Fixed
-Luigi special moves enabled.
-Right side edge expanded to match left side.
-Fixed attacks ignoring the state check if the following hit would cause dizzy, making them hit twice.
-Removed ability to do reversals from any state except for guard and getup; cancels still exist otherwise.
-Guarding attacks now causes pushback in the corner.
-Attacker pushback is now dynamic and only happens in the corner. Instead of stopping when the character was far enough back, the stopping distance is determined from where the hit happened and gradually closes in.
-Stage starting point recentered to not favor P1.
-Stage edges can now be moved to properly.
-You can no longer throw while the opponent is downed, preventing easy throw loops.
-Getup vulnerability removed; duration shortened to allow control as soon as you stand.
-Slight tweak to corner pushback on left side for symmetry.
-CSS sprites now line up properly with their grey sprites.
-Fixed projectile despawn asymmetry now at 16 pixels for each side rather than 8 and 24.
-It is impossible to cross under an opponent in the corner.
-Fixed close P being unblockable as P2.
-Pushback altered to accommodate differing speeds and have solidity in more situations, with a hard cap of 8 pixels per tick.
-Getting hit from behind causes turnaround if both players face the same direction.
-Projectiles now stay relative to their position when the camera shifts.
-Projectile speeds are no longer asymmetrical depending on what side you're facing.
-You are less likely to throw the wrong way if too close.
-Holding down no longer dodges certain attacks in states where you can't crouch.
-Matches can no longer be interrupted on time-over, damage can no longer happen, and waits for both players to return to neutral before ending. This prevents any situations where the game could continue.

Gameplay changes
-Health expanded from 88 to 96.
-Timer reduced 80 > 50; second duration 64 frames > 60.
-Stage edges expanded 4 pixels.
-Pushback is much less overall, and pushboxes now work in many more situations.
-Attack code redone to allow combos even if the next attack wouldn't change the opponent's hurt state; this also lets certain moves hit multiple times.
-Jump attacks now need to be blocked standing.
-Throws have been adjusted to be more consistent overall.
-Throw distance reduced slightly as a result of above change.
-Throws and fireballs cannot be cancelled until 4 ticks pass.
-Fireball cooldown doesn't start until it comes out.
-Fireball visual asymmetry fixed, and hit 8 pixels sooner.
-Fireballs can now clash, and resets cooldown for both players.
-You can hold A before the fireball comes out for a fast version.
-It is now possible to mash out of dizzy.
-Dizzy limit raised from 4 to 5 hits.
-Dizzy drain is now decremental, which removes the pseudorandomness of not getting dizzied; drain timer lowered to ~60 frames to match.
-Dizzy drain modified: the first point is removed once the timer lapses second a second time. Once it starts the delay will not happen again until dizzy becomes 0 or you get knocked down.
-Drain timer resets and stalls while in hitstun.
-All attacks except throws and projectiles add to dizzy instead of only non-knockdown attacks.
-Getting two dizzies in a row forces a normal wakeup.
-The redizzy tracker is also used lower damage from any followup combos.
-Projectile damage is reduced by 1 if used as OTG alongside the redizzy tracker reduction, but does not scale by damage.

Character Changes
Note: There are too many for brevity, so a general list of notable changes is provided instead
-Forward speed increased to be faster than back speed
-Damage modifiers:
--Bowser= 125%
--DK Jr.= 112%
--Peach=  75%
--Daisy=  99%
-Close and Far normals damage swapped, with close normals now being weaker
-Fireball cooldown reduced from 64 ticks (256 frames) to 20; Mario has 19 and Yoshi has 18
-More attacks are capable of hitting upward, with Close P being able to beat jump-ins
-Range for most attacks increased
-Close P has one more frame of recovery
-Characters with a tick-3 Crouch P have reduced recovery and a bit more reach
-Sweeps do a bit more damage and have more range
-Uppercuts move forward, and have better overall reach
-Koopa, Bowser, and DK Jr. do extra damage on their throws
-Flying attacks except for Yoshi's cannot hit ducking opponents
-Attack and fireball invuln added for specials, but not all specials have such
-Crouching attacks cannot hit airborne opponents
-Jump Attacks normalized:
--Punches have more forward reach but less vertical reach
--Kicks have more vertical reach but less forward reach
--Rising attacks cover more upward and do 6 damage
--Falling attacks cover more downward and do 8 damage
--Mario/Luigi have in-between ranges for their neutral jump P/K
-Mario and Luigi decloned:
--Mario has more i-frames on specials, Luigi's move further and do more damage
--Mario DP has better upward coverage, Luigi covers downward
--Mario Flying Kick has better horizontal range, Luigi Flying Punch has more vertical reach
--Mario has less cooldown on fireball, Luigi's starts further out
--Luigi walks slower than Mario
-Bowser's walkspeed increased to be slightly slower than average
-Bowser Dive now has movement
-Koopa Shell Slide attack invulnerability no longer hard-coded nor lasts the entire duration; projectile invuln added
-Koopa Close crouch P removed; now done with D,F,P. It throws when close enough and not in blockstun
-DK's projectile can be avoided if airborne during a special move, but otherwise ignores invuln
-Fixed Mario air command normal and allowed Luigi and Toad to use it too
-Yoshi's kicks have long reach
-Yoshi's Tongue hits sooner and can hit well-beyond his nose
-Peach's Hair Whip has less range, but hits 1 tick sooner; Daisy's remains close to the original
-Animations have been repositioned to look cleaner on the x-axis

If you want to figure out the meta and tech for yourself, then don't read the following section. There was a lot of shock and awe while figuring out the game myself, and these protips give a general outline of what you can possibly do.

-Block damage and unblockables do not exist. The only way to get guaranteed damage is to throw on wakeup, but it's still possible to reverse out of it.
-Normals and specials can be cancelled into specials anytime, but you can't cancel while airborne nor into the same special again. You can guard-cancel into specials as well.
-You can also cancel throws, and even throw on their wakeup, but there's a limit to how many times you can throw in the corner before the game stops you one way or another. The first few ticks can't be cancelled to help throws work properly and encourage skill.
-Hold A before your fireball comes out for it to move faster. They rely on the fireball state itself, and will despawn if you cancel out or get hit. They can hit OTG and will let you juggle. While they normally have a cooldown upon coming out, clashing resets it. If you don't have a special to bypass them, this is a good defensive option if stuck in another attack.
-A full redizzy combo forces a normal getup. OTG fireballs do not work during this, ending your combo. It is up to you to decide whether to cut your combo short for dizzy, or go for damage. Alternatively, you can sacrifice the dizzy for some quick damage by following up your OTG fireball with another attack. Dizzy doesn't reset if they never went to the dizzy state, but you can't dizzy them again until they touch the ground.
-You can attack while falling after an air hit. "Breaking" is as basic as it is important: it stops juggles and lets you punish bad anti-airs. Use P to challenge jumps and K if they stay on the ground. Yoshi needs to do the opposite.