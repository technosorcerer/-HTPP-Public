"Mobile Suit Z Gundam Hot Scramble"
Traducción al Español Ver. 1.3 (29/03/2025)
por Max1323 (Traducciones Max1323).
---------------------------------------------------
Descripción:
Basado en el anime de Mobile Suit Z Gundam (Kidou Senshi Z-Gundam).
Hot Scramble es un juego de acción de disparos,
el objetivo es derribar a los demás suits y
luego ir a las naves enemigas para destruir
su núcleo y así sucesivamente.

Desarrollado: Game Studio
Publicado:    Bandai
Lanzamiento:  28/08/1986 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregó solo la Ñ por temas de espacio.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/

Archivo IPS
Kidou Senshi Z Gundam - Hot Scramble (Japan).nes
File Size:    160 KB
File MD5      BBD0AC6C2E97E33926804B61DBD93922        
File SHA-1    E95F90B4BC4601CBFECD468678B4A7D1FBB5DDFF
File CRC32    1D8C24AD