Kiwi Kraze - A Bird-Brained Adventure! (NES)
Traducci�n al Espa�ol v1.0 (23/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kiwi Kraze - A Bird-Brained Adventure! (U) [!].nes
MD5: 938f4640c7d3812d554d93d09ddb16ed
SHA1: 09d4793feda89b6878394ba9ed7bc89fa4fd0e53
CRC32: 7caf2452
262.160 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --