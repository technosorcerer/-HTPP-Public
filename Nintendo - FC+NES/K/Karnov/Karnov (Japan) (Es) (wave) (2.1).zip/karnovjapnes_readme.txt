Karnov (NES)
Traducción al Español v2.1 (16/11/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de 	Eien Ni Hen / Vice Translations.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducido GAME OVER
-Retraducción del script
-Traducida pantalla de "STAGE"
-Traducido PAUSE
-Traducido READY
-Traducido THE END
V2.1:
-Arreglada cabecera manualmente para mejorar compatibilidad con algunos emuladores.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Karnov (Japan) (Rev 1).nes
MD5: 35fa43f7ac7d25a3a0c1813c14999b3b
SHA1: 4bf5cab72a36ac61c2138dbaabc31e32a6509b8c
CRC32: 63d71cda
196624 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --