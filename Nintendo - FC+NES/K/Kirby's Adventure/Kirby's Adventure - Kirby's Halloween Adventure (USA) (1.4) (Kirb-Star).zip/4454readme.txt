KIRBY'S HALLOWEEN ADVENTURE

HOW TO PATCH:
-Download Lunar IPS (FLIPS)
-Put APPLY PATCH
-Select the original rom, make sure it's Revision A of Kirby's Adventure.
-Apply the patch you just downloaded to the rom, and it'll create a new rom file.
-And presto! Kirby's Halloween Adventure is all yours now!

RECOMMENDED PROGRAM SETTINGS:
=================================

Mesen is probably the best emulator to run this romhack on, and with how prone to lag the original game is, here's a small fix:

-Go to Options -> Emulation
-Go to Overclocking
-PPU Vertical Blank Configuration
-Type a large number (even 999) for the first option (Before NMI).
-Presto! Kirby's Adventure with no lag can be enjoyed now!

Instructions for FCEUX:
-Go to Config
-Go to Timing 
-Type a large number where it says Overclocking (preferably 100)
-And presto! You can now play Kirby's Halloween Adventure with no lag.


PATCH 1.4
==========
The final patch is upon us! After a whole year with the previous final version around, I decided to celebrate this year's halloween with a brand new overhaul!
-Every level has been modified and transitions into each other more naturally now, pay attention to the backgrounds to catch what I mean.
-New Mid-Bosses! Mother Moth over Bugzzy and Tokkon over Mr. Tick Tock
-New Enemies! Many variants and enemies have been added, such as Gaw Gaw, Keke, Como, Nidoo, Clown Acrobot, Chuckie, etc!
-Subgames now boast unique graphics! Look for enemy cameos in Crane Fever and Quick Draw! Egg Catcher now has you catch Doomer-themed eggs.
-Warp Star Stations replaced with a unique subway aesthetic!
-Hub Areas have unique icons for each world now.
-Level background details have been edited to fit their world theme much closer. Also some of the levels have had their backgrounds edited to tell apart easier what's background and what's foreground.
-MAJOR Overhauls for Skull Street, Ghostly Graves and ESPECIALLY Hades Harbor. As stated before, there's no major repeats with the original game now, so expect all levels to feel unique now.
-Balanced the difficulty on the game's latter worlds, with most Twin mid-bosses being trimmed to one, as well as many Switch puzzles being made a bit more obvious.
-And many more surprises!

KNOWN ISSUES:
Present in the original game are a couple things you may run into, among these include:
-[SEIZURE WARNING]: Crash and other boss and enemy patterns flash rapidly, and I haven't found a method to remove these effects. Avoid using Crash if you're sensitive on the eyes.
-Ice and Freeze won't be able to kill Heavy Mole, only drain their health, but spitting the ability star or the boss' projectiles will be able to defeat them.
-Western tileset is still a bit hard to tell what's solid and background, these graphics are shared with Quick Draw, so there's not much room to modify these, apologies.



This is still quite an old game, so here's a few tips to defeat a few of the lategame bosses if you plan on playing the game on one sitting in a stream:

-Meta Soldiers: They resist most abilities, and it's easier to fight them with just Inhale, as that'll defeat them in one-swoop. Backdrop and Throw work wonders for them.
-Meta Knight: The game will force you to use Sword, so just spam the B button to attack non-stop while keeping your distance away from Meta Knight. Also slide and jump to move quicker if you want to dodge his aerial attacks easier.
-King Dedede: He resists most abilities, except 3 ones: Hammer, Hi-Jump and UFO. Hammer can be obtained from World 6's Museum, and Hi-Jump is on the room previous to his boss fight. Most recommended is to fight him with just Inhale though, but if you want UFO to snap the fight in half, inhale both the Stone and Freeze enemies in the last room to get Mix and let the roulette finish on its own to get it.
=============

==================================================================
Thanks a lot for downloading this project! This has been the fruit of my work for the last months, so I thank you for that. Have a nice day and enjoy playing! Happy Halloween!

-Kirb-Star

Special Thanks:
-Hal Laboratory for making this amazing game and franchise!
-YY-CHR's Developers for their awesome sprite editing program
-Revenant for creating KALE, an incredible editor for this game
-Lard Pulsar for teaching me about text hex coding in FCEUX
-@GAMACHEAH1 for making such an amazing boxart
-Antdude for checking out the very first version of this once simple romhack and motivating me to make an even better update
-And you!







==================================================================
==================================================================
==================================================================
PAST CHANGELOGS:
==================================================================
PATCH 1.3
========
-Due to the game being somewhat rushed for SAGE 2020, a new additional update has been made! It includes a new mid-boss replacement: Bonkerstein! (Bonkers with a Frankestein reskin)
-Finished level design for all intended levels now, basically the romhack is complete now
-Quality of life adjustments (no more misplaced tiles or that stuff)
-Made several enemy placement tweaks and other stuff of the same kind

=====
PATCH 1.2
Developed by Kirb-Star, 2020 update:

This is it! The long awaited updated version of Kirby's Halloween Adventure!
Now about 90% of the game's levels are modified, as well as several improvements (like bug fixes on some areas' exits, glitched screen intros, etc)

New Additions:
--Dozens of new enemy sprites have been added in, giving the game even more variety than before!
--6 Brand new level tilesets! These feature:
-Wild West (constructed using Quick Draw's assets)
-Underground Art Gallery (using the unused cave tileset for the base)
-Graveyard (mainly inspired by Amazing Mirror's Moonlight Mansion, brand new sprites)
-Haunted Circus (Based on Triple Deluxe's circus level, new sprites as well)
-Factory/Laboratory (Based on Kirby 64's Factory inspection level)
-Volcanic Temple (Based loosely on Dangerous Dinner from RTDL, but it doesn't borrow much from many Kirby games)

--All bosses have been modified! From Adeleine taking over Paint Roller's sprites, Kracko's Revenge being fought atop a giant tower, every boss is now packing a brand new experience
-Bugfixes (graphical errors like Level 6's title screen breaking and other minor errors have been corrected)
-New Title Screen!
-New level layouts, about almost every level has had modified levels or flat out replaced ones, have fun as many surprises await you!
