changelog:

01.09.2023 (v2.2 / 2023.09)
+ correct wave attack sfx time (less music interrupt).
+ updated stage7 song.
+ added music in cutscene after stage6.

07.08.2023 (v2.1 / 2023.08)
+ fixed not working on some emulators.

09.07.2023 (v2.0 / 2023)
+ added new music.


BOSS NAMES:
1) Karmagon.
2) Mousen.
3) Mudgloom.
4) Doghunter.
5) Lizartini.
6) Maledictus Maggot.
7) Catsher.
