# Kick Master Input Bugfix v1.0.0

Planned and developed by Alex "trap15" Marshall in 2025.

email: <trap15@raidenii.net> | web: <http://daifukkat.su/> | twitter: @trap0xf

Source code: <http://bitbucket.org/trap15/kickmaster_inpfix/>


# About

This hack fixes a poorly implemented workaround to the DPCM input bug, as described on NESdev: <https://www.nesdev.org/wiki/Controller_reading_code#DPCM_Safety>

The original workaround implementation could cause dropped inputs, especially during percussion-sample-heavy sections in the game, as it just reads the inputs twice and any buttons that don't match are ignored. This hack will no longer cause dropped inputs, as it implements the workaround in the "standard" way, by reading the inputs until they stop changing.

I just wrote the patch into the ROM with Mesen and exported the IPS, so the source includes the bytes changed for manual application rather than a real patcher.


# History, etc.

* v1.0.0 - 20250517 - Public release
    - First public release
