KING FISHING SPECIAL - RELEASE V1.0

Setup ============================================

	- Using either NintendulatorNRS or FCEUX is recommended, but other emulators should work fine.

	- Make sure a Zapper/light gun is connected in controller port 2. this should also go for if you are running 
	this on physical hardware (however i haven't tested if it works on physica; hardware). otherwise the title
	credit cards are absent.
	
	- This is an NTSC game so make sure your emulator reigon is set to NTSC.

Credits ==========================================

	Credits to krzysiobal for dumping the King Fishing Excalibur version:

		Wesbite:			krzysiobal.com
		Check out their NES flashcart: 	krzysiocart.com

	Game Hacked by Yuewaix

		sonwaix.net

==================================================
DOWNLOAD THE GAME AT ROMHACKING.NET

Copyrights 2024 Yuewaix (A Company of Sonwaix Computer Development Co., LTD.)