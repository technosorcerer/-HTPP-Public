Thank you for reading the README file of this hack! 
This is the first hack I made with my new laptop!
Anyways, the only sprites I didn't change were
1.squish sprite during multiplayer gameplay
2.specific mario "arms up" pose
New addition(s)
1.additional patch for the assymetrical beta pose for mario found in the playchoice 10 arcade