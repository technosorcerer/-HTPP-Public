Kid Kool and the Quest for the 7 Wonder Herbs (NES)
Traducción al Español v1.0 (22/01/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Kid Kool and the Quest for the 7 Wonder Herbs (U) [!].nes
MD5: 6edf7f10231fc9cd7389f755dd1fea0d
SHA1: b851ef1c19478df8987a7f82314ffebbf9884341
CRC32: 99626ab1
131088 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --