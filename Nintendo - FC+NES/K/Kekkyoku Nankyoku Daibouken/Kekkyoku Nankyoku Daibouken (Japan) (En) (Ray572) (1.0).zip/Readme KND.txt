Name: Antarctic Adventure (World)
Name Original Japan: Kekkyoku Nankyoku Daibouken (Japan)
Patch Add Versión 1.0.

Full translation of the game Kekkyoku Nankyoku Daibouken or Antarctic Adventure for NES, it's my first translation... and yes, I know it's a simple translation and there are already a couple of translations published... But mine has something different... I restored the original countries and removed the 2 that have nothing to do with having bases or claiming sovereignty in Antarctica. The two removed countries were the USA and Japan (I'm really sorry) and they were replaced by Chili and Norway. Leaving only the original countries of the cold continent.
I used Mesen to translate and change the flag sprites. I would have liked to keep those countries taking advantage of repeated flags like the USA and Australia but both use the same sprite in each stage.
I also included an alternative patch that is an addition for the English translations of the game, tested in the translations of Dvd Traducciones and Quest Games.
And as in my previous publications, bonus media is included.
I hope you like it.

Kekkyoku Nankyoku Daibouken (T-En Ray572 1.0 Original Countries).ips:               Full translation of the game with its countries restored
Kekkyoku Nankyoku Daibouken (Add-En Ray572 1.0 Original Countries) (DvDT,QuestG.):  Addendum for the translations of DvD Traducciones and Quest Games to keep their original translations and only restore the countries. I recommend the Quest Games translation.
https://www.romhacking.net/translations/864/
https://www.romhacking.net/translations/1549/

Nombre: Kekkyoku Nankyoku Daibouken (Japan) (Rev 1).nes
CRC-32: cb57fb29
MD4: 5f59cb2e3f4c5ab33201e2a7b638bcf8
MD5: c73b128fbfc31c0900c1a5972a08d54d
SHA-1: e2d7243a7c87eea7d94fb05852522b60a79b7a46

Translation by Ray572 

The file comes with a bonus media made by me from the Japanese version covers but modified to the "World" version. :)