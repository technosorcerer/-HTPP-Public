·Puedes los hacks de Crying Onion aquí:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

·Canal de Youtube:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

·Twitter:
@CryingOnion3

·Instagram:
crying.onion


                     d8.            #############################################
                   d888 d8          #						#
                  d8888d8'          #						#
                 d888888P           #	      :::: Ranma vs. Ranma! ::::        #
          __  .m8888888P            #						#
          # \d888888888b            #		   :::: ver.2.2 ::::		#	
        |   d888888P`888b           #						#
        |# 88888888   Y888          #	 :::: Arte ASCII de Dov Sherman ::::	#
         \ 88888888    Y88          #						#
        /#\8888888b.   (|L          #						#
        \/  Y8888888b.__dP)         #############################################
       /  #| Y8888888888(/
       \#  db#Y888888888(
        \_|88b.#~"""8mm88b
            Y88bmmmd8888888(\ )
             d8888888888888L_T~
             ""Y88P"Y88888P
                  `-"888"~


1) Introducción

2) Lista de cambios

3) Parches y sus características

4) Agradecimientos

_______________________________________________________________________________________________________________________________________________________


1) Introducción


En primer lugar, gracias por descargar este hack, el cual es una actualización de uno de mis primeros trabajos, por lo que es un lavado de cara a éste
y al mismo tiempo, una celebración de mi quinto aniversario en el mundillo del romhacking.

Kung Fu Master es un Arcade de 1984 desarrollado por Irem, considerado el padre del género beat'em up. En solo un año el título fue portado a la
Famicom y varios ordenadores de la época. En él encarnamos a Thomas, un artista marcial al que Mr. X secuestra su prometida, Sylvia, para extorsionarlo.
Para rescatar a Sylvia, deberemos subir cada planta de una torre enfrentándonos a esbirros genéricos y a un jefe, hasta llegar al combate final con
Mr. X. Si ésto os suena, se deberá a que Irem tomó inspiración en la última cinta de Bruce Lee, "Juego con la muerte", aunque oficialmente se basa en
"Wheels on Meals", una película de Jackie Chan.

Siendo el protagonista un joven y talentoso artista marcial, parecía que emparejar este clásico con uno de los más divertidos luchadores de la historia
del manga era una buena idea y me puse a ello. Ésto sucedió en 2018 y viendo el resultado con los ojos de ahora, sentía que con la habilidad adquirida
desde entonces, podría llevar el hack a un nuevo nivel.


2) Lista de cambios


Ranma vs. Ranma! 2.0

·El archivo comprimido contiene dos parches: el nuevo hack y el original, por si los usuarios sienten curiosidad por compararlos.

·ABSOLUTAMENTE TODO ha sido mejorado: pantalla de título, la HUD, fondos y sprites (siempre teniendo en mente que es un juego antiguo).

·Se han añadido o modificado cameos de personajes: a ver si los reconocéis todos ;).


Ranma vs. Ranma 2.1

·A los dos parches anteriores se les suman dos más (los detalles en el punto 3), ampliando las opciones para el usuario.

·Se han realizado correcciones y mejoras para en cada caso, sacar el mejor partido a los gráficos.


Ranma vs. Ranma 2.2

·Se elimina el parche con chaleco blanco y pasamos a tener 3 disponibles: El original de 2018, con Ranma-chico o con Ranma chica.

·Se ha añadido un nuevo cameo que se omitió en la versión 2.1.

·Se ha aprovechado para realizar retoques menores.


3) Parches y sus características

·Ranma vs Ranma! Old Edition.ips --------------> El hack original publicado en 2018.

·Ranma vs Ranma! Ranma-Kun Edition.ips --------> Versión de 2023 en la que podemos jugar como Ranma chico.

·Ranma vs Ranma! Ranma-Chan Edition.ips -------> ¡Versión de 2023 en la que podemos jugar como Ranma chica!


4) Agradecimientos

·En especial a Ssicosomatico/Terwilf, por sus enseñanzas y ayudar a localizar algunos valores hexadecimales que resultaban esquivos.

·A los usuarios de la comunidad RHDN greyfox, xenophile y RHZ por su participación en el foro del proyecto.

·A mis amigos Super Buni y Protopixel, que han aportado sugerencias y realizado el trabajo de testeo.

·A mi adorada Vicky, por ser una persona maravillosa y por supuesto, por apoyarme en mis proyectos.