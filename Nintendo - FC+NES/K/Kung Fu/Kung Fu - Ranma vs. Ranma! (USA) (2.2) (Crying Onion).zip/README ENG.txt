·You can find the hacks from Crying Onion here:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

·Youtube Channel
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

·Twitter:
@CryingOnion3

·Instagram:
crying.onion


                     d8.            #############################################
                   d888 d8          #						#
                  d8888d8'          #						#
                 d888888P           #	      :::: Ranma vs. Ranma! ::::        #
          __  .m8888888P            #						#
          # \d888888888b            #		   :::: ver.2.2 ::::		#	
        |   d888888P`888b           #						#
        |# 88888888   Y888          #	 :::: ASCII Art by Dov Sherman ::::	#
         \ 88888888    Y88          #						#
        /#\8888888b.   (|L          #						#
        \/  Y8888888b.__dP)         #############################################
       /  #| Y8888888888(/
       \#  db#Y888888888(
        \_|88b.#~"""8mm88b
            Y88bmmmd8888888(\ )
             d8888888888888L_T~
             ""Y88P"Y88888P
                  `-"888"~


1) Introduction

2) Features list

3) Patches and their features

4) Acknowledgements

____________________________________________________________________________________________________________________________________________


1) Introduction


Firstly, thanks to download this hack, which is a facelift of one of my first works and at the same time, a celebration of my fifth anniversary
in the romhacking world.

Kung Fu Master is a 1984 arcade game developed by Irem, considered the grandfather of the beat'em up genre. In just one year the title was
ported to the Nintendo Famicom and several computers of the time.

In this game we take the role of Thomas, a martial artist whose fiancée, Sylvia, is kidnapped by Mr. X in order to extort him. To rescue Sylvia,
we will have to climb each floor of a tower facing generic henchmen and a boss, until we reach the final battle with Mr. X. If this sounds
familiar, it's because Irem took inspiration from Bruce Lee's last film, "Game of Death", although officially it's based on "Wheels on Meals",
a Jackie Chan movie.

With the main character of the game being a young and talented martial artist, it seemed like pairing this classic of the Arcades with one of
Rumiko Takahashi's funniest characters was a good idea and I went for it. This happened in 2018 and looking at the result with now eyes,
I felt that with the skill acquired since then, I could take the hack to a new level.


2) Features list


Ranma vs. Ranma! 2.0

·The compressed file contains two patches: the new hack and the original, in case users are curious to compare both.

·ABSOLUTELY EVERYTHING has been improved: title screen, HUD, backgrounds and sprites (always keeping in mind that this is an old game).

·Cameos of characters have been added or modified: let's see if you recognize them all ;).


Ranma vs. Ranma 2.1

·In addition to the two previous patches, there are two brand new ones ( listed in section 3), which offer more options to users.

·Fixes and improvements have been made to get the best out of the graphics in each version.


Ranma vs. Ranma 2.2

·The patch with white vest is removed and we now have 3 available: The original from 2018, and the new one playing with Ranma-boy or with Ranma-girl.

·A new cameo that was omitted in version 2.1 has been added.

·Minor improvements have been made.


3) Patches and their features


·Ranma vs Ranma! Old Edition.ips --------------> The hack publisehd in 2018.

·Ranma vs Ranma! Ranma-Kun Edition.ips --------> 2023 version where we can play as Ranma boy.

·Ranma vs Ranma! Ranma-Chan Edition.ips -------> 2023 version where we can play as Ranma-girl!


4) Acknowledgements


·Especially to Ssicosomatic/Terwilf, for his teachings and help locating some elusive hex values.

·To the users of the RHDN community greyfox, xenophile and RHZ for their participation in the project forum.

·To my friends Super Buni and Protopixel, who have made suggestions and the testing work.

·To my beloved Vicky, for being a wonderful woman and, of course, for supporting me in my projects.