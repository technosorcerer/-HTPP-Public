///////////////////////
/                     /
/       KUNG FU       /
/                     /
/ Spanish translation /
/                     /
///////////////////////


( 1. MAIN INFO
(( 2. VERSION HISTORY
((( 3. LINKS



( 1. MAIN INFO
------------------------------
This translation to spanish language was made by Manuel Riguera for "RC Translations",
part of "La Retrocaverna".

This patches the original NES Kung Fu (U) game rom into spanish language.



(( 2. VERSION HISTORY
------------------------------
v1.0 12 JAN 2016
Every text translated.



((( 3. LINKS
-------------------------------------------------
WEB: http://laretrocaverna.es
YOUTUBE: https://www.youtube.com/c/laretrocaverna
