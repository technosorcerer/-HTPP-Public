"Ninja Enmascarado Akakage"
Traducción al Español Ver. 1.0 (06/12/2024)
por Max1323 (Traducciones Max1323).
Basada en la gran traducción de Zynk Oxhyde.
---------------------------------------------------
Descripción:
Kamen no Ninja: Akakage (Ninja Enmascarado Akakage) es un videojuego basado en el manga/anime.
La historia se desarrolla en el Japón feudal y gira en torno a
Akakage y sus compañeros Aokage y Shirokage quienes pelean contra los malvados señores de la guerra, magos y kaijus utilizando aparatos de alta tecnología.

Desarrollado: Shouei
Publicado:    Toei Animation
Lanzamiento:  20/05/1988 (JAP)
---------------------------------------------------
Acerca del proyecto:
-La mayoría de los textos están traducidos. Se agregaron
los caracteres españoles.
---------------------------------------------------
Instrucciones del parche:
Utilizar Lunar IPS (PC)
Utilizar UniPatcher (Android)
Utilizar Rom Patcher (Parcheador Online):
https://romhackplaza.org/patch/

Archivo IPS
Kamen no Ninja - Akakage (Japan).nes
File Size     128 KB
File MD5      59E32A7B2332A1C9AB0AE645C8C211F6        
File SHA-1    DBADDB9427BE2602B64698E6DFBA3B5788EE2762
File CRC32    1BC800E1