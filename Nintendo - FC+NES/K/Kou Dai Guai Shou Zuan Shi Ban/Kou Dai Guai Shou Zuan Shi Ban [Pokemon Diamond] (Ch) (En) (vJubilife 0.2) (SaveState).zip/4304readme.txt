     -  Pokemon Diamond NES English translation  -

Hello there, folks! This is an all-new translation for
Kou Dai Guai Shou - Zuan Shi Ban (Pokemon Diamond) from
Chinese to English.


So far, the Hack contains: 
- Redone graphics for many tilesets
- Redone text boxes designed to look like those from the
  actual Pokemon Diamond
- Translation to English up to Jubilife  City
- Most of the Battle system text translated to English
- A redone title screen

The zip folder should contain two .ips files to be
patched to the game, and this ReadMe file. 


INFO ON MAPPERS
There is an optional patch here for mapper 224. It is a
good idea to test both with and without the mapper 224
patch for your emulator. This is because the ROM for this
game and others like it were mistakenly labeled as a
mapper 4 game when they were ripped, rather than mapper
224. Some emulators added support for mapper 4 with the
correct configuration of this game, while others correctly
support only mapper 224. The Mapper 224 patch corrects the
error and correctly changes the ROM header to mapper 224. 

Here is a list of the emulators I tested:

Emulators that support mapper 4 for this ROM:
- FCEUX (Windows, Wii)
- NES.EMU (Android)

Emulators that support mapper 224 for this ROM: 
- Mesen (Windows)

Emulators that don't support this ROM at all:
- JNES (Windows)
- PocketNES (GBA)
- NESDS (Nintendo DS)
- NesterDS (Nintendo DS)

Thanks to torridgristle for helping with text pointers
and some other things!


Thanks to you for downloading, and enjoy this translation!