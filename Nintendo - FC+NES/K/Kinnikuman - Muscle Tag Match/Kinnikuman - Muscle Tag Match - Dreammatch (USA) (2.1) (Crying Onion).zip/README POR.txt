﻿

● Você pode encontrar mais hacks do mesmo autor neste link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Ir

● Você também pode ver pelo Youtube, este trabalho (e o de outros) aqui:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

● E, é claro, se você quiser acompanhar projetos em andamento, pode fazê-lo através de sua conta no Twitter, onde ele normalmente
compartilha capturas de tela, vídeos, pensamentos, etc:
@CryingOnion3


   #############################################
   #                                           #
   #                                           #
   #    ::::   Kinnikuman: Dreammatch   ::::   #
   #                                           #
   #    ::::         Ver.1.0            ::::   #
   #                                           #
   #############################################


	1) Introdução/lista de melhorias

	2) Lista de compatibilidade

	3) Diferenças entre as regiões

	4) Lista de movimentos/ataques especiais

___________________________________________________________________________________________________________________________________________


1) Introdução/lista de melhorias


	Antes de mais nada, obrigado por baixar este hack, que é basicamente uma tentativa de melhorar um dos jogos mais infames de
	Nintendo NES, 'Kinnikuman: Muscle Tag Match

	Este jogo é baseado na manga/anime de sucesso criado pela dupla artística "Yudetamago" em 1983. É uma paródia do gênero "tokusatsu".
	e da luta livre em geral, com caracteres bizarros às vezes até criados por fãs. Nos Estados Unidos, os caracteres são conhecidos
	por a linha de figuras de borracha comercializada pela Mattel para explorar o boom da luta livre de meados da década de 80.
	
	Os comentários mais negativos sobre este jogo se concentram em dois aspectos: Controle estranho e gráficos medíocres. 
	Estes comentários ignoram o fato de que o jogo é de 1985 e tem apenas 24 kilobytes de memória, metade do tamanho do clássico Donkey Kong!
	
	Então, este hack tenta resolver pelo menos um desses problemas, melhorando os gráficos e tornando os caracteres reconhecíveis.
	para qualquer fã.
	
	Aqui está uma lista de melhorias:


		Kinnikuman - DX Edition Ver. 1.0

			● Melhorias na aparência dos personagens. Agora eles são mais reconhecíveis, mas ainda têm um estilo SD.

			● O personagem de lançamento de power-ups conhecido como Meat in the manga/anime é substituído por Nachiguron
			  (o monstro/kaiju que é um fã de Kinnikuman).
			
			● Melhorias na barra superior: Agora eles têm um estilo de Street Fighter II.

			● Melhorias na paleta de cores por razões cosméticas, e às vezes práticas (a lona é branca pura que
			  pode ser irritante de ver a longo prazo, especialmente em televisores antigos).


		Kinnikuman: DX Edition Ver. 2.0


			● Melhorias na aparência dos personagens. Agora eles se parecem mais com o que o autor tinha em mente em seu
			  primeira tentativa, com rostos mais detalhados e corpos estilizados.

			● Terryman é o "típico cowboy", inicialmente apresentado na manga/anime como um super-herói/chojin sem
			  defeitos (o oposto do Kinnikuman), mas que va perdendo o interesse à medida que a trama avança. Tem sido
			  substituído por Blackhole, um dos Sete "Super-Heróis Maléficos/Akuma Choujin", como Buffaloman.		

			● Melhorias na barra superior.

			● Melhorias na Paleta de cores. Os caracteres têm melhor aparência e são menos confundidos com o fundo.

			● Inicialmente, Asuraman manteve as cores mangá (azul e dourado). Ele agora usa uma paleta de cores
			  mais como o anime, como os outros personagens do jogo.

			● Pequenas melhorias. Agora o público nos estandes parece mais difuso novamente, e detalhes foram acrescentados
			  para as cordas do anel.


		Kinnikuman: DX Edition Ver. 2.1

			● Pequeno error detectado e corrigido: Nachiguron usou a mesma cor do fundo do estágio 3 (0C). Agora
			  a cor preta (0F) é utilizada.

		Kinnikuman: Dreammatch 1.0

			● A principal novidade desta versão (renomeada "Dreammatch") é sua compatibilidade. O arquivo *.rar inclui
			  5 patches diferentes que o fazem funcionar com praticamente todas as versões existentes do jogo (você pode
			  dar uma olhada na Lista de Compatibilidade).

			● Ligeiras melhorias na tela de título.

			● A nova fonte de texto dá ao jogo um visual diferente e renovado.

			● Melhorias na barra superior (novamente).

			● Nova tela de título para a versão americana que va mais com o estilo manga/anime.

			● Adiciona intencionalmente diferenças entre a versão americana e japonesa (você pode conferir o
			  Diferenças entre as regiões).

____________________________________________________________________________________________________________________________________________


2) Lista de compatibilidade


		● Kinnikuman - Dreammatch Ver. A --> Kinnikuman - Muscle Tag Match (J) (PRG0) [!].nes
						 --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1].nes
						 --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b2].nes
						 --> Kinnikuman - Muscle Tag Match (J) (PRG0) [p1].nes


		● Kinnikuman - Dreammatch Ver. B --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o1].nes
						 --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o2].nes
						 --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o3].nes
						 --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o4].nes
						 --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b2][o1].nes
						 --> Kinnikuman - Muscle Tag Match (J) (PRG0) [p1][o1].nes


		● Kinnikuman - Dreammatch Ver. C --> Kinnikuman - Muscle Tag Match (J) (PRG1) [!].nes


		● Muscleman Ver. A	       --> M.U.S.C.L.E. (U) [!].nes
					       --> M.U.S.C.L.E. (U) [b1].nes
					       --> M.U.S.C.L.E. (U) [b3].nes
					       --> M.U.S.C.L.E. (U) [o1].nes
					       --> M.U.S.C.L.E. (U) [o2].nes
					       --> M.U.S.C.L.E. (U) [o3].nes
					       --> M.U.S.C.L.E. (U) [o4].nes


		● Muscleman Ver. B	       --> M.U.S.C.L.E. (U) [b1][o1].nes
					       --> M.U.S.C.L.E. (U) [b1][o2].nes
					       --> M.U.S.C.L.E. (U) [b1][o3].nes
					       --> M.U.S.C.L.E. (U) [b1][o4].nes
					       --> M.U.S.C.L.E. (U) [b2].nes
					       --> M.U.S.C.L.E. (U) [o5].nes


	Nota: O arquivo "M.U.S.C.L.E. (U) [b4].nes" é aparentemente um rom corrupto (não funciona corretamente na maioria dos
	emuladores existentes (como FCEUX, Mesen ou Nestopia), portanto, tem sido impossível testar sua compatibilidade com o hack.

____________________________________________________________________________________________________________________________________________


3) Diferenças entre as regiões

	O jogo original tem algumas diferenças entre as versões lançadas nos EUA e no Japão. Algumas delas são esperadas, tais como la tela
	de título ou a música, mas o mais notável é a omissão de um personagem controverso (um super-herói/chojin alemão que usa um
	uniforme da SS e usa uma suástica em seu peito). Na versão americana, Geronimo, um super-herói/chojin indígena americano toma seu
	lugar.

	A fim de dar mais exclusividade a cada versão, as seguintes mudanças são acrescentadas:

		● A versão americana tem Meat (o melhor amigo e conselheiro da Kinnikuman) como o personagem que lança power-ups do. Na
		  versão japonesa é substituído por Nachiguron (um monstro/kaijuu que foi salvo por Kinnikuman e tornou-se seu maior fã).

		● A versão americana tem Geronimo (o nativo americano), Terryman (o cowboy) e Ramenman (o típico lutador de kung-fu)
		  como personagens exclusivos. A versão japonesa tem Brocken Jr. (o nazista), Blackhole (membro dos Sete "Super-Heróis")
		  Diabólicos/Akuma Choujin") e Mongolman (alguém suspeitamente parecido com Ramenman, mas não vou explicar por que não fazo
		  Spoilers XD).

____________________________________________________________________________________________________________________________________________


4) Lista de movimientos/Ataques  especiais


		● Pressione (B)
		  --> Pular

		● Pressione (A)
	 	 --> Punch

		● Pressione (B) e depois (A)
		  --> Chute Voador
	
		● Pressione (A) atrás de seu oponente
		  --> Duplex

		● Pressione para frente + (A)
		  --> Ele joga seu oponente contra as cordas

		● Pressione (A) após atirar o adversário contra as cordas
		  --> Aríete

		● Pressione (B) perto das cordas
		  --> Dê um impulso nas cordas

		● Empurrar contra as cordas e pressionar (A)
		  --> Ataque aéreo

		● Volte para o seu canto e pressione (A)
		  --> Mude seu caráter


	Todos os personagens têm os mesmos movimentos e ataques, até conseguirmos o power-up lançado por Meat/Nachiguron, que
	permite que você use seus próprios ataques especiais:


		● Kinnikuman
		  --> Kinniku Driver : Pressione (A) atrás de seu oponente	

		● Blackhole/Terryman
		  --> Bulldogging Headlock: Pressione para frente + (A) quando o oponente estiver na sua frente

		● Mongolman/Ramenman
		  --> Patada asesina: Pressione (B) e depois (A) quando o oponente estiver na sua frente

		● Robin Mask
		  --> Tower Bridge: Pressione (A) atrás de seu oponente

		● Buffaloman
		  --> Hurricane Mixer: Pressione (B) e depois (A) quando o oponente estiver na sua frente

		● Warsman
		  --> Bear's Claw: Pressione (B) quando o oponente estiver na sua frente

		● Asuraman
		  --> Asura Buster: Pressione (A) atrás de seu oponente

		● Brocken Jr./Gerónimo
		  --> Poison Gas Attack/Tomahawk: Pressione (A)
		