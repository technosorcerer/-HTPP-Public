

● You can find many more hacks from the same author at this link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

● You can also find him on Youtube, showing his work (and that of others) here:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

● And of course, if you want to follow closely his current projects, you can do it through their twitter account, where he usually share
screenshots, videos, thougts, etc:
@CryingOnion3


   #############################################
   #                                           #
   #                                           #
   #    ::::   Kinnikuman: Dreammatch   ::::   #
   #                                           #
   #    ::::         Ver.1.0            ::::   #
   #                                           #
   #############################################


	1) Introduction/features list

	2) Compatibility list

	3) Differences between regions

	4) Move list/Distinctive attack

___________________________________________________________________________________________________________________________________________


1) Introduction/features list


	First of all, thanks for download this hack, which is basically an attempt to improve one of the most infamous Nintendo NES games,
	'Kinnikuman: Muscle Tag Match'

	This game is based on the successful manga/anime created by the artistic duo “Yudetamago” in 1983. It’s a parody of the “tokusatsu”
	genre and of wrestling in general, with bizarre characters often created by fans. In the USA, the characters are best known for the
	line of rubber toys that Mattel distributed to exploit the wrestling boom on the middle of the 80’s.

	Most negative comments about this game focus on two aspects: : A clumsy control and poor graphics. These comments ignore that game
	is from 1985 and occupies 24 kilobytes of memory, the half of classic Donkey Kong!

	So, this hack tries to solve at least one of this aspects, improving graphics and making characters recognizable to any fan.
	
	Here’s a list of the changes:


		Kinnikuman - DX Edition Ver. 1.0

			● Improved character design. Now, all of them are pretty recognizable, but keeping the original SD style.

			● The "throwing power-ups" character known as Meat in the manga/anime has been replaced by Nachiguron (a kaiju/
			  monster fan of Kinnikuman).

			● Changes in the top bar: Now it has an SFII style.

			● Palette changes for cosmetic, and sometimes for practical reasons (the blank mat was annoying for
			  the eyes, especially on old TVs).


		Kinnikuman: DX Edition Ver. 2.0


			● Graphic improvement in character sprites. Now, they look like what the author of the hack intended
			  in his first attempt, with more detailed faces and stylized bodies.

			● Terryman is a "cowboy cliche guy", initially introduced in the manga/anime as a seemingly flawless chojin/
			  superhero (the opposite of Kinnikuman), but the character loses interest as the plot progresses. It has
			  been replaced by Blackhole, one of the "Seven Akuma Choujin/Devil Superheros", as Buffalo Man.

			● Revised Top Bar design.

			● Revised color palette. The characters look better and don’t get confused with the background color.

			● Initially, Asuraman retained the manga color pattern (blue and gold). Now, he shows a colour pattern close
			  to the anime, like the rest of the characters.

			● Slight improvements, such as the background audience that looks diffuse again, or details added to the ropes
			  of the ring.


		Kinnikuman: DX Edition Ver. 2.1

			● Small flaw detected and fixed: Nachiguron used the same color as the background of stage 3 (0C). Now it uses
			  black color (0F).


		Kinnikuman: Dreammatch 1.0

			● The most notable improvement of this hack (renamed as "Dreammatch") lies in its compatibility. The *.rar file
			  includes 5 versions of the patch that work with almost all existing roms (Check Compatibility list).

			● The title screen is updated with slight improvements.

			● Added a brand new text font that gives the game a new feel.

			● Revised (again) Top Bar design.

			● New title screen for the USA version that catches the style of the manga/anime.

			● Added intentional differences between USA/Japanese versions (check Differences between regions)

____________________________________________________________________________________________________________________________________________


2) Compatibility list


		● Kinnikuman - DX Edition Ver. 1.0  --> Kinnikuman - Muscle Tag Match (J) (PRG0) [!].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b2].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [p1].nes


		● Kinnikuman - DX Edition Ver. 2.1  --> Kinnikuman - Muscle Tag Match (J) (PRG0) [!].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b2].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [p1].nes


		● Kinnikuman - Dreammatch Ver. 1.0a --> Kinnikuman - Muscle Tag Match (J) (PRG0) [!].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b2].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [p1].nes


		● Kinnikuman - Dreammatch Ver. 1.0b --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o1].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o2].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o3].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o4].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b2][o1].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [p1][o1].nes


		● Kinnikuman - Dreammatch Ver. 1.0c --> Kinnikuman - Muscle Tag Match (J) (PRG1) [!].nes


		● Kinnikuman Ver. 1.0a	            --> M.U.S.C.L.E. (U) [!].nes
					            --> M.U.S.C.L.E. (U) [b1].nes
					            --> M.U.S.C.L.E. (U) [b3].nes
					            --> M.U.S.C.L.E. (U) [o1].nes
					            --> M.U.S.C.L.E. (U) [o2].nes
					            --> M.U.S.C.L.E. (U) [o3].nes
					            --> M.U.S.C.L.E. (U) [o4].nes


		● Kinnikuman Ver. 1.0b	            --> M.U.S.C.L.E. (U) [b1][o1].nes
					            --> M.U.S.C.L.E. (U) [b1][o2].nes
					            --> M.U.S.C.L.E. (U) [b1][o3].nes
					            --> M.U.S.C.L.E. (U) [b1][o4].nes
					            --> M.U.S.C.L.E. (U) [b2].nes
					            --> M.U.S.C.L.E. (U) [o5].nes


	Note: The "M.U.S.C.L.E. (U) [b4].nes" file is apparently a corrupt dump (it doesn't work properly in many of the existing emulators
	like FCEUX, Mesen or Nestopia), so it hasn't been possible to check its compatibility with the hack.

____________________________________________________________________________________________________________________________________________


3) Differences between regions


	Original game has a few changes between USA/Japanese release. Some of them are to be expected, like the title screen or the music,
	but the most noticeable is the omission of a controversial character (a German chojin/superhero who looks like an SS officer and
	has a swastika on his chest). In the American version he was replaced by Geronimo, a Native American chojin/superhero.

	With the idea of giving more exclusivity to each version, the following changes are introduced:


		● The American version has Meat (Kinnikuman's best friend and counselor) as the character that appears randomly throwing
		  power-ups. In Japanese version, he is replaced by Nachiguron (a kaijuu/monster who is saved by Kinnikuman and becomes
		  his biggest fan).

		● The American version has Geronimo (the Native American), Terryman (the cowboy) and Ramenman (the cliche kung-fu guy) as
		  exclusive characters. Japanese version has Brocken Jr.(the Nazi guy), Blackhole (member of the "Seven Akuma Choujin/
		  Devil Superheroes"), and Mongolman (someone suspiciously similar to Ramenman, but I won't explain why, because they would
		  be Spoilers XD).

____________________________________________________________________________________________________________________________________________


4) Move list /Distinctive attacks


		● Press (B)
		  --> Jump

		● Press (A)
	 	 --> Punch

		● Press (B), and then (A)
		  --> Air Kick
	
		● Press (A) from behind opponent
		  --> Back Body Drop

		● Press Forward + (A)
		  --> Throw opponent to the ropes

		● Press (A) after sending opponent to the ropes
		  --> Lariat

		● Press (B) near the ropes
		  --> Bounce off the ropes

		● Bounce off the ropes and press (A)
		  --> Flying Body Attack

		● Retreat to your corner and press (A)
		  --> Swap character

	All characters have the same moveset and attacks, until we collect the power-up thrown by Meat/Nachiguron, which allows us to use
	their Distinctive Attacks:

		● Kinnikuman
		  --> Kinniku Driver: Press (A) when you're behind your opponent

		● Blackhole/Terryman
		  --> Bulldogging Headlock: Press Forward + (A) when your opponent is facing you

		● Mongolman/Ramenman
		  --> Killer Kick: Press (B) and then (A) when facing the opponent

		● Robin Mask
		  --> Tower Bridge: Press (A) when you're behind your opponent

		● Buffaloman
		  --> Hurricane Mixer: Press (B) and then (A) when facing the opponent

		● Warsman
		  --> Bear Claw: Press (B) when your opponent is facing you

		● Asuraman
		  --> Asura Buster: P Press (A) when you're behind your opponent

		● Brocken Jr./Geronimo
		  --> Poison Gas Attack/Tomahawk: Press (A)
		