

● Puedes encontrar más hacks del mismo autor en este link:
https://www.romhacking.net/?page=hacks&genre=&platform=&game=&category=&perpage=20&order=&dir=&title=&author=crying+onion&hacksearch=Go

● También puedes encontrarle en Youtube, mostrando sus trabajos (y los de otros) aquí:
https://www.youtube.com/channel/UCKgNcvTtNkbT2hzIUZPHeuw

● Y por supuesto, si quieres seguir de cerca proyectos en curso puedes hacerlo a través de su cuenta de Twitter, donde suele compartir
capturas de pantalla, videos, pensamientos, etc:
@CryingOnion3


   #############################################
   #                                           #
   #                                           #
   #    ::::   Kinnikuman: Dreammatch   ::::   #
   #                                           #
   #    ::::         Ver.1.0            ::::   #
   #                                           #
   #############################################


	1) Introducción/lista de mejoras

	2) Listado de compatibilidad

	3) Diferencias entre regiones

	4) Lista de movimientos/Ataques distintivos

___________________________________________________________________________________________________________________________________________


1) Introducción/lista de mejoras


	Antes que nada, gracias por descargar este hack, que básicamente es un intento de mejorar uno de los juegos más infames de la
	Nintendo NES, 'Kinnikuman: Muscle Tag Match'

	Este juego se basa en el éxitoso manga/anime creado por el dúo artístico “Yudetamago” en 1983. Es una parodia del género “tokusatsu”
	y de la lucha lubre en general, con personajes bizarros a veces incluso creados por fans. En EE.UU. los personajes son conocidos por
	la línea de figuritas de goma comercializada por Mattel para explotar el boom de la lucha libre de mediados de los 80.
	
	Los comentarios más negativos sobre este juego se centran en dos aspectos: Un control raro y gráficos mediocres. Esos comentarios
	ignoran el echo de que el juego es de 1985 y ocupa 24 kilobytes de memoria, ¡la mitad que el clásico Donkey Kong!
	
	Así que, este hack intenta resolver al menos uno de esos aspectos, mejorando los gráficos y haciendo a los personajes reconocibles
	para cualquier fan.
	
	Aquí tenéis una lista de los cambios:


		Kinnikuman - DX Edition Ver. 1.0

			● Diseño de personajes mejorado. Ahora son más reconocibles, pero manteniendo el estilo cabezón.

			● El personaje que lanza power-ups conocido como Meat en el manga/anime se reemplaza por Nachiguron (un
			  monstruo/kaiju fan de Kinnikuman).

			● Cambios en la barra superior: Ahora tienen un aire a lo Street Fighter II.

			● Cambios en la paleta de colores por razones cosméticas, y a veces prácticas (la lona es de un blanco puro que
			  puede ser molesto a la vista, especialmente en televisores antiguos).


		Kinnikuman: DX Edition Ver. 2.0


			● Mejora gráfica en los sprites de los personajes. Ahora se parecen más a lo que el autor tenía en mente en su
			  primer intento, con caras más detalladas y cuerpos estilizados.

			● Terryman es el "típico vaquero", inicialmente presentado en el manga/anime como un superhéroe/chojin sin
			  defectos (lo opuesto a Kinnikuman), pero que va perdiendo interés conforme la trama avanza. Ha sido
			  reemplazado por Blackhole, uno de los Siete "Superhéroes Diabólicos/Akuma Choujin", como Buffaloman.

			● Diseño de la barra superior revisado.

			● Paleta de colores revisada. Los personajes se ven mejor y se confunden menos con el fondo.

			● Inicialmente, Asuraman conservó los colores propios del manga (azul y dorado). Ahora usa una paleta de colores
			  más parecida al anime, como el resto de personajes del juego.

			● Pequeñas mejoras. Ahora la audiencia en las gradas vuelve a verse más difusa otra vez, y se han añadido detalles
			  a las cuerdas del ring.


		Kinnikuman: DX Edition Ver. 2.1

			● Pequeño fallo detectado y arreglado: Nachiguron usaba el mismo color que el fondo del escenario 3 (0C). Ahora
			  se usa el color negro (0F).


		Kinnikuman: Dreammatch 1.0

			● La mayor novedad de esta versión (rebautizada como "Dreammatch") es su compatibilidad. El arhivo *.rar incluye
			  5 parches distintos que la hacen funcionar prácticamente con todas las versiones existentes del juego (podéis
			  echar un vistazo al Listado de compatibilidad).

			● La pantalla de título se actualiza con ligeras mejoras.

			● Nueva fuente de texto que da al juego un aire diferente y renovado.

			● Diseño de la barra superior revisado (otra vez).

			● Nueva pantalla de título para la versión EE.UU. que pega más con el estilo del manga/anime.

			● Se añaden intencionadamente diferencias entre la versión americana y japonesa (podéis echar un vistazo a las
			  Diferencias entre regiones).

____________________________________________________________________________________________________________________________________________


2) Listado de compatibilidad


		● Kinnikuman - DX Edition Ver. 1.0  --> Kinnikuman - Muscle Tag Match (J) (PRG0) [!].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b2].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [p1].nes


		● Kinnikuman - DX Edition Ver. 2.1  --> Kinnikuman - Muscle Tag Match (J) (PRG0) [!].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b2].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [p1].nes


		● Kinnikuman - Dreammatch Ver. 1.0a --> Kinnikuman - Muscle Tag Match (J) (PRG0) [!].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b2].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [p1].nes


		● Kinnikuman - Dreammatch Ver. 1.0b --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o1].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o2].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o3].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b1][o4].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [b2][o1].nes
						    --> Kinnikuman - Muscle Tag Match (J) (PRG0) [p1][o1].nes


		● Kinnikuman - Dreammatch Ver. 1.0c --> Kinnikuman - Muscle Tag Match (J) (PRG1) [!].nes


		● Kinnikuman Ver. 1.0a	            --> M.U.S.C.L.E. (U) [!].nes
					            --> M.U.S.C.L.E. (U) [b1].nes
					            --> M.U.S.C.L.E. (U) [b3].nes
					            --> M.U.S.C.L.E. (U) [o1].nes
					            --> M.U.S.C.L.E. (U) [o2].nes
					            --> M.U.S.C.L.E. (U) [o3].nes
					            --> M.U.S.C.L.E. (U) [o4].nes


		● Kinnikuman Ver. 1.0b	            --> M.U.S.C.L.E. (U) [b1][o1].nes
					            --> M.U.S.C.L.E. (U) [b1][o2].nes
					            --> M.U.S.C.L.E. (U) [b1][o3].nes
					            --> M.U.S.C.L.E. (U) [b1][o4].nes
					            --> M.U.S.C.L.E. (U) [b2].nes
					            --> M.U.S.C.L.E. (U) [o5].nes


	Nota: El archivo "M.U.S.C.L.E. (U) [b4].nes" es aparentemente una rom corrupta (no funciona correctamente en la mayoría de
	emuladores existentes (como FCEUX, Mesen, o Nestopia), así que ha sido imposible testear su compatibilidad con el hack.

____________________________________________________________________________________________________________________________________________


3) Diferencias entre regiones

	El juego original tiene algunas diferencias entre las versiones lanzadas en EE.UU. y Japón. Algunas de esperar, como la pantalla de
	título o la música, pero la más notable es la omisión de un personaje controvertido (un superhéroe/chojin alemán que viste uniforme
	de las SS y luce una esvástica en el pecho). En la versión americana ocupa su lugar Gerónimo, un superhéroe/chojin nativo americano.

	Con la idea de dar más exclusividad a cada versión, se añaden los siguientes cambios:

		● La versión EE.UU. tiene a Meat (mejor amigo de Kinnikuman y consejero) como el personaje que arroja power-ups desde el
		  fondo de la pantalla. En la versión japonesa es reemplazado por Nachiguron (un monstruo/kaijuu que fue salvado por
		  Kinnikuman y se convirtió en su mayor admirador).

		● La versión EE.UU. tiene a Gerónimo (el nativo americano), Terryman (el vaquero) y a Ramenman (típico luchador de kung-fu)
		  como personajes exclusivos. La versión japonesa tiene a Brocken Jr.(el nazi), Blackhole (miembro de los Siete "Superhéroes
		  Diabólicos/Akuma Choujin") y a Mongolman (alguien sospechosamente parecido a Ramenman, pero no explicaré por qué por no
		  hacer Spoilers XD).


____________________________________________________________________________________________________________________________________________


4) Lista de movimientos/Ataques distintivos


		● Pulsa (B)
		  --> Salto

		● Pulsa (A)
	 	 --> Puñetazo

		● Pulsa (B) y después (A)
		  --> Patada voladora
	
		● Pulsa (A) situándote justo detrás del rival
		  --> Súplex

		● Pulsa hacia adelante + (A)
		  --> Lanza al rival contra las cuerdas

		● Pulsa (A) tras lanzar al rival contra las cuerdas
		  --> Ariete

		● Pulsa (B) cerca de las cuerdas
		  --> Toma impulso contra las cuerdas

		● Toma impulso contra las cuerdas y pulsa (A)
		  --> Ataque aéreo

		● Retírate a tu esquina y pulsa (A)
		  --> Cambia de personaje


	Todos los personajes tienen los mismos movimientos y ataques, hasta que cogemos el power-up lanzado por Meat/Nachiguron, que nos
	permite usar los ataques distintivos de cada uno:


		● Kinnikuman
		  --> Kinniku Driver : Pulsa (A) situándote justo detrás del rival		

		● Blackhole/Terryman
		  --> Bulldogging Headlock: Pulsa hacia adelante + (A) cuando el rival esté frente a tí

		● Mongolman/Ramenman
		  --> Patada asesina: Pulsa (B) y después (A) cuando el rival esté frente a tí

		● Robin Mask
		  --> Tower Bridge: Pulsa(A) situándote justo detrás del rival

		● Buffaloman
		  --> Hurricane Mixer: Pulsa (B) y después (A) cuando el rival esté frente a tí

		● Warsman
		  --> Garra de Oso: Pulsa (B) cuando el rival esté frente a tí

		● Asuraman
		  --> Asura Buster: Pulsa(A) situándote justo detrás del rival

		● Brocken Jr./Gerónimo
		  --> Ataque con gas venenoso/Tomahawk: Pulsa (A)
		