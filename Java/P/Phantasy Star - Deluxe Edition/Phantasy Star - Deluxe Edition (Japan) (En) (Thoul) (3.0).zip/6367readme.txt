                                    PHANTASY STAR: DELUXE EDITION
                                         ENGLISH TRANSLATION
                                          v3.0 (Nov 29 2021)


Quick Find: Press Ctrl + F and type in the keyword, then press Enter to search for the section.


      TABLE OF CONTENTS
     Disclaimer .............. [DSC1]
     Preface ................. [PRF2]
     Changelog ............... [CHG3]
     Differences and Issues .. [DAI5]
     Credits ................. [CRD6]

====================================================================================================
Disclaimer [DSC1]
==========
- Phantasy Star (c) Sega. All rights reserved.


- No ownership is claimed by vivify93 over Phantasy Star or the franchise from which it originates.
   Commercial use of this patch, including but not limited to reproduction, sale, etc. is strictly
   prohibited.


- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   vivify93 is not liable for damage incurred to the end-user, their OS, or their hardware while
   using this patch.


- Apply this patch only to "psdeluxe-chinese.jar" with the following specifications.

     Hashes: CRC32 - 7804C88C
              SHA1 - 4AEECAC5A71E38978C85D12E9320FBEA1AB486AD


- Players are encouraged to keep a backup of their original game file in case an error occurs.
====================================================================================================

====================================================================================================
Preface [PRF2]
=======
In 2004, Sega released a Java-based version of Phantasy Star for mobile phones. It had several
differences and enhancements, which piqued the interest of international players when they
discovered its existence. A Chinese version was developed in 2009 for China Mobile Market; after
acquiring it a year after its release, Thoul, webmaster of Fringes of Algo, quickly busied himself
with inserting the English Sega Master System translation into this port.

However, the conversion had a few flaws. The Chinese title screen remained intact, the advertisement
graphics were left untranslated, and some scattered rare text was never caught, showing the obvious
Google Translate roots of the project.

I myself had tried time and time again to play this oddity, but the Java game emulator KEmulator
delivered underwhelming results. After I discovered the Android J2ME Launcher, however, I gave it
one more shot and found a surprisingly competent port. My desire to give this odd piece of Phantasy
Star history the finished translation it deserved led to v3.0's development.
====================================================================================================

====================================================================================================
Playing the Game [PLY3]
================
Windows 10 seems to struggle with emulating Phantasy Star: Deluxe Edition, and Java games in
general.

- KEmulator is commonly recommended, but I've found it bloated and irritating to fiddle with.
- FreeJ2ME is a simpler alternative; however, it lacks even the most common customization features.

Neither option properly loops the music after it plays once. Please contact me if you've found a way
to fix the looping in either emulator.

- J2ME Loader for Android has almost all of KEmulator's customization without any of its bloat.
- It properly loops the soundtrack.
- iOS users may be better off getting Bluestacks and using J2ME Loader through that.

- If using KEmulator:
   * Use Size 11 Tahoma font.

- If using J2ME:
   * Set leftmost box for font size to 12 or 14.
   * Turn OFF "Values are in Scaled Pixels" under "Font."
   * Turn ON "Anti-Aliasing" under "Font."
   * Save your profile by tapping the 3 dots in the upper right, then tapping "Save profile."
====================================================================================================

====================================================================================================
Changelog [CHG4]
=========
v3.0 - Nov 28, 2021 (vivify93)

- Replaced Chinese title logo with English version from Japanese original release. Its palette
   is more muted due image constraints. Removed the Japanese text from this title screen.


- Corrected Google Translated dialogue by either inserting the necessary dialogue from the original,
   or smoothing out the machine translation as best as I cared. (The latter approach was taken
   primarily for the advertisement text.)


- Official translation amended where required.


- Text for purchasing item Shortcake now reflects actual amount of 280 meseta taken from the player.


- Thanks to Google Translate, translated the Mobile Market splash screen text, and the advertisement
   graphics under the "MORE" title menu option.


- Several texts reformatted to account for screen size.


- Changed character name "Noah" to "Lutz." There will not be an alternate version with his incorrect
   name, as it was discarded by future games in the series.


- Changed character name "Tajim" to "Tarzimal." This is to reflect the Game Boy Advance port's text
   touch ups, where Tajim/Tarzimal is consistently referred to by the latter name.


- Changed planet name "Parma" to "Palma" to match SMS original.


- Changed 8 item names. First Food restaurants are now pharmacies.
(Cola               -> PelorieMate
 Burger             -> Roginine
 Polymeteral        -> Polymetryl
 Transfer           -> Transer
 Nut of Laerma      -> Laerma Nut
 Aero-Prism         -> Aeroprism
 Crystal            -> Damor's Crystal
 Killian of the gun -> Zillion)


- Changed 7 equipment names.
(Wand            -> Psycho Wand
 Titan Sword     -> Titanium Sword
 Silver Fang     -> Silver Tusk
 Thick Fur       -> Spiky Fur
 Gloves          -> Animal Gloves
 Laser Shield    -> Laser Barrier)


- Changed 3 spell names.
(Terrify -> Terror
 Trap    -> Untrap
 Help    -> Hyper)


- Changed 12 enemy names.
(N. Farmer     -> Motavian
 E. Farmer     -> Brigand
 Big Club      -> Big Crab
 Tarantul      -> Tarantula
 Manticor      -> Manticore
 Marman        -> Merman
 Big Nose      -> Elephant
 Evilhead      -> Evil Chief
 Batalion      -> Battalion
 Elephant      -> Golem
 Shadow        -> Lassic
 Golden Dragon -> Gold Dragon
 Saccubus      -> Succubus)


- Swapped the names of enemies Crawler and Leech to match the SMS original.


- Added my username to the credits in the "ABOUT" title menu option.

----------------------------------------------------------------------------------------------------

v2.0 - May 25, 2010 (Thoul)

- Inserted the rest of the official English localization, adapted to the formatting of the Chinese
   version where necessary.


- Translated title screen options.


- Due to the game using a proportional font, item and enemy names have been expanded compared to
   the SMS original.


- Several lines of dialogue unknown to Thoul were left in a Google Translated state.


- Four enemies remained named incorrectly because Thoul never encountered them in the beta test.

----------------------------------------------------------------------------------------------------

v1.0 - May 17, 2010 (Thoul)

- Official localization up until Eppi inserted.

----------------------------------------------------------------------------------------------------

v0.1 - May 15, 2010 (Thoul)

- Proof-of-concept patch.
====================================================================================================

====================================================================================================
Differences and Issues [DKI5]
======================
- Thoul based this on the official English localization, and I followed suit. However, some changes
   were necessary due to Deluxe Edition's text routine. Some examples:

    * The result of using the Untrap spell when no trap is present will display part of the message,
      "Nothing special seems to be in this area." Both messages had to be reworded to avoid nonsense
      messages, e.g. "There was no trap. anything special about it."

    * There is an extra space at the beginning of system messages, e.g. " Uses PelorieMate." Again,
      this text is referenced between multiple other system messages. Without the space, this
      becomes "AlisUses PelorieMate."

    * Inconsistent capitalization and missing punctuation in several messages, again because of the
      text routine assembling multiple different strings.


- Some characters have different levels of dialogue in the Chinese mobile version compared to the
   English SMS script. At times, it was necessary to trim or expand the original English lines to
   meet the required text space.


- The script has also received some grammar corrections, but not where it's meant to indicate speech
   patterns.


- As pointed out in the changelog, names of things are allowed longer lengths than the SMS original,
   and this has been taken advantage of to the fullest extent.


- For other differences in Deluxe Edition not strictly related to the translation, visit here:
   http://www.psalgo.com/phantasy-star-deluxe/differences.html
====================================================================================================

====================================================================================================
Credits [CRD6]
=======
- Thoul: Original project author.

- Orakio Rob, Tanith: Credited by Thoul as contributor to v2.0 and previous.

- Rewolf: Author of dirtyJOE.

- Play Software: Author(s) of J2ME Loader for Android.

- Sega

...And all you Phantasy Star fans out there! See you in the Algol System!
====================================================================================================