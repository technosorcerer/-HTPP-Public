﻿********************************************************************************
*                             Tengai Makyou: Ziria                             *
*                          English Translation Patch                           *
*                           by LIPEMCO! Translations                           *
*                              v1.0 (06 Dec 2023)                              *
*                                                                              *
*                               Supper -- Hacking                              *
*                        TheMajinZenki -- Translation                          *
*                               cccmar -- Testing                              *
********************************************************************************

Long, long ago, amidst the seas of the farthest reaches of the Far East, there 
was once a mystical land called Jipang: a beautiful and terrible place where 
gods and demons, wonders and horrors, men and beasts alike all coexisted in a 
strange and fantastic harmony. But that harmony is threatened when a foreign 
religion called the Cult of Daimon arrives on the country's shores and begins 
spreading across the land, its leaders aiming to steal human souls in order to 
revive the sealed demon Masakado and transform Jipang into their own utopia. 
Will Ziria, the fated hero descended from the Fire Clan which once sealed 
Masakado, stop the wicked Daimonists – or will Jipang's oriental beauty burn in 
demonic hellfire?

Tengai Makyou: Ziria is the debut entry of the Tengai Makyou series. Published 
by Hudson Soft for the PC-Engine CD-ROM² system in 1989, it was the first RPG 
ever released on CD and served as a showcase for the new medium, with elaborate 
visuals and voice acting far beyond what any competing title could offer. Its 
success led it to become the first in a popular series, very little of which was 
ever released outside Japan.

Oh, and don't pay too much attention to that first paragraph. The game may wear 
the trappings of a serious plot, but the real theme is "what foreigners 
mistakenly think Japan is like."

This patch fully translates the game into English.

                    ****************************************
                    *          Table of Contents           *
                    ****************************************

  I.    Patching Instructions
  II.   Running the Game
  III.  Known Issues
  IV.   Additional Features
  V.    FAQ
  VI.   Bonuses and Easter Eggs
  VII.  Authors' Comments
  VIII. Special Thanks
  IX.   Version History

                    ****************************************
                    *       I. Patching Instructions       *
                    ****************************************

To use this translation, you'll need to apply a patch to a disc image of the 
game. Unfortunately, patching disc images is inherently complicated because 
there are numerous CD image formats in use, as well as many ways that 
poorly-written disc ripping programs can mess things up and make a patch not 
work properly. As a result, this is a rather long section – sorry! But please 
read it over carefully before complaining that the patch doesn't work.

Just to be clear: this patching process is designed to support every disc image 
format it reasonably can. Though a Redump-verified disc image is a definite 
plus, options are provided to patch pretty much any image so long as it has the 
correct data track. If you don't have one of the Redump images, just go ahead 
and try to patch whatever you have using whichever of the options below applies 
to it.

Now then, here are your options for patching, approximately ordered from best to 
worst:

  A. Directly patch a single-file Redump-verified BIN or IMG image
  B. Directly patch a multi-track Redump-verified BIN image
  C. Automatically patch a BIN or IMG image via binpatch.bat
  D. Automatically patch an ISO+WAV+CUE image via isopatch.bat
  E. Manually patch

These options are explained in the subsections that follow.

  -----------------
  - GAME VERSIONS -
  -----------------

Several different versions of Tengai Makyou exist:

  - Revision 6: The original release from 1989 for the base CD system.
  - Revision 7: A bugfixed update.
  - Super CD version: A later (1992) version of the game that targets the Super 
CD-ROM² hardware.

This translation is based on Revision 7, so it's the primary target for the 
patching process. Because the differences between Revisions 6 and 7 are fairly 
minimal, patches are also provided for Revision 6. The Super CD version, 
however, makes many internal changes to the game, including compressing all of 
the map data, and is therefore *not* supported by this patching process. Please 
use Revision 6 or 7 instead.

  -------------------
  - BEFORE STARTING -
  -------------------

It should go without saying, but first, extract all the contents of the 
translation patch's ZIP to your hard drive if you haven't already.

Before you start, you'll need to determine what format your disc image is in. At 
the very least, you must have an image in BIN+CUE, IMG+CUE, or ISO+WAV+CUE 
format; more exotic formats are not supported. It's unfortunately not uncommon 
to come across disc images that don't use the standard file extensions used in 
this section, or use them differently from normal, which makes things very 
confusing. Some tips:

  - One common way of distributing disc images is the "dual CCD/CUE" format. 
This consists of four files: a CCD, a CUE, an IMG (or possibly BIN), and a SUB. 
If your image is like this, you can throw away the CCD and SUB files, as they 
aren't needed for the patch. For our purposes, an IMG is the same as a BIN, so 
any references to a "BIN" below can also refer to an "IMG" or vice versa.
  
  - If your disc image has a CCD but no CUE, you may be able to patch it with 
method A. If that fails, you'll need to look into creating or obtaining a CUE 
file for the disc.
  
  - If your disc image consists of a CUE and a large number of BIN files, it's 
in the "split BIN" format. This format is particularly used by the distributions 
available on certain archival web sites. It's possible to patch this format as 
long as the BIN files represent one of the Redump disc images, just split up 
into its component tracks.
  
  - You're not likely to see them much these days, but old, lossy formats like 
ISO+MP3 are not supported.

  --------------------------------------------------------------------
  - A. Directly patch a single-file Redump-verified BIN or IMG image -
  --------------------------------------------------------------------
  
Use this method if at all possible. While not as simple as the auto-patching 
method described later, it gives the most reliable results.

You can patch using this method if your disc image *exactly* matches one of the 
two verified "good" images as listed on Redump.org, and if all the tracks on the 
disc are combined into one single BIN or IMG file.

First, check that your disc image contains a single file with the extension 
".bin" or ".img". If it does, verify that that file matches one of the following 
specifications. (If you don't know how to do that, just go ahead and follow the 
steps listed below; if you get an error, your disc image is wrong.)

REVISION 7: http://redump.org/disc/37134/
  Redump name: Far East of Eden: Tengai Makyou: Ziria
  CRC32:       ed6bc123
  MD5:         2deae1bfcc13ffe0d4e52b59883a9376
  SHA-1:       67fe95097fd18c0e063de947430f538f3893d3ec

REVISION 6: http://redump.org/disc/27388/
  Redump name: Far East of Eden: Tengai Makyou: Ziria
  CRC32:       73f049f7
  MD5:         6b8e12679d529fbefdea8bda6649774e
  SHA-1:       f47f6ab6ae79fae79354364dfe9ee87c0398b87e

If your disc image is a match, all you need to do is apply an xdelta patch to 
the BIN or IMG file, then rename it and pair it with the CUE file provided in 
the download.

  1. Extract the "redump_patch" folder from the translation ZIP and open it.
  
  2. Run "DeltaPatcher.exe", which should be present in that folder. This is the 
popular Delta Patcher program for applying xdelta patches. If you're not using 
Windows, you'll need to obtain an alternate patching program for your system, 
such as the command-line "xdelta3" program.
  
  3. Locate the .xdelta patch files in the "redump_patch" folder. Select the one 
labeled "Revision 7" or "Revision 6" depending on which version you have.
  
  4. Use Delta Patcher (or another xdelta patching tool) to apply the patch to 
the BIN or IMG file. If you get an error, you'll need to try one of the other 
patching methods below.
  
  5. If your disc image came with a CCD or CUE file, delete it now.
     DO NOT USE THE OLD CCD OR CUE FILE WITH THE PATCHED IMAGE!
     Also get rid of any SUB file if it exists. It's not needed.
     
  6. The "redump_patch" directory should contain a CUE file with a name like 
"Tengai Makyou - Ziria EN [v1.0] Redump.cue". Rename your patched disc image so 
it has *exactly* the same name as the CUE, except with a .bin extension instead 
of .cue.
     IMPORTANT: If the file you patched was originally an IMG file, make sure 
that you change the extension to .bin. The CUE will not work if the extension is 
.img.
     
  7. You're done! Make sure you have the CUE and BIN in the same directory, then 
open the CUE in an emulator. Or if you have the hardware, burn the image to a CD 
and play it on your PC-Engine. Or better yet, use a Turbo EverDrive or 
something, because it's a whole lot less hassle.

  -------------------------------------------------------------
  - B. Directly patch a multi-track Redump-verified BIN image -
  -------------------------------------------------------------
  
  One common distribution of the game found on certain archival sites uses the 
Redump-verified disc image, but splits it up into separate tracks instead of 
combining them into a single file. This is easily recognized by the presence of 
6 separate BIN files and a single CUE.
  
  Before patching:
  
  - Make sure that your disc's CUE file has a name like "Far East of Eden - 
Tengai Makyou - Ziria (Japan) (Rev 7).cue". "(Rev 6)" is also acceptable for the 
final label, but make sure that it is *not* "(Hibaihin)"; this is the Super CD 
version of the game, and isn't supported.
  
  - Make sure that the BIN files are named like this:
      Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (Track 1).bin
      Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (Track 2).bin
      …
      Far East of Eden - Tengai Makyou - Ziria (Japan) (Rev 7) (Track 6).bin
  
  To patch:
  
  1. Copy the CUE file and all BIN files into the "splitbin_patch" directory.
  
  2. Drag-and-drop the CUE file onto "binpatch_rev7.bat" (to patch a Revision 7 
disc) or "binpatch_rev6.bat" (Revision 6).
  
  3. If all goes well, this should produce a new, single-track format disc image 
in the same directory. (This works by simply combining all the tracks together 
and then applying the same patch as in method A.)
     
  4. Use the CUE file provided in the "splitbin_patch" directory to play the 
game.

  --------------------------------------------------------------
  - C. Automatically patch a BIN or IMG image via binpatch.bat -
  --------------------------------------------------------------

If your disc doesn't match the Redump dump, or you otherwise couldn't get method 
A to work, it may still be possible to patch it. If your disc is in BIN+CUE 
format or IMG+CUE format, and you're using Windows:

  1. Make sure that your BIN/IMG and CUE have the same base name (e.g. 
"tenma.bin" and "tenma.cue", or "tenma.img" and "tenma.cue"). Note that if you 
rename the BIN file, you will need to open your CUE in a text editor and make 
the same change to any occurrences of the name inside the file.
  
  2. Copy both the BIN/IMG and CUE into the "auto_patch" directory.
  
  3. Drag-and-drop the BIN/IMG file onto either "binpatch_rev7.bat" or 
"binpatch_rev6.bat", depending on which version you think you have.
  
  4. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ----------------------------------------------------------------
  - D. Automatically patch an ISO+WAV+CUE image via isopatch.bat -
  ----------------------------------------------------------------

If your disc image is already in ISO+WAV+CUE format, you can perform a procedure 
similar to patching via binpatch.bat:
  
  1. Copy all the disc image files to the "auto_patch" directory.
  
  2. Drag-and-drop track 2 of your image onto "isopatch_rev7.bat" or 
"isopatch_rev6.bat", depending on which version you think you have.
  
  3. If all goes well, this should produce an ISO+WAV+CUE format disc image in 
the same directory.

  ---------------------
  - E. Manually patch -
  ---------------------

You can also attempt to apply the xdelta patches in the "auto_patch" directory 
to the ISO of an ISO+WAV+CUE image manually. Pretty much the only reason to do 
this is if you're on Linux and can't or won't use Wine. If that's the case, then 
presumably you're smart enough to handle it yourself, so you're on your own 
here.

                    ****************************************
                    *         II. Running the Game         *
                    ****************************************

** NOTE: This patch was developed and tested using two forks of v1.29.0 of the 
Mednafen emulator: the mainline version that you'll find if you search for 
"Mednafen", and the "pceDev" fork that has improved PC-Engine features and 
accuracy (https://github.com/pceDev16/mednafenPceDev/). The translation should 
run fine on either version, but some subtitles won't appear soon enough on 
mainline Mednafen due to the disc seek delays not being accurately emulated. If 
you're planning to play on Mednafen, we recommend using the pceDev branch if 
possible.



If you're unfamiliar with the PC-Engine, figuring out how to run CD-based games 
can be confusing. This section tries to make things clear for new users.

The simple version is this: Originally, NEC/Hudson released the PC-Engine. Then 
they decided they needed a CD add-on and released the CD-ROM² ("CD ROM-ROM") 
system. Then they decided that their original CD add-on wasn't powerful enough, 
so they made the upgraded Super CD-ROM². Most CD-based games target the Super 
CD-ROM² and are not compatible with the original, unenhanced CD-ROM².

Tengai Makyou was actually not a Super CD-ROM² game in its original release. 
However, this patch converts it into one so that the Super CD system's extra 
memory can be used to provide a high-quality translation, and also improve the 
game's notably poor loading times. As a result, you'll need to have a ROM image 
of the Super CD-ROM² System Card Version 3.00 in order to play the translation. 
Using a card with a lower version number will cause an error screen to appear 
when the game starts. (Though you can still play the game in Japanese in this 
case!)

You're on your own for obtaining the BIOS image; the No-Intro name is "[BIOS] 
Super CD-ROM System (Japan) (v3.0).pce".

You'll also need to set up your emulator to use this BIOS image, of course. 
Stock versions of Mednafen will look for a file named "syscard3.pce" in the 
"firmware" directory and give an error if it doesn't exist, so move and rename 
your BIOS image accordingly. Mesen2 will prompt you for the BIOS image the first 
time you try to launch a CD game. Other emulators have their own setup 
procedures, so check their documentation for instructions.

Additionally, make sure to run the game in two-button Control Pad mode. The 
PC-Engine was originally released with controllers that had two buttons, but 
later had upgraded controllers released with six buttons. The six-button 
controllers use a different protocol from the two-button controllers, meaning 
that games that weren't specifically designed to support them – including this 
one – will have "glitchy" input unless the controller is put in two-button 
compatibility mode. Emulators will generally default to two-button mode, but if 
you have problems with the game not accepting input or pressing buttons on its 
own, check your emulator's settings.

                    ****************************************
                    *          III. Known Issues           *
                    ****************************************

As mentioned above, in the demo sequences that appear if the game is left idle 
at the title screen, some subtitles will appear slightly too late on mainline 
Mednafen due to inaccurate emulation. This shouldn't occur on real hardware or 
the more accurate pceDev branch.

This translation adds a new "Turbo" text speed setting that prints all text as 
fast as the hardware can handle processing it. This causes any animations that 
are playing to temporarily freeze until the text finishes printing. If you find 
this bothersome, don't set the text speed above Fast.

In a related issue, if the game is saved with the text speed set to Turbo, and 
that save file is then loaded in the Japanese version of the game, text printing 
will not work correctly and become filled with erratic delays. This can be fixed 
by using the Mode menu to set the text speed to any of the three original speed 
settings.

                    ****************************************
                    *       IV. Additional Features        *
                    ****************************************
  
  In the interest of providing a slightly more palatable experience for the 
modern player, we've added a few features to the translation that weren't in the 
original. Don't worry: the game itself is unchanged, but you can make a few 
things go slightly faster now.

  --------------
  - Load Times -
  --------------
  
  This translation converts the original game, which was for the base CD 
hardware, into a Super CD-ROM² game, quadrupling the amount of memory available. 
This was done primarily to make it easier to add extra code and resources that 
were needed for the translation, but since those only take up a small portion of 
the extra memory, we used the remaining space to make improvements to the game's 
rather long and frequent load times. (As previously noted, the game's official 
Super CD conversion tried to do this, so strictly speaking, it's not really a 
"new" feature.)
  
  - The code modules for the overworld and battle system are permanently cached 
to memory at startup, and no longer have to be loaded from disc when switching 
game modes. This also means that the ADPCM buffer is no longer used as a 
middleman when loading those modules, providing further speedups. The small 
downside to this is that the jingle played when an encounter starts is rarely 
heard in full in the translation, since the game now finishes loading well 
before the music ends. We figure that given the choice, most people would take 
the reduced wait times over hearing the whole track every time.
  
  - The two most recently used overworld maps are kept cached in memory. When 
moving to a new map, the game won't have to load from disc if the new map is 
either of the cached ones. This greatly improves on situations where you 
repeatedly switch to the same map (such as in towns, where you're constantly 
returning to the same map as you go in and out of buildings). It also means the 
game doesn't have to reload the current map from disc when returning to the 
overworld after a battle. Combined with the code module caching, this makes 
transitioning to and from battle extremely fast compared to the original game.
  
  - Since a small bit of memory was still free after implementing the above 
enhancements, it was used to cache the item and jutsu descriptions, meaning 
there's no longer a load delay when opening the Descriptions menu.

  --------------
  - Text Speed -
  --------------
  
  The original game's text speed maxes out at one character per frame (when 
holding Button I with text speed set to "Fast"). To account for the fact that 
English uses more characters than Japanese, the translation doubles all text 
speeds, so the fastest "standard" text speed is now two characters per frame.
  
  However, an additional "Turbo" text speed setting has also been added. If 
used, the game will print all text as fast as possible with no delays. As noted 
in the Known Issues section, this causes animations to temporarily freeze, so 
don't use it if you're trying to properly savor the game. (But if you wanted 
that, you probably wouldn't be using the fastest text speed anyway.)
  
  Also, it's a small thing, but using the auto-battle feature (press Select 
during combat) will now increase the text speed just as if you were holding 
Button I, because if you're using this feature at all, it's a pretty safe bet 
you want the battle to go faster.

  --------------
  - Voice Skip -
  --------------
  
  The original game doesn't provide the option to skip individual lines of 
voiced dialogue. Turning on the "Line Skip" option means that pressing Button II 
will turn off voice acting and fast-forward through the current text until the 
box closes, which is "thoughtful," but very clunky and probably not what most 
people actually want.
  
  As a result, we decided to add the ability to skip individual voice clips 
simply by pressing Button I, though the original "fast-forward" mode is still 
available in the Mode menu if you want it.

  -------------------
  - Language Select -
  -------------------
  
  This translation requires the Super CD-ROM²'s expanded memory to run, and will 
show an error message on startup if run on an incompatible BIOS (below version 
3.0). However, the original game is for the basic, non-Super CD system, so we 
included the option to play the game in Japanese instead in this scenario. 
Simply press Run on the error screen, as it instructs you.
  
  We've also included a code to allow you to play the game in Japanese even on a 
Super CD-ROM² system. After pressing Run on the BIOS startup screen to start the 
game, hold Up, Select, and Button II. This will force the System Card error 
message to appear, at which point you can, as before, press Run to boot into the 
Japanese version of the game.

                    ****************************************
                    *                V. FAQ                *
                    ****************************************

Q. Hey, I thought this game was called "Far East of Eden"?

A. Short answer: Not really. Maybe.

   Long answer: According to the game's "backstory," "Far East of Eden" is the 
title of a book written by P.H. Chada, an American devotee of Japanese (or 
perhaps "Jipangese") history, with this game presented as an "adaptation" of 
that book. In reality, neither P.H. Chada nor his book exist; they're a framing 
device to explain the game's wildly inaccurate depiction of Japan, which is 
supposed to represent foreigners' misperceptions of the country.
   
   As part of this conceit, "Far East of Eden" appears prominently on the box 
art, title screen, marketing materials, etc., for many games in the series, 
which led many Westerners to interpret it as part of the title (perhaps assuming 
it to be a translation of "Tengai Makyou," which it is not). However, it's 
really not a "proper" part of the title. Look this game up on any 
Japanese-language resource – web sites, old magazine coverage, you name it – and 
you'll find that it is unfailingly referred to as "Tengai Makyou" with no 
mention of "Far East of Eden" beyond maybe printing it next to the logo.
   
   It's probably easiest to understand if you look at the title screen and try 
to perceive things as a Japanese person would. The Japanese text, "Tengai 
Makyou", is the part that naturally draws a Japanese speaker's attention, since 
it's in their native language. The English text is secondary, and mostly there 
to create an impression – it's emphasizing the idea that some sort of mixture of 
Eastern and Western cultures is going on here. It's really not meant to be an 
actual part of the title (so Redump, please stop labeling the game as "Far East 
of Eden: Tengai Makyou," thank you).
   
   That said, the only game in the series to get an official release outside of 
Japan was the Neo Geo fighting game Tengai Makyou: Shinden, which was localized 
under the title "Kabuki Klash" while retaining the "Far East of Eden" text that 
already appeared above the game's logo. Whether that makes "Far East of Eden" 
part of the localized title or not isn't clear, but it certainly muddies the 
waters further.
   
   In the end, you probably shouldn't worry about it too much.



Q. Okay, so if "Tengai Makyou" doesn't translate to "Far East of Eden," what 
DOES it mean?

A. Short answer: It's not really translatable.

   For the long answer, we'll first refer to part of a sidebar that appeared in 
the Japanese magazine PC Engine Fan's pre-release coverage of the game (May 1989 
issue, p. 14, translation by Supper):
   
      『天外魔境』のヒミツは…？
      What are the secrets of 'Tengai Makyou'...?
      
      
      どうして「天外魔境」というタイトルがついたのか？
      これは、原作者のアメリカ人チャダから見た日本（ジパング）が、
      「奇想天外な魔境」であったことがひとつ。
      また、天上界から地上を支配する悪神がいて、その天上界を呪うことばとして、
      その名が付けられたというのがもうひとつ。
      Why is the title "Tengai Makyou"? One reason is that Japan (Jipang) as 
seen by the author of the original work, the American "Chada," was a "kisou 
tengai na makyou" [奇想天外な魔境, literally "fantastic mysterious place" or "bizarre 
demon-infested place"]. Another is that there is an evil god who rules over the 
earth from heaven, and that name was created as a phrase to curse heaven.
   
   The individual characters in "Tengai Makyou" and their meanings are as 
follows:
     天 "ten"   = heaven
     外 "gai"   = outside
     魔 "ma"    = demon
     境 "kyou"  = place/boundary
   
   "Tengai" (天外) by itself means "beyond the heavens" (literally) or "the 
furthest reaches" (metaphorically). "Makyou" (魔境) means "demon-infested place" 
(literally) or "mysterious place" (metaphorically). Put together, they don't 
form a real word, but give an impression that includes elements of "a demonic 
place beyond heaven" and "a faraway and mysterious place." Basically, it's a 
title that's meant to sound "cool" while also being a bit ridiculous in context, 
since to a Japanese person, Japan is obviously neither of those things. You can 
see how "Far East of Eden" has a loose thematic connection to the actual title, 
but it's certainly not a translation of it (because, as stated, it's really not 
translatable).
   
   Incidentally, this title is heavily "inspired" by the title of the "Jingai 
Makyou" (人外魔境, "[mysterious] uninhabited place") serial stories that were 
published from 1939 to 1941.


  
Q. Ugh, you used Japanese honorifics? Why?

A. Well, the entire concept of this series is that it represents the worldview 
of an idiotic weeaboo who's reverential of the fantastic and mystical land of 
"Jipang" while understanding nothing about it. From that perspective, leaving 
honorifics in is the most fitting thing we could possibly do.

   More seriously, this is an extremely Japanese game, and we felt that 
honorifics worked well with it. Dropping them would certainly have been the 
"safer" option – very few people will notice or care if honorifics are absent, 
and quite the opposite if they're present – but if there was ever a game where 
keeping honorifics fits, this is probably it. Sorry to anyone who finds it 
bothersome; as always, feel free to download the source code and edit the script 
to your liking.


  
Q. If there was already a Super CD version of the game, why didn't you base the 
translation on that instead of making your own Super CD conversion?

A. Because the official Super CD version kind of sucks. It somehow manages to 
use the system's large amounts of additional memory to make the load times 
*longer* than the original while adding absolutely no enhancements. Also, that 
version wasn't even released commercially, or at least wasn't intended to be: it 
was a giveaway prize for a Duo sales campaign which flopped, allegedly resulting 
in many copies of the game ending up in stores at discount prices.

   Using the Super CD version as a base would also have made it harder to 
integrate the translation into the game, since most of the expanded memory is 
already used in that version. Basically, despite what you might expect, this was 
the best option. Doing the Super CD conversion from scratch allowed us to do 
everything our way, and also to make loading optimizations that actually, you 
know, work.


  
Q. Why does the title screen say "Tengai Makyō" when you wrote "Tengai Makyou" 
everywhere else?

A. Honestly? Because it was going to be impossible to cram another letter in 
there without squishing the logo to the point of looking ridiculous, and this 
was a convenient out. No deeper reason than that.


  
Q. Is there a point to the "thieving school" minigame?

A. No, unless you're in desperate need of a few pennies. Originally, stealing 
was supposed to be a major game mechanic: you would break into the businesses of 
corrupt merchants and steal money to give away to those in need in order to gain 
Virtue. As a result of repeated changes during development, this aspect was 
gradually whittled down until it was completely removed from the main game, with 
the already-developed code and levels for it recycled as a pointless minigame in 
Kumogiri Hamlets.


  
Q. How do I beat [name of boss] without grinding for 15 levels?

A. Tsukine Powder and luck.


  
Q. So like, this game is fine and all, but when are you going to translate 
Tengai Makyou II? I've heard lots of hype and buzz about how super long and 
expensive it was!

A. Sorry, we have no plans to translate Tengai Makyou II. Please see Supper's 
section of the Authors' Comments for more information.

                    ****************************************
                    *     VI. Bonuses and Easter Eggs      *
                    ****************************************

  ===============
  = Auto-Battle =
  ===============
  
  It's less a bonus and more an undocumented feature, but pressing Select during 
battle activates a simple auto-battle feature that simulates mashing the I 
Button every other frame, causing your party to use normal attacks on the first 
enemy over and over.

  ======================
  = Folk Tale Classics =
  ======================
  
  A small series of bonus scenes can be accessed from the title screen. Use a 
multitap to plug a controller into port 3, then press Run on it while the title 
screen is displayed.

  =================
  = Bonus Gallery =
  =================
  
  After completing the game, when the "The End" message appears, press any 
button and the game will show a bonus gallery of animations from the game, as 
well as a few from earlier versions that got cut.
  
  (This is speculation, but this feature's length and content suggests that it 
was repurposed from a rejected credits sequence that got replaced with the final 
game's more elaborate setup. It's pretty easy to imagine the staff credits 
appearing alongside these scenes.)

  ===================
  = Edo Easter Eggs =
  ===================
  
  In the course of making this translation, we discovered a set of highly 
elaborate developer easter eggs hidden in Edo that have, as far as we can tell, 
never before been found. So here they are for your enjoyment!

  ---------------------
  - Activation Method -
  ---------------------
  
  To activate the easter eggs:
  
  1. Start a new game and play normally, but don't free the White Deer in 
Kashima Shrine. In order for this procedure to work, you must not release it at 
any point. Note that this will make the game significantly harder, since the 
Wakakusa jutsu is normally an important source of cheap healing.
  
  2. Continue playing all the way up to Edo, the final area.
  
  3. Enter the Show Tent. IMPORTANT: Until you've done everything described 
below, don't leave or do anything else, or you'll be permanently locked out of 
using this code.
  
  4. Walk up to the pedestal directly north of the entrance and use the "Talk" 
command on it. A stream of water will spawn on top of it.
  
  5. Walk 1 step left, 3 steps up, and then 1 step left. You should now be 
facing the only character on the left side of the audience that's wearing green 
clothing. Use the "Talk" command again.
  
  If the code has been entered correctly, Tsunade will say her normal line about 
how quiet the audience is, and the easter eggs listed below will become 
accessible. If nothing happens, then you did something wrong.

  ----------------
  - Coffin Maker -
  ----------------
  
  A small secret can be found by using the Check command on the third container 
from the bottom on the left side of the Coffin Maker's shop.

  ---------------
  - Stonecutter -
  ---------------
  
  A new character will appear at the Stonecutter's shop. He has a special scene 
that occurs after the event where Tsunade crushes a block.

  -------------------
  - Earthquake Room -
  -------------------
  
  Go to Hoteimaru's earthquake experience room and select the "Extreme" setting. 
The ladder will fall in an unusual location; follow it to reach an extra room 
with an additional NPC.

  ------------------
  - Kabuki Theater -
  ------------------
  
  After watching the show at the Kabuki Theater, the curtains will remain open 
instead of closing. Go to the right side of the long bit of the stage that 
protrudes into the middle of the room. You'll find that the third block from the 
bottom is not solid, and you can use it to walk onto the stage. Follow it 
backstage to find an unusual room. You can "Check" the keyboard at the 
upper-right side for an additional effect.

                    ****************************************
                    *        VII. Authors' Comments        *
                    ****************************************

  -----------------
  - TheMajinZenki -
  -----------------
  
  Tengai Makyou Ziria has been an interesting project. I didn't know about the 
series beforehand, so I had to do a lot of research. It was a fairly challenging 
translation due to its many references to Japanese culture, from folklore, to 
Japanese history and geography, up to modern popular culture (at least, modern 
for 1989). My favorite character was without a doubt Tsunade, as I'm sure many 
will agree. At any rate, I hope you will enjoy this PC Engine gem!

  ----------
  - cccmar -
  ----------
  
  Tengai Makyou is probably one of the most overlooked series in the West. It's 
important historically, but barely known outside of Japan (no surprise there, 
seeing that none of the RPGs were released overseas). Red Entertainment in the 
West is arguably mostly known for Record of Agarest War, but in Japan their most 
popular series were/are Tengai Makyou, Galaxy Fraulein Yuna and, of course, 
Sakura Taisen. So, what's the first Tengai Makyou game like? It's a fairly 
standard RPG, with a good amount of cutscenes/voice acting, especially for 1989 
(totally novel stuff at the time). You go from town to town, solve the local 
issues while fighting monsters/navigating dungeons, which have some secrets 
every now and then, in order to deal with the Cult of Daimon; rinse and repeat. 
It stands out in its presentation for the time; it has a good soundtrack and 
many likeable characters. The difficulty is quite high if you don't know certain 
tricks later on ('Sleep' spells/items and Ice Mirror will become some of your 
best friends). Some of the triggers can be a bit obtuse and it's not always 
fully obvious what to do, but if you talk to every NPC, you should be able to 
figure things out on your own. Overall, it's a good effort for the time, and 
while it will be outdone by the later entries in the series (in particular 
Manjimaru, one of the top bestsellers on PCE-CD), it holds an important place in 
video game history. If you're interested in learning more about this game, Jimmy 
Hapa of Import Gaming FTW! has a good video on it up on YouTube!
  
  ----------
  - Supper -
  ----------
  
  "Supper, why do you waste your time translating games nobody goddamn cares 
about like Galaxy Fraulein Yuna instead of the ones people actually want to 
play?" no one's ever asked me, probably because no one's paying any attention 
because I only ever translate games nobody goddamn cares about. But if anyone 
out there has ever looked at the list of projects I've worked on over the last 
five years, I expect they had a thought that was more or less equivalent. Well, 
here you are: an honest-to-god "major" game from a big mainstream franchise, an 
important critical and commercial success that was the foundation of a hit 
series. Am I in the big leagues now? Will they inscribe my name on the walls 
next to Gideon Zhi, Tomato, Tom, and Neill Corlett? When do I get my golden 
CD-ROM?
  
  I didn't originally intend to work on this game; I didn't even start the 
project, really. During a thumb-twiddling period on Yuna back in 2021, I found 
out dot_lvl (https://www.twitch.tv/dot_lvl) was planning to do a translation of 
the game as a stream series, but didn't have a script dump to work from. I'm 
always looking for interesting things to work on, it seemed fairly low-risk, and 
most importantly I had nothing else to do at the time, so I put together a 
partial script dump in about a week and offered it up on the off chance it might 
turn into a full translation project. But while dot was very gracious and I 
think we were both hopeful, that ended up being the last of things for quite 
some time for understandable real-life reasons.
  
  Near the start of this year, we tried to resume the project. I put together a 
complete script dump and set up all the basic script insertion, but for various 
reasons, things again didn't pan out. Ultimately, after TheMajinZenki's schedule 
opened up, I asked dot to just let us do it instead, and that's what ended up 
happening. I know it's no comfort, but I feel terrible for the way it all worked 
out, and I'm sorry all I have to offer are hollow apologies.
  
  But regardless, that cleared the way for production to finally get underway in 
earnest at the end of August. Things went about as smoothly as they could have, 
and we basically made steady progress from then until now. It's a long game, but 
not monumentally so; I don't have the statistics on hand, but I believe it's 
comparable in length to Community Pom if not shorter, so we've certainly done 
projects on this scale before. It wasn't _easy_ – especially for TheMajinZenki, 
who had to deal with a lot of intensely Japanese material laced with more 
obscure jokes and pop culture references than ever – but fundamentally, it 
wasn't anything new to us.
  
  That said, coming from a well-known series resulted in the game having some 
rather lofty expectations attached. Based on my discussions with other people in 
the PC-Engine community, this game seems to exist in some strange space where, 
thanks to being an early and rather primitive CD title, no one is super 
enthusiastic about the idea of hacking it, but everyone nevertheless feels that 
it absolutely must have a top-notch translation due to its historic importance.
  
  So, with community enthusiasm tepid but expectations high, I perhaps rolled my 
eyes a little but gave it my all. Battle messages look awkward because there's 
no automatic word wrap? Well, guess we're adding that in, then. Item names won't 
fit? Screw cutting them down or using icons, let's implement automatic text 
squishing. We need subtitles for the attract demos no one's actually going to 
watch? Ha, that's old hat by now. Oh, whoops, the intro's text is too flowery 
for a good translation to fit in three lines? Time to add hacks all across the 
whole printing code so we can use four instead, just for that sequence! And by 
special request, I even spent some time cooking up improvements to the game's 
subpar loading times (it really says something about how bad the official Super 
CD version is that I easily improved on it with a few days and no source code).
  
  Honestly, I enjoyed putting this together, but the effort may be a little 
excessive for what the game actually is: an RPG with high production values and 
future-facing visuals and voice acting, but also very old-school and 
orthodox-to-a-fault gameplay. It's a historic milestone, and it's certainly not 
a bad game – it was undoubtedly considered very good in 1989, when it was going 
up against the likes of Dragon Quest III and Final Fantasy II – but it's the 
kind of game you really have to be into old-style RPGs to enjoy playing for 
long, which unfortunately undermines the aspects of the game which are the most 
unique and interesting: the unusual setting, high-powered visuals, and oddball 
characters.
  
  And that, I have to say, nicely answers that question no one's ever asked me. 
This was a major mainstream title, it had high expectations attached to it, and 
I wouldn't be at all surprised if it ends up being my most-played translation 
project to date simply due to name recognition. But at the end of the day, I 
have to tell you: I work on games nobody goddamn cares about because I'm into 
them, and I just wasn't that into this. I didn't dislike it, I didn't not enjoy 
it, but frankly? I'd take Galaxy Fraulein Yuna over it any day.
  
  But you know, whatever. I put a lot of work into this in the hopes that people 
would enjoy it, and I especially hope that you, person who actually reads the 
readme, will. Even if it's not to my tastes personally, it's a well-made game, 
and it was worth snapping a two-year, three hundred and fifty-eight–day streak 
of exclusively doing fan translations of games with girl protagonists for it.
  
  So thank you, and enjoy.
  
  P.S. Zenki's 100% right, Tsunade is the best character. I kept thinking while 
working on this about how much I'd rather be playing a game about Tsunade, then 
I realized that's basically Galaxy Fraulein Yuna.
  
  P.P.S. I promised multiple people we weren't going to do Tengai Makyou II as 
part of fraught negotiations that allowed us to work on this game. Please please 
please don't start in about Tengai Makyou II, because unless everyone else who's 
already working on it is wiped off the face of the Earth by meteorites, we're 
not doing it. Though now that we're finally done with this, I might actually 
play it and find out what all the damn fuss is about.

                    ****************************************
                    *         VIII. Special Thanks         *
                    ****************************************

The existence of this translation is owed to dot_lvl. Thank you, and sorry for 
the way things worked out.

Additional apologies to Tom and EsperKnight, whose own translation effort we 
unintentionally sniped. It's unfortunate, but honestly, things could have turned 
out much worse.

Thank you to elmer for some helpful pointers during the map dumping process, as 
well as for extracting some promises from Supper about optimizing the load times 
(anyone who plays the translation really ought to be grateful for this!). And, 
of course, thanks as always for the bugfixed bchunk executable.

Thanks to SadNES cITy Translations for the Delta Patcher program, which is 
bundled with this patch as a convenience.

And while Xanathis was sadly unable to participate in testing this time around 
due to circumstances beyond his control, we'd like to thank him anyway for being 
a steadfast presence in our little band of weirdos. Sorry you missed it...though 
considering how brutal the game can sometimes get, you may actually have lucked 
out there.

                    ****************************************
                    *         IX. Version History          *
                    ****************************************

v1.0 (06 Dec 2023): Initial release.
