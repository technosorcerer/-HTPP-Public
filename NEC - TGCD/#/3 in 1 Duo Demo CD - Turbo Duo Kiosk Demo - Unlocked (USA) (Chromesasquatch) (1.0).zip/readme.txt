 
 
 Duo Demo Patching Notes
 
 CRC32 4349ADEF
 MD5: c2c15ece828bae6c9dfff8d89c199cff

If your demo is a .chd file, you must convert that to bin/cue first!
 
 Apply patch Duo_Demo_v2.xdelta to "Duo Demo.bin" (or whatever your bin is named) with Xdelta Patcher
 
 Replace your old .cue file with included one
 
 Rename the patched .bin file to "Duo_Demo_unlocked.bin"
 
 V2 patch notes:
 
 Fully unlocked Gate of Thunder, Bonks Adventure, Bonks Revenge.
 
 Bomberman unlock will come in a new update
 
 2025-09-26
 Turbo-Reproductions
 