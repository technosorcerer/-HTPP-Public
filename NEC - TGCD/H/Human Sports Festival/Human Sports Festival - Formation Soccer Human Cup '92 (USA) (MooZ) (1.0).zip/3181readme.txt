Formation Soccer Human Cup 92.

Extract the data from offset 0x221000 to 0x261000 in Track02.iso.
Apply the IPS patch to the extracted ROM and voilà!
