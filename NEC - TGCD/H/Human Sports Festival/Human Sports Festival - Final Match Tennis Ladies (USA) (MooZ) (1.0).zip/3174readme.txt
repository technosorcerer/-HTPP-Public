Final Match Tennis Ladies

Extract the data from offset 0x1e1000 to 0x221000 in Track02.iso.
Apply the IPS patch to the extracted ROM and voilà!
