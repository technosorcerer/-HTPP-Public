[GUIDA alla PATCH ITALIANA di Final Fantasy Crystal Chronicles: The Crystal Bearers] 

Un grazie infinite, va ai creatori di tutto il necessario: 
@Phoenix, per il FFCBEditor (editor per ogni singolo testo di gioco).
@Vash, Packing\UnPacking dei file + database in xml per catalogarli bene.

(un doppio grazie a @phoenix per la sua cortesia e gentilezza, mi ha aiutato 
in un momento di bisogno e se questa patch ora è ottima è solo grazie a lui
e per il DeltaPatcherLite, indispensabile...)
------------------------------------
[Controlli di gioco + Info]
Premetto che si gioca mille volte meglio su wii usando il wiimote+nunchuk rispetto
a mouse+tastiera su dolphin... Ad esempio con dei grossi boss ci saranno dei problemi, 
sarà difficile puntare, camminare e ruotare la telecamera contemporanemente.
Anche in alcuni minigiochi tipo la pesca o dove si deve scuotere anche il nunchuck sarà dura.
Così come dover cambiare direzione alla navetta, o lanciare un nemico in una precisa direzione,
vanno impostati ulteriori controlli. 
Tuttavia l'avventura può essere portata a termine anche tramite dolphin al 100%.

Quindi, l'epserienza migliore è sulla wii o l'emulazione di un wiimote (vero) tramite dolphin.

Detto questo, per essere più precisi, il gioco non spiega nelle statistiche
a cosa si riferisce il focus o il raggio.
Allora il focus è il tempo impiegato per catturare un oggetto, più avremo focus e poco 
impiegheremo a riempire la barra per catturarlo. Il raggio invece ci permetterà
di raggiungere con facilità tutti gli oggetti lontani, meno raggio avremo e meno oggetti 
saranno evidenziati per essere presi. 
-------------------------------------
[Questa patch cosa traduce? + Info]
Storia Principale: 100%
Dialoghi Npc: 100%
Testi Secondari: 100%
L'unica cosa che ho lasciato in inglese sono solo 2 cose:
1: I nomi dei pesci nella pesca, davvero assurdi... li dovevo inventare, ma li ho lasciati così.
2: Alcune descrizioni dei negozi moogle perché (succede solo in rari casi fortunatamente) cambiano
il testo in "base" al progresso della storia principale. Sfortunatamente ogni "file di negozio",
racchiude più di 1.000 linee di testo, tra linee duplicate a non finire e non 
(ogni file comprende tutte le descrizioni esistenti ogni volta, di tutti i negozi), 
sì o.O sembra assurdo ma è così e quindi anche se si traduce la descrizione giusta, 
potrebbe capitare che durante tot ore lo stesso negozio generi un'altra frase random 
dalle 1000 disponibili...... Ripeto, fortunatamente succede questo solo con pochissimi negozi 
e quindi non è nulla di grave. (ah e il copia e incolla non si può mica fare eh).
-------------------------------------
[Passiamo a come si applica la patch al gioco, passo per passo]

IMPORTANTE - Preparazione della Iso:
Allora, io ho lavorato su una iso dal peso canonico di 4.37GB, 
questa patch l'ho testata su quel peso e non sui backup di FFCC da 3GB e qualcosa, trimmati.
Dovrebbe funzionare anche lì al 100% visto che sono 4 patch che puntano direttamente a 4 file,
ma non l'ho testato. Quindi io direi di provarci prima.
SE MAI non dovesse funzionare il metodo scritto più in basso con la iso trimmata, 
allora basta che masterizzi tale iso trimmata su dvd vergine
con "imgburn" (è un ottimo programmino), scegli "write image file to disc" e
una volta finita la masterizzazione ri-inserisci il dvd e clicca su "create image file from disc"
dopodiché si avrà la iso da 4.37GB pronta da usare.

ORA

Scarica WiiScrubber (ultima versione)
1 - Apri WiiScrubber
2 - Clicca su Load ISO (carica la iso di FFCC)
3 - Clicca sul [+] di Partition:1 - Data (si aprirà una serie di file)
4 - Ora, tasto destro e poi Extract su: dvdimageA.dat, dvdimageA.pos, dvdimageB.dat, dvdimageB.pos
5 - Metti questi 4 file da parte in una cartella dove vuoi tu.
Lascia aperto così wiiscrubber, ci torneremo dopo.
Fine 

Ora passiamo al DeltaPatcherLite
1 - Apri la cartella "Patch Crystal Bearers ITA"
2 - Apri DeltaPatcherLite.exe
3 - Patcha i seguenti file nel modo GIUSTO, con calma:

Allora, su original file carica: 
dvdimageA.dat (prendilo dalla cartella che hai messo da parte prima)
su XDelta patch:
dvdimageA.dat.xdelta (dalla cartella: Patch Crystal Bearers ITA)
poi clicca su Apply patch
Servirà un po' di tempo... FATTO.

Ora ripeti tale sistema per gli altri 3 file, quindi

1 original file: dvdimageA.pos / XDelta patch: dvdimageA.pos.xdelta / Apply patch, OK
2 original file: dvdimageB.dat / XDelta patch: dvdimageB.dat.xdelta / Apply patch, OK
3 original file: dvdimageB.pos / XDelta patch: dvdimageB.pos.xdelta / Apply patch, OK

Se sei uscito vivo da tutto questo, hai quasi finito, manca l'ultimo passo!

Torna su wiiscrubber fai tasto destro su dvdimageA.dat poi "replace" 
e cerca dvdimageA.dat che hai messo nella cartella da parte prima, (ma ora è patchato in ita).
ripeti questo procedimento anche con dvdimageA.pos, dvdimageB.dat, dvdimageB.pos 
tasto destro, replace e ad ognuno gli inserisci il file patchato sempre 
dalla cartella messa da parte.

una volta finito, ci vorrà un po', chiudi wiiscrubber e carica la nuova iso dove vuoi tu
o su wii o su dolphin. 

Buon Divertimento








