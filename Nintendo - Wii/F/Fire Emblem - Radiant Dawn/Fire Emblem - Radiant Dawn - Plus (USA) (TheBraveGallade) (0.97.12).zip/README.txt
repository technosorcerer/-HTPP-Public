How To install

1. Get a ISO of Fire Emblem Radient Dawn, NTSC-U, v.1.1
2. Download and install Dolphin Emulator
3. Extract the iso using Dolphin Emulator 
----->	https://youtu.be/plUi3Ak-B98
4. copy and paste the contents of the DATA folder in this zip folder onto the DATA folder of the extracted ISO
5. point dolphin towards the main.dol file in DATA/sys on the extracted ISO
6. boot dolphin and enjoy!

Any updates can just be copy pasted over the old modded files.
