This is a simple generic "patcher" batch for Wiims ISO Tools to rebuild your copy of the game into the undubed one.

Place your copy of the game into the patcher's directory (where this txt is located) and execute the "PatchIt!.bat" batch file.
IMPORTANT: Make sure there are no other WBFS/ISO files in the patcher's directory other than the input image!
The provided input image and the patch data will be deleted after the patching process ends.

In case you'd like your output image to be ISO instead of WBFS, edit "PatchIt!.bat" and replace these lines:
	wit copy Extracted Dokapon_Kingdom_Undub_[R2DEEB].wbfs
	move Dokapon_Kingdom_Undub_[R2DEEB].wbfs ..
with these ones:
	wit copy Extracted Dokapon_Kingdom_Undub_[R2DEEB].iso
	move Dokapon_Kingdom_Undub_[R2DEEB].iso ..

Naturally, the patcher is only for the user's convenience. You can freely rebuild the image without it or simply sideload the undub as a Riivolution patch.
The batch will probably won't function correctly on Mac and Linx, you guys will just have to do the thing manually.