This patch was provided by Barronwaffles. Many thanks to him !

-------------------------------------------------------------

This is only necessary if you want to play online.

The patch will modify your iso, so that you can connect to the "zwei" server without having to modify your Wii DNS, thus being able to continue to use Riiconnect.

Simply drag your iso to "network patch.bat", and choose "A" (for "zwei.moe" server host).

You should now be able to use Wifi menu and play online !

