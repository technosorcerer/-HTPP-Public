====================================================
Metroid Prime 2: Unlimited Beams Authorized (U.B.A.)
====================================================

Made by: z_pucK, Dybbles
Written by: z_pucK

Date: April 5, 2020

======================================
      -=U.B.A. Patcher Instructions=-
======================================

1. Put game inside the same folder as this file first.

2. Drag game onto "DRAG GAME ONTO HERE.bat".

3. Follow instructions on-screen. Patching will finish in under 10 minutes
unless you are patching Trilogy USA, and then it will take at least 10 minutes.
If nothing happens on the patcher screen for more than 10 minutes, then try it again.
Attention: Patching Trilogy requires at least 20GB of free hardrive space before patching.

Takes:	U.B.A. requires an unmodified dump of either Metroid Prime 2 (.gcm/.iso format)
	or USA Metroid Prime Trilogy (.iso format).

Full size games are recommended [1,459,978,240 bytes for Gamecube] but not required.

Refer to MD5listmp2.txt in "patchmp2" for a full list of the MD5 checksums
that the patcher will produce, and some of the tested checksums that it will take.


======================================
	   Troubleshooting
======================================

1. A "Windows protected your PC" message pops up on a Windows blue screen.

Fix: 	Right below the error message, click on "More info" and then select "Run"
	or "Continue" to run the patcher.

2. A black window pops up and then quickly closes, or the file seemingly does nothing.

Fix:	Try running the patcher file from the CMD prompt. You have to open the
	CMD prompt (try typing CMD in the Start Menu), and then use "cd" to navigate
	to where your patcher is located. Once there, type in "Drag game onto here.bat"
	with quotes, just like that, followed by a space, followed by the name of your
	game (e.g. "Metroid Prime 2"), also in quotes, if it has spaces, and hit enter.
	You can auto-complete entries and cycle through available names using "Tab."

3. Still doesn't work.

Fix:	Right-click on the patcher file and select "Create shortcut."
	Right-click on the shortcut you just created and go to "Properties".
	On the properties page, look up to the box that says "Target", with the
	name of the patcher "DRAG GAME ONTO HERE.bat" inside of it. Put your cursor at
	the end of that name, and put a space after the quotation mark. Type in
	the full file name of the game you are trying to patch, and make sure it
	is surrounded by quotes. For example, it should say
	Target: ..."DRAG GAME ONTO HERE.bat" "Metroid Prime 2.iso"
	or whatever your game name is, just like that. Note the space in between the
	two names, between the different quotation marks. Make sure the typed file is
	EXACTLY the same as how the name of the actual file is. You can rename your
	game to make it simpler, or you can right click your game and
	go to "Properties" and look at the top there. The full file name will be in
	a box. You need to copy that name exactly, including the file extension at
	the end of the name. You MUST make sure the filename has quotation marks
	around it when you type or paste it into the "Target" bar in the shortcut's
	"Properties" page. Make sure you have everything saved correctly, and then
	double-click the shortcut file.
	NOTE: If you right-click and go to the shortcut's "Properties" page and
	click "Advanced" in there, an option to "Run as administrator" will become
	available. Do NOT select this option - selecting it may cause the patcher to
	not run at all. However, in the case that the patcher didn't run anyway, you
	can try selecting this box afterward and try again. Windows is dumb. Just make
	sure that the file name is exact: you must have quotes and you must also have
	the file extension and have the extension inside those quotes. Refer to the
	example above as a guide.

Fix:	Re-download and extract the files, double-check all of the steps, make
	sure you've read any error messages closely. There are manual patching
	instructions for advanced users inside "patchmp2," the file can be opened
	with any program that displays text.


======================================
	    Introduction
======================================

Metroid Prime 2: Unlimited Beams Authorized is an unlimited beam mod for Metroid Prime 2: Echoes
for the Nintendo Gamecube. It removes all beam ammo spawns from the game, and instead gives Samus
unlimited beam shots. Missiles, energy, and powerbombs all drop as normal.

Prime 2 originally gave Samus limited beam usage. Many Metroid fans have wondered, however, what
Prime 2 would have been like without an ammo bar on Samus' beam weapons. This was the guiding
direction for this mod. The rest of the game has been preserved as much as possible. e.g. Beam
ammo expansions are still a collectible pickup, and still count toward total completion percent
as normal, and enemies, crates, and bosses all still spawn missiles, energy, and powerbombs as
normal.


=================================================
    -=Unlimited Beams Authorized Highlights=-
=================================================

- Gives Samus unlimited beam ammo.
- Can remove Beam Ammo bars from HUD (user-choice at patching).
- Hides Beam Ammo counter from HUD (the numbers).
- Enemies and bosses no longer spawn beam ammo.
- Crates no longer spawn beam ammo.
- All other events no longer spawn beam ammo.
- Charge beam combos still cost missiles (unchanged).
- Enemies, bosses, and crates all still drop suit energy, missile ammo, and powerbombs as normal
  (largely unchanged, see exceptions below).

======================================
	 UBA Patcher Features
======================================

- Mod compatibility for all 3 GCN regions: USA, EUR, and JPN.
- Mod compatibility for USA Metroid Prime Trilogy.
- Save-file compatibility between U.B.A. and original versions of MP2 and Trilogy (only for same-
  region, of course). No save file corruption whether you load Unlimited Beams Authorized or
  vanilla MP2/USA Trilogy.
- Drag 'n drop patcher.
- "Hardmode" secret playable mode. (No ammo spawns... but no unlimited ammo, either!)
- No special requirements to patch. U.B.A. uses an unmodified Trilogy or MP2 .iso/.gcm.


======================================
Other side effects and (known) changes
======================================

Despite having unlimited ammo, the overall difficulty of the game is more or less the same.

A very limited number of enemies and boss attacks that would normally spawn beam ammo now drop
nothing at all - a small price to pay for unlimited ammo. This typically affects swarm-type
enemies, and for example may be noticeable on boss attacks like Chykka's spawns, or in the final
boss battle. This effect largely goes unnoticed, however, as most everything else in the game
still drops health and missiles and powerbombs as normal (enemies, crates, bosses after you kill
them, and powerbomb-specific enemies).

Multiplayer now gives ALL players unlimited ammo when firing beams.


======================================
	-=Acknowledgements=-
======================================

Dybbles
Initial mod proposal, game research, AR code hacking and asm injection, documentation, testing

z_pucK
General research, documentation, patch creation, testing, writeups

Special Thanks to
Metroid Prime Modding - Antidote, Aruki, Cirrus, and Pwootage for modding and guidance help
Prime World Editor
Retro Modding Wiki
Paktool
NODtool
John Nathaniel - .bat help for patcher

Thanks to
MetConst - kkzero, thedopefish - patcher help
TJG Minty Meeo - getvalue, patcher help
encounter - Trilogy AR codes


======================================
	       FAQ
======================================

Q: Does this mod affect logbook scans?
A: No, item drops in MP2 don't give logbook scans, so they won't take away from your logbook%.

Q: Can you remove beam ammo expansions from completion%?
A: Changes the save file, likely causes corruption if you load Vanilla or UBA in between
   gameplays. So we left it out from even being an option.

Q: Remove beam ammo expansions be from the game?
A: Possible.

Q: Make beam ammo expansions give missiles/powerbombs/new upgrade/change their models?
A: Possible. Missiles and powerbombs are capped at the in-game values, meaning you'll never go
   over the total. However, you could get a missile tank or something early, which could make for
   an interesting route.

Q: What is hardmode?
A: Beam ammo does not spawn, but Samus is not given unlimited beam ammo either. You will only be
   able to refill your beam ammo at ammo stations or your gunship.

Q: How do I access Hardmode?
A: When the patcher prompts you whether to HIDE or KEEP beam ammo bars, press the "h" key instead
   to activate hardmode 1, which will remove ammo from spawning, but give Samus limited ammo. If
   you want to access the hardest mode, press the "s" key instead and hardmode 2 will activate.
   Hardmode 2 is a "silent" mode where Samus won't know when she'll run out of ammo until she
   does. Hardmode 2 hides the beam ammo bars, in addition to the effects of hardmode 1.