===========================================================================
Version 1 - October 30, 2017

* Main Menu Complete
* Opening Video Subtitled
* Main Dialogue Complete
* Island Bulletin Board Complete
* Home Button Menu is English
* "+" Menu (Items, Character Bios) Complete
* "-" Menu (Map) Completed

/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\

ISSUES REMAINING

- Instructions for mini games not translated
- Some Narrator text not translated
- Characters wandering around map, (not mission related), not translated
  (These have been translated, next patch release will have these corrected.)

===========================================================================