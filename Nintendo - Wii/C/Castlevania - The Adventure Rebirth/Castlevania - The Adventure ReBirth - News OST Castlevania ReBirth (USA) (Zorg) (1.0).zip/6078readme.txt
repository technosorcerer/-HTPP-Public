This patch is intended to replace the music of the first three stages
Castlevania The Adventure Rebirth game for Nintendo Wii, two of them being
Official soundtracks for the game that were not used in its final release.

The changes were as follows:

- Battle of the Holy on Stage 1 (unused official soundtrack)
- Reincarnated Soul on Stage 2 (I didn't want to get rid of this music so I put it here)
- Lost Painting on Stage 3 (official soundtrack not used)

Apply the patch to the following file
-------------------------------------------------- --------------
Name: Castlevania - The Adventure ReBirth (USA) (WiiWare).wad
CRC32: 40470D65
-------------------------------------------------- --------------
I wanted to make this modification based on the work done by
Thirteen 1355 that changed Reincarnate Soul for Batttle of the Holy in
stage 1, but my goal was to keep the music from Reincarnated
Soul placing it on stage 2 and the other change I made to it
was adding Lost Painting on stage 3.
************
INSTRUCTIONS
************
To apply the patch you will have to Download an xdelta patcher, you can
download it from here:
https://www.romhacking.net/utilities/598/

Enjoy it!

Zorg © 2021