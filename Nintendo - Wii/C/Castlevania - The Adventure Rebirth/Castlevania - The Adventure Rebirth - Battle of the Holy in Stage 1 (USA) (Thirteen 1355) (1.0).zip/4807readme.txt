This patch will replace the music of the first stage (Reincarnated Soul, originating from Castlevania: Bloodlines) 
with Battle of the Holy, a track from the original Castlevania: The Adventure, that went unused in this remake. 

If anyone would like to see another track replaced with this one, instead of the Stage 1 theme, feel free to PM me. 