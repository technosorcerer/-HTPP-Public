-- Patching guide --
1. Move your clean Puyo Puyo 7 .ISO in this folder (WBFS won't work)
2. Click "patch.bat" (just "patch" if you have file extensions disabled)
Wait for the batch to finish, it will output a WBFS named "RY4J8P.wbfs" 

USB Loader GX users, move the WBFS to a folder named "Puyo Puyo 7 [RY4J8P]" in usb:wbfs/

Dolphin users can simply load the WBFS in the emulator.


I've also included a custom banner, icon and banner audio in case you want to make a Wii U VC inject of the patch.
