The things you'll need:

[] xdelta patcher
[] WiiScrubber

1. (If you already have a compressed version of Animal Parade you can skip this step!)
	
	If you don't know how to use WiiScrubber just a quick google search works!
	You're going to scrub you're game, if you don't the patch won't work.

2. 
	Now that the game is scrubbed you're going to launch xDelta. You're going to put
	the patch in the "Patch" box. In the "Source File" box you'll put the patched
	game. In the blank typable box where you normally see file names you're going to
	name your patched file.

	Ex: AVP-HMAnimalParade.iso

	Make sure you type .iso at the end!!! if you don't your emulator won't read it!

3.
	Enjoy and have fun!

~~~~~~~

If you find any errors or things that could be improved you can contact me on my socials!


Twitter: @CowEgg_Dev

ROMHacking.net: CowEgg