==============================================================================
SHINSETSU SAMURAI SPIRITS BUSHIDO RETSUDEN TRANSLATION                    v1.00
https://ko-fi.com/moriyamug
==============================================================================
Here's what you've been waiting for... version 1.0 of the long-awaited English
translation of Shinsetsu Samurai Spirits Bushido Retsuden, better known
outside of Japan as "Samurai Shodown RPG," with its new localized title of
"Samurai Shodown: Tales of the Bushido." My white whale has finally been slain.

This is a free translation. If you paid for it, you got ripped off. Don't
reward bootleggers by buying repros, especially not of a CD-based game. And
PLEASE don't make, sell, or distribute pre-patched versions of the game.

Features:
- 100% complete translation to English.
- Bug fixes from the original Japanese, like some character portraits not
  being displayed
- A healthy amount of original art, including a new font & title screen by
  combustocrat
- Two variant patches, one for the TOSEC rip and another for the REDUMP rip

Quality of Life improvements, which can be toggled via soft DIPs, but are
enabled by default in US/EU mode, or disabled for JP mode.
- Choose between the original Neo*Geo CD or the PS1/Saturn version of the
  elements system
- Improved potency of permanent stat boost items
- Improved potency of Repellent item (temporarily lowers encounter rate)
- Selectable alternate palettes. Hold D while pressing A when confirming any
  character selection until you hear a chime. Not dependent on soft DIPs.

==============================================================================
REVISION HISTORY
==============================================================================
          1.00      11/29/2023          Initial release

Please report bugs to deucemugen @ hotmail . com with subject "SSRPG"

==============================================================================
HOW TO APPLY THE PATCH
==============================================================================
This patch is distributed in XDELTA format (http://xdelta.org/). You can use
the command line executable or another XDELTA-compatible patcher (NOT INCLUDED).

Included are two patches, each meant for a specific commonly-available rip
of the game. One is for the REDUMP set, the other for TOSEC. Both can be found
on archive.org.

1. Extract either set into the same folder as the patch and xdelta.exe
2. Compare your track 1 with the CRC32 checksum below
3. Open the batch file that corresponds to your copy of the game. This will
   apply the patch and rename the files appropriately.
4. Burn to disc or load to ODE/NeoSD/MiSTer/emulator (fbNeo is recommended).
5. Enjoy!

==============================================================================
COMPATIBLE DUMPS
==============================================================================
REDUMP rip - 1 CUE and 32 BIN files
Archive: Shinsetsu Samurai Spirits - Bushidohretsuden (1997)(SNK)(JP).zip
File to patch: Shinsetsu Samurai Spirits - Bushidou Retsuden (Japan) (Track 01).bin
File/ROM SHA-1: 69DA036E094A971A035C63C7B365179E031AEA2C
File/ROM CRC32: 6D0FAABA

==============================================================================
BEFORE YOU PLAY
==============================================================================
Because of the way the font routine works, text will appear two characters at
a time. This is normal, but the side effect is that names with an odd number
of characters will have an additional trailing space, so instead of seeing
"Genjuro attacks!" you'd see "Genjuro  attacks!" Adjusting the system to use
strictly 8x16 characters and eliminating this issue would require massive
changes to the font routine as well as having to make significant adjustments
throughout the game for memory and timing on auto-advancing text. It was
deemed not worth the additional work and delay.

==============================================================================
CREDITS
==============================================================================
MoriyaMug               (@PricePartDeux)
    That's me. All of the script work, editing, a few minor graphical edits
    (like the nameplates on the character select), hex editing, most of the
    testing, and basically everything you see that isn't covered below.
combustocrat            (@combustocrat)
    For decades of friendship, boundless enthusiasm for my crazy projects,
    and every graphical alteration that actually requires artistic talent.
    Literally couldn't have done this without him.
Justin Gibbins          (@JustinGibbins)
    For an absurd amount of hacking work, including miscellaneous minor
    graphical fixes, forcing text display on voiceover-only scenes, fixing
    the smithy screen, modifying the opening text crawl, among many others.
Pennywise               (@ElCaminoOscuro)
    For the original hacking work, thus enabling proper display of the
    character profiles/input method/chapter select when starting a new game,
    as well as enabling proper display of certain combat messages.
smkdan                  (@superfamicom)
    For his original work on the app that made it possible to get proper
    timing on the voiceover segments. Not his fault that I gave him bad
    info, which made my original attempt useless.
khalismur               (forumgoer on romhacking.net)
    For going in and updating smkdan's app with correct data, thus enabling
    me to fix the errors I made in my original attempt to fix the voices.
Video Game Esoterica    (@vesoterica)
    For putting fuel back in the tank and compelling me to start tinkering
    with the old project files.
Chris
    For being the brother I never had, for always being there to support and
    encourage me, and for invaluable translation consulting.
Lazarus                 (@Lazarus_DS)
    For additional translation support and being a sounding board for the
    general aches and pains caused by this project over the years.

Last but not least, everyone who has supported me on Ko-Fi and everyone who's
taken the time to say something nice on Twitter and RHDN. For those on a
certain ancient forum who are still salty about interactions from literal
decades ago... I hope the past intervening years have treated you well. May
you find whatever peace you're looking for, and I hope you enjoy the game.

==============================================================================
ABOUT THE PATCH
==============================================================================
So you want to know what the hell happened here? Well, back in 2007, when I
was occasionally working with Gideon Zhi of Aeon Genesis fame, a mysterious
"Guest" in his chat provided me with the tools to dump the game's script.
Only the tools, mind you. Only the most basic of instructions and no table.
In essence, I was told "have fun figuring the rest out." And since I'm more
than a little Samurai Shodown-obsessed, I immediately set to work.

The first order of business was getting the font table. I knew where it was
and how to get at it, so I found the earliest possible place to display text
(in Ukyo's intro to Descent of Dark Skies, if you're wondering) and just had
it list off every single entry in the table in order, then took screenshots.
16 characters per line. 1800 characters, almost all of which are Kanji, and
many of them are somewhat archaic and not in common usage. Then I had to
identify all of those Kanji and get them into a Shift-JIS form... so I used
WWWJDIC and its multi-radical Kanji finder. For over 1500 Kanji. Nowadays, I
could just let an OCR app do this work for me. Once I had a table, then I
was able to dump the entire script into something I could actually read.

Next was learning the way control codes work. This required a LOT of fiddly
little changes and throwing various stuff at the font routine to see what
broke. I learned, primarily, that there are two really important codes, and
they are both context-sensitive. Let me tell you how much fun figuring that
out wasn't.

For the next few months or two, I worked on translating the entire script,
and those two important control codes were and are the linchpin of how the
game handles spoken dialogue. Unlike the PSX or Saturn versions of the game,
which stream the voices off the disc like any other game audio, the Neo*Geo
CD loaded the entire voice samples into memory, and called them up at the
appropriate moment. The other thing is that these voiced segments are not
broken up into individual lines, but are a fixed length, and the game uses
those control codes to adjust the text display speed to keep up with the
voices. The "context sensitive" aspect meant I was going to have to learn
exactly how they worked or else the voices were just going to either be
mistimed or left out entirely. So I did my best to figure out how they
worked.

In the middle of all of this, I was also using a PHP app called FEIDIAN to
extract the graphics to be edited in Paint Shop Pro 6 (which I still use to
this day). With the occasional help of my brother-in-arms and artist friend
combustocrat, I gradually replaced the Japanese text of the intro and put in
an English title, as well as the combat menus (which use the same part of the
hardware as the HUD in other Neo games).

A fine gentleman going by the handle smkdan reached out to me and offered
to help by putting together a little VisualBasic app, which would allow me
to paste Japanese text in with those control codes and determine how long
each character was onscreen before the next character was displayed, etc.
With a separate box for entering the control codes in English text. The
idea being, naturally, if they match up, the timing will be accurate.
Unfortunately, I made a massive error in figuring out the control codes.
For reasons unknown to me, the text timing function is the only thing in
the game's code which demands DECIMAL values instead of HEXADECIMAL. If a
hex value is passed, the entire command gets ignored. Which meant that most
of my modifications, the game disregarded entirely, as I was entering hex
values.

So imagine my surprise when I spent weeks on timing the entire script, only
to find all of this work was useless and would have to be redone. I was also
being accosted online by people who felt like the mere existence of my work
meant that they were personally entitled to it, regardless of my thoughts on
the matter. These two things, plus some tedious personal shit going on at the
time, utterly sapped my drive to work on it, so I shelved the project.

A few years passed and the urge to mess with it popped up again, so I started
back up. Put in some work on the combat menus and cleaning up a few pieces of
the script, streamed a playthrough of the entire game on Twitch, and just as
I was really starting to get back into it, the HDD on which my work was stored
died. It was a Western Digital USB3.0 one, meaning everything on it was
encrypted and data recovery was unlikely to be able to get at the data. Sent
it to a data recovery specialist and he had no luck.

That, it seemed, was that. While I had an older backup, it was another huge
setback that would require redoing EVEN MORE work, and I gave up on the idea
of ever finishing it. Didn't think much about it until I started talking to
Video Game Esoterica about SNK on Twitter and the subject of Samurai Shodown
came up. I decided to send him the beta from 2008 to show on his channel, and
the response to the video was so strong that I decided to start poking at the
work files again.

Lo and behold, I got sucked back in. Had to reacquaint myself with how a lot
of stuff worked, threw my efforts into getting the text timing RIGHT this
time (and khalismur helped by tweaking smkdan's app to use correct data), and
wound up getting some useful ASM hacking assistance from Pennywise, who fixed
issues with combat messages as well as several issues with proper display of
text on the opening menus when starting a game.

He found himself tied up with other projects and tasks, and referred me to
another hacker by the name of Justin Gibbins. Justin took to the task almost
immediately and not only fixed a graphical glitch in the intro, but he found
how to force text display on a handful of scenes that had full-screen images
and voiceover, but no dialogue boxes. With a bit of collaboration, we got
them taken care of very quickly.

And then Justin decided to add additional quality-of-life changes, accessible
via soft DIP switches, as well as opening up the alternate colors that were in
the game but not used. Try holding SELECT and/or D when you confirm your
character/chapter when you start a new game, or hold D when closing out the
dialogue where a character joins to have them appear in their alt colors.

From there, it came down to fixing the opening text crawl to look a bit more
professional, correcting some issues on the smithy screen, and final script
polish. It took a couple more playthroughs to squash a few more bugs and
find/fix some context errors, but the game is now 100% playable in English,
start to finish.

It's been a hell of a journey. And it's finally done, barring any bug fixes.
Thanks for being here at the end of it.