Agent - X (ZX Spectrum)
Traducción al Español v1.0 (23/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Agent - X.tzx
MD5: e09588c93a7e384d92b97bd175c40f28
SHA1: 1b37bd67220be85372f8dcc77a013c9df699ce5a
CRC32: 7fe581ab
74017 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --