The Alchemist (ZX Spectrum)
Traducción al Español v1.0 (10/02/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
The Alchemist.tzx
MD5: af3ad60f957b2dbd1e98390ae1bd87cf
SHA1: 2276b464032c6b6851bfd1e7c3f8a13458e3d89b
CRC32: b22e97b9
47202 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --