Action Reflex (ZX Spectrum)
Traducción al Español v1.0 (20/04/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Action Reflex.tzx
MD5: 2010c4969d07da4564a9a1611178c8dc
SHA1: 6210b84403b0e0307b2c975e36e8d852ed522b12
CRC32: 0c923953
41655 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --