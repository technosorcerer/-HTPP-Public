Devil's Crown (ZX Spectrum)
Traducción al Español v1.0 (30/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Devil's Crown.tzx
MD5: ad223c4b8986f45c9c2aee4ce5fdd4c4
SHA1: 4d4a672c9e90fd49cce5c3fc3b0d5040a3a73a25
CRC32: 674a870e
48028 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --