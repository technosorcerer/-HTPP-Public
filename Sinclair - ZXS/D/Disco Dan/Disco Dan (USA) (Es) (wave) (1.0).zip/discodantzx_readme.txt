Disco Dan (ZX Spectrum)
Traducción al Español v1.0 (04/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Disco Dan.tzx
MD5: faf57ea041d631643ac71f79d0d4af3f
SHA1: bc3c66960bdc9cb4c76b6e3aad281bb459f7547d
CRC32: 17600aad
19978 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --