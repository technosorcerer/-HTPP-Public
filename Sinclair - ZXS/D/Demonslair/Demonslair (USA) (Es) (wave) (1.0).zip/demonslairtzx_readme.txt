Demonslair (ZX Spectrum)
Traducción al Español v1.0 (06/04/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Demonslair.tzx
MD5: 1f285b5137e6a5f0042c2458b950f666
SHA1: e59c19bfae6c8d370270fefd49a934da5005d446
CRC32: c8665a38
42956 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --