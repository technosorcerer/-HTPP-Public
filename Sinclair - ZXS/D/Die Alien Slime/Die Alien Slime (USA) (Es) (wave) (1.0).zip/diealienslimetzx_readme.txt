Die Alien Slime (ZX Spectrum)
Traducción al Español v1.0 (15/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Die Alien Slime.tzx
MD5: 45149e5e863e4ffc5df6e4967f9dcfc3
SHA1: 481a10cedbbda610096fb5b448b0b395eefdf277
CRC32: 8d6e4673
41280 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --