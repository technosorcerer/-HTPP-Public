Ultimate Combat Mission (ZX Spectrum)
Traducción al Español v1.0 (21/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ultimate Combat Mission.tzx
MD5: bd0481aa54367c1b180a2bcb540e5507
SHA1: 58521ff31b83bc32bcf778bbcc71dabf8c1c68d2
CRC32: 0975d701
44970 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --