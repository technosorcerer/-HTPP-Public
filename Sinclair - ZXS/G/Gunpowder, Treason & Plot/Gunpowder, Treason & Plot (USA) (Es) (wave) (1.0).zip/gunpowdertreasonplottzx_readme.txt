Gunpowder, Treason & Plot (ZX Spectrum)
Traducción al Español v1.0 (29/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gunpowder, Treason & Plot.tzx
MD5: 47da1cb71c1425d47cb5db048b22c6f9
SHA1: 833977dab87929e343e620d292f12abfad9b598b
CRC32: 3cfe0610
48250 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --