Yazzie (128K) (ZX Spectrum)
Traducción al Español v1.0 (27/07/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
yazzie128.tap
MD5: d2b85c1f5d162d2520075d9c0d4a4139
SHA1: 97c5adad67bba0633780976d21a9e6de70bd2706
CRC32: 68d21e49
70103 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --