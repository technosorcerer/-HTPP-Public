Yazzie (48K) (ZX Spectrum)
Traducción al Español v1.0 (27/07/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
yazzie48.tap
MD5: 107cad94aae17442fac10e70c6678946
SHA1: d8d0a7339ffafb6b80681d9c353b05e3c1194450
CRC32: b4b55b08
44860 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --