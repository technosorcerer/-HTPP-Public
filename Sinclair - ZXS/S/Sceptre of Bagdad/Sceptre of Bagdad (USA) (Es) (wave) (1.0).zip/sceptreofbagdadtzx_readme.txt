Sceptre Of Bagdad (ZX Spectrum)
Traducción al Español v1.0 (14/05/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sceptre Of Bagdad.tzx
MD5: dfed3a0cab4c5a95acbcdea67a5cd12e
SHA1: 9c3d28ac68b3eeba5abce6554ea2e4c754f29df8
CRC32: 8845d8f5
48607 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --