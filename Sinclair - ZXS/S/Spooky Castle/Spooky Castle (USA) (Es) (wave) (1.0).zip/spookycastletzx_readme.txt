Spooky Castle (ZX Spectrum)
Traducción al Español v1.0 (16/04/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Spooky Castle.tzx
MD5: 6d0ccaf76984615aaadb72a3a808f6be
SHA1: 53d77707738fe67d687aa5d4bfc2ea2c64b5674c
CRC32: a991eb04
24907 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --