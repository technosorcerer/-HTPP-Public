Sorcery (ZX Spectrum)
Traducción al Español v1.0 (03/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Sorcery.tzx
MD5: 44321fc6eb812a74b9d689ed43c4d4ff
SHA1: 5239fe681dacb0cb24d1a786629c6082ac294df1
CRC32: 28229ef6
35201 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --