Motorbike Madness (ZX Spectrum)
Traducción al Español v1.0 (28/09/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Motorbike Madness (Dro Soft).tzx
MD5: 48127f0a9f3ed8d3a363a543c03ef3e3
SHA1: fb085edb46367eb045dca2caedae319ce91b14f3
CRC32: 13a4b937
68614 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --