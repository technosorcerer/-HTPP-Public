Master Blaster (ZX Spectrum)
Traducción al Español v1.0 (01/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
MBLASTER.TAP
MD5: b633328bc100a80de2c928f289db5fc7
SHA1: 7d0664405f6fe0cbe8ed03e7128af9f40c6e609e
CRC32: 83f104ce
49304 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --