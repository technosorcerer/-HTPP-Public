Omega 1 (ZX Spectrum)
Traducción al Español v1.0 (29/10/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Omega 1.tzx
MD5: 5628d2c2324a3ee9ff102bf99f52caf5
SHA1: 6cdddf487412ec146e09c95dcbdd14ec6997d297
CRC32: f86ba570
49424 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --