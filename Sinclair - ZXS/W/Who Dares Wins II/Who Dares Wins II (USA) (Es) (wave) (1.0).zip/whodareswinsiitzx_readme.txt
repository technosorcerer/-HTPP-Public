Who Dares Wins II (ZX Spectrum)
Traducción al Español v1.0 (04/05/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Who Dares Wins II.tzx
MD5: 8bc0269c252313fc5ae8b77bcbd7797d
SHA1: de4cffd0bd0d6ceb6b55e96eca42c854914c7c2a
CRC32: bf14f1aa
48692 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --