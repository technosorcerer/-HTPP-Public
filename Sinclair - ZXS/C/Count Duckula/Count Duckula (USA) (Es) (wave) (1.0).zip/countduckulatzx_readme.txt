Count Duckula (ZX Spectrum)
Traducción al Español v1.0 (16/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Count Duckula.tzx
MD5: 2786c6a9e82e3973049932f09ffb414d
SHA1: 41b4a20e610df475e6a2d556879bd683c3cd3adf
CRC32: 086c74bb
48638 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --