Roboto (ZX Spectrum)
Traducción al Español v1.0 (14/11/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Roboto.tzx
MD5: 890f75da8023077d680933b47131e1d7
SHA1: 6d72f059d19564e188e797a807d16c025cc6f75e
CRC32: bed8b184
49824 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --