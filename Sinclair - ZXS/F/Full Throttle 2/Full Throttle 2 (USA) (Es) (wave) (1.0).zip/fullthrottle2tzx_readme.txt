Full Throttle 2 (ZX Spectrum)
Traducción al Español v1.0 (29/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Full Throttle 2.tzx
MD5: 2bf8c598e7b27d0561e55f69c133a946
SHA1: 953dc98e489b5ac3fe5060da384fbe959f6b4d68
CRC32: 9a97ae34
44762 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --