Nonterraqueous (ZX Spectrum)
Traducción al Español v1.0 (28/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Nonterraqueous.tzx
MD5: 6f8c9496036a727df096279dca82b44a
SHA1: 8f4133be950be122ff9c2f6c9f9bdddd3262c29f
CRC32: 7948353f
48523 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --