Zythum (ZX Spectrum)
Traducción al Español v1.0 (04/05/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zythum.tzx
MD5: 0b0857eec7b8091bee2ed7e9aaf2dd7a
SHA1: 5e1118f3cd940c4a77b970baa34cb6690cd891b4
CRC32: 53238629
43912 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --