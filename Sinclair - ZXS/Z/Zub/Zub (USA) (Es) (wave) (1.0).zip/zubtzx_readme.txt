Zub (ZX Spectrum)
Traducción al Español v1.0 (28/01/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zub.tzx
MD5: b75e626c9f26068303d9e6717e925e16
SHA1: 514264fe8248fe43b49a5906b72b0f0afa000b61
CRC32: 3fd114b9
62098 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --