The Evil Dead (ZX Spectrum)
Traducción al Español v1.0 (30/01/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
The Evil Dead.tzx
MD5: 494bec6f485897d5f7b891d370edfbe3
SHA1: d4c40902651fd5ecb7c295b7dea6a3e4fb55bcbe
CRC32: ec205502
35319 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --