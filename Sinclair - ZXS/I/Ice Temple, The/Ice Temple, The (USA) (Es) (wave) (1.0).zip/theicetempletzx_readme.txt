The Ice Temple (ZX Spectrum)
Traducción al Español v1.0 (20/04/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
The Ice Temple.tzx
MD5: b9ab49c2b7dff336d27bbeed4ad3e247
SHA1: 7aeb7087ea83f380c375b5a3a733303c4af35b51
CRC32: 1ae69740
49575 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --