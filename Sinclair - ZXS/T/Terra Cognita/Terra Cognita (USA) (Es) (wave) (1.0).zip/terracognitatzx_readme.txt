Terra Cognita (ZX Spectrum)
Traducción al Español v1.0 (01/04/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Terra Cognita (1986)(Codemasters).tzx
MD5: b714b3ea5602b32504bff725b218243d
SHA1: 0005e78a06cd1b73fc307884e8fb731f5bb8db00
CRC32: 827df902
39122 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --