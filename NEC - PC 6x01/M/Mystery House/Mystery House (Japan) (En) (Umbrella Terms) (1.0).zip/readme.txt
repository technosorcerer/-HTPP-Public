----------------------------
--      Mystery House     --
--    Complete English    --
--       Translation      --
----------------------------

Mystery House {m2p2}.cas
SHA-1: BAAB3298CAFC9D751CC52E60F0923C96CCC86FDE
SHA-256: 55AA7E2F836D6F87E04C260CDB688CAC50CEA9613883BB43DBAADB22EC3CC7E4
MD-5: 716D36987C163DB606E72855167F6247

Apply patch with DeltaPatcher.

NOTE: All text should be translated, but if you find
anything untranslated, contact @UmbrellaTerms on Twitter.

Historical Context:
Micro Cabin's Mystery House is the first Japanese
graphic adventure game. The original MZ-80 version
was developed by Tsukasa Moritani and published by
Micro Cabin on June 1982. This PC-6001 version was
released sometime in 1983, with porting work done
by N Minami at Arrow Soft. 
(Note: The Arrow Soft/N Minami fact came from reading
the game's data and could not be found anywhere else
in-game or online.)

To load game:
Mode 2, 2 Pages
cload
run

Controls:
Commands are separated by verbs and nouns.
When the game asks you "Action?", you type in the verb
then press enter. Then the game will ask you "What?",
where you will type in the noun and press enter.
EX:
Action? open
What? door

Directions are controlled by the cursor/arrow keys.

To see the screen graphic again, press space.

Typing in help will give you some possible verbs and
nouns.