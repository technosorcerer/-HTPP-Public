----------------------------
--          Magic         --
--    Complete English    --
--       Translation      --
----------------------------

Magic {m1p2}.p6
SHA-1: 083F01ABBA7F5A0EE230B0284A484333ED26B985
SHA-256: 7E9A22D9BBC704D4CBA4BA514F9F2FF278970700CBD6C8C08AB5B59E08756A37
MD-5: 5747BF118A6B7E3BFBB3CB1320E48177

Apply with DeltaPatcher

To run, choose mode 1, then 2 pages.
Type in these commands:
cload
run

Historical Context:
Released sometime in 1983 in an issue of POPCOM magazine.
Developed by Afoxai.

Game Description:
A flashier version of tic-tac-toe. Cast 9 magic spells
to defeat your foe. There is a tic-tac-toe board the
player can't see until the game is over. Each spell
corresponds to a place on the board, but that place
changes each turn, so the same spell could potentially
fill multiple spaces. You can play 1 or 2 player. Names
can only be up to 3 letters.