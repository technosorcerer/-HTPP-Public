Use Deltapatcher to apply the patch.

(Translated from manual on internet archive. Source: https://ia800204.us.archive.org/zipview.php?zip=/20/items/Neo_Kobe_NEC_PC-6001_2016-02-25/Neo%20Kobe%20-%20NEC%20PC-6001%20(2016-02-25).zip)

This is the manual for the Adventure game �Earthbound� from XTAL SOFT. Enjoy.


				EARTHBOUND
One morning you wake up with no knowledge of who you are or what you were doing 
up to this point. The only memory that remains is of someone named Lady June. 
Having left the town of COMUSCHAIR where you woke up, and relying on information 
from strangers, you finally reach the entrance to the town of La Tale. 
It seems that there is a woman with mysterious power called June that lives here. 
In any case, all you can do now is search the town for a clue as to Lady June�s 
whereabouts.

	How to Load the Game
+------------------------+
�PC Model   � Instructions�
+-------+----------------�
�PC-6001mk-II  �SELECT BASIC MODE: Pick Option 2�
�       �How Many Pages? Enter 2 �
�       �Load the program with the command CLOAD �
�       �RUN               �
+-------+----------------�
�PC-6001(32KB) �How Many Pages? Enter 2 �
�       �Load game with CLOAD then enter RUN �
+-------+----------------�
�FM-7     �RUN "CAS0:"           �
+------------------------+

	How to Play
You will begin the game at the entrance to La Tale. When entering a movement command, 
you will move through the village. At each point in town you will always face 
a certain direction. So you can�t look left or right on a road, in a house, 
etc. Don�t worry though, as facing forward means you will always
be making progress in the game.

	Explanation of Command Inputs
Basically, you enter two words in a verb + noun (object) format as one command input. 
There are exceptions where you can enter a single word for a command input. When it is 
a two word input, remember to put a space between them. When you move, you type in all 
"GO" + objects, but one caveat is necessary here. For movement, 
you type in �GO� + Direction, but be careful.

�GO FORWARD� will move you to the next spot you see until you can�t anymore. For example, 
if you enter "GO FORWARD" when you see a house just ahead of you, you will arrive in 
front of the house and you will not be able to go past it. Therefore, 
in such a case, enter "GO THROUGH" at the point where you can see the house just ahead. 
This way you will move past that house and proceed to the next point.

Commands that can be input with only one word are "OUT", "TALK" and "GO" "DOWN". 
When you search for something, the screen may change depending on the situation, 
and the part you searched may be displayed. In that case, use "OUT" to return to 
the original screen. That is, "OUT" is a command to exit from the SEARCH state. 
(Excluding PC-6001 & mk II)

"TALK" is, of course, a command to talk to characters in this game. 
In this game, when you meet someone, please talk to them first. 
If you don�t do that, they won�t like you. When you enter the "TALK" command, 
you will see "Whom do you talk with?", so please enter the name of the person 
you�re referring to. There are so many hard to please people in this game, 
so if you call them by the wrong name, you will not be able to talk to them, 
so be careful.


Command Table
 Enter all commands in capital letters.
.Movement
GO FORWARD to move forward    TURN RIGHT to turn right
GO BACK    to go back      TURN LEFT  to turn left
GO THROUGH to go past a house      UP or U     to go up
GO OUT     to leave a house   DOWN or D    to go down
.Verbs
CROSS to cross               GET    to take an object
GIVE  to give an item              HIT    to hit
LIGHT to start a fire            LOOK   to look
MOVE  to move an object            OPEN   to open
PUT   to put an object            SEARCH to search
TAKE  To ride boat              TALK      to talk
OUT   (From SEARCH state) exit
USE   to use an object
.Nouns
AXE            BOAT    
BOOK           CABINET 
CANDLE              CAT     
CLOTHES             CRYSTAL 
DOOR           GRAVE   
HOLE           KEY    
LOCKER               MONEY   
PICTURE            POUCH   
RING              RIVER   
ROAD           ROCK    
SHELF                      TREE   
WALL              WINDOW  



   Explanation of Display
.No! You cannot do it!
   This text appears when you enter an invalid command.
.OK! You got it!
   This text appears when you pick up an item.
  In addition to this, there are several displays asking for input, 
please enter according to the screen display at that time.

Place Names/Character Names
COMUSCHAIR - The name of the village where the protagonist began their journey.
OLDFUETH - A man who sells clothes.
REISCIA - A woman prophet.
CLOUDHANPH - The keeper of the river.
LADY JUNE - Someone the protagonist knows about but doesn�t know where they are.

Spells
The spell to use the crystal is  "TEALE FOUGH QUE LAH PASSE". 
There are also some spells in addition to this, so please find them in the game.

P . L . E . A . S . E
In adventure games, as is often said, the big mystery is what the game is all about.
The fun of the game comes from solving the mystery, so we can�t answer any inquiries 
or telephone calls about the game�s contents, such as how to solve puzzles or hints.
If you really want a hint, please contact us at Xtal Soft with a round-trip postcard.
