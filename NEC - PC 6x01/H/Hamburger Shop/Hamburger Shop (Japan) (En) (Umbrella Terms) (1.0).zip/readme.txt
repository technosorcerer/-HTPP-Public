----------------------------
--     Hamburger Shop     -- 
--    Complete English    --
--       Translation      --
----------------------------

Hamburger Shop {m1p2}.cas
SHA-1: 348DA165CF613BA60FD68958B5B5D7BE8B71095E
SHA-256: 72F39693BAE2DD80F5E7F489A53E84CFFF2C9C134A24ECFB2D1138EDF7FC1106
MD-5: AA956B41A9D5C88C1568BF795D61D1A5

Apply with DeltaPatcher.

NOTE: All text should be translated, but if you find
anything untranslated, contact @UmbrellaTerms on Twitter.

To run, choose mode 1, then 2 pages.
Type in these commands:
cload
run

Historical Context:
Released in Micom Basic Magazine's May 1983 issue.
Developed by Yoshikatsu Matsuki.

Translation of Mico Basic Magazine's section about the game:

Intro:
If you look over the recent games on computers,
you'll see lots of stuff like wars and science fiction,
things far away from reality. In this, the experience
of our daily lives is reflected in this fun game. In
it you'll work a part-time job at a hamburger shop.
Try to make enough money to buy a computer.

Description:
Place the ingredients just as the customer tells you.
The cheese, patty, vegetables, and ham are matched to the
arrow keys (right, up, left, down respectively). Last
is the bun which is the space key. There's also fun
music that plays.

Rules:
You will get complaints if you are too slow to respond or
get the order wrong. If you make 3 mistakes you will be
fired. As the game progresses, you will need to respond
faster and faster.
The bun is the harshest timing. Your wage is calculated
by the amount of ingredients you placed in a burger
and the speed with which you placed them. The higher the
speed, the higher the wage, but also the higher the
difficulty.

Advice:
For people that are too kind, decrease the value of SP
on line 170 in the code.

Ending:
There's a lot of colors and music, maybe too much,
but colors and music make things more exciting. The
Pineapple Soft name comes from my last name(Matsuki in
English is "PINE"). To end I want to give special thanks
to the president of Aikoh Denki (Aikoh Electric).

CHECKER FLAG:
	Dr.D: This game's pretty good. By going deep into
	      the lives of young people today, you get
	      a heartwarming feeling among all the
	      pettiness.
	Editor: What pettiness?
	Dr.D: Like the ending message, it's really
	      emblematic of how young people act today,
	      don't you think?
	Editor: I see this time you're pushing your theory 
		on modern civilization.

