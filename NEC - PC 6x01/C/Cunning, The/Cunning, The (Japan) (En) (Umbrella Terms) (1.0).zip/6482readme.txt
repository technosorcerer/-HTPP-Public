----------------------------
--      The Cunning       -- 
--     (or The Cheat)     --
--    Complete English    --
--       Translation      --
----------------------------

The Cunning {m1p2}.p6
SHA-1: FE133D3C95C2DB95A77628289D265BD08C05B267
SHA-256: F45D30F8B712C8E334863A5185B35C875268F3DBEA9CB358EBC03711146EC822
MD-5: 5BD4D94E8D7D6A2CD1DE985EB05A87D6

Apply with DeltaPatcher

To run, choose mode 1, then 2 pages.
Type in these commands:
cload
run

Released January 1983 in Mycom Basic Magazine.
Developed by Afoxai.

Game Description:
Play as 3 students trying to cheat at a test. Use the
arrow keys to have the respective student cheat
one number at a time. Avoid doing so when the teacher
is watching or get caught. Get caught 3 times and
that's game over. There's also a time limit to the test,
so have every student finish before test time's over.