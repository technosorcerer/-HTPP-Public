Apply the patch using Delta Patcher.
Apply it to the Christ .CAS file.

Sha-1: C3E11EC7EB4B89BA6783D4A60336BEF3489FCDC2
Sha-256: 1105AF9C291FDED9BEAC404CF516C93DE9C751E5B4C7637AA9ADE54AA89AA1A3
MD-5: 2F2EF2DB717AB623DF96A87543D16C11

Full translation into English. A decision was made
to keep the original English mispelling of Christ
as "Chrith", but it's supposed to be Christ. 
The spoken dialogue remains in Japanese, but 
the subtitles for it are translated.