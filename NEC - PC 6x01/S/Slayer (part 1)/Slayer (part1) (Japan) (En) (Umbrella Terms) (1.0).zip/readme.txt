----------------------------
--          Slayer        --
--    Complete English    --
--       Translation      --
----------------------------

Slayer (Part 1) {m1p2}.p6t
SHA-1: C61CE8E9DE6FB50952DB4FEDEF6531BC102B1D20
SHA-256: E152F67FE907CD4F1010844A6B60ED184F40B694F00CCC9183A9905806131724
MD-5: CB21911DF5C6F2F0B9703638462056CC

Slayer (Part 2) {m1p2}.p6t
SHA-1: 82F942AE24A63BAD6F12FAD4D19103A8E33F6FD9
SHA-256: 254AB477F76DF8472B5CBCACF62FC7D3F1748135E3E677236374C9DDE0D36919
MD-5: F2661B4845320A96474B73FAA5355C51

Apply each patch to the respective
.p6t file with DeltaPatcher.

NOTE: All text should be translated, but if you find
anything untranslated, contact @UmbrellaTerms on Twitter.

Developed by Shigeki Niino and published in
Micom Basic Magazine October 1986 Issue.

Basic Game Description:
A game where you search through a brick maze to
find a hidden treasure.

This game should work on PC-6001, PC-6001mk2, 
PC-6001mk2SR, PC-6601, and PC-6601SR.

To load the game:
Mode 1, 2 Pages.
Insert the Part 1 tape, enter cload.
After loading, insert Part 2 tape. Enter run.
The intro will play. Wait for it to load and show “Ok”.
Press enter. It will say “Wait Again!!” Enter run.
The game will start.

Translation of Micom Basic Magazine where it talks about
the game:
Slayer

Story:
A brick labyrinth has opened up before you. Why have you
come here? You seek the treasure known as “The Slayer”,
hidden somewhere within. It is said that whoever obtains
the Slayer will achieve world-altering power. You may be
eager, but it is not so easily done. You will require
3 rings and courage to be able to obtain the Slayer.
What could the Slayer be? A sword, a shield…
A living creature?
You have no time to ponder such questions.
The one who will solve the mystery of the Slayer… is you!

How To Play:
You can move with the arrow keys. You cannot move through
brick walls. Going past the end of the screen will lead
you to the next screen. Your goal in each stage is to
find the ring and the exit. The exit is hidden among one
of the storehouses. To attack enemies you must move into
them. The screen flashes when you take damage, so if you
find the enemy too strong, it may be better to run away.
If your life meter reaches 0, that’s a game over.
And don’t worry, if the meters go out of the bounds of
the screen, they are still being properly counted!

Mystery:
Storehouses do not just contain the exit. You can’t
just start attacking enemies right away. The Slayer is
located on the 3rd stage. On the lower half of the screen
is where messages are displayed. Sometimes you may need
to push Space to advance a message. Pay attention to the
messages.

End:
Create maps, take notes about what you find,
and don’t be greedy.
