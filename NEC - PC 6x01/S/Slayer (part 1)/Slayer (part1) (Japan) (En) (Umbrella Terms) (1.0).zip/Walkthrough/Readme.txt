These are maps I made when testing the translation,
they are incomplete, but you can finish
the game using these. These are what each color means:

Orange: Starting Point
Red: Dead End
Light Green: Storage House
Purple: Ring
Light Yellow: Exit
Blue: Water (If you find a switch in a storehouse,
             that will create a bridge here)
Darker Green: If you pass this point, you will be stuck
              in a trap
