----------------------------
--   3D Golf Simulation   -- 
--      Super Version     --
--    Complete English    --
--       Translation      --
----------------------------

3D Golf Simulation Super Version {m5p3}.cas
SHA-1: 2B58D5405A96FDD393E42CAD288601F4B3495007
SHA-256: 9BAA74F814020597FE29ADFA69968C4707DC7DDC1B096D6D760DA0275DA7437F
MD-5: 21BBF80B96064BF1C35D8EEE89F7B076

Apply with DeltaPatcher

To run, choose mode 5, then 3 pages.
Type in these commands:
cload
run

Historical Context:
Before T&E Soft were known for the games they are known for
today like the Hydlide series, or even before games like
the Star Arthur series, they were known for Golf games.
Their earliest released game was Real Golf Game on
April 1982. They would follow this up with 3D Golf
Simulation on February 1983. There was a sequel with
3D Golf Simulation Part 2 on July 1984. Then there was
3D Golf Simulation Super Version on November 1984.
This specific version for PC-6601 apparently was released
sometime in 1985 though. It is an upgraded version of the
original 3D Golf Simulation game. It was written in
machine code for high performance, allowed for up to
4 players, had 18 holes, and had impressive graphics for
the time.

Game Instructions (Not official, just from playing):
Choose which hole to start from 1-18.
Choose how many players from 1-4.
Name each player (up to 6 letters).

Use arrow keys to select club then press return.
Use arrow keys to select direction you will swing
then press return.
Press space to swing, the red meter guaging power.