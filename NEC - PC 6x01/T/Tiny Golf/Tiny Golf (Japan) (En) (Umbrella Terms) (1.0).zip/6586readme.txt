----------------------------
--        Tiny Golf       -- 
--    Complete English    --
--       Translation      --
----------------------------

Tiny Golf {m1p2}.cas
SHA-1: 52090848C51C19FABB5F64C3D83DF0319B61DCFA
SHA-256: FE8F3944588E7CA460EEFF24893E0E9A07AEDB8CD68E1D050358B5429AB7AC5D
MD-5: 54A363F4CECAC28CA9A2460F32BC5C57

Apply with DeltaPatcher.

NOTE: All text should be translated, but if you find
anything untranslated, contact @UmbrellaTerms on Twitter.

To run, choose mode 1, then 2 pages.
Type in these commands:
cload
run

Release Date: January 10, 1987 
Program Pochette No.12
Creator: Roadist Sakai
[Note: “Roadist” is a term to denote fans of the magazine Fanroad.
 Fun fact: This game was written in only 10 lines of BASIC!]

Instructions
This is a fun minigolf game that includes 9 holes (a half course). However, 
every hole takes place on one screen with a par of 4.
0-9 keys determine how hard you hit the ball, with 9 being the strongest. 
Try to hit the ball into the red hole on the right side of the screen.
If the ball goes outside of the screen, it will be OUT OF BOUNDS. 
This does not cause a penalty, the ball will be placed back to where it was on screen. Even so, getting under par will be unlikely if you get out of bounds.
Trees are the ball’s only obstacle. The further in the game you go the more trees 
there will be. Use your intuition to choose the right strength to hit the ball 
at and avoid trees. When under the tree, low power shots to get out are best. 
If you get under par, it’s okay to gloat. It’s pretty difficult.
Also, there is no replay function.

Game Code Variable List
X,Y - Ball Position
I - Number of Holes
J - Score
M - That hole’s number of hits

Explanation of Game Code
0-4 Initial configuration
5 Key input
6-9 Ball movement and position processing
10 The end of the game
