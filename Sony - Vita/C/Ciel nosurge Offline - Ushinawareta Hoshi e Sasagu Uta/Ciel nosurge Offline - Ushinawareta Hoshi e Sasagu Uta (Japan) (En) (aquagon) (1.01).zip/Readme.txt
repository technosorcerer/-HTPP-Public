**************************************************************
*** English translation of Ciel nosurge Offline on PS Vita ***
**************************************************************

The game has been translated to English by the Atelier Traduction team in collaboration with the A Reyvateil's Melody fan community:
A Reyvateil's Melody: https://www.tapatalk.com/groups/revatail_hymmne/ 
Atelier Traduction: http://ateliertraduction.forumactif.org

The patch works on PS Vita, PSTV and Vita3K.
If you have a hard time to follow the basic instructions, you can see the detailed ones on "Tutorial_patch_EN_Ciel_Nosurge.pdf" provided with the patcher.


*******************************************
*** Patch Installation for PS Vita/PSTV ***
*******************************************

Here's the basic instructions to install the English patch of the game on your PS Vita/PSTV:

You must get the HENkaku or H-Encore mod installed on your PS Vita/PSTV.
You also must install "nonpdrm" and "repatch" plugins.
For PSTV, an extra plugin must be installed: "DolcePolce".

You must install "Ciel Nosurge Offline" on your PS Vita/PSTV with its official patch 1.04. If you have the cartridge, it's compatible.
The three "Voice packs" DLC are highly recommended to get voiceovers during all the game.

You have two methods according to your setup:

- Follow the USB method if you have a PS Vita with the digital version of the game installed only. PSTV or cartridge can't be patched with this method.
- Follow the FTP method if you have a PSTV or if you use the game's cartridge. However, take into account that this method is slower than the USB, taking over 10 minutes
  to complete the patching process.

*************************************************************

A - USB:

1. Open VitaShell in your PS Vita, press Start to open the options, and put the Select mode function to USB. Close the options.
   Connect your PS Vita to your PC using a USB cable and press Select.

2. Run the provided patching program "Ciel_Nosurge_to_English.exe". Once finished, the game will be patched with the translation.

3. Restart your PS vita.

4. Enjoy!

*************************************************************

B - FTP:

1. Open VitaShell in your PS Vita/PSTV, press Start to open the options, and put the Select mode function to FTP. Close the options.
   Connect your PS Vita/PSTV to your network and press Select.
   Take note of the IP address shown there. 

2. Open the "ftp.txt" file included in the patching archive, and write into it the IP address and the port that you got from VitaShell in the first line (for example: 192.168.1.112 1337).
   Save the file and close it.

3. Run the patching program "Ciel_Nosurge_to_English.exe". Once finished, the game will be patched with the translation.

4. Restart your PS vita/PSTV.

5. Enjoy!


*******************************************
****** Patch Installation for Vita3K ******
*******************************************

Here's the basic instructions to install the English patch of the game on Vita3K on your PC:

You must install "Ciel Nosurge Offline" on Vita3K with its official patch 1.04.
The three "Voice packs" DLC are highly recommended to get voiceovers during all the game.

*************************************************************

1. Open your Vita3K game folder in your explorer. You can get there easily by running Vita3K, selecting "File" at the top left and "Open Pref Path".
   There, open "ux0/app/", you should have the "PCSG00454" folder.
   
2. Drag this folder with your mouse into the patching program "Ciel_Nosurge_to_English.exe". Once finished, the game will be patched with the translation.

3. It is highly recommended to check the "Tutorial_patch_EN_Ciel_Nosurge.pdf" file for configuring Vita3K for the game (section 1.3).

4. IMPORTANT: Some people reported many random crashes, it entirely depends on your PC hardware.
   The game may work with very few crashes or many ones due to the instability of the emulator.


********************************
***  Gender-Neutral Version  ***
********************************

The base version of the patch refers to the player as he/him, but if you wish to play the version of the game that changes the pronouns the characters use to refer
to the player in the Ion Communication sections that take place in Ion's room to a gender-neutral form, please follow these steps.

1. Open the "Extra" folder included with the patch.

2. Do one of the following depending on whether you are playing the game on a PlayStation Vita/PSTV, or on Vita3k:

  PlayStation Vita/PSTV:
   Just follow the standard PS Vita/PSTV procedure above, but instead of running "Ciel_Nosurge_to_English.exe", run "Extra\Ciel_Nosurge_to_English_alt.bat".
	
  Vita3k:
   Just follow the standard Vita3k procedure above, but instead of dragging the game folder into "Ciel_Nosurge_to_English.exe", drag it
   into "Extra\Ciel_Nosurge_to_English_alt.bat".
	

********************************
*** Changes Done to the Game ***
********************************

1. The script and images are fully translated into English. The only exceptions are the digital manual, trophies, some voiceovers that Ion says at random while idle,
and the LiveArea.

2. The Add HymP microtransaction system has been removed and replaced with a feature called the Offline Link, which allows players to register their birthday date and trigger all
Ar nosurge-related flags at once to access the World Link content in the game without needing to connect to the internet.

3. Several unique voiceovers that were removed from the game in the passage from Online to Offline have been restored, and they have been given translations via subtitles.

4. The Evangenomize costume and its corresponding Symphonic Roar accessory have been reimplemented into the game and given item images, descriptions, and a save file image.

5. The check for whether the game is connected to the internet for date checking and synchronization purposes when starting a new game has been removed.

6. The date system for the game has been overhauled to work similarly to the DX remaster of the game: instead of using a date unrelated to the one in the Settings
app, the game now takes its date information from the date in the Settings app.

7. The events for the Filament Star book have been reimplemented in the same way as in the DX remaster.

8. The Sharls Ratio and Myosotis, formerly exclusive to the Online and DX versions, have been added to the game.

9. All dialogues written in Emotional Song Pact now utilize the unique font that was created for the language.

10. Several dummied-out dialogues were added to the final episode seen in the game.

11. The track "White Cherry Blossom Park" now has proper unlock conditions: it unlocks upon starting Chapter 6 instead of during the Terminate Pack.

12. The swap between the post-memory scenes for Episodes 2 and 3 of Chapter 11 has been corrected.

13. The 7D Mailbox menu has been backported from the DX remasters, allowing for the perusing of the special wallpapers and voicemails within the game. This includes all
the audio and image files for the menu, as well as the implementation of the Voice Stop event command for it, and subtitles for the voicemails. Each voicemail unlock also
features a notification informing the player of it, with a few exceptions.

14. All videos have been subtitled.

15. The lyrics for the songs found in the Song Theater now provide the option to see them either in romaji or translated form.

16. The bug that made it impossible for the player to progress in the relationship with Ion if they finished the game as friends and restarted using the clear data
has been corrected.

17. The BGM "Dwelling of Dreams" has been changed to the one used originally in the Online version of the game.

18. The HymP x1.5 bonus that was originally reserved only to players that had Gust accounts synced to the game is now available to everyone.

19. Several event conditions have been changed to prevent players from finding themselves in a situation where some voicemail conversations can't be triggered
due to having a Romance Level higher than the one the stock game allowed for them.

20. The final World Link conversation with Nelico now requires having seen all other conversations and dates with her.

21. Added a glossary of terms that can be accessed through the following menus: 7-Dimensional Info -> GenomiLink Explanation -> World Link ->
Link Recommendations and Terms Glossary. This glossary will be updated with every Dream World chapter completed.

22. Fixed a bug that caused the visual status of the Quasar's Charge Info window to regress after dismissing a Sharl.

23. Fixed a bug that caused the Sharl equipment names to change incorrectly after performing a Class Change.

24. Fixed some event trigger issues caused by improper conditions or incorrect calls. 

25. Fixed a bug that caused the menu texts to become garbled if the menu was closed due to an event.

26. Changed the Sharl reset time to 04:00 AM at the player's local time instead of being fixed to 04:00 AM JST.

27. Added the possibility to input a barcode's number using a form instead of using the camera for creating Sharls. The camera is automatically disabled when not recognized by the hardware (PSTV, Vita3K).

28. Added the possibility to quickly tap the C button to keep it pressed by itself, allowing to use the mouse on Vita3K to tap on Ion instead.

29. Fixed all freeze/time/3D model bugs on Vita3K. The game is perfectly playable on it now.

30. Fixed the lag in staff rolls on Vita3K.


*****************
*** Changelog ***
*****************

v1.01:

- Corrected script bugs that caused the event for Chapter 08, Episode 07 to have its dialog broken and the game to get stuck after it ended.

- Several typos and grammar issues fixed.

- The fake DLC files have been removed, as the proper DLC files for them are now available on pkgj.


v1.0:

- Many translation corrections and improvements.

- Fixed some minor bugs

- Fixed all major bugs on Vita3K and added features to make it playable on it.


Beta 3:

- Several translation corrections and improvements.

- Added notifications for whenever a voicemail is unlocked.

- Fixed the menu text garbling glitch that happened to the menus in Ion's Room whenever the menu was closed without a closing animation.

- The Sharl reset flag time has been changed: instead of being at 04:00 JST, it will be at 04:00 as indicated by the console's local time.


Beta 2:

- Fixed a bug that made the Face Accessory items not work.

- Fixed a bug that erroneously caused events to trigger the character models' speaking animations when they shouldn't.

- Fixed several typos, linebreaks, grammar issues, and swapped dialog options.

- Fixed a softlock in the World Link dream sequences.

- Corrected an event ending that was broken in all the stock versions of the game.

- Added the Glossary.


Beta 1:

Initial release.


***********************
*** Troubleshooting ***
***********************

If you have issues running the patcher, please try the following:

- Make sure your Vita/PSTV has Unsafe Homebrew enabled under Settings -> HENkaku Settings.

- Place the patcher in a directory that isn't Read-Only or protected by the OS.

- Check that your Vita/PSTV and PC are connected to the same network.

- Check that the storage unit where you are running the patcher has enough free space.

- Make sure your antivirus is disabled before running the patcher.

If none of the above work, please reach out to us in the A Reyvateil's Melody Discord server and we will do our best to help you.

Additionally, please take into account that the patcher is known to not work in virtual Windows environments.


***************
*** Credits ***
***************

Hacking: RyleFury
Reverse Engineering: RyleFury
Graphics Editing: RyleFury
Original Translator: blackraen (main story, a few side-events)
Translators: aquagon, Infel
Editors: Replicant, Tizona, Presea, Kat, aquagon
Translation Check: exfictz, aquagon
Voicemail Translations: Infel, Blara, aquagon
Voicemail Japanese Audio Transcription Review and Correction: ell
DX Voicemail Audio Extraction: Gamma
Testing: aquagon, RyleFury, Kamië, Thia.kkll.Preciel, Dooroflight, StarSketch, ReimuHakurei, Members of the A Reyvateil's Melody Discord Server
Special Thanks: blackraen, Renshin23
