#!/bin/sh
cd "$(cd "$(dirname "$0")" && pwd)"
chmod +x ./diff/xdelta3_x64_linux
echo Ensure these files are inside the !!input directory:
echo --------------------
echo AMAGAMI.IMG
echo graph/GRAPH.CPK
echo SCENARIO.CPK
echo --------------------
echo After you see \"Complete.\", you can drag the rePatch folder to ux0 on your PS Vita.
./bin/xdelta3_x64_linux -v -d -s "!!input/AMAGAMI.IMG" "bin/AMAGAMI.IMG.diff" "repatch/PCSG00291/AMAGAMI.IMG"
./bin/xdelta3_x64_linux -v -d -s "!!input/graph/GRAPH.CPK" "bin/GRAPH.CPK.diff" "repatch/PCSG00291/graph/GRAPH.CPK"
./bin/xdelta3_x64_linux -v -d -s "!!input/SCENARIO.CPK" "bin/SCENARIO.CPK.diff" "repatch/PCSG00291/SCENARIO.CPK"
echo Complete.