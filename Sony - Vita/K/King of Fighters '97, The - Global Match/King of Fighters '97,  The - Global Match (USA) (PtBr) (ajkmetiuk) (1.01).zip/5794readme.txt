Tradu��o de The King of Fighters 97 Global Match (PSVita/PC/PS4)

Sobre a tradu��o:
Feito em cima da "tradu��o" oficial, s� dei uma arrumada nela, corrigido os imensos bugs e praticamente quase todos acentos
errados e palavras n�o acentuadas. (Foi usado como base a vers�o do PSVita com o patch 1.02, mas testado no PC tb e � totalmente compat�vel.)

Progresso: 100%
V1.0 = Lan�amento inicial (14/07/19)
V1.01 = Corrigido mais algumas coisas que faltaram e tamb�m arrumado o "Como jogar" que tinha passado batido.

Tradu��o de alguns textos ingl�s, corre��o e acentua��o: ajkmetiuk


Cr�ditos: Todos os cr�ditos da tradu��o oficial ficam pela SNK.


Agradecimento especial ao Mr.Fox que me indicou uma tool do f�rum para conseguir driblar um probleminha com os textos. Sem isso nem
teria iniciado e por todos que reportaram os erros. Meu muito obrigado!


Como utilizar:

- Copie a pasta Data e substitua todos arquivos. Testado somente no PC/PS4 e PSVita.


*Esta tradu��o � disponibilizada gratuitamente, sem fins lucrativos, se voc� comprou ela, voc� foi enganado!