Secret of Mana PS Vita

Patch ini telah diterjemahkan ke dalam bahasa Indonesia oleh Ronald Dlanor.
30-07-2023

Cara mengaplikasikannya cukup mudah. 
Kamu hanya perlu masuk ke folder Media lalu script_resource, dan kemudian
replace atau timpa 2 file scrtxt_en-Vita103 dan systxt_en-Vita103 
yang sudah aku terjemahakan ini dengan file aslinya.

Versi yang digunakan untuk terjemahan ini adalah versi Update 3 untuk file gamenya.

Proses terjemahan: 100%
Seluruh teks percakapan dan menu-menunya sudah berhasil aku terjemahkan semua.
Kecuali kalimat-kalimat di bagian teks video awal gim dan teks grafis tidak
diterjemahkan.

Ayo dukung saya agar semakin lebih bersemangat dalam menerjemahkan
game-game lainnya menjadi berbahasa Indonesia.

Donasi:
https://trakteer.id/round
https://saweria.co/round2

Kontak kami di FB:
https://www.facebook.com/New-Gamer-Adventures-100689069313828

Kunjungi juga channel youtube aku namanya New Game Adventures.

Special Thanks:
- RAnonym (Packing, Tester & hal-hal yang berhubungan sama PS Vita lah intinya)