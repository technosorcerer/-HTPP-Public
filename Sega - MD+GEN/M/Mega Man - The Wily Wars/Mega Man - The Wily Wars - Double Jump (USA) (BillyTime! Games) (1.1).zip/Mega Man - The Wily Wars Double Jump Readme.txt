Mega Man - The Wily Wars Double Jump
Oct 31st, 2023
BillyTime! Games
--------------------
This is a simple patch that adds a double jump in Mega Man - The Wily Wars  on Sega Genesis.

How it works:
--------------------
Mega Man is allowed a second jump to traverse levels. Sliding in disabled while in midair.
Patch is available for all regions of the game.

How to Patch:
--------------------
1.Grab a copy of Mega Man - The Wily Wars (USA)
or
Mega Man - The Wily Wars (Europe)
or 
Rockman - Mega World (Japan)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

