
  Megaman the Wily Wars Redux/Definitive Version by darthvaderx:

 This hack is based on the modifications made by Retro-bit in the Genesis Mini version to reduce slowdowns as much as possible (they still exist, but only in extreme cases of many elements on the screen) with the addition of the following hacks:

- World Fixer Upper ver.1.0.5 by Josephine Lithius:

  https://www.romhacking.net/hacks/7257/

 Rockman Mega World (aka Mega Man: The Wily Wars) is a splendid compilation of the first three games in the series, redone with 16-bit graphics and sound for the Sega 16-bit consoles.  It’s a very faithful recreation in a lot of ways, too.  However, there are some inconsistencies between the original games and the Sega remakes that lead to a less-than-ideal gameplay experience.  This ROM hack is here to fix some of the lesser flaws that add up.

    -Enemy invulnerability time has been all but eliminated.  This means that enemies can take damage more frequently and reliably.  No more “missed” shots!
    -The default weapon (the Buster) has been sped up to match its 8-bit counterpart.  Watch those lemons fly!
    -The default weapon and some boss weapons can be fired more rapidly!  Hammer that “fire” button and launch waves of projectiles!
    -Rockman pulls his Buster back a little sooner after firing!  This… only affects a handful of weapons and the change isn’t that big, but hey!  It might help!
    -The SRAM patches by an unknown author (J), MottZilla (E), and Plombo (U) have been added to the base hack. This makes the saves more compatible across the board and helps the game run on more emulators / hardware.

--------------------------------------------------------------------------

- Proto Man Size Fix ver.1.1 by Stifu:

  https://www.romhacking.net/hacks/8444/

 In the original game, Proto Man is smaller than he should be. This patch replaces Proto Man’s sprite with a bigger one drawn by JackelZXA. 

--------------------------------------------------------------------------

- Double Jump ver.1.1 by ver.1.1 by BillyTime! Games:

  https://www.romhacking.net/hacks/8184/

 This is a simple patch that adds a double jump, Mega Man is allowed a second jump to traverse levels. Sliding in disabled while in midair.(A big thank you to BillyTime! for providing a fix to make this hack work.)

--------------------------------------------------------------------------

- Weapon Restock ver1.1 by BillyTime! Games:

  https://www.romhacking.net/hacks/8500/

 This is a simple patch for Mega Man - The Wily Wars on Sega Genesis that refills your weapons after death.(A big thank you again to BillyTime! for providing a solution to make this hack work.)
--------------------------------------------------------------------------

 There are patches for European (EUR to USA conversion) and Genesis Mini (USA).

--------------------------------------------------------------------------

 Bonus: Game Genie codes that work in this version:

  REBT-A6XL Enabler Code (Must Be On)

  AJBT-AA5J Master Code (Must Be On)

  J4CT-AA3E Invincible Against Enemies

  ADJT-FA9C Infinite Weapons Energy

  R11T-E6YY Invincible Against Spikes

  RHTA-E61G Jump in Midair Infinitely 

----------------------------------------------------------------------------

ROM / ISO Information:

    Database match: Mega Man - The Wily Wars (Europe)
    Database: No-Intro: Genesis (v. 20240212-043616)
    File/ROM SHA-1: EA9AE2043C97DB716A8D31EE90E581C3D75F4E3E
    File/ROM CRC32: DCF6E8B2
    –
    Database match: Mega Man - The Wily Wars (USA) (Genesis Mini)
    Database: No-Intro: Genesis (v. 20240212-043616)
    File/ROM SHA-1: 26AD72719991E94DBE477C78E65D68F4A4FE51E6
    File/ROM CRC32: CD405DB
 