Patch by Stifu
New Proto Man sprite by JackelZXA

Change log:
- 1.1 (2024-07-17): Replace Break Man's sprite (thanks to Brunoxsa)
- 1.0 (2024-02-13): Replace Proto Man's sprite

In the original game, Proto Man is smaller than he should be.
This patch replaces Proto Man's sprite with a bigger one drawn by JackelZXA.
Unlike the "SRAM+ Proto Man Size Fix" hack, which includes various changes,
this patch only changes Proto Man's sprite.

This patch is compatible with all other versions of the game, including the
Retro-Bit re-release, aka "Mega Man - The Wily Wars (USA) (Aftermarket) (Unl)",
which features reduced slowdowns.

This patch should be compatible with most other patches.

This patch is compatible with all of these ROM variants:

Mega Man - The Wily Wars (Europe)
	SHA-1: EA9AE2043C97DB716A8D31EE90E581C3D75F4E3E
	CRC32: DCF6E8B2

The Wily Wars (USA) (Aftermarket) (Unl)
	SHA-1: 617BC1EE5F31F4215CF47C5337FA7CA0BCEB6A45
	CRC32: 831020B

Mega Man - The Wily Wars (USA) (Genesis Mini)
	SHA-1: 26AD72719991E94DBE477C78E65D68F4A4FE51E6
	CRC32: CD405DB

Database match: Rockman - Mega World (Japan)
	SHA-1: A435AC53589A29DBB655662C942DAAB425D3F6BD
	CRC32: 85C956EF

Database match: Rockman - Mega World (Japan) (Mega Drive Mini)
	SHA-1: 77DE1A2BDC359044E8AEC5A3BCD6A5D878D23837
	CRC32: E8F5668E