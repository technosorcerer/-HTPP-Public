 _______________________________________
/					\
|        Wily Tower retranslation	|
|	   by CoolCatBomberMan		|
\_______________________________________/
Mega Man: The Wily Wars is not a text-heavy game. That being said, the dialogue present in the Wily Tower segment (namely, Dr. Wily's speech) simply isn't up to modern localization standards. Dr. Wily is so caught up in '90s-era attitude that his speech doesn't flow naturally. This patch resolves this by rewriting his dialogue, using hondoori's translation of the JP script as reference. Also, Dr. Light's dialogue in the weapon/item selection menu is given a minor touch-up, to better convey that the player needs to equip at least one item.

This patch was made exclusively for the Genesis Mini version. Compatibility with other hacks is untested, but conflicts are unlikely. 


--Instructions--
Simply use Floating IPS to apply the patch to your ROM.


--Credits--
CoolCatBomberMan: Hacking