Mega Man - The Wily Wars Weapon Restock
Mar 6, 2024
BillyTime! Games
--------------------
This is a simple patch for Mega Man - The Wily Wars on Sega Genesis that refills your weapons after death. This particular patch targets the US revisions from Retro-Bit and The Genesis Mini.

How to Patch:
--------------------
1.Grab a copy of Mega Man - The Wily Wars (USA)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

