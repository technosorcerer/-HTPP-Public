Mighty Morphin Power Rangers - The Movie (Mega Drive)
Traducci�n al Espa�ol v1.0 (03/08/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Mighty Morphin Power Rangers - The Movie (U) [!].bin
2.097.152 bytes
MD5: bbf3c7bfad1e2110da1469c711949709
SHA1: 866d7ccc204e45d188594dde99c2ea836912a136
CRC32: aa941cbc

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --