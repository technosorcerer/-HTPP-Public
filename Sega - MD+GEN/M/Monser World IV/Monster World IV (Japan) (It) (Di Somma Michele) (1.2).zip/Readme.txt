Questa patch traduce in italiano il gioco identificato dal No-Intro come: 
Monster World IV (Japan)

Dopo la mia prima traduzione di Wonderboy in Monster World ecco a voi Monster World IV in italiano. All'inizio ho dato solo un'occhiata alla rom, poi mi sono accorto che la parte grafica aveva molto in comune con il precedente episodio e cos� ho deciso di tradurre anche questa. Mi sono basato molto sulla traduzione inglese dei DEJAP per� devo dire che � una traduzione molto superficiale, con tanti errori, e parti tagliate. Comunque, nel possibile ho cercato di ripristinare alcune cose con l'aiuto del forum di Romhacking.net in quanto io non so nulla di giapponese. 
Un'ultima nota su questo gioco. Molto bello graficamente e come gameplay. Sicuramente inferiore al precedente per quanto riguarda la mancanza di libert� di ritornare nelle varie zone. 

Comunque ecco le caratteristiche:

Ver. 1.0

* Fixato il controllo regionale per farlo partire su qualsiasi console sia europea che giapponese o americana.
* Tradotti tutti testi , anche quelli del men� segreto del suono.
* Tradotta la schermata iniziale a la STAR WARS e un'altra durante il gioco lasciata in sospeso dai DEJAP. La schermata a la STAR WARS � visibile solo con gli emulatori Regen, Mess, oltre che su un vero Megadrive penso.
* Aggiunte le lettere accentate e i simboli speciali per l'indovinello nella piramide ghiacciata.
* Decompressa e modificata grafica varia(titolo,game over,finale,soldi,menu di pausa,slot machine,schermata di salvataggio,schermata del venditore,ecc.)
* Ripristinato l'enigma dei segni nella prima piramide.
* Corrette molte frasi e puntatori buggate dai DEJAP.
* Ripristinato il menu per l'armatura debug(era stato tagliato anche dalla versione originale jap).
* Corretti vari bug dei DEJAP come quello all'inizio in cui se tu parli sempre con la madre di Asha ottieni sempre elisir.
* Altri fix vari che adesso non ricordo.

Ver. 1.1

* Fix vari

Ver. 1.2

* Fixato il dialogo con il mercante segreto. 
* Modificata grafica del men� pausa con piccola modifica ai puntatori. Sostituito Equipaggio (sarebbe equipaggiamento ma � troppo lungo e non ci entra) con un pi� elegante Dotazione. Sostituito Ogg. con Oggetti
* Tradotto anche il Super debug men�

(C) 2024 Di Somma Michele
mike.1983@libero.it