Mighty Morphin Power Rangers - The Movie (2x Damage)
Oct. 7th 2025
BillyTime! Games, Pyron
--------------------
This is a simple patch for Mighty Morphin Power Rangers - The Movie on Sega Genesis that increases damage dealt with each hit. Comes in two flavors.

2x Damage - Hits only deal 2x damage on enemies
Players Too - Hits deal 2x damage to enemies and players.

1.2 Update
--------------------
Special thanks to Pyron for contributing his Enhanced Colors patch which makes the visuals much more clear, vibrant and appealing!

How to Patch:
--------------------
1.Grab a copy of Mighty Morphin Power Rangers - The Movie (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file