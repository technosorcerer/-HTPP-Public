Mighty Morphin Power Rangers (2x Damage)
Sep. 15th 2025
BillyTime! Games
--------------------
This is a simple patch for Mighty Morphin Power Rangers on Sega Genesis that increases damage dealt with each hit. Comes in two flavors, 2x Damage and 3x Damage.

NOTE:
Compatible with VS Hack:
https://romhackplaza.org/romhacks/mighty-morphin-power-rangers-vs-hack-genesis/

How to Patch:
--------------------
1.Grab a copy of Mighty Morphin Power Rangers (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file