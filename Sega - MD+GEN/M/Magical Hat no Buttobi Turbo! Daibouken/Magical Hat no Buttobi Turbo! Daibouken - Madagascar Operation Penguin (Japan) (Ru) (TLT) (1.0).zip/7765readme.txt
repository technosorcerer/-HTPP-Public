Unchanged ROM file:
Magical Hat no Buttobi Turbo! Daibouken (J) [!]

Changed ROM file:
Madagascar Operation Penguin

Russian Language

2016, (c) TOF