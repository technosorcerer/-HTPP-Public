Monopoly (Mega Drive)
Traducción al Español v1.0 (03/04/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Monopoly (USA).md
MD5: 40794bbfc3f9a73df5255fe6d10b5107
SHA1: 8ff34d2557270f91e2032cba100cd65eb51129ca
CRC32: c10268da
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --