This patch fixes the DEJAP english translation of the game indentified by GoodGen v.3.00 as: 
Monster World IV (J) [!]

After my italian translation of this game I release also a bugfix of the english translation of DEJAP. I've fixed many errors of grammar, pointers, and text not translated from Jap thanks to forum of Romhacking.net.

However here's the features:
* Fixed the regional check to allow the use on every console.
* Fixed the secret menu of sound.
* Translated the scrool text as STAR WARS and another through the game left pendig from DEJAP. The STAR WARS screen can be seen only with the emulators Regen, Mess, beside a real Genesis though.
* Added the special simbols for the Ice Pyramid I quest.
* Decompress and modified graphics of main screen and Game Over.
* Restored the Ice Pyramid I quest.
* Corrected many text and pointers bugged.
* Restored the Armor Debug menu (it was cutted also from the original Jap version).
* Corrected many bugs as at begin where if you talk always with your mother, you receive always elixirs.
* Other fixes that I don't remember.


A last note on this game. It's name is "Monster World IV" and not as wrongly it called "Wonderboy 6". 


(C) 2008 Di Somma Michele
mike.1983@libero.it