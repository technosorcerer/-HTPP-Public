Mortal Kombat - Controller Fix
Oct. 8th 2024
BillyTime! Games
--------------------
This patch is designed to improve compatibility with third party six button controllers for Mortal Kombat.

Note: Tested with 8bitdo wireless genesis pad and Hyperkin 6 button pad.

Special thanks to IEqualShane for his help!

How to Patch:
--------------------
1.Grab a copy of Mortal Kombat (World) (v1.1).md 
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file