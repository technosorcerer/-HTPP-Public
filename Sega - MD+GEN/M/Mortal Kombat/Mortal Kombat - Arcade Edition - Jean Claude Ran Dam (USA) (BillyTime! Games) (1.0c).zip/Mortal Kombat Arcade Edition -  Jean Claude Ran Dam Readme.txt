Mortal Kombat Arcade Edition -  Jean Claude Ran Dam
April. 1st 2025
GoofyTime! Games
--------------------
This fun patch is designed to randomize all damage from all attacks in Mortal Kombat - Arcade Edition. This in turn leads to very quick matches and playthroughs. 

Bugs:
--------------------
*Pit Fatal no longer works
*Scorpion's Spear no longer stuns
*Sub-Zero's ice no longer freezes

Based on v1.0c of Mortal Kombat - Arcade Edition
Original Credits:
--------------------
Master Linkuei - Hacking, New Sounds, New Graphics & Testing
Chev Chelios - GFX adaptations, Pixel art & Testing.
Danilo Dais - Pixel art & Testing.
TiagoSC - Custom Tilemap Tool
Billytime! Games - SRAM save feature and help with the code

*V.1-0c adds compatibility for third party six button controllers. Tested with Hyperkin and 8BitDo controllers. Special Thanks to IEqualShane for his help!

How to Patch:
--------------------
1.Grab a copy of Mortal Kombat (USA, Europe) (Rev A) (Beta).md 
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file