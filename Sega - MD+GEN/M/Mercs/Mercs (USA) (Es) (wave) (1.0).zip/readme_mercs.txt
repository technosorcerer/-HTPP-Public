Mercs
Traducci�n al Espa�ol v1.0 (29/01/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Mercs
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Mercs
-----------------
Cl�sico de sega en versi�n domestica, que a pesar de no tener multijugador a�ade un modo original muy interesante.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.
Todo traducido excepto la barra de estado y el congratulations final del modo original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Mercs (W) [!].bin
1.048.576 bytes
CRC32: 16113a72
MD5: 4643f5da530463356ce56fae5c346ddc
SHA1: ab633913147325190ef13bd10f3ef5b06d3a9e28

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --