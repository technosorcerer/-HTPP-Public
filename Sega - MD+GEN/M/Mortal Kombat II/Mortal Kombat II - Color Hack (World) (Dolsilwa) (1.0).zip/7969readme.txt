Mortal Kombat 2 color hack

Mortal Kombat 2 for Genesis lacks a bit in visuals. This hack aims to make colors a bit more faithful to original, or just more interesting in some cases.

v. 1.0 changes:
* tweaked colors for most stages,
* tweaked colors for battle plan,
* minor changes in intro, characters screen, continue screen,


Credits: to Linkuei for inspirations 

Just apply .ips patch on original rom. 

Hope you'll like it.

Dol.