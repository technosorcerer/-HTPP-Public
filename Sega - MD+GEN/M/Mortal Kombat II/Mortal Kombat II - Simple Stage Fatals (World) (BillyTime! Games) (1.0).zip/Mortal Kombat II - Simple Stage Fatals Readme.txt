Mortal Kombat II - Simple Stage Fatals 
July 30th, 2024
BillyTime! Games
--------------------
This patch is designed to allow for Simpler Stage Fatalities in Mortal Kombat II for Sega Genesis

How it Works:
--------------------
At the end of a Match, players can simply uppercut an opponent in The Deadpool, Kombat Tomb or Pit II and perform a stage fatality. This operates similar to MK1's Pit mechanics.

Stage Fatality inputs are still accepted and work as intended.  


How to Patch:
--------------------
1.Grab a copy of Mortal Kombat II (World).md 
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file (Use only one patch.)