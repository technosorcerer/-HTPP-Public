Mortal Kombat Deux
July. 24th 2025
BillyTime! Games
--------------------
This is an overhaul patch for Mortal Kombat II which explores the idea of characters having additional gameplay quirks to them.

Character Perks:
--------------------
Liu Kang, Kung Lao and Mileena - XP System: (Human Players Only)
Players deal one extra point of damage every 2 wins. Level cap is at 14 wins.

Sub-Zero - Defense Buff:
Attacks against Sub-Zero are reduced in damage by two points.

Johnny Cage - Split Shot:
Johnny Cage's groin attack deals 50% damage.

Kitana - Deadly Fans
Kitana's fans deal much more damage.

Baraka - Deadly Blades
Baraka's blades deal much more damage.

Jax - Attack Buff:
Attacks performed by Jax deal an extra 3 points of damage.

Raiden - Faster Uppercuts: (Human Players Only)
No delay after uppercutting an opponent.

Shang Tsung - Life Steal
Shang Tsung regenerates a small amount health after a successful attack. 

Reptile - Regenerating Health
Every second, Reptile regenerates a small portion of health.

Scorpion - Attack Buff
Attacks performed by Scorpion deal an extra 2 points of damage.

AI Nerf:
--------------------
By selecting a difficulty setting in the options menu, 
the AI adjusts itself depending on which difficulty level was selected.

All difficulties are now heavily toned down compared to the retail release in terms of AI Difficulty
and will be less likely to read inputs and counter you.

Difficulty does not scale with this patch.

Simple Stage Fatals:
--------------------
At the end of a Match, players can simply uppercut an opponent in The Deadpool, Kombat Tomb or Pit II and perform a stage fatality. This operates similar to MK1's Pit mechanics.

Stage Fatality inputs are still accepted and work as intended.  

How to Patch:
--------------------
1.Grab a copy of Mortal Kombat II (World) (No-Intro).md

2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file