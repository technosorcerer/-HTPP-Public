Mortal Kombat II - XP System
Nov. 23rd 2024
BillyTime! Games
--------------------
This patch is designed to add a XP level system to Mortal Kombat II 
for the Sega Genesis. Comes in two flavors.

Normal:
Players deal one extra point of damage and earn one defense point every 2 wins. Level cap is at 14 wins.

Reverse:
CPU opponents become stronger in both damage and defense every 2 wins. Damage and defense points are variable dependant on level.

NOTE:
*Compatible with MKII - AI Nerf 
(https://romhackplaza.org/romhacks/mortal-kombat-ii-ai-nerf-genesis/)
*Patches Included for Mortal Kombat II Unlimited
*NOT Compatible with Simple Stage Fatals - Combination patch included.

Codes:
--------------------
Change Reverse to Normal XP
Raw: 30001A:B608
Game Genie: BAAD-BPJ4
Change Normal to Reverse XP
Raw: 30001A:B6F8
Game Genie: 9AAD-BPJ4

How to Patch:
--------------------
1.Grab a copy of Mortal Kombat II (World) (No-Intro).md

or

Mortal Kombat II Unlimited.md (CRC32:	A98D5306)
 
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file