Mega Bomberman SRAM
Feb. 22nd, 2021
BillyTime! Games
--------------------

This patch is designed to add a simple saving mechanism to the single player portion of Mega Bomberman.

How to use:
--------------------

Saving:
Game saves after a boss is defeated.

Loading:
Enter the Password screen and press start. 

NOTE:
Game will produce a crash if no prior save is detected.

How to Patch:
--------------------
1.Grab a copy of Mega Bomberman (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file