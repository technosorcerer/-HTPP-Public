PCE MEGA MULTI BOMBERMAN PATCH by insane/rabenauge

adapts original pce/amiga bomberman/dynablaster multiplayer gameplay

- starts directly into multi player mode
- removes all powerups apart from bombs + range
- 10 bombs, 8 fire-range powerups
- round time increased from 3 to 4 minutes
- hurry up and shrinking of play area removed

