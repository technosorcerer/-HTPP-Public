Mega Bomberman - Battle Randomizer
July 30th, 2024
BillyTime! Games
--------------------
This patch is designed to randomize stages and player loadouts in Mega Bomberman's Battle Mode

How it Works:
--------------------
When in Battle Mode, Select the Beach Stage. Once per game the stage is randomized and every match players start with randomized items. 


How to Patch:
--------------------
1.Grab a copy of Mega Bomberman (USA).md 
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file (Use only one patch.)