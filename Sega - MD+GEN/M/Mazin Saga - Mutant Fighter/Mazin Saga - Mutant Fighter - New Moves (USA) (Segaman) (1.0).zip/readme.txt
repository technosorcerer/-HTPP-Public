/************************************
 * Info:
 ***********************************/

Name: Mazin Saga - New Moves Hack by SEGAMAN & DOCM@N
Date: 19.05.2021
Version: 1.0
Original ROM: Mazin Saga (U) [!].bin
Code: Segaman, DOCM@N

/************************************
 * Features:
 ***********************************/
 
-Improved super attacks
-Added projectile attack on uppercut

/************************************
 * Notes:
 ***********************************/
 
Projectile attack was done by adding invisible copy
of player, locking his attack pose and replacing his
sprite with projectile graphics, which is now always
loaded into VRAM.
This added a new neat move into our hero's moveset
and also made enemy AI react to such attack.

/************************************
 * How to patch:
 ***********************************/
 
Patch (U) version of the game with provided ips-patch file

