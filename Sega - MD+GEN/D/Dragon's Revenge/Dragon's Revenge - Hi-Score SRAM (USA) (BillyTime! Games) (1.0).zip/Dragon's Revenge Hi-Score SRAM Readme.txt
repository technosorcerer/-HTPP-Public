Dragon's Revenge Hi-Score SRAM
June. 3rd 2024
BillyTime! Games
Spkleader
--------------------
This patch is designed to add a simple saving mechanism for High Scores in Dragon's Revenge.


How to use
--------------------
Saving:
Scores save after player returns to the Title screen.

Loading:
Scores load at the Tengen screen. If checksum fails or it is your first time booting, default scores are loaded.


How to Patch:
--------------------
1.Grab a copy of Dragon's Revenge (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file