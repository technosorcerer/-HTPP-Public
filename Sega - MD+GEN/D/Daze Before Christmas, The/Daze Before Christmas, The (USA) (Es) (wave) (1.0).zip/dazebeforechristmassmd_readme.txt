Daze Before Christmas
Traducci�n al Espa�ol v1.0 (29/03/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Daze Before Christmas
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Daze Before Christmas
-----------------
Plataformas sobre papa noel y las navidades.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
El texto del final del juego en realidad es una imagen, as� que no est� traducido.
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Daze Before Christmas, The (E) [!].bin
2.097.152 bytes
CRC32: b95e25c9
MD5: 334d109c48ed477ad00eaaf7e38c6813
SHA1: 240c0d9487d7659a4b2999e0394d552ab17bee8a

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n
juandex - Testing

-- END OF README --