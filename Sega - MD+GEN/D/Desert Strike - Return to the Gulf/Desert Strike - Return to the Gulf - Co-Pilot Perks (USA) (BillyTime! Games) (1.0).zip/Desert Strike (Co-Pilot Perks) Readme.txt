Desert Strike - Co-Pilot Perks
Aug. 29th, 2024
BillyTime! Games
--------------------
This patch is designed to add a simple perk mechanic to Desert Strike - Return to The Gulf.

How to use:
--------------------
Each Co-Pilot has a unique trait to assist you.

X-Man - Slower Fuel Consumption
Aussie - Extra Passenger Room
Jake (Needs to be Unlocked first) - 2x Damage
Mr. D - 2x Armor per life
Tracker - Start with 5 lives instead of 3


How to Patch:
--------------------
1.Grab a copy of Desert Strike - Return to the Gulf (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file