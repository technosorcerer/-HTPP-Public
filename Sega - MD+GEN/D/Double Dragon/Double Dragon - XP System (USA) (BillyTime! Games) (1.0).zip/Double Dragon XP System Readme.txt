Double Dragon - XP System
Dec. 3rd 2024
BillyTime! Games
--------------------
This patch is designed to add a XP level system to Double Dragon
for the Sega Genesis.

How it works:
--------------------
Players gain levels based on score. Players deal one extra point of damage. Level cap is at 90,000 points. (lvl.9)

XP GAINS:
Lvl 1.:Increased Damage (10,000 POINTS)
Lvl 2.:Increased Damage and Defense (20,000 POINTS)
Lvl 3.:Increased Damage (30,000 POINTS)
Lvl 4.:Increased Damage (40,000 POINTS)
Lvl 5.:Increased Damage (50,000 POINTS)
Lvl 6.:Increased Damage (60,000 POINTS)
Lvl 7.:Increased Damage and Defense (70,000 POINTS)
Lvl 8.:Increased Damage (80,000 POINTS)
Lvl 9.:Increased Damage (90,000 POINTS)


How to Patch:
--------------------
1.Grab a copy of Double Dragon (USA, Europe) (Unl).md 
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file