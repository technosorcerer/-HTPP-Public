/************************************
 * Info:
 ***********************************/

Name: Double Dragon Music & Sound Hack
Date: 17.08.2024
Version: 1.0
Original ROM: Double Dragon (U) [!].bin
Code: Segaman
Music & SFX: VLD

/************************************
 * Features:
 ***********************************/
 
-Replaced sound engine with GEMS
-Added all Music Tracks from the arcade
-Added all Sound Effects from the arcade
-Added some missing sounds
-Minor changes on main menu palette
-Changed soundtest

/************************************
 * Known issues:
 ***********************************/

-Not all Music Tracks are used, since not all content from the Arcade version is present in the Genesis port
-Game sometime will slowdown the music. That is happening, because old code is constantly stopping Z80 and I dont want to spend another 3 weeks on fixing it. Not a blocking bug, let it pass

/************************************
 * How to patch:
 ***********************************/
 
Patch (U) version of the game with provided ips-patch file

