Dick Tracy Arcade
Aug. 9th 2023
BillyTime! Games
--------------------
This patch is fast paced level randomizer for Dick Tracy on Sega Genesis.

Players go three random stages,one for stage A,one for stage B and finally a random stage C (Boss level) before the game ends.

Players are given three lives and no continues, full health is awarded at the cost of 20,000 points. 

Note:
--------------------
Due to technical issues, Stage 2-B , Stage 3-B and Stage 5-B are not present in the level randomizer.


How to Patch:
--------------------
1.Grab a copy of Dick Tracy (World).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file