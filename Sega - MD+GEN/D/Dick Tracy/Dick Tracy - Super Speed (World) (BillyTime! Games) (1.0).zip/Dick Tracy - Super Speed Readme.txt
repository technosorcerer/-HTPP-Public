Dick Tracy - Super Speed
July. 1st 2024
BillyTime! Games
--------------------
This is a simple patch for Dick Tracy on Sega Genesis which increases movement and jump speed.

*Compatible with Dick Tracy Arcade
https://www.romhacking.net/hacks/7988/

*Compatible with Dick Tracy SRAM
https://www.romhacking.net/hacks/5973/

How to Patch:
--------------------
1.Grab a copy of Dick Tracy (World).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file