----------------------------------------------------------------
Title:		Dr. Robotnik's Mean Bean Machine: DX Edition (Ver. 3.0)
Author:		RadioTails
URL:		https://sonichacking.org/entries/contest2020/207
----------------------------------------------------------------

The aim of this hack is to make improvements to the totally not a Puyo Puyo reskin original addictive puzzle game: Dr. Robotnik's Mean Bean Machine
This DX Edition (Version 3.0) has the following improvements:

Sonic replaces Has-Bean (Sonic art created by E-122-Psi, updated by RadioTails).
New improved dialog for Dr. Robotnik and his 12 Robots.
X marks are placed on the dungeon areas (aka playing fields) to indicate where you must not place a bean.
In Options, you can select to use the Original dialog, or the DX Edition dialog.
During Scenario Mode, the name of your opponent is displayed during battle.
The Sound Test is available in Options.
The Music and Voice tracks in the Sound Test each have a Track Name.
The unused music is now used at the following sections in the game:

Intro during Stages 4 to 6
Battle during Stages 7 to 9
Danger during Stage 13
Options

The game supports SRAM to save the following:

High Scores for Scenario Mode and Exercise Mode
Settings you have selected in Options
The Password you receive in Scenario Mode (this will automatically be entered when you go to the Password Screen)
When you enter a correct Password (this will automatically be remembered when you go to the Password Screen)

Options includes a option to reset the High Scores.
Region check has been disabled so it will run on any region Sega Genesis/Sega Mega Drive consoles.
Changed the Serial Number in the header so a different Blue Sphere stage will be generated when connected to Sonic & Knuckles.
Other miscellaneous changes that are too boring to list.


So this time I decided to look into how disassemblies work for the Mega Drive. Using the asm68k.exe tool, it occurred to me I could use the disassembler to make it easier to compile any custom code. Once I had most of it figured out, I then started to import the custom code from Version 2.2 into the disassembly, along with making new improvements as well. Let's just say I have bean really busy!
Last year in the I made you a Salad hack, VAdaPEGA stored the diassembly in their hack. This is a clever idea, and there is room to store the disassembly in my hack. If you go to hex location 140000 in the rom, you will find instructions on how to extract it. Enjoy poking around my code, you nosy kids and that meddling dog!
Have fun playing all hacks during the Sonic Hacking Contest 2020!