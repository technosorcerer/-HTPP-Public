   Name: Dr. Robotnik's Mean Bean Machine - DX Edition
Console: Sega Genesis / Sega Mega Drive
Version: 2.1

Original ROM Info:
    - Dr. Robotnik's Mean Bean Machine (U) [!].bin
    - File MD5 4D6BDAC51D2F5969A91496142EA53232
    - File SHA-1 AA6B60103FA92BC95FCC824BF1675E411627C8D3
    - File CRC32 C7CA517F
    - File Size 1.00 MB

Modders:
    - RadioTails (Main Modder)
    - Immense Chicken (Support)
    - E-122-Psi (Sonic Sprite)

List of Improvements:
    - Region check has been disabled so it will run on any region Sega Genesis/Sega Mega Drive.
    - An improved font for the dialog.
    - New dialog for Dr. Robotnik and his 12 Robots.
    - The name of the enemy is displayed during battle (4 letters like in Puyo Puyo).
    - The game has save (SRAM) support to save the Option Settings and High Scores.
    - Sonic replaces Has-Bean.
    - The Sound Test is available in the Options menu.
    - The Music and Voice tracks in the Sound Test each have a Track Name.
    - The unused music is now used at certain points in the game:
        - Intro during Stages 4 to 6
        - Battle during Stages 7 to 9
        - Danger during Stage 13
        - Options

Known Issues:
    - You can't currently reset the saved High Scores.
    - In the Password section, Sonic's colors are flashing.