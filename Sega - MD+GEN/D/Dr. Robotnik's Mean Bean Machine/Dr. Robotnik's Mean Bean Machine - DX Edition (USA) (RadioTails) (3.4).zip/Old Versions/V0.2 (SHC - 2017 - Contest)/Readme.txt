This rom hack is a DX (Deluxe) Edition of the classic puzzle game Dr. Robotnik's Mean Bean Machine.

Version 0.1:
- The region check has been disabled, so it can be played on any Sega Mega Drive / Sega Genesis.  Doesn't matter what Hz or Language is set.
- Disabled the checksum.
- A better dialogue font is used along with additional characters.
- Sound Test is unlocked without having to set your console's region to Japan.
- The "BGM" and "VOICE" sounds each have a title and the order have been rearranged.
- Sonic has replaced Has-Bean.
- New improved / funny dialogue has been inserted.

Version 0.2:
- Made some minor improvements to the dialogue font.
- "1P" & "DR R" text in Scenario Mode has been changed to "YOU" & "Dr. R".
- "1P" & "2P" text in VS. and Exercise Modes has been changed to "SONIC" & "TAILS".
- The "TRY AGAIN" graphic in VS. Mode has been improved.

Current Issues:
- If the console's region is set to Japan, some unused tracks can be played in the Sound Test.  Want to get this changed so any region can listen to them.
- The Sonic sprite will be improved on.  Possible add a black border around the sprite.
- Sonic's sprite flashes on the Password Screen. This was because I didn't know two colours were used for the cursor, hence why the sprite needs improving.
- To give Sonic some blue colours, I had to swap the red and blue in Palette 0 and Palette 1.  So sprites like the beans and text are using the wrong colours.  Need to figure out how to do this.
- Some of the dialogue will need polishing.  Mainly adding pauses during sentences.

Future Stuff:
- Have the names of the robots appear on the play area.
- Use some of the unused music in scenario mode.
- Add more people in the Credits Scene.
- Change the play area background to one from Puyo Puyo 2.
- Save the high scores by adding SRAM.
- Play against Sonic (one idea is you go against him if you don't use a continue).
- Include a counter-system like in Puyo Puyo 2.

Credits:
- RadioShadow: The one who hacked all the content into the game.
- Immense Chicken: Helped come up some ideas on the hack and provided support.
- E-122-Psi: Produced the sprite for Sonic (https://e-122-psi.deviantart.com/art/DrMBM-Sonic-Sprite-Sheet-138345477).