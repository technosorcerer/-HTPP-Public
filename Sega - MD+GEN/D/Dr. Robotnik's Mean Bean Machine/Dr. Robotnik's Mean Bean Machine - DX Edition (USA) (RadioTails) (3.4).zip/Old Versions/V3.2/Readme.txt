   Name: Dr. Robotnik's Mean Bean Machine - DX Edition
Console: Sega Genesis / Sega Mega Drive
Version: 3.2

Original ROM Info:
    - Dr. Robotnik's Mean Bean Machine (U) [!].bin
    - File MD5 4D6BDAC51D2F5969A91496142EA53232
    - File SHA-1 AA6B60103FA92BC95FCC824BF1675E411627C8D3
    - File CRC32 C7CA517F
    - File Size 1.00 MB

Modders:
    - RadioTails
    - Immense Chicken

Special Thanks:
    - E-122-Psi
    - Devon Artmeier
    - Reld 

The aim of this hack is to make improvements to the original
addictive puzzle game: Dr. Robotnik's Mean Bean Machine

This DX EDITION has the following improvements:
    - Sonic replaces Has-Bean (original art by E-122-Psi).
    - New improved dialog for Dr. Robotnik and his 12 Robots.
    - X marks are placed on the dungeon areas (aka playing
      fields) to indicate where you must NOT place a bean.
    - In OPTIONS, you can select to use the ORIGINAL dialog,
      or the DX EDITION dialog. You can also choose to display
      the USA or UK spelling of words (like color > colour).
    - In OPTIONS, you can activate Colorblind Mode. Support
      for: Tritanopia, Protanopia, and Deuteranopia.
    - During SCENARIO MODE, the name of your opponent is
      displayed during battle.
    - The SOUND TEST is available to select in OPTIONS.
    - The MUSIC and VOICE tracks in the SOUND TEST each have
      a Track Name.
    - The unused music is now used in the following sections:
        - Intro during Stages 4 to 6
        - Battle during Stages 7 to 9
        - Danger during Stage 13
        - Options
    - The game supports SRAM to save the following:
        - HIGH SCORES for SCENARIO MODE and EXERCISE MODE
        - Settings you have selected in Options.
        - The PASSWORD you received in SCENARIO MODE (this
          will automatically be entered when you go to the
          PASSWORD screen).
        - When you enter a correct Password (this will
          automatically be remembered when you go to the
          PASSWORD screen).
    - OPTIONS includes a option to reset the HIGH SCORES.
    - The Region Check has been disabled so it will run on
      any region Sega Genesis / Sega Mega Drive consoles.
    - Changed the Serial Number in the header so a different
      Blue Sphere stage will be generated when connected to
      SONIC & KNUCKLES.
    - Changed all the PASSWORDS.
    - Added website link on SOUND TEST
      to: www.shc.zone
    - Fixed bug on HIGH SCORES so you can only select
      letters A to Z.
    - Player 1's font is now blue, while Player's 2 font is
      now red.
    - Other miscellaneous changes.

Known Issues:
    - Have removed the option to turn Sampling ON or OFF.
      Currently Sampling is set to ON. I plan to add
      this back in a future update.

Notes on Colorblind Mode:
    - I have not had the chance to find people who are
      colorblind to test this feature out.
    - Protanopia, Deuteranopia, & Tritanopia are the
      three most common types of colorblind. It is
      possible to add more options if needed.
    - Only the Beans and Options selection palettes
      have been changed. It is possible to change the
      rest of the palettes.
    - This will affect both play field areas. Support
      to only affect one field would required a lot
      of work.
    - The color palettes were based on this mod for
      Sonic Mania: https://gamebanana.com/skins/161232
    - If you are colorblind and would like to improve
      the palettes, please contact me at:
      radiotailspuyo@outlook.com 

If you go to hex location 140000 in the rom, you will find
instructions on how to extract the disassembler for this
hack. Enjoy poking around my code, you nosy kids and that
meddling dog!