Double Dragon V - The Shadow Falls
Traducci�n al Espa�ol v1.0 (26/11/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Double Dragon V - The Shadow Falls
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Double Dragon V - The Shadow Falls
-----------------
Versi�n de Mega Drive del juego de pelea de Double Dragon.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Double Dragon V - The Shadow Falls (U) [!].gen
3.145.728 bytes
CRC32: 27e59e35
MD5: 0b2d342a98a3436faceaf539cbedf698
SHA1: 53402b7c43cd20bf4cbaf40d1ba5062e3823f4bd

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --