Dark Castle (Mega Drive)
Traducci�n al Espa�ol v1.0 (22/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dark Castle (UE) [!].bin
MD5: 56965eb7dde9bc22d16ffa72331c0e09
SHA1: 23e1ad9822338362113e55087d60fb9a1674bf8a
CRC32: 0464aca4
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --