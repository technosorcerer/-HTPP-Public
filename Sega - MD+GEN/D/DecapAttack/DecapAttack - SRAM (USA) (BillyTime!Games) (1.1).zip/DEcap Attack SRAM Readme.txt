DEcap Attack SRAM
Jan. 20th, 2022
BillyTime! Games
--------------------

This patch is designed to add a simple saving mechanism to DEcap Attack.

How to use:
--------------------

Saving:
Game saves after every level.

Loading:
Enter Options, Highlight Sound Test, Press left and change the selection from
01 to 60. Exit options and start your game. 

NOTE:
*Game will produce a black screen if no prior save is detected.
*Potions and bonus coins will also be saved alongside progress.

Update 1.1 (10/20/2025)
--------------------
Patch fixed to allow game to start.

How to Patch:
--------------------
1.Grab a copy of Demolition Man (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file