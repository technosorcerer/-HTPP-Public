DEcap Attack DX
Oct. 21st, 2025
BillyTime! Games
--------------------
This patch is designed to add a new and fun upgrades to DEcap Attack for the Sega Genesis.

Features:
--------------------
*Collect important items at the end of every third level to obtain a new perk
*1 Item - Ability to skip other import items to finish the level (Required to advance)
*2 Item - Chuck jumps higher
*3 Item - Chuck gets a free skull when obtaining an item
*4 Item - Chuck gets a stronger punch when obtaining an item
*5 Item - Chuck gets 2x Potions upon pick up

*99 Lives
Hold A and Press Start when highlighting "Start" at the title screen, Chuck will receive 99 Lives.

*One Shot Mode:
Hold B and Press Start when highlighting "Start" at the title screen, Chuck only has one life and one health.
Potions and coins are not retained across levels. Saves are disabled.

*All Perks
Hold C and Press Start when highlighting "Start" at the title screen, Chuck will receive all perks.

SRAM:
--------------------

Saving:
Game saves after every level after the first.

Loading:
Enter Options, Highlight Sound Test, Press left and change the selection from
01 to 60. Exit options and start your game. 

NOTE:
*Game will produce a black screen if no prior save is detected.
*Potions, Perks and bonus coins will also be saved alongside progress.


How to Patch:
--------------------
1.Grab a copy of DEcapAttack (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file