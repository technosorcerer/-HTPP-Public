Dahna - Megami Tanjou (Mega Drive)
Traducción al Español v2.0 (08/06/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking está basado en el de cccmar.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres españoles
-Traducido PAUSE
-Traducido GAME OVER
-Traducido ETAPA
-Traducido subtítulo
-Traducido H.P. por P.S.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Dahna - Megami Tanjou (Japan).md
MD5: 731b77ec3acab4aaf3b76cd3c8d82a41
SHA1: da0246a063e6f70933e251b9ae84587fe620d4f0
CRC32: 4602584f
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --