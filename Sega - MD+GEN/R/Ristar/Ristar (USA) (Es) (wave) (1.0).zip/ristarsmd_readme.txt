Ristar
Traducci�n al Espa�ol v1.0 (29/12/2017)
(C) 2017 Wave Translations

---
TdC
---

1. Sobre Ristar
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Ristar
-----------------
Original juego de plataformas en el que agarras a tus enemigos y les das cabezazos.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Ristar (UE) [!].gen
2.097.152 bytes
CRC32: 6511aa61
MD5: ecf9d0bac130fed7b6a54a67d7b27df7
SHA1: 1d15ff596dd4f3b2c1212a2e0c6e2b72f62c001e

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --