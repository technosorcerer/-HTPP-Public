RoboCop versus The Terminator (Armor Plating)
Jan. 10th 2026
BillyTime! Games
--------------------
This is a simple patch for RoboCop versus The Terminator which universally reduces incoming damage to Robocop.

How to Patch:
--------------------
1.Grab a copy of RoboCop versus The Terminator (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file