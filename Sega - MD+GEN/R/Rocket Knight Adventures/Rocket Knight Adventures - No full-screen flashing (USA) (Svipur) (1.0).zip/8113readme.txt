This hack removes full-screen flashing that occurs when you hit or kill certain bosses in the game.

The flashing does at times get somewhat overwhelming, and several people have complained that it gets to the point of inducing headache, so this patch is intended to improve the game's accessibility.

Author: Svipur - reverse engineering.