Road Rash II - Nitro Circus
Nov 11th 2025
BillyTime! Games
--------------------

This is patch is an overhaul to Road Rash II on Sega Genesis. 

Includes frame rate Improvement and mode 1 music hack by Ti.

New Bikes with three levels per class (Ultra Light/Super Bikes/Nitro Bikes)
-----------------------------------
Six New Bike Classes with perks!
(Bike 1 - Citizen) - Normal Bike
(Bike 2 - Dune) -  Off Road Capability -> Bike Takes Less Damage 
(Bike 3 - Jackpot) - Extra Money when winning races (250 -> 500 -> 1000)
(Bike 4 - Brawler) - Damage Multiplier (Club at start for Lvl 2 and up)
(Bike 5 - Pursuer) - Money Earned when Eliminating racers (100 -> 200 -> 500) (Chain at start for Lvl 2 and up)
(Bike 6 - Starburst) - All Perks Active! (Replaces Wild Thing 2000)

Universal Changes
Adjusted acceleration for all bikes
Slightly Nerfed enemy acceleration for higher levels
Faster walk speed when thrown from bike
Wild Thing Cheat adds extra $250,000 when performed on the title screen.

SRAM
--------------------
Saving:
Game saves after completing all five tracks and advancing to the next level.

Loading:
Enter Game Options, select Load Game, then press start.

NOTE:
Game will produce a black screen if no prior save is detected.

Player 2's Progress will not be saved.

How to Patch:
--------------------
1.Grab a copy of Road Rash II (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Apply patch to rom