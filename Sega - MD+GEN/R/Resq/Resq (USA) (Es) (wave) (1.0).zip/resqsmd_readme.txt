Resq (Mega Drive)
Traducción al Español v1.0 (18/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Resq (Europe) (Proto).md
MD5: cb08de736dcb0d2baf14dc728a792644
SHA1: f572443bd1e0cf956c87e6cd925412cb0f35045f
CRC32: 558e35e0
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --