Revenge of Shinobi - Better Jumping
December 6th, 2020
BillyTime! Games
--------------------
This patch Modifies jumping physics for better control. Changes include:
*Easier Double Jump
*Slightly Higher jump height

How to Patch:
--------------------
1.Grab any of these copies of Revenge of Shinobi
-Revenge of Shinobi, The (W) (REV 00) [!]
-Revenge of Shinobi, The (W) (REV 01) [!]
-Revenge of Shinobi, The (W) (REV 02) [!]
-Revenge of Shinobi, The (W) (REV 03) [!]
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file