Ultimate X-Men 2
Oct 15th 2025
BillyTime! Games
--------------------
This patch is designed for for X-Men 2 - Clone Wars SRAM which tweaks certain gameplay aspects and mechanics.

*NightCrawler can teleport through walls
(NOTE: Pause, Hold C and Press Left to return back to the character select screen if you accidentally teleport out of bounds.)
*Cyclops and Gambit can charge faster
*Gambit Jumps Higher
*Magneto jumps higher
*Psylocke Jumps higher
*Psylocke deals slightly more damage via her sword.
*Wolverine can Regenerate to full health (Final red bar before yellow) 
*Beast deals double damage
*Big DNA grants 4 health instead of 3
*Full Health DNA also grants an Extra Life
*Tusk has 1/2 health
*Electric doors stay open longer (Stage 1)

*SRAM

Saving:
Game saves after Siberia and every level onward after selecting a character.

Loading:
Press C+-> when the game is paused.

Character Select:
<-+C when the game is paused.

NOTE:
Game will produce a black screen if no prior save is detected.

How to Patch:
--------------------
1.Grab a copy of X-Men 2 - Clone Wars (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file