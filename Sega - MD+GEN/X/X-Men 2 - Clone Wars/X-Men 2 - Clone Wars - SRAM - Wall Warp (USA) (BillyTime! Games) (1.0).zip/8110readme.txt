X-Men 2 - Clone Wars SRAM - Wall Warp
Sept 27th 2023
BillyTime! Games
--------------------
This Addendum patch for X-Men 2 - Clone Wars SRAM is designed to allow Nightcrawler to teleport through floors and walls.

NOTE:
Pause, Hold C and Press Left to return back to the character select screen if you
accidentally teleport out of bounds.

How to Patch:
--------------------
1.Grab a copy of X-Men 2 - Clone Wars (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Apply X-Men 2 - Clone Wars SRAM patch to rom (https://www.romhacking.net/hacks/5684/)
4.Apply X-Men 2 - Clone Wars SRAM - Wall Warp patch to rom