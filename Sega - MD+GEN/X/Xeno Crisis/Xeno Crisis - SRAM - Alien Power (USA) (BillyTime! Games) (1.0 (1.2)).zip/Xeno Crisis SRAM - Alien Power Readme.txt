Xeno Crisis SRAM - Alien Power
Oct. 29th 2025
BillyTime! Games
--------------------
This patch is designed to overhaul and add new mechanic to Xeno Crisis for the Sega Genesis.

*New Perks: 
Max Lvl. Pow - 2x Damage
Max lvl. Ammo - Infinite Ammo
Max Lvl. Health - 2x health Pickups
Max Lvl. Speed - Infinite Pickup Time

*Players now have same invulnerability time between Easy and Hard Mode
*Players get 2x time with Special Weapons on Easy difficulty

Update 11/30/2022:
--------------------
*Checksum function added to prevent crashes if no save data is present.
*Patch will now detect and disables saves when playing bonus modes.
*Boss rush crashes fixed
Special Thanks to FelineFrequencies for reporting these issues and helping with bug testing!

*SRAM
--------------------

Saving:
Game saves after leaving the shop.

Game saves:
P1 dog tags
P2 dog tags
All purchased upgrades for both P1 and P2

Game does not save:
Current continues or any purchased continues.

Loading:
At the character selection screen press the A button to select your character and load a previous game
OR
Press Start when selecting a character to start a new game.
Player who chooses their character lastwill be in control of load functions. 

How to Patch:
--------------------
1.Grab a copy of xenocrisis_gold_v1_0_0.bin at 
https://shop.bitmapbureau.com/products/xeno-crisis-sega-mega-drive-genesis-rom-download
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file