This patch fixes some NPCs misplaced in the game indentified by No-Intro as: 
Wonder Boy in Monster World (USA, Europe)

This patch is a small fix for the hidden shop keeper at Purapril. He is placed 4 pixels underground hiding his legs. With this patch the correct appearance is restored.

Ver. 1.01

In the ending, the middle three NPCs at Purapril are placed 1 pixel too low. Now the correct appearance is restored.

Ver. 1.02

The first npc at the start of the game is placed 1 pixel low. Now the correct appearance is restored.

(C) 2024 Di Somma Michele
mike.1983@libero.it