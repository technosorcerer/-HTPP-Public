Questa patch traduce in italiano il gioco identificato dal No-Intro come: 
Wonder Boy in Monster World (USA, Europe)

� la mia prima traduzione e mi ha portato via molto tempo in quanto ho dovuto modificare anche un po'di assembler(ho dovuto studiare un po'). Ho scelto questo gioco in quanto � stato uno dei giochi che mi hanno accompagnato nella mia infanzia quando andavo a giocare a casa di un amico che possedeva il mitico megadrive oltre allo snes mentre io possedevo "solo" un C64. Oltretutto questo gioco ha aiutato un po'la mia conoscenza dell'inglese. Ho iniziato la mia traduzione circa due anni fa ma dopo un paio di giorni l'avevo abbandonata. Qualche mese fa mi � venuta di nuovo la voglia e dopo un paio di mesi eccola qua.

Comunque ecco le caratteristiche:

Ver. 1.0

* Tradotti tutti testi spostando puntatori alla fine della ROM in modo da avere pi� spazio. La maggior parte dei nomi propri li ho lasciati in inglese perch� per me sono migliori cos�.
* Decompressa la grafica e aggiunte le lettere accentate ed altre lettere speciali per il nome degli oggetti con n. di caratteri limitati.
* Modificata grafica varia(titolo,game over,finale,pozioni,insegna delle locande,ecc.)
* Spostata pi� in alto la finestra di testo quando suoni l'ocarina in modo da visualizzare Shion.(ho preso spunto dalla versione jap del gioco).
* Modificato demo(ho preso anche qu� spunto dalla versione jap e l'ho modificato). Non era necessario ma mi piaceva di pi� il demo jap e l'ho anche allungato.
* Piccola modifica asm per centrare la parola arma nel men�.
* Risincronizzata la musica finale con il testo(traducendo si era sfasata).
* Corretto un'errore del gioco non presente nella versione jap. In pratica quando rispondi correttamente a tutte e cinque le domande della sfinge dovresti ottenere la magia tuono ma in realt� non la ottieni.
* Corretto un altro errore di allineamento della freccetta accanto al SI NO del negoziante nascosto.
* Altri fix vari.

Ver. 1.1

* Fix vari

Ver. 1.2

* Dopo tanti anni ho scoperto che c'era ancora una frase visualizzata in modo sbagliato per un puntatore errato. Oltretutto � appena all'inizio cercando di entrare a Purapril senza parlare prima con le guardie. Come ho fatto a non notarla?
Nella patch � incorporato anche un save fix in quanto il gioco usava un tipo di salvataggio particolare(EEPROM) mentre la normalit� per un gioco del megadrive era la SRAM. Molti emulatori non emulano la EEPROM. Fortunatamente nel codice del gioco � gi� presente la routine di salvataggio in SRAM e quindi io ho solo sbloccato questa funzione. 
Inoltre � incorporata anche l'altra mia patch del negoziante nascosto a Purapril. 

Ver. 1.3

* Aggiunto l'altra mia patch dei 3 personaggi a Purapril nel finale. Tradotti anche 2 oggetti inutilizzabili nel gioco e che non compaiono mai ma mi andava di tradurli.

Ver. 1.4

* Aggiunta un'altra patch riguardante il primo personaggio che incontri posizionato un pixel pi� in basso.

Ver. 1.5

* La sorella di Hotta ed il vecchio capo erano posizionati un pixel pi� in basso ed ora � stato corretto.
* A Begonia c'era una porta esteticamente posizionata male. Adesso posizionandola 16 pixel a sinistra e aggiustando la parete di conseguenza � molto meglio.
* La stanza dell'Anziano dragone e quella che collega Purapril a Begonia avevano problemi di trasparenze e ombre che sono stati corretti.
* Nel castello dell'Incubo, c'� una serie di piattaforme mobili ed equipaggiando gli stivali marini o da scala, che ti permettono di saltare un po' in pi�,  era possibile saltare la seconda parte del livello aggrappandosi ad una corda. Accorciando la corda adesso si � costretti ad affrontare l'intera stanza.
* Nel villaggio Lilypad, quando entravi nella locanda o nel negozio di oggetti, una parte del ramo che regge l'insegna era mal colorata. Adesso � corretto.
* Alla schermata iniziale, in presenza di un salvataggio, il cursore � piazzato gi� su continua evitando di iniziare una nuova partita per errore.
* Implementate varie modifiche asm per espandere il men� pausa con incremento del numero di caratteri per descrivere magie, oggetti e armi.
* Implementate varie modifiche asm per permettere l'espansione dell'insegna delle locande e inserimento della relativa grafica.
* Correzione ulteriore dei testi di gioco, implementando il testo dalla versione giapponese. Il dialogo con il principe del mondo dei demoni (nella versione inglese mondo oscuro) nel castello e nel finale � leggermente diverso, aggiungendo un po' di pathos.
* Altri fix vari.


(C) 2024 Di Somma Michele
mike.1983@libero.it