Questa patch traduce in italiano il gioco identificato dal No-Intro come: 
Wonder Boy in Monster World (USA, Europe)

� la mia prima traduzione e mi ha portato via molto tempo in quanto ho dovuto modificare anche un po'di assembler(ho dovuto studiare un po'). Ho scelto questo gioco in quanto � stato uno dei giochi che mi hanno accompagnato nella mia infanzia quando andavo a giocare a casa di un amico che possedeva il mitico megadrive oltre allo snes mentre io possedevo "solo" un C64. Oltretutto questo gioco ha aiutato un po'la mia conoscenza dell'inglese. Ho iniziato la mia traduzione circa due anni f� ma dopo un paio di giorni l'avevo abbandonata. Qualche mese f� mi � venuta di nuovo la voglia e dopo un paio di mesi eccola qu�.

Comunque ecco le caratteristiche:
* Tradotti tutti testi spostando puntatori alla fine della ROM in modo da avere pi� spazio. La maggior parte dei nomi propri li ho lasciati in inglese perch� per me sono migliori cos�.
* Decompressa la grafica e aggiunte le lettere accentate ed altre lettere speciali per il nome degli oggetti con n. di caratteri limitati.
* Modificata grafica varia(titolo,game over,finale,pozioni,insegna delle locande,ecc.)
* Spostata pi� in alto la finestra di testo quando suoni l'ocarina in modo da visualizzare Shion.(ho preso spunto dalla versione jap del gioco).
* Modificato demo(ho preso anche qu� spunto dalla versione jap e l'ho modificato). Non era necessario ma mi piaceva di pi� il demo jap e l'ho anche allungato.
* Piccola modifica asm per centrare la parola arma nel men�.
* Risincronizzata la musica finale con il testo(traducendo si era sfasata).
* Corretto un'errore del gioco non presente nella versione jap. In pratica quando rispondi correttamente a tutte e cinque le domande della sfinge dovresti ottenere la magia tuono ma in realt� non la ottieni.
* Corretto un altro errore di allineamento della freccetta accanto al SI NO del negoziante nascosto.
* Altri fix vari.


Ver. 1.02
Dopo tanti anni ho scoperto che c'era ancora una frase visualizzata in modo sbagliato per un puntatore errato. Oltretutto � appena all'inizio cercando di entrare a Purapril senza parlare prima con le guardie. Come ho fatto a non notarla?
Nella patch � incorporato anche un save fix in quanto il gioco usava un tipo di salvataggio particolare(EEPROM) mentre la normalit� per un gioco del megadrive era la SRAM. Molti emulatori non emulano la EEPROM. Fortunatamente nel codice del gioco � gi� presente la routine di salvataggio in SRAM e quindi io ho solo sbloccato questa funzione. 
Inoltre � incorporata anche l'altra mia patch del negoziante nascosto a Purapril. 
Quindi questa � una versione definitiva (speriamo...) 


Ver. 1.03
Aggiunto l'altra mia patch dei 3 personaggi a Purapril nel finale. Tradotti anche 2 oggetti inutilizzabili nel gioco e che non compaiono mai ma mi andava di tradurli. Sar� l'ultima versione? 


Ver. 1.04
Aggiunta un'altra patch riguardante il primo personaggio che incontri posizionato un pixel pi� in basso.


(C) 2024 Di Somma Michele
mike.1983@libero.it