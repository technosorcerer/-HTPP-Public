This patch fixes some NPCs and objects misplaced plus some other fixes, in the game indentified by No-Intro as: 
Wonder Boy in Monster World (USA, Europe)

Ver. 1.00

* This patch is a small fix for the hidden shop keeper at Purapril. He is placed 4 pixels underground hiding his legs. With this patch the correct appearance is restored.

Ver. 1.01

* In the ending, the middle three NPCs at Purapril are placed 1 pixel too low. Now the correct appearance is restored.

Ver. 1.02

* The first npc at the start of the game is placed 1 pixel low. Now the correct appearance is restored.

Ver. 1.03

* The sister of Hotta in the Lilypad village is placed 1 pixel low. Now the correct appearance is restored.
* The elder chief of the Lilypad village is placed 1 pixel low. Now the correct appearance is restored.
* In the Begonia village there is a misplaced door. The door was accidentally placed inside part of the wall. Now the door is shifted 16 pixel on the left, and the wall is restored.
* In the room of the Elder Dragon at Begonia the left wall is semitrasparent and lacks shadows. Now it is restored.
* In the Dark Castle, after the first pair of moving platforms, there is a rope that can be reached with the marine and ladder boots that jumps slightly higher than all other boots, skipping the second part of the level. As the jump height difference is barely noticeable and the player would've most likely had Legend Boots equipped at this point, testers never discovered this. Now the rope is shortened forcing you to go through the entire level.
* If you respond correct at all 5 questions of the Sphinx, it should reward you with Thunder magic, but that doesn't happen. Now it is repaired.
* Fixed the game saving forcing it to use SRAM.  

Ver. 1.04

* In the room that connect Purapril to Begonia the wall lacks shadows. Now it is restored.
* In the Lilypad village when you enter inn or item shop, the branch that supports the sign, when you enter is badly colored. Now it is restored.
* At the title screen, when save is present, the icon is now placed on continue avoiding starting a new game by mistake.



(C) 2024 Di Somma Michele
mike.1983@libero.it