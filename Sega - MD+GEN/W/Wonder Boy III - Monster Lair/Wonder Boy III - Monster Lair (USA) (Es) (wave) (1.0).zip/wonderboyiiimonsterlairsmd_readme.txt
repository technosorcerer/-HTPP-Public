Wonder Boy III - Monster Lair (Mega Drive)
Traducción al Español v2.1 (19/06/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Añadidos caracteres especiales
-Guion reescrito
V2.1:
-Arreglada compatibilidad con algunos emuladores como Kega Fusion

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Wonder Boy III - Monster Lair (Japan, Europe).md
MD5: 17f53791945ce7ccd83a4e812e3705e4
SHA1: 1fd3f77a2223ebeda547b81e49f3dfc9d0197439
CRC32: c24bc5e4
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --