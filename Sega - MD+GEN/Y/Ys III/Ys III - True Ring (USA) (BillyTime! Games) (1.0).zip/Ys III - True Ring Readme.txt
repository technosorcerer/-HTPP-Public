Ys III - True Ring
Dec. 21st 2025
BillyTime! Games
--------------------
This is a patch for Ys III - Wanderers from Ys on Sega Genesis that revamps the Power Ring into True Ring.
Inspired by The Lord of the Rings. :p

Changes from Power Ring to True Ring in addition to 2x damage against enemies:
--------------------
*New flavor text
*3x EXP when equipped
*5+ Gold per kill when equipped
*2x Damage taken from enemies when equipped  

How to Patch:
--------------------
1.Grab a copy of Ys III (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file