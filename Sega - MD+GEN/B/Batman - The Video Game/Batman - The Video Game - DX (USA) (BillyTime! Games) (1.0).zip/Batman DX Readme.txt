Batman DX
Nov. 19th, 2025
Billy Time! Games
--------------------------------
This patch is designed to add a simple saving mechanism to Batman - The Video Game.

Four new costumes:
--------------------
Blue Batman (2x Damage - Start with no Batrangs)
Press and Hold A while highlighting and Press Start

Purple Batman (Extra Health and Batrangs)
Press and Hold C while highlighting and Press Start

Red Batman (Move Faster - Jump Higher - Less Health)
Press and Hold A+C while highlighting and Press Start

Green Batman (Infinite Batrangs)
Press and Hold A+C+Left while highlighting and Press Start

SRAM:
--------------------
Saving:
Game saves after every level.

Loading:
At the main menu, Hold B and press start. Continue to hold B and your game will load.

NOTE:
Game will produce a black screen if no prior save is detected.
Game saves Level and Costume Selected

How to Patch:
--------------------
1.Grab a copy of Batman - The Video Game (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file