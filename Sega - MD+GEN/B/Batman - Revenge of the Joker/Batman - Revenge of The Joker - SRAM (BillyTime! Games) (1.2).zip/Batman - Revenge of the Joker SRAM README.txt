Batman - Revenge of The Joker SRAM
Mar. 3rd 2021
BillyTime! Games

This patch is designed to add a simple saving mechanism to Batman - Revenge of The Joker.
How to use

Saving:
Game saves after every level past stage 1-1.

Loading:
At the main menu Press up to loop back to options. Then select New Game.

NOTE:
Game will default to stage 1-1 if no save detected.

How to Patch:
--------------------
1.Grab a copy of Batman - Revenge of the Joker (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file