Batman - Revenge Of The Joker DX
July 21st, 2024
Billy Time! Games
--------------------------------
This patch is designed to overhaul gameplay and add new features to Batman - Revenge Of The Joker on Sega Genesis.


Changes and Features:
--------------------
*Weaponry has been buffed to match the NES version
*Slide now has an short invulnerability window
*Jump Kick now has an short invulnerability window
*Batman's Health is restored when advancing to the next level
*Less time needed to charge special weapons
*Batman's lean forward stance has been removed when Idle.
*Hit box for Jump kick adjusted
*Electricity and Buzzsaw sounds have been removed from stage 2-1 and 3-1 respectively

*Improved timing for more responsive control.
-Can jump immediately after firing when standing still
-Landing animation removed
-Pre-jump animation removed 
-Increased animation speed when kicking

Color Select:
--------------------
At the main menu, Hold A, B, C and optinally left or right and press start to begin the game. 
Batman has Nine new costume colors in addition to his original colors.

Start - Blue and Grey (Original)
A - Blue (Movie)
B - Purple and Blue (Batzarro)
C - Red
A + Left - Green
B + Left - Grey
C + Left - Orange and Red
A + Right - Purple
B + Right - Pink
C + Right - Gold

Optional patch:
--------------------
*An optional patch is included to remove a majority of the blinking frames during Batman's Invulnerability.

NOTE:
*Color select not available when entering passwords
*Compatible with Batman - Revenge of The Joker SRAM
https://www.romhacking.net/hacks/5789/ 
 

How to Patch:
--------------------
1.Grab a copy of Batman - Revenge of the Joker (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file