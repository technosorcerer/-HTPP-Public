Batman Returns SRAM
Jan. 27th 2021
BillyTime! Games

This patch is designed to add a simple saving mechanism to Batman Returns.
How to use

Saving:
Game saves after every level past stage 1.

Loading:
Hold -> and press Start when highlighting options at the main menu. Press start when prompted to load game.

NOTE:
Game will produce a black screen if no prior save is detected.

How to Patch:
--------------------
1.Grab a copy of Batman Returns (World).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file