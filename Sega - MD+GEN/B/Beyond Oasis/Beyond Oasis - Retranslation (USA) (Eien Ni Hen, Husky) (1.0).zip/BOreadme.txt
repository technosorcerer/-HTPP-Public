BEYOND OASIS RETRANSLATION Version 1.0

Table of Contents:
1- Notes
2- Instructions
3- Known Bugs
4- Credits and special thanks
5- Legal stuff

#####################################################################
#                              NOTES                                #
#####################################################################

This is my first hack. I specifically chose this game due to the fact
the script is stored in plain ASCII; thus there's no need for messy
tables et al.

This project started many time ago, 4 or 5 years. I spent 3 years to
locate someone willing to translate this for me, when Eien responded
to my advertisement in romhacking.net. Eien translated it from a
table with the Japanese text and the official English translation
that was given to me by Daniel Reyes. After that I kept this project
as a hobby, slowly re-adding the text back.

There was no need for a messy rom expansion, as there's a big empty
area that kept part of the Japanese font. Since it is not used in the
English release, I just put the extra text there.

At the same time, I will soon be releasing a document detailing all
you'd need to hack the text of this game.

#####################################################################
#                           INSTRUCTIONS                            #
#####################################################################

This IPS file is based on the Beyond Oasis (4) [!].bin file. The file
I used had a size of 3,145,728 bytes.

THIS MEANS YOU MUST APPLY IT TO THE ENGLISH VERSION OF THE GAME.

I reccomend Lunar IPS ( http://fusoya.eludevisibility.org/lips/ ) to
apply the patch.

#####################################################################
#                            KNOWN BUGS                             #
#####################################################################

There are two known bugs and a warning.

I have not found a way to make the intro last longer, thus the last
line of text disappears VERY quickly. It is readable as long you're
a fast reader.

In the Japanese version, the lines "What dangerous times these are!"
and "I was so scared!\nI won't go out alone again." are said by two
different women in the village after you defeat the initial ambush.
In the English version, they were joined in a single line. I cannot
change this, sadly. It's minor, but it is something that delayed the
release for a long time.

Less importantly, since the retranslated text was substantially
bigger than the original, I had to overwrite an area which was blank.
Thus, I cannot assure the game will not crash. Me and two betatesters
have finished the hack successfully, so hopefully you will be able to
as well.

#####################################################################
#                    CREDITS AND SPECIAL THANKS                     #
#####################################################################

Substitute the � symbols for a @ if there is any need to email us.
This is done to prevent spam.

Me (joao_albertoni�hotmail.com) for all the technical work.
Eien Ni Hen (wise_mage�yahoo.com) for the translation.
Daniel Reyes (pokeeiyuu�hotmail.com) for dumping the text.
Tony H from the romhacking.net forums for help with figuring how to
edit the text pointers.
Zee and Christopher "Mouse" for testing. Zee in particular pointed 
out the second bug in the section above.

#####################################################################
#                           LEGAL STUFF                             #
#####################################################################

This work is released under the Creative Commons CC BY-NC-SA 3.0 
License. In short, it means you can do anything you want to it, as
long as it is released non-commercially, with credit to me and under
the same or similar license.

Summary: http://creativecommons.org/licenses/by-nc-sa/3.0/
Full text: http://creativecommons.org/licenses/by-nc-sa/3.0/legalcode