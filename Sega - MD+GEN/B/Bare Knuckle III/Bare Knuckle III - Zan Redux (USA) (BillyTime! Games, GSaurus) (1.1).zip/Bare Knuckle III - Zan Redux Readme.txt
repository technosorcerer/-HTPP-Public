Bare Knuckle III - Zan Redux 
Jun 4th, 2025
BillyTime! Games
--------------------
This patch is makes a few tweaks to Dr. Zan, a playable character in Bare Knuckle III.

Changes:
--------------------
*Zan has a passive Health regen (Works for both player 1 and 2)
*Energy ball attacks changed from 10 damage to 20 damage.
*Last from on forward jump attack changed from 4 to 10 damage.
*Last frame of forward offensive special changed from 6 to 15 damage.
*Star 2 Blitz changed from 8 to 12 damage. 
*Star 3 Blitz changed from 2 and 8 to 16 damage.

NOTE:
--------------------
Compatible with Highscore SRAM.
Compatibility Patches for XP System and Difficulty Randomizer included.
Fix patch is also included for this release in all patches.

Fix Patch: (Credit to Gsaurus)
--------------------
This is a hack that fixes the most important bugs of the original game, and add a few other enhancements to improve the overall gameplay experience (BK3 and SOR3 version).

Bugs and problems from the original that were fixed:

1 - Combo not being reseted when performing special
2 - Combo not being reseted when being hit
3 - Combo not being reseted when grabbing
4 - Roll up/down too short
5 - Special with low power meter causing huge damage
6 - Unable to do offensive special when being grabbed (only defensive)
7 - Zan grab combo finalization was using a beta frame, instead of the final animation
8 - Blaze combo finalization had an invalid hit (so only the last hit was occurring)
9 - Blaze offensive special was not invincible, unlike all other characters
10 - Skate instantly release the first grab after using plank/pipe spin special
11 - Rocket punch had a wrong collision box
12 - Rocket kick had a wrong collision box
13 - When grab combo hits enemies around, sometimes it makes you loose the grab, others don’t.
14 - Pressing offensive special when zack is headbutting you does nothing.
15 - BK3 enemies cause very low damage
16 - BK3 was too easy

XP System:
--------------------
Players gain a level every 100,000 points. 
With each level players deal one more point of damage and take one less point of damage. 
Players each max level at 900,000 points.

Difficulty Randomizer:
--------------------
As you play, the internal difficulty counter is randomized and will introduce enemies from Very Easy all the way to Mania difficulties with various speeds, health bars and aggression. No playthrough will ever be identical! 

Note:
End of round bonuses will be randomized

How to Patch:
--------------------
1.Grab a copy of Bare Knuckle III (Japan).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file