Bare Knuckle III - XP System
Sep. 6th, 2024
BillyTime! Games
--------------------
This patch adds an XP System to Bare Knuckle III on the Sega Genesis.

How It Works:
--------------------
Players gain a level every 100,000 points. 
With each level players deal one more point of damage and take one less point of damage. 
Players each max level at 900,000 points.


How to Patch:
--------------------
1.Grab a copy of Bare Knuckle III (Japan).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file