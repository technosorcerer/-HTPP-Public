Beyond Zero Tolerance (Mega Drive)
Traducción al Español v1.0 (06/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Beyond Zero Tolerance (USA) (Proto).md
MD5: 6e89c8eb5aae7e1adee3d1e8c3e4b0e3
SHA1: 663a1a6c7e25ba05232e22f102de36c1af2f48f8
CRC32: c61ed2ed
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --