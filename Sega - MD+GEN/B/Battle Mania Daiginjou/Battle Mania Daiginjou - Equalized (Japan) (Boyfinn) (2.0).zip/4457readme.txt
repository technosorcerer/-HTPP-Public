Battle Mania Daiginjou Equalized
Boyfinn v2 2019-04-13

The music in BMD was incredible, but suffered from severe high-end harshness that made it tinny and thin sounding. This is especially apparent when listening with headphones. 

This patch replaces the overdriven/harsh instruments in Battle Mania Daiginjou with more rounded choices, vastly improving the overall sound of the game's music. 

Two versions of the patch are included. BMD Equalized IPS is for the original ROM, and the two M.I.J.E.T. versions should be applied over [url=https://www.romhacking.net/translations/1075/]M.I.J.E.T.'s translation hacks[/url].

Notes:
A huge thank-you to Boyfinn for doing this. I asked him if something like this would be possible and a year later he returned with my wish fulfilled. It took a lot of research and instrument work to pull this complex hack off. Combining Boyfinn's Equalized music hack with MIJET's BMD Hacks creates one of the greatest video game experiences you will ever play --SmokeMonster

Database match: Battle Mania Daiginjou (Japan, Korea)
Database: No-Intro: Genesis (v. 20180824-045026)
File/ROM SHA-1: FBCF7E899FF964F52ADE160793D6CB22BF68375C
File/ROM CRC32: 312FA0F2

M.I.J.E.T. Daiginjou Version
Database match: Battle Mania - Dai Gin Jou (JK) [T+Eng(TShooter)20061029-TSV_MIJET]
Database: GoodGen: Genesis v3.21
File/ROM SHA-1: 89412D9C5408F26A53560D3EB030A5A75AC5E4E7
File/ROM CRC32: FAB20C39

M.I.J.E.T. Trouble Shooter Vintage Edition
Database match: Battle Mania - Dai Gin Jou (JK) [T+Eng(BMania)20061029-BMD_MIJET]
Database: GoodGen: Genesis v3.21
File/ROM SHA-1: F425DB086A2FA2C21EBF0E54FFF5A06ADC4B48E9
File/ROM CRC32: 07BA38F6

README by SmokeMonster