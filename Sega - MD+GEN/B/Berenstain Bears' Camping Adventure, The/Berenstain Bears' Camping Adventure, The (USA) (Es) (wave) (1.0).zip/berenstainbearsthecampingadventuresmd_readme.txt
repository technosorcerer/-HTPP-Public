Berenstain Bears', The - Camping Adventure (Mega Drive)
Traducci�n al Espa�ol v1.0 (01/02/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Berenstain Bears', The - Camping Adventure (U) [!].bin
MD5: 9c60d0a0dc49a0e9f076b7e6ed922c2f
SHA1: 5fd62e60fd3dd19f78d63a93684881c7a81485d6
CRC32: 1f86237b
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --