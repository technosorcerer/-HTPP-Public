Batman Forever (Mega Drive)
Traducción al Español v1.1 (27/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado enigma.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Batman Forever (W) [!].gen
MD5: b04c06df1009c60182df902a4ec7c959
SHA1: 6e6776b2c9d0f74e8497287b946ead7f630a35ce
CRC32: 8b723d01
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --