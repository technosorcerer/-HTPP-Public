Bram Stoker's Dracula - Invincibility Frames 
Oct. 20th 2023
BillyTime! Games
--------------------
This patch is designed to give the player a longer Invincibility grace period when taking damage in Bram Stoker's Dracula.

Included in the download is two patches.
--------------------
2X - Player recieves double invincibility time when taking damage.
3X - Player recieves triple invincibility time when taking damage.


How to Patch:
--------------------
1.Grab a copy of Bram Stoker's Dracula (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file
