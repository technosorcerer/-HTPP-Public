Beavis and Butthead SRAM
Sept. 10th 2021
BillyTime! Games

This patch is designed to add a simple saving mechanism to Beavis and Butthead.


How to use
--------------------
Saving:
Game saves after death.

Loading:
Hold B at boot to Load game. 

NOTE:
*Game will produce errors if no prior save is detected.

*Only tickets are saved

*Tickets must be returned to the GWAR poster in Beavis and Butthead's Bedroom first.

How to Patch:
--------------------
1.Grab a copy of Beavis and Butt-Head (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file