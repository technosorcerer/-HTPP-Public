Baby's Day Out (Mega Drive)
Traducción al Español v2.0 (03/06/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Adaptada traducción a prototipo más nuevo que incluye música.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Baby's Day Out (USA) (Proto).md
MD5: 4414423f27efd460b578833a270ee04c
SHA1: 5cc32a2826b3cc5c581043fe6c481ffb753321dd
CRC32: b2e7cc49
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --