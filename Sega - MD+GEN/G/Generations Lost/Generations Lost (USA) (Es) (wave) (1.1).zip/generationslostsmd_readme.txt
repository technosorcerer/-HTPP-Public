Generations Lost (Mega Drive)
Traducción al Español v1.1 (27/07/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado texto introductorio.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Generations Lost (UE) [!].bin
MD5: e91d85e82c9ab9770d86e00dbc78f7c5
SHA1: 86af34198a8c67bd92fb03241d14861b2a9e270a
CRC32: 131f36a6
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --