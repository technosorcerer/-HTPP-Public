Power Instinct Plus
Aug 3rd, 2023
BillyTime! Games
--------------------
Power Instinct Plus is an Improvement patch for Gouketsuji Ichizoku on Sega Genesis.

Improvements:
--------------------
*Able to skip post match dialogs and go into the next fight in story mode.

*Young Otame can now be selected in story mode
(Hold Start and press any button while Otame is highlighted)

*Hi-Score SRAM
(Scores are saved at Game Over Screen. Scores are loaded upon booting game.)
  

How to Patch:
--------------------
1.Grab a copy of Gouketsuji Ichizoku (Japan).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

