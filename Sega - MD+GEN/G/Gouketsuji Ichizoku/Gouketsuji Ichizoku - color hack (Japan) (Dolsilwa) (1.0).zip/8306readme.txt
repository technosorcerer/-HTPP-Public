Gouketsuji Ichizoku (J) Dolsilwa's hack

Gouketsuji Ichizoku (Power Instinct) is a fun fighting game, but original Genesis colors are a bit bland. This color hack makes everything a bit more colorful.    

v. 1.0 changes:
* tweaked colors for all stages,
* tweaked colors for all characters,
* tweaked menus, fonts, character select screen, map

Just apply .ips patch on original rom. 

Hope you'll like it.

Dol.