Gunstar Heroes - No HUD Flash 
May 29th, 2025
BillyTime! Games
--------------------
This simple patch is designed remove the blue and red HUD flash when health is low in Gunstar Heroes. The resultant fix also turns P1's costume blue.


How to Patch:
--------------------
1.Grab a copy of Gunstar Heroes (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file