Translation files for the Mega Drive console GODS game.
For language: Brazilian Portuguese.
They must be applied to the ROM with the information:

ROM Info
Gods (U) [!].bin
MD5: 7c3fcd8a86e01e5b542434fd37a49002
SHA1: bfc84beba074c7dc58b0b4fcac73fffcf0c6b585
CRC32: fd234ccd
1048576 bytes

Modifications must be applied using the application:
LUNAR IPS

You can apply only one of the files if you wish.
The two files will leave the game in Brazilian Portuguese,
with graphics and accents.

The difference between them is that "Font Flat" will also leave the game
with common fonts, as in the original game it is a little difficult to read
the written ones, mainly on a conventional TV monitor.


Author of the translation and modifications:
Andrei Felipe Lopes.
AFSBLOOD - 2023
