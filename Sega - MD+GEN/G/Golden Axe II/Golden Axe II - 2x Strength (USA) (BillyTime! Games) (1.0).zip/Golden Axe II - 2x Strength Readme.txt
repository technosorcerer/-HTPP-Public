Golden Axe II - 2x Strength
Dec. 25th 2024
BillyTime! Games
--------------------
This simple patch is designed to double the amount of Damage players inflict in Golden Axe II.


How to Patch:
--------------------
1.Grab a copy of Golden Axe II (World).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file