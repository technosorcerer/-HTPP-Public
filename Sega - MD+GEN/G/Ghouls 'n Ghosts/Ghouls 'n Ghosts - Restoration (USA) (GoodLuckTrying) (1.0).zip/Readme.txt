Ghouls 'n Ghosts - Restoration 1.0 - by GoodLuckTrying
(https://github.com/GoodLuckTrying)

This is a Ghouls 'n Ghosts (World) (Rev A) romhack that restores the characters' names.

Changes:
- Loki is Lucifer.
- Valkyr is St. Michael.
- Princess of Hus is Princess Prin Prin.

Rom Information: Daimakaimura ~ Ghouls'n Ghosts (World) (Rev A)
Database: No-Intro: Genesis (v. 20210226-213851)
File/ROM SHA-1: AAB6D20F01DB51576B1D7CAFAB46E613DDDF7F8A
File/ROM CRC32: 4F2561D5

Tools used:
- WindHex
- HxD

