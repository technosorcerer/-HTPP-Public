Ghouls'n Ghosts - Artoria Edition v1.0 - by GoodLuckTrying
(https://github.com/GoodLuckTrying)

This is a Ghouls'n Ghosts (World) full sprite conversion hack that changes Arthur's sprites into those of a Maiden/Knight, Artoria.

Changes:
- All of Arthur's sprites were changed to those of Artoria.
- Map, Life, Opening/Ending scenes were changed to show Artoria instead of Arthur.
- New "The End" Screen fitting Artoria.
- Dialogue was adjusted to fit Artoria.
- Hack includes the uncensoring made in my Ghouls 'n Ghosts Restoration hack.
- Citizen/Knight Dolls & 1-Up are now modeled after Artoria.

Tools used:
- Tilemolester 0.21
- HxD
- ImHex
- Aseprite
- Photoshop
- GIMP
- Gens (r57Shell KMod)
- WindHex
- monkeymoore
- https://goodlucktrying.github.io/Genesis-CRAM-Converter/

Rom Information: Daimakaimura ~ Ghouls'n Ghosts (World) (Rev A)
Database: No-Intro: Super Nintendo Entertainment System (v. 20210222-050638)
File/ROM SHA-1: F12280B13EEA88CA03D700B75CF3C13A0E13F3BC
File/ROM CRC32: 6AABA901

Credits:
tryphon - Provided invaluable assistance with many things like understanding the ending screen's tilemaps, character frame tile moving, assistance in understanding character palette shifts during some stage transitions, among other things.
sleepyren - Collaborating artist behind the Citizen/Knight Dolls, as well as Nightgown/Gray Armor's Up/Down attack frames and the Artoria + Princess ending sprites.
bogaa1492 - A lot of assistance for getting started and understanding how to properly read the tiles through Tile Molester, and introduced me to Pyxel Edit which led to finding Aseprite.