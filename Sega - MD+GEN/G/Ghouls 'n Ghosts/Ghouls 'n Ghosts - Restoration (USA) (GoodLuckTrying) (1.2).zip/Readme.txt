Ghouls 'n Ghosts - Restoration 1.2 - by GoodLuckTrying
(https://github.com/GoodLuckTrying)

This is a Ghouls 'n Ghosts (World) (Rev A) romhack that restores the characters' names and fixes spelling mistakes.

Version 1.2 Changes:
- Fixed typos and sentences. Changed CONGRATURATION to WAY TO GO! (Thanks for the feedback, Lagghard!)

Version 1.1 Changes:
- Better spacing for the bad ending screen.

Changes:
- Loki is Lucifer.
- Valkyr is St. Michael.
- Princess of Hus is Princess Prin Prin.

Rom Information: Daimakaimura ~ Ghouls'n Ghosts (World) (Rev A)
Database: No-Intro: Genesis (v. 20210226-213851)
File/ROM SHA-1: AAB6D20F01DB51576B1D7CAFAB46E613DDDF7F8A
File/ROM CRC32: 4F2561D5

Tools used:
- WindHex
- HxD

