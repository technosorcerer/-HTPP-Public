Ghostbusters - Special Edition 2.0
March 01, 2024
------------------------------------------------
BillyTime! Games
Master Linkuei
Danilo Dias

Ghostbusters - Special Edition is a complete overhaul of the 1990 Ghostbusters for
Sega Genesis by Compile. This patch contains several new features, upgrades and other neat surprises for all players! 

Features:
*New Playable Character: 
Winston Zeddemore (To select, press Right on Egon.)
- Stamina: Normal
- Speed: Normal
- Unique Ability: Increased Jump Height

*Uniform Color Select
-Press A,B or C for new costumes. 
-Five brand new color choices for a total of six!

*Restored some cheat codes from the original Japanese release.
*NOTE: Max Weapons, Energy, & Bombs code replace with Nightmare Mode Easter egg.

*New Cheat codes and Unlockables (Ectoplasm Patch Only)
-Listed in separate readme file

*Nightmare Mode Difficulty
Hold B upon booting up the game to receive the challenge and how to enter.
-Lives are reduced to one. *Extra lives can be earned in this mode*
-Reduced health cap
-No Continues
-No Cheats allowed
-Saves are disabled

*Soft Reset function
-Press A+B+C+Start will return you to the Sega logo at anytime.

*Coffee mugs take less damage to destroy. (Ectoplasm Patch Only - v1.2)

*SRAM Save Function
-How It Works:

Loading:
Select Load Game at the main menu, then select your character. after the initial cutscene all weapons, upgrades, Items and level progress will be retained.

*Note - Final Stage:
Reloading the game upon completing the Castle stage will send you back to the Castle stage with any extra money or upgrades earned after completing the stage. 
Both Castle and Deep Hole stage must be completed in one sitting. Due to limitations, the game cannot directly load into the final stage at the start of the Game. 

Saving:
Game saves upon returning to HQ at any point. Via cutscene or by exiting the current stage.

*NOTE: Pure and Ectoplasm patches are available as legacy patches. Pure excludes all cheat codes outside of nightmare mode. 

v2.0 Changelog
--------------------
Optional patches integrated into base game!
*New Character - Sigma from Mega Man X!
-Speed - High
-Life - Very Low
-Unique Ability - 3x Proton Pack damage (With his own unique proton pack!)

*Ultra Nightmare Mode Difficulty
Hold B upon booting up the game to receive the challenge and how to enter.
-Lives are reduced to one. *Extra lives can be earned in this mode*
-Heavily reduced health cap
-No Continues
-No Cheats allowed
-No Money Earned
-Saves are disabled

*Three brand new colors! (See secrets readme for more info.)
*Random Color Select! (See secrets readme for more info.)
*New Cheat Codes! (See secrets readme for more info.)
*Upgraded Director's Cut! (See secrets readme for more info.)
*Item Shop keep replaced with Janine Melnitz (Or Louis Tully.)

*New Character - Janine Melnitz
Press Left on Sigma
- Stamina - Normal
- Speed - Normal

v1.2c Changelog
--------------------
Optional Patches added!
*Ultra Nightmare Mode Difficulty
Hold B upon booting up the game to receive the challenge and how to enter.
-Lives are reduced to one. *Extra lives can be earned in this mode*
-Heavily reduced health cap
-No Continues
-No Cheats allowed
-No Money Earned
-Saves are disabled

*New Character - Sigma from Mega Man X!
-Speed - High
-Life - Very Low
-Unique Trait - 3x Proton Pack damage
-Replaces Louis Tully

v1.2b Changelog
--------------------
Optional Patches added!
*Soft Reset Disable Patch added
*New Costume Colors (Replaces Pink only, cannot stack)
Black
Purple
Orange 

v1.2a Changelog
--------------------
*Ladder timing restored. (Pure patch only)
*SRAM Header fixed.
*Headers modifed to signify which version of GBSE is being used.

v1.2 Changelog
--------------------
*Character Specific Perks now appear for Egon and Ray in Director's Cut Mode.
*Players can no longer recieve a money bonus by selecting easy difficulty before entering Nightmare Mode.
*Coffee cup health has been Restored for Pure patch. 
*Ladder to Mr. Stay Puft appears instantly after beating all middle ghosts to combat the disappearing ladder glitch.

v1.1 Changelog
--------------------
*Fixed Uniform color in capture scenes when playing with default color
*Winston's high stamina stat restored in Director's Cut Mode
*Issue involving players obtaining Infinite Energy pack outside Director's Cut Mode has been resolved

v1.1 Changelog
--------------------
*Fixed Uniform color in capture scenes when playing with default color
*Winston's high stamina stat restored in Director's Cut Mode
*Issue involving players obtaining Infinite Energy pack outside Director's Cut Mode has been resolved


How to Patch:
--------------------
1.Grab a copy of Ghostbusters (World) (v1.1).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file
BONUS.Patch rom with corresponding optional patch.

Special Thanks to
--------------------
SCD
Retrobrando
Ricky Spanish
