Ghostbusters - Special Edition
------------------------------------------------
May.1st 2023
BillyTime! Games
Master Linkuei
Danilo Dias

Ghostbusters - Special Edition is a complete overhaul of the 1990 Ghostbusters for
Sega Genesis by Compile. This patch contains several new features, upgrades and other neat surprises for all players! 

Features:
*New Playable Character: 
Winston Zeddemore (To select, press Right on Egon.)
- Stamina: Normal
- Speed: Normal
- Unique Attribute: Increased Jump Height

*Uniform Color Select
-Press A,B or C for new costumes. 
-Five brand new color choices for a total of six!

*Restored some cheat codes from the original Japanese release.
*NOTE: Max Weapons, Energy, & Bombs code replace with Nightmare Mode Easter egg.

*New Cheat codes and Unlockables (Ectoplasm Patch Only)
-Listed in separate readme file

*Nightmare Mode Difficulty
Hold B upon booting up the game to receive the challenge and how to enter.
-Lives are reduced to one. *Extra lives can be earned in this mode*
-Reduced health cap
-No Continues
-No Cheats allowed
-Saves are disabled

*Soft Reset function
-Press A+B+C+Start will return you to the Sega logo at anytime.

*Coffee mugs take less damage to destroy. (Ectoplasm Patch Only - v1.2)

*SRAM Save Function
-How It Works:

Loading:
Select Load Game at the main menu, then select your character. after the initial cutscene all weapons, upgrades, Items and level progress will be retained.

*Note - Final Stage:
Reloading the game upon completing the Castle stage will send you back to the Castle stage with any extra money or upgrades earned after completing the stage. 
Both Castle and Deep Hole stage must be completed in one sitting. Due to limitations, the game cannot directly load into the final stage at the start of the Game. 

Saving:
Game saves upon returning to HQ at any point. Via cutscene or by exiting the current stage.

*NOTE: Pure patch lacks any cheat codes outside of Nightmare Mode and is meant for Speedrunners.

v1.2 Changelog
--------------------
*Character Specific Perks now appear for Egon and Ray in Director's Cut Mode
*Players can no longer recieve a money bonus by selecting easy difficulty before entering Nightmare Mode.
*Coffee cup health has been Restored for Pure patch. 
*Ladder to Mr. Stay Puft appears instantly after beating all middle ghosts to combat the disappearing ladder glitch.

v1.1 Changelog
--------------------
*Fixed Uniform color in capture scenes when playing with default color
*Winston's high stamina stat restored in Director's Cut Mode
*Issue involving players obtaining Infinite Energy pack outside Director's Cut Mode has been resolved

v1.1 Changelog
--------------------
*Fixed Uniform color in capture scenes when playing with default color
*Winston's high stamina stat restored in Director's Cut Mode
*Issue involving players obtaining Infinite Energy pack outside Director's Cut Mode has been resolved


How to Patch:
--------------------
1.Grab a copy of Ghostbusters (World) (v1.1).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

Special Thanks to
--------------------
SCD
Retrobrando
Ricky Spanish
