Grind Stormer (USA) Color Hack

Grind Stormer (or V-V in Japan) is quite good vertical shooter, but its colors are a bit washed down. This simple color hack was made to make it a little more colorful.

v. 1.0 changes:
* tweaked colors of all stages,
* tweaked player and enemy colors
* tweaked title screen

Just apply .ips patch on original rom. 

Hope you'll like it.

Dol.