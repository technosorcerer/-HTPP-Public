Gunship (Mega Drive)
Traducción al Español v1.0 (25/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Gunship (Europe).md
MD5: b4fe88cb2842314c9b9169d2f393d514
SHA1: 3820eac00b888b17c02f271fab5fd08af99d5ef9
CRC32: da1440c9
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --