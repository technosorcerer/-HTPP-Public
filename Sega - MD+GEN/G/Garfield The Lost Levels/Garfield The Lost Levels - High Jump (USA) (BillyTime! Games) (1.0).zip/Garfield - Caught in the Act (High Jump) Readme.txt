Garfield - The Lost Levels (High Jump)
Dec. 16th 2025
BillyTime! Games
--------------------
This is a simple patch for Garfield - The Lost Levels on Sega Genesis that increases stationary jump height. 

How to Patch:
--------------------
1.Grab a copy of Garfield - The Lost Levels.bin 
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file