Garfield - Caught in the Act (High Jump)
???. ?? 2025
BillyTime! Games
--------------------
This is a simple patch for Garfield - Caught in the Act on Sega Genesis that increases stationary jump height. 

NOTE:
Compatible with Password SRAM:
https://romhackplaza.org/romhacks/garfield-caught-in-the-act-password-sram-genesis/

How to Patch:
--------------------
1.Grab a copy of Garfield - Caught in the Act (USA, Europe).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file