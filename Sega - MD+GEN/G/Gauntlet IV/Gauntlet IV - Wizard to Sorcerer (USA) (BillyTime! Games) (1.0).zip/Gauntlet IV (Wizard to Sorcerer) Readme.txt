Gauntlet IV (Wizard to Sorcerer)
Mar. 7th 2025
BillyTime! Games
--------------------

This patch is designed to retool the power set of The Wizard character in Gauntlet IV.

How it works:
--------------------
Wizard now gains health from defeating enemies and treasure. However, Wizard recieves 3x as much damage per hit.

Works with multiple players active and in quest mode.

How to Patch:
--------------------
1.Grab a copy of Gauntlet IV (USA, Europe) (En,Ja) (August 1993).MD (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file