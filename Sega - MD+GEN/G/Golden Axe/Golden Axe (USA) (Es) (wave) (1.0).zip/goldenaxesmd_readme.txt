Golden Axe (Mega Drive)
Traducci�n al Espa�ol v1.0 (07/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
La palabra STAGE mientras se juega no he podido traducirla.
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Golden Axe (W) (REV01) [!].bin
524.288	bytes
MD5: e4263c39487f0b55e8f33cbd5acd9b93
SHA1: 2ce17105ca916fbbe3ac9ae3a2086e66b07996dd
CRC32: 665d7df9

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --