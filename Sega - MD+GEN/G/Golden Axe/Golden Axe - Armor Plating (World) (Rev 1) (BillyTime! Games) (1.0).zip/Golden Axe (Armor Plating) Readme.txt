Golden Axe (World) (Armor Plating)
Jan. 10th 2026
BillyTime! Games
--------------------
This patch is designed to reduce damage for players in Golden Axe for the Sega Genesis.
Works for both players.

How to Patch:
--------------------
1.Grab a copy of Golden Axe (World) (v1.1).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file