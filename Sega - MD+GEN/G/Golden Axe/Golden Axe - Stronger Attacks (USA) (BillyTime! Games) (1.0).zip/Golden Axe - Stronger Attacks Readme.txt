Golden Axe - Stronger Attacks
Dec. 26th 2024
BillyTime! Games
--------------------
This patch is designed to attack damage for players in Golden Axe for the Sega Genesis.

How to Patch:
--------------------
1.Grab a copy of Golden Axe (World) (v1.1).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

Bonus:
--------------------
The offsets will allow you to change the numerous attacks values for players so you can tweak the game to your liking.

Normal Attacks:
007292:0002

Bird Mount:
0081B4:0008

Jump Attack:
00766E:0006

Dash Attack:
00787E:0004

Dragon Breath & Fire Ball:
008202:0004

Downward Slash:
007984:0010

Reverse Attack:
0070FC:000C

Throw:
007230:0004

Gillius Magic Lvl 1:
007D12:1704
Gillius Magic Lvl 2:
007D14:0F08
007D16:0F08
Gillius Magic Lvl 3:
007D18:1810

Ax Battler Magic Lvl 1:
007CF0:1204
007CF2:1204
Ax Battler Magic Lvl 2:
007CF4:1308
007CF6:1308
Ax Battler Magic Lvl 3:
007CF8:1410
Ax Battler Magic Lvl 4:
007CFA:0B18

Tyris Magic Lvl 1:
007CFE:2004
007D00:2004
007D02:2004
007D04:2004
Tyris Magic Lvl 2:
007D06:1108
Tyris Magic Lvl 3:
007D08:2510
Tyris Magic Lvl 4:
007D0A:2318
Tyris Magic Lvl 5:
007D0C:0D20
Tyris Magic Lvl 6:
007D0E:0928