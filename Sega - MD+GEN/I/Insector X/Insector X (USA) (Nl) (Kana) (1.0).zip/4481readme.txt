Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 29-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt
met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Insector X (USA).md
Platform: Sega Mega Drive/Sega Genesis
Database: No-Intro: Genesis (v. 20180824-045026)
MD5:   77574085187602BF50DD1167DA389F60
SHA1:  4F4ECFF167D5ADA699B0B1D4B0E547B5ED9964D5
CRC32: 70626304
Bytes: 524288

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --