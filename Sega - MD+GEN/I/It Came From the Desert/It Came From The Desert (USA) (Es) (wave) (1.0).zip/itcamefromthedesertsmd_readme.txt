It Came from the Desert (Mega Drive)
Traducción al Español v1.0 (31/08/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Arreglado texto que desbordaba al volver a entrar después de curarte.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
It Came from the Desert (USA) (Proto).md
MD5: 7dec575a0370920b4f96a779b462ceb1
SHA1: 245816c9744552856fc2745253db7b37ce9d9251
CRC32: 25afb4f7
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --