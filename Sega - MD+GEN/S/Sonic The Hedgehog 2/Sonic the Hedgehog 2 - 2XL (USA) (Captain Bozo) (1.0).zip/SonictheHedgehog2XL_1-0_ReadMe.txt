Sonic the Hedgehog 2 XL


Credits: Captain Bozo, Ranger

==Gameplay==
Sonic 2 XL takes after other hacks that penalize the player for collecting rings, 
such as OMG THE RED RINGS, a Sonic the Hedgehog hack. The fatter Sonic is, the 
slower he runs and the shorter he jumps. With enough onion rings, Sonic is unable 
to roll properly, and if he gets too fat, he dies. Sonic can burn off the fat by 
running, or by hitting the "?" monitors strategically scattered through levels.

==Facts about the game's fat feature==
*It takes about 5 rings to to go up a level in fatness.
*You lose spindashing and normal spinning all together at fat level 5.
*It takes about 30 rings to die of fatness.
*The fatter you get, the less effort Sonic puts into looking up and down until 
he gives up (Level 6).
*If you use debug mode to finish Death Egg Zone as fat Sonic, he goes down to 
fat level 3.
*If you break a 10 ring box, Sonic will become fat instantly.
*If you break a "?" box, Sonic will lose weight instantly. 
