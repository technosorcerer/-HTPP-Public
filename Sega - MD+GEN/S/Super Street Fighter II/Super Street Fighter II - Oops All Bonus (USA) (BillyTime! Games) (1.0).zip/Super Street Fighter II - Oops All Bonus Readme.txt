Super Street Fighter II - Oops All Bonus
Apr. 10th 2025
BillyTime! Games
--------------------
This fun patch is designed for Super Street Fighter II
for the Sega Genesis. It allows plays to repeatedly play the bonus stages.

How It Works:
--------------------
In Normal Mode only (Disabled in Expert Mode) after your first match, you will play all three Bonus Stages in an Infinite Loop. A second player can join in at any time.

How to Patch:
--------------------
1.Grab a copy of Super Street Fighter II (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file