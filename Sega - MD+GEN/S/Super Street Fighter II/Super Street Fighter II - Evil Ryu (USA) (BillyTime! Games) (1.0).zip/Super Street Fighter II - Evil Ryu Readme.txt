Super Street Fighter II - Evil Ryu
Sep. 13th 2024
BillyTime! Games
--------------------
This patch is designed to add a Ryu variant to Super Street Fighter II
for the Sega Genesis.


How it Works
--------------------
By pressing start on Ryu at the character select screen, Players can access Evil Ryu.

Character Features:
*All hits burn
*Evil Ryu gives and recieves more damage from all attacks
*Custom win quote

NOTE:Ending defaults to "Try a higher difficulty level" when completing arcade mode.
Portrait Palette no long fades to grey upon game over.

How to Patch:
--------------------
1.Grab a copy of Super Street Fighter II (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file