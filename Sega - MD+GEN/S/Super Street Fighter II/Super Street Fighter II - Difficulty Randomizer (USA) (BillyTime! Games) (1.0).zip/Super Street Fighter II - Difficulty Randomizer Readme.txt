Super Street Fighter II - Difficulty Randomizer
Sep. 6th 2024
BillyTime! Games
--------------------
This patch is designed to introduce difficulty in Super Street Fighter II
for the Sega Genesis.


How it Works
--------------------
At the start of every round, AI is randomly set to any level between 1-8. 
Randomizer does not effect eligibility to view endings.


How to Patch:
--------------------
1.Grab a copy of Super Street Fighter II (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file