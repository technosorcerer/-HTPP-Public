Super Street Fighter II - XP System
Nov. 15th 2024
BillyTime! Games
--------------------
This patch is designed to add a XP level system to Super Street Fighter II
for the Sega Genesis. Comes in two flavors.

Normal:
Players deal one extra point of damage and earn one defense point every 100,000 points. Level cap is at 1,000,000 points.

Reverse:
CPU opponents become stronger in both damage and defense every 100,000 points. Damage and defense points are variable dependant on level.


Extra Patch - Evil Ryu
--------------------
By pressing start on Ryu at the character select screen, Players can access Evil Ryu.

Character Features:
*All hits burn
*Evil Ryu gives and recieves more damage from all attacks
*Custom win quote

NOTE:Ending defaults to "Try a higher difficulty level" when completing arcade mode.
Portrait Palette no long fades to grey upon game over.

How to Patch:
--------------------
1.Grab a copy of Super Street Fighter II (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file