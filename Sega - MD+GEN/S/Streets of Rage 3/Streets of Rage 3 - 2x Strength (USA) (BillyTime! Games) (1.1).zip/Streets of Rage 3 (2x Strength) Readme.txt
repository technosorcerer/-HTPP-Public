Streets of Rage 3 (2x Strength)
Jan. 21st 2025
BillyTime! Games
--------------------
This is a simple patch designed for Streets of Rage 3 that doubles the amount of damage inflicted. Comes in two flavors.

Enemies Only
--------------------
Enemies only take double damage.

Enemies and Players
--------------------
Everyone takes double damage!

How to Patch:
--------------------
1.Grab a copy of Streets of Rage 3 (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file