Streets of Rage 3: Candra Returns

By Candra Software

This is my final Streets of Rage ROM Hack. After 4 years of
making these, I am now finished with making them.

Candra Returns takes place after Streets of Rage 2: Girls'
Paradise. Candra Minsky and her robot clone Sandra try to
defeat Neo Chaos.

Patch over a US Streets of Rage 3 ROM.