STORY:

I was upset for not seeing the bullets who killed me in this game.

the original colors for the bullets can hardly been seen from the background.
-----
So the plot is to turn them PINK !
-----

warning = this hack does not change the hit-box of the ship, who stays massive !
 

WHAT WAS DONE:

Some hexediting.
512 bytes were changed at the adress $79E00
512 bytes were changed at the adress $99E00
the original colors used are 1,2,6,8.
now it's color 5 (pink)

the bullet sprite is 16x16 in size, and is located in two adresses in the rom , splitted in :
-4 tiles with 4 variants at the first adress,
-and in another 4 tiles with 4 variants at the second adress. (so a total of 32 tiles)

CREDITS:

i didn't do anything,all credits goes to UPSILANDRE ,who hacked the rom, i've just created the .ips and tested the .ips


HOW TO USE:

patch with lunar ips the original rom "Slap Fight MD (Japan).bin"
