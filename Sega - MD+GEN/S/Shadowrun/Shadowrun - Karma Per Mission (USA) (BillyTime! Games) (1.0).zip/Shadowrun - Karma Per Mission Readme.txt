Shadowrun - Karma Per Mission
Dec. 25th 2024
BillyTime! Games
--------------------
This simple patch is designed to adjust and lock Karma earn rates in Shadowrun for the Sega Genesis.

How It Works:
--------------------
Using the corresponding patch, Players will earn a set amount of Karma per mission. Allowing players to level up faster.


How to Patch:
--------------------
1.Grab a copy of Shadowrun (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file