Shadowrun - Permadeath
Oct. 23rd 2023
BillyTime! Games
--------------------
This patch is designed to add permanent death mechanic into shadowrun for the Sega Genesis

How it works
--------------------
*If your character runs out of mental or physical health, the game is over.
*Saving and loading has been disabled entirely. Good Luck! 
*Karma earned is set to 2 for each run.
*Wired Reflexes melee instant death bug has been fixed


How to Patch:
--------------------
1.Grab a copy of Shadowrun (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file