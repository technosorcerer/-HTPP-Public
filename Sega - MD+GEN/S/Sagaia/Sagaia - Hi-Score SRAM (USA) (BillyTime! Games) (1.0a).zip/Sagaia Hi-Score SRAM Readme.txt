Sagaia Hi-Score SRAM
Apr. 22nd 2024
BillyTime! Games
Spkleader
--------------------
This patch is designed to add a simple saving mechanism for High Scores in Sagaia.


How to use
--------------------
Saving:
Scores save after Initials are entered and player returns to the sega screen. 

Loading:
Scores load upon boot. If checksum fails or it is your first time booting, default scores are loaded.


How to Patch:
--------------------
1.Grab a copy of Sagaia (USA).md or Darius II (Japan).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file