Street Fighter II' - Special Champion Edition - Modern Tiger Knee Input
Sept. 4th, 2023
BillyTime! Games
--------------------
This is a simple patch that changes the required input needed to perform Sagat's Tiger Knee in Street Fighter II' - Special Champion Edition on Sega Genesis.

How it works:
--------------------
Tiger Knee can now be performed using a Z Motion followed by any kick button, similar to how Tiger Uppercut is performed. 

Tiger Knee:
Forward, Down, Down Forward + Any Kick Button

This input is more in line with Sagat's moveset in later Street Fighter games.   

How to Patch:
--------------------
1.Grab a copy of Street Fighter II' - Special Champion Edition (USA)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

