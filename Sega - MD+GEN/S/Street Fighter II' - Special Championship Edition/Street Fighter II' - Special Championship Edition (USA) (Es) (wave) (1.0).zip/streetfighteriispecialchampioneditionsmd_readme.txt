Street Fighter II' - Special Champion Edition (Mega Drive)
Traducción al Español v1.1 (24/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1:Arreglado modo dual. 

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Street Fighter II' - Special Champion Edition (USA).md
MD5: 94c07e0d90ecb7a7745d5eec376b1d61
SHA1: a5aad1d108046d9388e33247610dafb4c6516e0b
CRC32: 13fe08a1
3145728 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --