Street Fighter II' - Special Champion Edition - Input Window Increase
Sept. 4th, 2023
BillyTime! Games
--------------------
This is a simple patch that increases the required input window needed to perform special moves in Street Fighter II' - Special Champion Edition on Sega Genesis.

How it works:
--------------------
Input timings located at offset 01:D556 have been increased from 09 - 0F to a universal 10.

This will loosen timing restrictions needed to perform special moves. The difference can be felt with performing Z motion attacks, full circle attacks and SF2 playing on a keyboard. 

How to Patch:
--------------------
1.Grab a copy of Street Fighter II' - Special Champion Edition (USA)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

