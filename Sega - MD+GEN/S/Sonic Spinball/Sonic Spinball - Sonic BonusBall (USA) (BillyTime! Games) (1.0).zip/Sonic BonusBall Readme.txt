Sonic Bonusball
Jun 26th, 2024
BillyTime! Games
--------------------
This is a simple patch allows you to play only the bonus stages in Sonic Spinball for the Sega Genesis.

How it works:
--------------------
Level ends immediately after the intro and skips to the three bonus stages. Game will end after the third bonus stage.

How to Patch:
--------------------
1.Grab a copy of Sonic Spinball (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

