Sonic Spinball - Emerald Safari
Sept. 25th 2024
BillyTime! Games
--------------------
This patch is a gameplay overhaul for Sonic Spinball which gives chaos emeralds unique abilities that stack.

A simple save function has also been implemented. 

How it Works:
--------------------
Emeralds no longer disappear upon level completion and only five emeralds are needed to access all boss arenas to complete the game. Collecting further emeralds grants additional bonuses. 

Controllable Sonic - 1 Emerald
5 Lives during Bonus Stages - 3 Emeralds
All Boss Doors Open - 5 Emeralds
Double Damage to Bosses - 7 Emeralds
Double Rings - 9 Emeralds
7 Lives during bonus stages - 10 Emeralds
Quad Rings - 11 Emeralds
Infinite Lives - 12 Emeralds



SRAM:
--------------------
Saving:
Game saves after each level before the bonus round.

Loading:
At the title screen hold A and Press Start.

Game Saves:
Current Level
Current Emerald Count

NOTE: An additional patch is available that features SRAM only.

How to Patch:
--------------------
1.Grab a copy of Sonic Spinball (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file