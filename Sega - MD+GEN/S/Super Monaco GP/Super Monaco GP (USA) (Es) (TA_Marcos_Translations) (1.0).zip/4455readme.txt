
       .-----------,-.-----. 
       |:_M_a_r_l//(_)\r_o_|:
    ___||=======// ,--.\===.|  ___
  .'.""'\\____.'/ | (__)\__|\.'.""'.
  | |"""||._       '---'__   `-|"""|
  | |"""||. '-.___  ` -'--'     `-.| ___
  | |"""|| '-.'.""'.----._     .---:'.""'.
  `.'_".'|   | |"""|_____ `. /\ \___||_""|
          '-.| |""_/_____\  \ \\ \_____\_|
             | |"|____    ', '.__/   ____|
             `.'__.'  `'---'-'---'-'.'__.'

SUPER MONACO GP EN ESPA�OL 
Color Hacker: TA Marcos
Spanish translator and Editor: TA Marcos
Special Thanks to Peixemacaco (Brazil) for revealing how to edit the big yellow letters
of the F1 teams and show me the right software for colors edition.


WHAT'S NEW (02/09/2019)
Super M�naco en Espa�ol 1.0

- F1 1989-1990 seasons are updated with real teams and drivers.
- Cars and engines names are mixed. Some of them match up with real life ones, some of them not. And some of them are NOT EXACTLY the proper ones.  
- Every driver wear overalls related to the team color that they start on the 1st season.
- Main menus, options, drivers challenge screens, boxes instructions, etc, are translated and adapted into Spanish.
- Mclaren (Madonna), Benetton (Bestowal), Arrows (Bullets), Rial (Rigel), Comet (Coloni) and Onyx (Orchis) colors are edited for better resemblance.
- New color design for menus.


NEXT UPDATE
Super M�naco en Espa�ol 2.0
- Include the picture of real drivers of the seasons 1989-1990.
- Improve the text concerning the names and nationalities (for instance "S. Johansson" instead of Johanson, or Francia instead of France).
- Match up with real life car names and engines at 100%.
- Translate text that have not been previously translated because I could not locate before.

All the best,

TA Marcos Translations�