SplatterHouse 3 SRAM
Feb. 23rd, 2021
BillyTime! Games
--------------------

This patch is designed to add a simple saving mechanism to SplatterHouse 3.

How to use:
--------------------

Saving:
Game saves after every level past stage 1.

Loading:
Enter the Password screen and press A six times. 

NOTE:
*Game will produce a crash if no prior save is detected.
*Game will not save if you head to Stage X before the next level
*Family Member statuses will be saved

How to Patch:
--------------------
1.Grab a copy of Splatterhouse 3 (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file