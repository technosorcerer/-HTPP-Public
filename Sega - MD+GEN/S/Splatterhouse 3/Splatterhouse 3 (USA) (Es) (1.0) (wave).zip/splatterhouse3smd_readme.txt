Splatterhouse 3 (Mega Drive)
Traducci�n al Espa�ol v1.0 (07/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Splatterhouse 3 (U) [c][!].gen
2.097.152 bytes
MD5: 8c2a9b15ba24b611c895efd49c175ebe
SHA1: 7f29f00ec724e20cb93907f1e33ac4af16879827
CRC32: 00f05d07

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --