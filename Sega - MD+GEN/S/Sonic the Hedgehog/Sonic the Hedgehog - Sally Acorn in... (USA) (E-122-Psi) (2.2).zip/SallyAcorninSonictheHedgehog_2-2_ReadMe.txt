Sally Acorn in Sonic the Hedgehog

Credits: E-122-Psi
Additional programming and coding by: MarkeyJester, Aquaslash, Selbi, and many others


Sally is slower than Sonic and can't use spin attacks; however, she has a number of stealth and agility-based abilities to compensate and access areas Sonic had difficulty reaching, as well as the use of handheld device NICOLE. She has the following moves:

*NICOLE Laser Attack: Press A and Sally uses NICOLE to fire a small projectile which hits nearby enemies and obstacles.
*NICOLE Scan Mode: Press B and NICOLE will send a data wave to reprogram monitors and other Eggman traps.
*NICOLE Downward Laser: Press Down + A/B while airborne to fire at objects straight below. Sally also gets a small vertical boost.
*Slide: Press Down while running to slide on the ground for a short distance. Sally can also slide under certain obstacles using this method.
*Somersault Dash: Press Down + B/C while on the ground and Sally will somersault forward at a high speed. This is useful for jumping long distances.