Sonic 2 - Emerald Safari
Mar. 8th 2023
BillyTime! Games
--------------------
This patch is a gameplay overhaul for Sonic The Hedgehog 2 which not only overhauls 
how to obtain Chaos Emeralds but gives each emerald unique abilities that stack.

A simple save function has also been implemented. 

How it Works:
--------------------
In addition to special stages, players can earn emeralds by gaining a continue at the end of each act. 
Each emerald will give the player new abilities before obtaining Super Sonic form.

These abilities are as follows:
First Emerald
Player 1 Gets one extra hit point per life before losing rings. (Does not stack with shields)
Second Emerald
Player 1 can stay underwater for extremely long periods of time.
Third Emerald
Player 1 now has faster acceleration.
Fourth Emerald
Player 1 now earns double rings in normal stages.
Fifth Emerald
Player 1 now earns double rings in both normal and special stages.
Sixth Emerald
Player 1 can now jump higher.
Seventh Emerald
Super Sonic now available.

NOTE:
While Tails cannot obtain Super Form as Player 1, he can gain the emerald abilities listed above.
Super Sonic form now requires 100 rings in order to activate.


SRAM:
--------------------
Saving:
Game saves at each title card screen transition.

Loading:
Enter the options menu, highlight player select and press start. Highlighting any other option will exit the options screen.

Game Saves:
Current Level and Act
Current Emerald Count
Selected Players (Sonic and/or Tails)

NOTE:
*Game will restart if no prior game save is detected. This is intentional as a checksum system in place.

Optional Patch:
--------------------
A Patch Has been included to allow players to skip Metropolis Zone entirely.
Players will move from Oil Ocean to Sky Chase Zone.

How to Patch:
--------------------
1.Grab a copy of Sonic The Hedgehog 2 (World) (Rev A).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file
4.Extra patches have been included to disable certain aspects of this mod, Please use only one of the three patches.