Sonic 1 Enhanced by paveldechev0604.
June 17th 2023

This is a hack of Sonic the Hedgehog for Sega Genesis with less bugs, new features and enhanced graphics. The hack has features include:

.	Display the Press Start Button Text
.	Fix Accidental Deletion of Scattered Rings
.	Fix Ring Timers
.	Fix the Hidden Points Bug
.	Fix Special Stage Jumping Physics
.	Change Spike Behavior
.	Fix the Walk-Jump Bug
.	Fix the Camera Follow Bug
.	Fix Scattered Rings' Underwater Physics
.	And finally... Add the Air Roll

How to patch:

1.Grab a copy Sonic The Hedgehog (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file
