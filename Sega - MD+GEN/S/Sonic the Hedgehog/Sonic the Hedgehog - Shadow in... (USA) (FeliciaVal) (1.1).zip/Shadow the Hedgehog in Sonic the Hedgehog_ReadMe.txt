Shadow the Hedgehog in Sonic the Hedgehog

Credits: FeliciaVal
Additional programming and coding by: Jimmy Hedgehog, Selbi, MarkeyJester and E-122-Psi

Controls
*Spindash: Down + Jump
*Kick: A
*Homing attack/Jumpdash: D Pad + Jump: 