So you chose to play wide sheep in sonic 1? Alright, I'll tell you what you need to know.

Story: Threatened by the girth of Dr Robotnik, Wide Sheep, now infused with the speed of
Sonic the Hedgehog, sets out to rid this world of all things Egg-shaped, and gain some
new people in there cult- I-I mean religion, in the process.

Gameplay: Just like Sonic 1, but you don't need to be in a ball to hurt enemies, they
just die by touching you. That's it, no hitbox change or anything.
The girth is purely cosmetic.

History: This is a tribute to a vtuber called Sleep Sheep.
She plays games, does ASMR and is a joy to be around.
In the discord server, there's a channel dedicated to our true god, Wide Sheep.
If you want the wide sheep lore, go here: https://www.youtube.com/live/0Fm4aS_rL6g?t=13174
Due to demand for a channel to count sheeps, it devolved into a channel for counting
wide sheeps.
Because to the small size of the community at the time, the counting was relatively slow.
This rom hack was planned entirely by me for a 100th sheep milestone.
In the end, I ended up posting it as the 149th sheep, due to wanting to polish it a
little bit more. For example, many character hacks have Sonic randomly appear.
This hack is no exception, but not nearly to the same degree as others.



