Super Sonic in Sonic the Hedgehog
beta 4

Credits: Puto, Assistance from
drx, Tweaker, and jman2050

Press A 6 times on the title screen for the ability to transform into Super Sonic without all emeralds.
Press B 5 times on the title screen to enable a Spin Dash.
Press A 15 times on the title screen to switch to Sonic the Hedgehog 3 drums. 
