Vector the Crocodile in Sonic the Hedgehog

Credits: E-122-Psi

Vector can perform the Spin Dash while on the ground, and the Air Dash while 
in mid-air in any direction. Due to his reduced jump height and acceleration, 
these new moves can become crucial to completing certain levels:

*Air Dash: Press A/B/C while holding on the D-Pad to have Vector thrust 
forward in any direction.
*Spin Dash: Hold Down and press A/B/C while standing still to rev up. 
Let go of down to dash forward in a rolling formation.
*Wall Climb: Air Dash into a wall while holding A/B/C to cling onto a 
wall, press Up or Down to climb up or down. Let go of A/B/C to jump off. 