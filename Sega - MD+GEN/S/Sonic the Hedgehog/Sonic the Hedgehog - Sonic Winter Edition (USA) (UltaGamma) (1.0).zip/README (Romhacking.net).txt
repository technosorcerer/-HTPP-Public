12/25/2023

Apply the SonicWinterEdition.ips patch to a Sonic 1 rom, then load it in an emulator.

~UltaGamma, romhacking.net
