Sonic1Jammed:

Sonic 1 with jam layouts and features wrapped up in a nice options menu

The Main features:

- includes Revision 00, Revision 01, Easy and Original Layouts. (Original is just Revision 01 but with a fix to prevent jumping over the level in SLZ2.)

- Can enable or disable the level order for easy mode separately from Easy mode itself. (Easy mode has files for every level, unsure if they're different from normal I never checked)

- Can enable or disable the spindash

- Same with Time Overs

- Switch bug behavior between original and Jam's (or S2 I guess)

Both patches are the same they just correspond to the two most common revisions of the game. Steam version used Revision 1 if you have that.

v2.1.1 changes:
Fixes bosses not actually using easy hit count due to typo.

v2.1 changes:
Fixes the rest of the bosses in easy mode not having the smaller hit count.

v2.0 changes:
Big update from devon fixing a lot of easy mode things and adding in missing features:

Includes:
- Port over easy mode Final Zone boss
- Apply easy mode hit count for Labyrinth Zone boss
- Fix spike bug not being disabled
- Default to 3 continues on start for easy mode