Spider-Man VS Kingpin DX
December 29th 2021
BillyTime! Games
--------------------

Spider-Man VS Kingpin DX in a complete overhaul of Spider-Man VS Kingpin with several fixes, tweaks and new features!

Features:
-------------------
*Faster Crawling (In most cases)
*Web Swing no longer uses web (If you have web.)
*Regenerate health faster at apartment
*Regenerate web at apartment
*Spider-Man has faster attacks
*2x invulnerability time when hit
*SRAM Function! (Saves all progress and Options!)
*New Costumes with exclusive powers!!!

Amazing Fantasy 15
-------------------
*3x invulnerability time when hit

Armored Spider-Man
-------------------
*2x maximum health

Symbiote Spider-Man
-------------------
*Deals extra damage with all attacks (Until Stage 8)
*Infinite webbing

SRAM Function
--------------------
Saving:
Game saves at the start of a new level.

Loading:
Hold B when at game boot.

Changelog:
--------------
v1.1
--------------
*Nerfed Gorilla in Stage 4

V1.2
--------------
*Keys can now be entered in any order without penalty in stage 8
*Boss invulnerability has been restored to normal to close a soft lock bug
*2x Damage for Symbiote suit is revoked on stage 8 to close a soft lock bug

v1.3
---------------
*Fixed branch causing Spider-Man to deal 0 damage to enemies

v1.4
---------------
Game returns to the sega screen instead of crashing when idling at the title screen for too long.

How to Patch:
--------------------
1.Grab a copy of Spider-Man (World) (Sega).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file