Space Invaders 91 (Mega Drive)
Traducci�n al Espa�ol v1.0 (05/04/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Space Invaders 91 (U) [c][!].bin
MD5: b12002f1e35c5116dc4a2a8d64b4687e
SHA1: d8046f1c703ea7c2d7f9f3f08702db7706f56cb4
CRC32: bb83b528
262.144 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --