Socket - No Low Health Sound
Aug 6th, 2025
Billy Time! Games
--------------------------------
This is a simple patch is designed to remove the low health alarm from Socket for Sega Genesis.

How to Patch:
--------------------
1.Grab a copy of Socket (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file