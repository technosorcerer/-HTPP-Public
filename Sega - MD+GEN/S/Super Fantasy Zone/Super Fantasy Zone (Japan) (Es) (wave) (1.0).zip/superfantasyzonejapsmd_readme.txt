Super Fantasy Zone (Mega Drive)
Traducción al Español v1.0 (24/07/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Super Fantasy Zone (Japan).md
MD5: f5683f3b2c24cdd7bc6771ea87efeacf
SHA1: 14dc8568205f3b1b89ce14b9412541ce4ae47f91
CRC32: 767780d7
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --