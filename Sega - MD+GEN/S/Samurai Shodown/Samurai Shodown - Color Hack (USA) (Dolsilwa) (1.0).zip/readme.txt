Samurai Shodown (USA) Color Hack

Pyrons's color hack of Samurai Shodown is great but i think that some stages could look better. So i've made this simple color hack.

v. 1.0 changes:
* tweaked colors of all stages,
* tweaked character colors

Just apply .ips patch on original rom. 

Credits: to Pyron for creating original hack.

Hope you'll like it.

Dol.