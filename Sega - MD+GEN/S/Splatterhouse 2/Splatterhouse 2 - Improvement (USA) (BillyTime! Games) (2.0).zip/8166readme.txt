Super Splatterhouse 2
Oct. 26th 2023
BillyTime! Games
--------------------
This patch is designed to add support for Alternate costumes and a save function to Splatterhouse 2.

How to use:
--------------------
By holding B and pressing start at the Namco screen, 
Rick will have a version of the Terror Mask from the Japanese version of Splatterhouse 2.

SRAM:
--------------------
Saving:
Game saves after losing a life.

Loading:
Select password at the main menu. You game will load automatically.

Saves:
*Current Level
*Current Difficulty
*Selected Mask

How to Patch:
--------------------
1.Grab a copy of Splatterhouse 2 (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file