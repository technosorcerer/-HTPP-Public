Spider-Man and Venom - Maximum Carnage
Traducci�n al Espa�ol v1.1 (17/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Spider-Man and Venom - Maximum Carnage
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Spider-Man and Venom - Maximum Carnage
-----------------
Beat em up de Spider-Man para Mega-Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

V1.1: Arreglado Gata Negra y palabra repetida.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Spider-Man and Venom - Maximum Carnage (W) [!].bin
2.097.152 bytes
CRC32: 8fa0b6e6
MD5: 75af3f1e3b16d725cac258bfafaaea8a
SHA1: 43624536cbebd65232abe4af042c0fa4b0d9e3b7

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --