Maximum Carnage - XP System
Nov. 29th 2024
BillyTime! Games
--------------------
This patch is designed to add a XP level system to Spider-Man & Venom in Maximum Carnage
for the Sega Genesis.

How it works:
--------------------
Players gain levels based on score. Level cap is 15. Levels are lost upon continuing.

XP GAINS:
Lvl 1.:Increased Defense (20,000 POINTS)
Lvl 2.:Increased Damage (30,000 POINTS)
Lvl 3.:Increased Damage (40,000 POINTS)
Lvl 4.:Increased Damage (50,000 POINTS)
Lvl 5.:Increased Health Recovery (60,000 POINTS)
Lvl 6.:Increased Damage (70,000 POINTS)
Lvl 7.:Increased Damage and Defense (80,000 POINTS)
Lvl 8.:ITS MORBIN' TIME! (100,000 POINTS) *When available*
Lvl 9.:Increased Damage (200,000 POINTS)
Lvl 10.:Increased Defense (300,000 POINTS)
Lvl 11.:Increased Damage (400,000 POINTS)
Lvl 12.:Increased Damage (500,000 POINTS)
Lvl 13.:Increased Damage (600,000 POINTS)
Lvl 14.:Increased Defense (700,000 POINTS)
Lvl 15.:Extra Life at Level Start (900,000 POINTS)

How to Patch:
--------------------
1.Grab a copy of Spider-Man . Venom - Maximum Carnage (World).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file