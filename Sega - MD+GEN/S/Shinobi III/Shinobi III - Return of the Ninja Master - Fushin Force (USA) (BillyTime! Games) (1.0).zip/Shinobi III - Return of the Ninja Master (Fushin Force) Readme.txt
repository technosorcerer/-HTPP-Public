Shinobi III - Return of the Ninja Master (Fushin Force)
Oct. 8th 2025
BillyTime! Games
--------------------
This is a simple patch for Shinobi III - Return of the Ninja Master on Sega Genesis that enables multi-jumping in midair when Fushin magic is used.

An addition SRAM enabled patch is provided.

How to Patch:
--------------------
1.Grab a copy of Shinobi III - Return of the Ninja Master (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file