Shadow Dancer (World) color hack

Shadow Dancer is quite a fun game, but it looks a bit plain. This color hack aims to make it a little bit colourful

v. 1.0 changes:
* tweaked all stages,
* tweaked title screens,
* tweaked level slider,

This hack goes well with "Shadow Dancer - 3 Hitpoint" patch by Nemesis_C

Just apply .ips patch on original rom. 

Hope you'll like it.

Dol.