Sword of Vermillion - Invincibility Frames
Aug. 20th 2023
BillyTime! Games
--------------------
This patch gives the player character a longer period of invulnerability after receiving damage in Sword of Vermillion by tripling the amount of time the player is invincible. 


How to Patch:
--------------------
1.Grab a copy of Sword of Vermilion (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file