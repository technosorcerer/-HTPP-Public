Streets of Rage Plus
Aug. 26th 2024
BillyTime! Games
--------------------
This patch is a combination patch, adding several new features to Streets of Rage.

Hi-Score SRAM
--------------------
Saving:
Scores save after Initials are entered. Score, Name, Round and Difficulty will be saved across the entire Top 10 players.

Loading:
Scores load upon boot. If checksum fails or it is your first time booting, default scores are loaded.

Expanded Alternate Colors!
--------------------
In a one player game, at the select screen press any button to receive one of many new colors for each character.

A - Original SOR1 Color
B - Alt Color 1
C - Alt Color 2
Start - Alt Color 3
B+C - Alt Color 4
A+B - Alt Color 5
A+C - Alt Color 6

Note: Alternate colors are disabled in two player mode. If player two joins, original colors are restored on the next stage. New palettes have cosmetic changes to global palette (Items, Background elements, etc...)

Bad Ending in Single Player
--------------------
When Confronting Mr.X in Stage 8, Say yes to become his right hand man. After returning to Stage 8, Mr.X will confront you. Defeat him to become the new boss. 

Six Button controls!
--------------------
New buttons have been added with brand new functions!
*Hold Y (Any direction) - Sprint
*Hold Y (When thrown) - Land Safely
*Z - Back Attack

Difficulty Randomizer
--------------------
Press mode during the introductory cutscene to skip to the title screen. From there enemy health and aggression will randomize. 

*Note: randomizer turns off if game returns to demo mode.*


How to Patch:
--------------------
1.Grab a copy of Bare Knuckle - Ikari no Tetsuken ~ Streets of Rage (World).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file
