Streets of Rage - Bad End 1P
Aug. 1st 2024
BillyTime! Games
--------------------
This patch allows players to reach the bad ending in Streets of Rage when playing Single Player.

How it Works
--------------------
When Confronting Mr.X in Stage 8, Say yes to become his right hand man. After returning to Stage 8, Mr.X will confront you. Defeat him to become the new boss. 


How to Patch:
--------------------
1.Grab a copy of Bare Knuckle - Ikari no Tetsuken ~ Streets of Rage (World).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file
