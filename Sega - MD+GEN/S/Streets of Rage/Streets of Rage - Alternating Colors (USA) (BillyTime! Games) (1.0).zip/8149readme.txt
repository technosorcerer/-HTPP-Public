Streets of Rage - Alternate Colors
Oct. 19th 2023
BillyTime! Games
--------------------
This patch is designed to add new alternate colors in Streets of Rage.

How it works
--------------------
In a one player game, at the select screen press any button to receive one of three new colors for each character.

A - Original SOR1 Color
B - Alt Color 1
C - Alt Color 2
Start - Alt Color 3

Note: Alternate colors are disabled in two player mode. If player two joins, original colors are restored on the next stage.


How to Patch:
--------------------
1.Grab a copy of Bare Knuckle - Ikari no Tetsuken ~ Streets of Rage (World).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file
4.Compatible with Streets of Rage Hi-Score SRAM, add SRAM patch second.
(https://www.romhacking.net/hacks/6199/)