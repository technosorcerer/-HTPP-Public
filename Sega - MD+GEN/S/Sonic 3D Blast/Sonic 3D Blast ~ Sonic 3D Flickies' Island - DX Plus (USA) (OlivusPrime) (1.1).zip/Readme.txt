--SONIC 3D DX Plus v1.1--

In 2017 Jon Burton released his director's cut of Sonic 3D Blast, which provided 
an improved way of playing a game that pushed the Sega Mega Drive to its limits. 
Since Burton didn't possess the source code for the Sega Saturn port of Sonic
3D Blast, he was unable to apply the same changes to that version of the game.

The aim of this hack is to apply some of the stylistic changes of the Sega 
Saturn version of the game to the Mega Drive Director's Cut, within the limits
of the Mega Drive hardware. Namely, this hack adjusts almost every colour
palette in the game to match the more realistic/nuanced visuals of the Saturn 
version.

Every scenario in the game has been painstakingly visually compared to their 
counterparts in the Saturn version to create visuals as accurate to that version
as possible. The Saturn version's special effects were turned off using an
emulator in order to determine the most authentic look. Of course, the changes
had to be done a) within the Mega Drive's limited colour reproduction abilities,
which meant that some palettes are not a direct match, and b) with respect to
elements in the game which share the same palettes, meaning compromises were
sometimes made to ensure that other elements in a level, such as enemies or
items, didn't look too far off from their original appearances.

Two patches are included - the standard DX Plus patch, as well as an extra
version with most of the music in the game removed, allowing you to listen to
the Saturn version's soundtrack (or indeed, any music of your choice) on an
external device without having to mute the game entirely.


-Patching-

Apply the desired xdelta patch to an unmodified Sonic 3D Blast/Flickies Island 
ROM. These patches should not be applied to a ROM that has had the original
Director's Cut patch previously applied.


-Palette Changes Breakdown-

Intro/Menus/Cutscenes
I tried my best to make the intro cinematic look less harsh than before.
Interestingly, the establishing shot of the island and the shot of Sonic
running each use their own palettes, so these could be customised individually.
The shot of the island looks far more natural now in particular.
Sonic's skin tone was then made lighter on the title screen (which minimally
affected the title text and Flickies too), and the menu tiles in the control
and sound test menus were coloured grey to match the main menu tiles in the
Saturn version.
It's worth noting here that the "cutscenes" found in the main game were
generally left alone, as they use some colour sharing tricks that cause them to
usually look pretty messy with altered palettes.

Sonic, Tails, Knuckles, HUD, Rings and Springs
All of the above elements share one specific palette throughout the game. The 
shades of blue were minimally adjusted, and similarly the shades of beige were 
desaturated slightly. The shades of red were then brought closer to cherry red
from their more orange-y shade in the original game, giving all of these
characters and elements a more subdued and naturalistic look. Of note is that
the HUD in particular now almost exactly matches that in the Saturn version.

General Enemies and Gates
Plenty of enemies in the game use a variety of different colours (some sharing 
their shades with those of the level they inhabit, see below), but the shades of 
purple on many of the enemies were shifted to be redder and the shades of gold 
made more subtle. These purples then also apply to the gates between each level 
section.

Special Stages and Chaos Emeralds
Special Stages have been left alone (since there's no direct match for them in 
the Saturn version) but each of the Chaos Emeralds has been recoloured to match
their corresponding version in the Saturn version. The cutscene once all of the
emeralds have been obtained uses these palettes in a very specific way, so the
Green Grove emerald (green) and Gene Gadget emerald (orange) have been swapped
for the entirety of the game.

Dr. Robotnik/Final Boss
There are three Robotnik palettes in the game - one for his Green Grove boss 
fight, one for all other Act 3 boss fights, and one for the Final Fight. 
Oddly, one of his shades after being hit by Sonic is stored much earlier in the
ROM than any other colour data, which at first made me think that I wouldn't be
able to get him looking how I wanted. The teal tint his ship takes on in most
boss fights was removed, his ship now being straight grey. His ship is still
shaded blue in the Green Grove boss fight, since he shares a palette with a
river at the very bottom of the stage, but this blue is much less teal and
saturated than before. His machine in the Final Fight has some additional
adjustments, including a darker shade of brown for the moustache.

Green Grove
Perhaps the most radically changed Zone in the game, lots of compromises had to
be made with the colours in these levels, as the Mega Drive isn't capable of 
reproducing some of the subtleties of the Saturn colours here. As such, some of 
the floor tiles are closer to a sand colour than the terracotta colour they have 
on the Saturn, and the rockwork walls are more saturated. The rivers/waterfalls 
were given a darker and more subdued colour scheme, which also meant that the 
enemies now look closer to how they were originally (as they share a palette 
with the waterfall in the Director's Cut). For accuracy's sake, a Director's Cut 
change was reversed - the orange laser bolts shot by the turrets have been
changed back to green.

Rusty Ruin
The brickwork in this Zone was made much darker and less saturated than before.
This does mean that a couple of the darkest shades are now crushed together, but
every other combination of colours I could come up with either looked too
bright/flat or too colourful. The floor tiles were also made darker, with the
yellower ones now being closer to brown. One change I wanted to make was to
subdue the colours on the Bee enemy in these levels, but since this enemy shares
its palettes with the flames and flame shield in this Zone, I left it alone.

Spring Stadium
Not too many changes to this one - primarily the brighter shades of pink-grey in
the environment were desaturated to become shades of grey. The shades of yellow
in the environment were also given a contrast boost so that the yellow shapes at
the edges of the stage would bear the lighting they have in the Saturn version.
The floor tiles were desaturated slightly and their pattern swapped.

Diamond Dust
I wanted to do more with this one, but the icy floor tiles already matched 
their appearance in the Saturn version and shared their shades with much of the 
environment, so not a lot could be done. One of the brighter shades of blue was 
made grey to give the snow a slightly more neutral look, and one of the darker 
shades made teal to introduce the teal tint that the icy walls have in the 
Saturn version. The floor tiles were darkened and their pattern kept the same - 
the icy tiles should have had their pattern reversed, but this would have thrown
off the colours of the rest of the Zone.

Volcano Valley
This one maybe had the most changes behind Green Grove, with the biggest being 
the lava. While the lava is coloured orangey-red in the Mega Drive version, it's 
bright orange in the Saturn version, which creates an entirely different look. 
The problem with following this was that all of the enemies, one of the Flickies 
and the flame shield all use the same palette in this Zone, so the shades of red 
found on those are now bright orange. This was a concession I was willing to 
make, seeing how the lava makes up such a substantial proportion of the Zone 
compared to the other elements. Otherwise, the rockwork was given the darker 
volcanic look it has in the Saturn version, the yellow crystals were given an 
emerald green colour, and the floor tiles were darkened, with more saturated 
yellow tiles, and had their pattern reversed. The result is a much more intense 
and dynamic look for the Zone.
There's an odd issue in the boss fight of Volcano Valley, wherein the floor
tiles share their palette with Robotnik, rather than using the palette they
have for the rest of the zone. Unfortunately there wasn't anything I could do
to fix this one, nor any feasible concessions I could make.

Gene Gadget
Some subtle changes to this Zone that add up to a distinctly different look. 
Almost all shades of blue-grey were changed to straight grey, the shades of
orange-yellow were changed to straight yellow to match the hazard stripes in the
Saturn version (and consequently, shades of orange were given a golden tint so
that other background objects would still look natural), the shades of blue on
the beacons/panels were brightened, and the floor tiles were brightened and
saturated, with their pattern reversed.

Panic Puppet
This was a slightly tricky one, as any changes I made affected the giant 
Robotnik figure in the second Act. Overall the greys of the level were given a 
yellow tint, the bright orange-yellows were brought closer to yellow as in the 
previous Zone (for the same reason as in that Zone), and the oranges were made 
more subdued. For some reason, the enemies in Act 2 have completely different 
colour schemes between the two versions of the game, so they were given the new 
purple and yellow scheme found in the Saturn version, which didn't affect 
anything else.

The Final Fight
The floor tiles were recoloured to match the glass/marble look they have in the
Saturn version, the stars glittering around the stage were updated to match
their subtler colours on the Saturn, and Robotnik's machine was given the
colours detailed above.


-Music-

I've created two versions of this mod - one which retains the original Jun
Senoue music, and one which removes all music from the game, allowing you to 
listen to the Richard Jacques soundtrack on a separate speaker as you play,
without having to mute the game entirely. While this is the primary intention 
of this change, this also ultimately means that you can play whatever music you 
like whilst playing the game. A few incidental pieces of music have been kept 
due to their brevity and similarity to the Saturn equivalents - namely the Act
Clear, Extra Life, and Chaos Emerald jingles.

Of course, an ideal final version of this hack would properly implement the
Saturn soundtrack through MD+ or MSU-MD support. While this is far beyond my
capabilities, if anyone with the know-how and time is interested in
contributing this, please get in touch via the ROMhacking.net forum, as it
would be much appreciated.


-Changelog-

Version 1.1
- Fixed an issue where the Green Grove emerald (orange) displays as green in the
  special stage results screen
- Fixed the Panic Puppet background being grey instead of black
- Various colour palette improvements:
	- Opening - Sega logo returned to original colour, mountains/temples made
	  grey, blues improved
	- Green Grove - Blues in water improved, increased green saturation slightly
	- Rusty Ruins - Brickwork darkened, increased green saturation slightly
	- Spring Stadium - Shadows darkened/blue tint removed, increased yellow
	  saturation slightly
	- Volcano Valley - Magma scenery darkened, lava highlights improved
	- Gene Gadget - Blue tint in shadows removed, brightened blue scenery
	- Panic Puppet - Improved shadows
	- Final Fight - All greys on Robotnik machine made darker
	
Version 1.0
- Original release
