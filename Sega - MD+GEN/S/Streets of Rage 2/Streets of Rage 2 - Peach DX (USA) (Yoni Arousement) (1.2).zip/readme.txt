Streets of Rage 2: Peach DX

By Yoni Arousement

http://yonihq.blogspot.com

Princess Peach befriends Roll from Mega Man. Together,
they must fight the Koopa and Foot Clans lead by Bowser
and one of Shredder's cronies.

To use, patch over a vanilla US Streets of Rage 2 ROM.