Streets of Rage 2 Difficulty Randomizer
Nov. 6th 2023
BillyTime! Games
--------------------
This patch is designed to introduce dynamic enemy placement in Streets of Rage 2 for the Sega Genesis.


How it Works
--------------------
As you play, the internal difficulty counter is randomized and will introduce enemies from Very Easy all the way to Mania difficulties with various speeds, health bars and aggression. No playthrough will ever be identical! 

Note:
End of round bonuses will be randomized
Semi compatible with SOR2 Hi-Score SRAM (https://www.romhacking.net/hacks/6231/)


How to Patch:
--------------------
1.Grab a copy of Streets of Rage 2 (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file