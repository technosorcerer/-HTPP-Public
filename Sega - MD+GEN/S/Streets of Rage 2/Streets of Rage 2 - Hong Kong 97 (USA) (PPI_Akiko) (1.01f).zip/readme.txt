Streets of Rage 2 Hong Kong 97
This is an ips patch for the Genesis roms "Streets of Rage 2 (USA)".

Main Patch
Please patch SOR2XX-HK97.ips to Streets of Rage 2 (USA) 

Sub Patch 
Please patch over the patched rom.
SUB_REPAIR_TO_SOR2BGM.ips is reverting BGM to the original Streets of Rage 2. 
