How to use:

MD+INAStreets of Rage 2 (U) [!].zip

Unzip this file.
Patch MD+INAStreets of Rage 2 (U) [!].ips over the main hakrom (ex. INAStreet of Rage 2(U).bin) and rename it "MD+INAStreets of Rage 2 (U) [!].bin" , which is the same as the cue sheet.
Next, unzip md+OGG_SOR2IDOLNEXT_SoundPak.7z, then place  all ogg files and MD+INAStreets of Rage 2 (U) [!].bin and MD+INAStreets of Rage 2 (U) [!] .cue in the same folder.
Boot MD+INAStreets of Rage 2 (U) [!].bin by Retroarch's Genesis_Plus_GX core.
When playing with MegaEverdrive Pro or similar, decode all ogg files to wav files and change the cue sheet to the one in the folder "wav_cue_sheet".


MSU-MD_INAStreets of Rage 2 (U) [!].zip

If you want to play with MSU-MD, as in the case of MegaEverdrive Pro mentioned earlier, first convert the ogg to wav, then extract MSU-MD_INAStreets of Rage 2 (U) [!] .zip and patch the MSU-MD_INAStreets of Rage 2 (U) [!] .ips over the main hakrom.
Rename it "MSU-MD_INAStreets of Rage 2 (U) [!].bin"  , which is the same as the cue sheet.
Then place all wav files and MSU-MD_INAStreets of Rage 2 (U) [!].bin and MSU-MD_INAStreets of Rage 2 (U) [!].cue in the same folder.
Note: The MSU-MD version has some bugs, such as the ending not being displayed correctly.

Credits:
MD+ Patch by infinest
MSU-MD Patch by infinest & converted for MSU-MD by Krikzz
