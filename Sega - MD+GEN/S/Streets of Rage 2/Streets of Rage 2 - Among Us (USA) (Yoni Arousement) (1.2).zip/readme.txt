---------------------------------------------------------------
Streets of Rage2: Among Us

By Yoni Arousement

https://yoni2.blogspot.com
or
www.yonih2.us

(New Blog URL since Google basically pulled a Tumblr in 2022)
---------------------------------------------------------------
I felt that an Among Us themed Streets of Rage 2 ROM Hack
needed to exist.

Gens emulator is recommended for this ROM Hack... except its
built-in AVI recorder crashes the emulator during certain
transitions. Gens is less lilkely for the ROM Hack to have
random bugs that would occur on more accurate emulators, and a
Model 1 Sega Genesis.

So... basically I forced myself to make this ROM Hack. I felt
that SOR2 ROM Hack themed after Among Us must exist. So I
decided to use what I've learned over the years from editing
SOR2. Did I have fun while making this? Yes I did! Was it also
stressful? Yes, because of the possible bugs from editing
enemies.

SOR2: Among Us is based on version 0.9 of SOR2: Syndicate Wars,
a ROM Hack by Red Crimson and gsaurus that not only makes all
the enemies playable (barring Vehelits), but converted their
graphics from compressed to uncompressed, so one can freely
customize their sprites. It also added Adam to the roster, and
a Survival Mode.

A later version of SOR2: Syndicate Wars was first publicly
shared in 2016, when the Genesis Collection on Steam was
updated with a Unity Hub and added support for Workshop items.
This new version added Zan and Roo to the roster, made enemies
use the alt palettes, lets you start from any area, added a
self-destruct command for Particle, the list goes on.

However, there are huge reasons I still prefer editing v0.9
over the 2016+ version (2.x). In addition to things being in
different addresses again (that's how assembly is), Pancake
wouldn't work properly with that version at the time I first
checked it out. Upon editing a character and loading the 2016+
version, and reaching the character select screen, the game
literally filled the whole VRAM with my character's tiles.

Editing enemies in SOR2: SW can lead to all sorts of problems
that must be reversed in a Hex Editor, such as editing Big-Ben
making the counter of vaulting over an enemy not reset. So,
one word of advice would be to make backups of your ROM Hacks.

Starting with Abadede's Back Slam sprites, I needed to start
generating sprites in Old Addresses (unused art tiles that I
blanked out), which is risky but worthwhile.
---------------------------------------------------------------
What programs did you use to create this ROM Hack?

Notepad, to take notes of course! In addition:

Gens: My main emulator used to test my ROM Hacks.

BizHawk: Usually, I use BizHawk to verify the sprites in case
they display incorrect art, in which case I can generate
duplicates of the same sprites that glitched on more accurate
emulators, and on an actual Genesis.

gsaurus' tools:

Pancake 2 v1.6: The bread and butter of tools, used to
customize character sprites, animations, hitboxes, etc.

Mega Drive Voice Editor: This program lets you easily replace
voice samples in Sega Genesis games, including guides for games
like Streets of Rage 2 & 3, and the European version of fellow
Yuzo Koshiro game The Story of Thor/Beyond Oasis.

Palettes of Rage: To customize the color palettes. On a few
occasions, I created my own guides.

RGBGen: Converts colors to Genesis format.

Tile Layer Pro: My Tile Editor of choice, TLP was a program I
used back in the day to view tiles. I also use it to blank out
unused/replaced art tiles and insert edits made to misc.
graphics such as fonts, items, icons and other HUD elements.

Paint.NET v3.5.10: My main tool to create and/or edit sprites
and artwork. I actually prefer to use an older version of this
program, for reasons I forget...

GraphicsGale: To create indexed sprite images that are to be
inserted into a SOR ROM.

GoldWave: To edit sounds. Usually I downsample sounds up to
22050hz. What's absolutely required, though, is to encode the
sounds to 8-bit mono, so they can properly be inserted into a
ROM via MDV. Wavosaur can be alternatively used for this
purpose.

Hex Workshop: My favorite Hex Editor to use. I make so many Hex
Edits with this program. One godsend of this tool is that you
can compare the Hex Values of two different files at once,
which helps me tremendously in reversing bugs. XVI32 would do
an okay job as a Hex Editor.

Spread32: A spreadsheet tool. As of this writing, I'm not too
used to using these tools. In the case of SOR2, I usually use
it for enemy names. I might suggest also creating a spreadsheet
for the Duel Mode palettes. Speaking of which, people should
make videos of Duel Mode matches in these Streets of Rage ROM
Hacks!
---------------------------------------------------------------
How to Patch:

Patch SOR2_AmongUs.ips over a regular US Streets of Rage 2 ROM,
via Lunar IPS.
---------------------------------------------------------------
Sub-Patches:

SOR2_AmongUs_NoGore:
Disables the gory deaths, and makes the characters' sprites
blink when they die.

SOR2_AmongUs_SoundDriver:
Reverts changes made to the Sound Driver.

Sub-Patches can be applied over a patched SOR2_AmongUs ROM.
---------------------------------------------------------------
Who's that little witch that has nothing to do with Among Us?

Meet Maddaneen, the witch! She's just one of my OC's who
appeared in an old comic series of mine:

https://web.archive.org/web/20121114180901/http://lorenzothecomic.blogspot.com/
---------------------------------------------------------------