Streets of Rage 2 - XP System
Sep. 1st, 2024
BillyTime! Games
--------------------
This patch adds an XP System to Streets of Rage 2 on the Sega Genesis.

How It Works:
--------------------
Players gain a level every 100,000 points. 
With each level players deal one more point of damage and take one less point of damage. 
Players reach max level at 900,000 points.

Reverse XP:
--------------------
Players gain a level every 100,000 points. 
With each level players deal one less point of damage and take one more point of damage. 
Players reach max level at 900,000 points.

How to Patch:
--------------------
1.Grab a copy of Streets of Rage 2 (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file