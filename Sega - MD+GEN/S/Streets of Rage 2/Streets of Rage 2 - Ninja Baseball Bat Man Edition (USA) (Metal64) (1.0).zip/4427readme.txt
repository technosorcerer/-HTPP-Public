Hack Name: Streets of Rage 2: ninja baseball batman edition

A Hack Of: Streets of Rage 2!

Hacked By: Metal64

Youtube channel: https://www.youtube.com/user/MetalOverlord64

                           SPRITES

Roger: https://www.spriters-resource.com/arcade/ninjabaseballbatman/sheet/70178/
Jose: https://www.spriters-resource.com/arcade/ninjabaseballbatman/sheet/70205/
Straw: https://www.spriters-resource.com/arcade/ninjabaseballbatman/sheet/69973/
Ryno: https://www.spriters-resource.com/arcade/ninjabaseballbatman/sheet/70206/ 
Baseball Bat: https://www.spriters-resource.com/arcade/ninjabaseballbatman/sheet/110935/
Submarine Ball: https://www.spriters-resource.com/arcade/ninjabaseballbatman/sheet/70189/

                      SOUND EFFECTS:
https://www.youtube.com/watch?v=MUQcKLtixSc

Credits:

Gsaurus for creating the Pancake2v16 	
Alvin Earthworm and Tonberry2k for ripped the ninja baseball batman sprites
aguila822 for ripped the ninja baseball batman sound effects
