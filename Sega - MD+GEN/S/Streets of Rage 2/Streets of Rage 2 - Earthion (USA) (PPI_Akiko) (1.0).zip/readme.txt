Main Patch : SOR2EARTHION.ips
-This is an ips patch for the Streets of Rage 2 (USA) ROM for Genesis Mega Drive.

Overview 
-The AXEL from the classic Streets of Rage 2 has been replaced by his own YK-IIA from the latest shmups's Earthion.

Modification
-Strikes recover the energy consumed by SP attacks or thrown.
-The BGM has been partially changed.
-(If you press A+C at the same time in Player Select (if successful, the voice of the MAX's throw will be played.) You can play with the pre-changed BGM.(Excluding Round 6-2))
-Enemy placement was changed.
-The font was changed.
-Increased scores by one digit
-Region Free
-No Friendly Attack
-You can use the same character.
-Air combos can be performed.
-Foward, Forward, A is BLITZ, such as Ground Upper. In addition, it changes to Hold B motion from the Round 6.
-Y button is the same as B+C.
-You can dash.

Special Features (AZUSA ONLY)
-The more health she has, the higher her attack power outside of throws. (Weakened by low HP. When HP is low and attack power is at its low, the attack power of the throw is increased as a remedy.)
-You press Back, Back, A after performing Forward, Forward,  A, you can perform Back BLITZ.


Additional Patch : SUB_HYPER.ips
-Apply this patch over this hackrom.
-It does not recover from strikes, but you can defeat the enemy with a single blow, and You can use the changed FFA from the beginning.

A patch linked below can be use, too.
-Streets of Rage Team Battle
https://romhackplaza.org/romhacks/street-of-rage-2-team-battle-genesis/