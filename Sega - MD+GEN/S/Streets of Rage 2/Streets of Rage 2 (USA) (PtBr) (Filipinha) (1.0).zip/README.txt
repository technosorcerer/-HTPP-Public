xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

NOME DO ARQUIVO ORIGINAL: Streets of Rage 2 (U) [!].bin
CRC32: E01FA526

Foi utilizado o programa "Lunar IPS" em sua versão 1.02 
para criar o arquivo .IPS contido neste .ZIP .

Em caso de algum erro na hora de aplicar o patch, verifique 
o CRC32 de sua ROM e, em último caso, busque a mesma versão 
do Lunar IPS que eu utilizei.

xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

Autor: Filipe Gomes - Filipinha

Ferramentas utilizadas: Hex Workshop, TileMolester e 
Streets of Rage 2 ROM Editor v2.87.