********************************************************************************
*                 BABE KNUCKLE II: REQUIEM OF THE DEADLY BATTLE                *
*                      System Changes and Character Guides                     *
*                                By 120Pythons                                 *
********************************************************************************

********************************************************************************
Part I. Summary
********************************************************************************
In this authors first ROM hack, the 4 playable characters in Streets of Rage 2 have been completely replaced with powerful female fighters from obscure games released in the 90s. Some of the bosses have been completely replaced with new characters who are more deadly. The item placements in each stage have been remixed significantly and many other changes were made to make the game more challenging without being too brutal. Some enemies were buffed and some annoying ones were nerfed. The unused music tracks are now used in later levels. Many new mechanics and features have been added as well, such as recovering from knockdowns in the same way as throws, an XP system that makes you more powerful the higher your score is, and 6 Button support so you can use Back Attacks with a single dedicated button press. The slow jump glitch that caused your jump startup to take 4 extra frames after hitting with certain attacks has also been fixed to make the gameplay smoother.



********************************************************************************
Part II. Change List
********************************************************************************

The detailed differences between this hack and the original Streets of Rage 2 (USA) are listed below:


* The four player characters are Blaze Fielding (Streets of Rage), Yuka Takeuchi (Super Variable Geo), Linn Kurosawa (Alien VS. Predator), and Mademoiselle Lady (Gourmet Warriors).
* The 3 guests have almost all of their moves from the games they come from.
* All of the player characters are very powerful and have totally different playstyles and strategies. Check the character guides section below for more information.
* 4 New bosses. The bar has hired a new bouncer and waitress. And a familiar face is waiting to terminate you in the alien cave... Don't get drop kicked!
* Thanks to PPI Akiko, you can now use Back Attacks without breaking your thumbs by simply pressing Y. You can also tech from any knockdown the same way as throws (hold jump+up before hitting the ground)
* Thanks to Billy Time, with the XP system you can increase your characters defense and attack by getting a higher score. Every 100,000 points causes a level up. Many changes have been made to accomodate this and make treasure hunting worthwhile. Cash bags are now worth 5,000. Gold is worth 20,000. All enemies give significantly less points. All 1-Ups have been replaced with money. There is also cash hidden in new places. Can you find them all and get the highest score?
* Remixed item placements. More money overall, less healing items in areas that were too easy and more healing in areas that were too brutal.
* Rebalanced some of the enemies HP and damage output to be less annoying while some later enemies were buffed to compensate for the XP system.
* New color and names for some enemies.
* KO Count can be viewed by pausing the game.
* The music has been changed in a few areas, the 3 unused tracks are now used as well.
* NO CONTINUES. The stakes are higher. Choose your character wisely and make it to the end!
* Default difficulty is set to "Hard" with 5 lives. (This is the main setting the hack was tested with)
* Mania difficulty (Pro) and Level Select are available at the start.
* Thanks to Dha_Lau_Hoo, jump lag glitch has finally been fixed.
* Player characters now have an animation when in the air recovering from a throw.
* Player characters can now move during the slow-motion after defeating a boss. Go for a photo finish!



IMPORTANT: Tips on how to play the new characters are below...

********************************************************************************
Part III. Character Guides
********************************************************************************
A = Special
B = Attack
C = Jump
Y = Back Attack
+ = Press At Same Time
> = Press In Sequential Order.

Each character is a fighting game archetype with different strengths and weaknesses. 


    
    -BLAZE: The Grappler. She has been training with Max.

Pros: The most powerful character, extremely high damage, great range, best blitz move and offensive special for movement and positioning, wide variety of grapple attacks that cause high splash damage, fastest pipe and sword swing that also hits from behind.

Cons: Slowest walk speed, slowest jab, lowest jump height and slow aerial attacks than can leave her vulnerable during recovery, requires good timing and spacing, must have skill with backwards jumps and backgrab manipulation to play optimally.

MOVELIST
* Power Slide: Forward>Forward>B. Her main tool. Does very low damage but can be used to move around much faster and to set up grabs. Unlike Max's slide, hers does not knockdown. With proper spacing she can jab then slide through an enemy and hold back to instantly combo into a back grab for Atomic Drop.
* Reverse Kikosho: Y or B+C. Very fast and high damage at close range. Her best tool to keep enemies away and her highest damaging combo ender outside of grabs. After the 3rd attack in her basic combo you can turn around and use this move to make it a combo ender.
* Atomic Drop: (During back grab) C>B while falling. The most damaging move in the game, invincible and does full splash damage. Her gameplan revolves around getting back grabs to land this move on top of crowds as much as possible. 
* Air Throw: (During front grab) C>B while rising. Decent damage, invincible, fast and good area of effect. Good for tossing a grabbed enemy into another one infront of you at a distance.
* Hair Flip: (During front grab) Neutral B. Slow start up and leaves her vulnerable but has decent range and it is her second most damaging attack. Knee>Knee>Hair Flip is slow and risky but her most damaging combo during a grab, dealing even more than an Atomic Drop.
* Judo Throw: (During front grab) Backward+B. Lowest damage throw but fast and fully invincible. Gives you a ton of frame advantage to attack the enemy again as they are getting up.
* Suplex: (During back grab) Backward+B. Similar to Judo Throw but much more damage and slightly less advantage. Decent alternative to Atomic Drop if you want to quickly deal splash damage behind you or dodge nearby enemies with its invincibility.
* Thunder Kick: Forward>A. Fastest horizontal movement in the game, high damage and covers 3/4 of the screen. Line up all of the enemies and tear through them.
* Blue Hand: C>Down+B. Good range jump-in attack, can hit twice with good timing. Very useful for jumping over enemies to hit them on the way down, leading into a back grab.


    
    -YUKA: The Shoto. Karate waitress, has the tools to serve her enemies in any situation.

Pros: By far the easiest character to play, simple and straightforward kit that is highly effective, good damage, fastest jab, best move in the game, only character who can use forward special without losing any health, long range fireball that is fast and high damage, fast jump kicks that have good range, can deal with most bosses easily.

Cons: Weakest grab attacks, worst back throw in the game, her forward special is hard to use as it will whiff and leave her completely open if not in point blank range, only character with no unique movement options, very short range jab, not skilled at using any weapons.
    
* Idaten Soku: Forward>Forward>B. Her "tatsu" and the best move in the game. Forward advancing, multi-hit, tons of invincibility, good range, high damage, 2 frame start up and recovers very quickly. This move is Grand Upper on steroids. It is your go-to.
* Sōryū Geki: Forward+A. "Shoryuken!!" Very fast and extremely high damage when all hits connect, comparable to an Atomic Drop. Can be used without draining HP, so you can spam this and destroy Jet. However, it has no invincibility and you need to be right on a grounded enemy for the knockdown hit to occur or else you will be left open for a long time. An easy way to combo into it is jump down+B right on top of an enemy, jab when you land and then mash forward+A.
* Ki Kō Dan: Y or B+C. "Hadouken!!" Her back attack is a fast fireball. Spammable and does good damage. Very effective at keeping enemies away from you. The little explosion at max range does more damage, it has a distinct sound effect so you will know when you get the bonus damage.
* Ipponzeoi: (During front grab) Backward+B. Shoulder throw. Low damage but invincible and can control crowds, gives much more advantage than her mediocre back throw.



    -LINN: The Zoner. "Anyway, I started blasting..."
    
Pros: The best character at dealing with enemies from a distance, sword and gun give her the best range, highest and fastest jump, unique aerial attacks, good mobility and grab attacks, has the best defensive special in the game, picking up a sword or pipe allows her to use her pistol freely and shoot enemies across the screen.

Cons: Very low damage outside of a few specific moves so her damage is very set-up dependant, her high jump can be unwieldy and hard to use, she expands her hurtbox when jumping leading to her getting smacked out of the air by some attacks, the recovery on her best air attack leaves her completely vulnerable upon landing.

* Koeikyaku: Forward>Forward>B. Low damage blitz move that can be used to switch sides and send an enemy flying behind you. Slow but has invincibility at the beginning so it can be used to go through attacks.
* Helm Splitter: C>Down+B. One of her main tools for approaching enemies from the air and deals good damage. With proper timing it can hit multiple times and do high damage before you start a combo on the ground. You can also do it early in a jump and keep the blade extended to knock enemies down instead.
* Aerial Shots: Forward+C>B. A very unique move. She will shoot enemies on the ground behind her while jumping forward. It covers a huge distance and is useful for creating space. The last shot knocks enemies down, but to get the last shot you need to fully commit to the move and start shooting early in a jump. She has to reload once she lands, so use it wisely.
* Senpuuzan: Neutral A. The best defensive special in the game and her best source of damage. You can move around in any direction while spinning. If you are right on top of an enemy and spin around while in their hurtbox, every hit from both sides will hit them and cause massive damage. 
* Iaikiri: Y or B+C. Very fast back attack that hits on both sides. Useful for crowd control and knocking enemies down quickly since her other options for knockdowns are fairly slow.
* Enemy Jump: (During front grab) Neutral B. Jump off an enemy and go flying in the opposite direction. Invincible and covers a large distance extremely quick. Good for creating space and moving around the screen to get better positioning.
* Suplex: (During back grab) Backward+B. Her main source for dealing decent damage without spending HP, and her best ender because as the enemy is getting back up it lets you set up a backwards jump helm splitter or go for another suplex to loop the enemy. Fully invincible too.
* Sokeiha: Hold B for 1 second and release. Double fist attack. One of her highest damaging attacks and a decent ranged poke to send enemies flying.



    -MADEM: The Pixie. Or in this case, the rushdown fairy.

Pros: The fastest character, has the best walk speed and is the only character who can run, blitz move covers a large distance quickly and can lead into combos, very useful back attack for knocking down groups and hitting enemies in the air, wide variety of different grab attacks that deal high damage and control crowds very well, has a few infinite combos, the best character with the knife.

Cons: Very technical, can be difficult to play and use all of her tools effectively, has a very stubby jab and neutral jump kick, the worst character with the pipe and sword.

* Dash Attack: Forward>Forward>B. Fast and covers a large distance. At close range it will knockdown, at long range you can kick through an enemy and combo into a back grab immediately. Very useful move.
* Satellite Kick: Y or B+C. Advancing high kick that covers a huge distance behind her. Start up is very fast and it also recovers fast. Can completely destroy Jet as an anti air and knock down groups of enemies like bowling pins.
* Body Press: C>Down+B. Her only jump attack that knocks enemies down. Slow startup but has good range and damage. Good timing causes 2 hits for slightly more damage.
* Jump Kick: Forward+C>B. Multihitting jump kick that can combo into itself infinitely with backwards jumps if you time it correctly and have good spacing. Or if you get an enemy against a wall you can  quickly infinite combo them to death too.
* Explosive Pose: Neutral A. Flexin. Gives a ton of invincibility frames and the explosions have very active hitboxes that surround her completely. 
* Fairy Fire: Forward+A. Flaming dive, can adjust how far it travels with left and right directions.
* Fairy Shoot: Hold B for 1 second and release OR (During front grab) Backward+B. Push enemies on both sides. Very fast, great range and damage. Useful for when enemies are closing in from behind while you are dealing with an enemy in front of you.
* Sky High Press: (During grab vaulting) Neutral B. Very fast and sends an enemy flying forward with decent splash damage. 
* Fairy Spin: (During back grab) Neutral B. Her most damaging attack. To get rid of enemies quickly you will be wanting to do Dash Attack from a distance, land behind them, back grab, and then use this move for maximum damage. The last few hits can cause splash damage, giving you some time to set up a grab on another enemy.



Choose your character wisely and have fun!