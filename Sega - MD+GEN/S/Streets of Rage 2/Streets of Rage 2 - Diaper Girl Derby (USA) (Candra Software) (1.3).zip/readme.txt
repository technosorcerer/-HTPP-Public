---------------------------------------------------------------
Streets of Rage 2: Diaper Girl Derby

By Yoni Arousement, formerly Lorenzo The Comic and
Candra Software

https://yonih2.blogspot.com
---------------------------------------------------------------
This ROM Hack was originally uploaded to the Steam Workshop for
the Unity Genesis Collection under a different name during the
Workshop's early years. People would often check out the
submissions that were shared on the Workshop.

It was more of a showcase than something that's actually meant
to be beaten. The previous title that this ROM Hack went by was
meant to reflect on the 2D sprites mashed together with
unrotoscoped model renders.

8 years later, I decided to rename this ROM Hack as a tie-in to
the Diaper Girl Derby series starring Marcella, who wears
spherical underwear passed off as diapers. No, I do not like
realistic diapers.

Seeing as there's quite a niche for a certain subject, I
thought I'd issue an update to reduce the difficulty, and to
make the ROM Hack more beatable. I can confirm that it doesn't
take as long to beat as SOR2: Puyo Wars, at least with Doppel.

Even in the previous revisions, there were still strats you
could use. One thing I learned from watching SOR2 players such
as Anthopants and King_iOpa, is using neutral jump attacks
against Galsia-type enemies. That doesn't mean that I shouldn't
try to tone down the difficulty, as it's a common theme with
the SOR2 hacks I made that replace a lot of characters (enemies
included), namely Girls' Paradise, Doraemon and Among Us.

Testing for random bugs was really scary for me. But how do you
strike a balance between being a complete and utter cakewalk,
and being such a tall order? It beats me.
---------------------------------------------------------------
Hisoka Hosokawa, one of Candra Minsky's neighbors decided to
hold Ropedog, a humanoid dog for ransom. Geo Tech is a female
led coporation known for attracting gullible people. As Candra
is friends with Ropedog, the former is lured into seeking out
for the latter. Candra teams up with one of her friends,
Marcella, Chibiko, a Doppelganger of Arle Nadja who's very
deredere and a clone of Roll produced by enthusiastic
scientists.
---------------------------------------------------------------
How to Patch:

Patch SOR2_DGD.ips over a regular US Streets of Rage 2 ROM, via
Lunar IPS or an online ROM patcher.
---------------------------------------------------------------
Rev. 1.3 Changes (Difficulty Nerf Update)

Palette Changes:
..Changed a color in the Pirates logo in Stage 3 to match other
  parts of the background.
..Alice's 3rd palette is changed from gray to red and orange
  with brighter skin.
..Adjusted Foofa's 3rd palette.
..Suwako uses Monami's 2nd palette as her Duel Mode palette.

Misc. Changes:
..You can now play as most of the enemy characters without
  external cheats or editing RAM, except Ropedog and Hisoka.
  More icons are displayed at the character select screen.
..Gayle and Donna play their walking animation in their arcade
  intro, like Yvette does.
..Going to the character select screen plays a voice clip that
  says "Welcome to the DGD Series".
..Players' KO count properly resets when confirming a selection
  at the main menu, so they don't carry over from the main game
  to Survival Mode.
..Edited a string of text in the ending that I forgot to edit.

Marcella Pan:
..Jab starts up 2 frames faster.
..3rd Attack has more backwards reach.
..Combo Finisher's 2nd Hitbox has slightly more range.
..Defense Special has more range. 1st 2 Hitboxes reach higher.
..Grab Finisher starts up 5 frames faster.
..Back Attack has slightly more range.
..Neutral Jump Attack does more damage.
..Jump Down Attack does more damage.
..Forward Jump Attack does more damage.
..Slide's 2nd hit has slightly more range.
..Offense Special starts up 2 frames faster.
..Offense Special has slightly more range.
..Offense Special does more damage.
..Atomic Drop does more damage (but not as much as Max's).
..Atomic Drop has slightly more range.
..Pipe and Sword Attacks have more horizontal reach.

Chibiko (Tomomi Yaoi):
..Jab has slightly more range.
..3rd Attack starts up 3 frames faster.
..3rd Attack has slgihtly more range.
..Both Combo Finishers startup 2 frames faster.
..Grab Knee does more damage.
..Grab Finisher and Neutral Grab Attack startup 2 frames
  faster.
..Neutral Jump Attack has more range.
..Neutral Jump Attack reaches higher.
..Forward Jump Attack does more damage.
..Back Attack's 1st hit has slightly more range.
..Grand Upper's invincibility is reinstated, also affecting its
  movement.
..Offense Special's later hits that did less damage have their
  damage increased.
..Offense Special's final hit does twice as much damage.

Roll:
..Knockdown sprite is changed to the one used in SOR2: Peach
  DX.
..Jab stays active 2 frames longer and recovers 2 frames
  faster.
..3rd Attack does twice as much damage.
..Combo Finisher's 1st hit does more damage.
..Grab Attack does slightly more damage.
..Neutral Jump Attack has more range.
..Forward Jump Attack is now her Puny Peach, which has more
  reach.
..Forward Jump Attack does more damage.
..Jump Down Attack is like the one seen in SOR2: Peach DX.
  It reaches lower.
..Back Attack starts up faster.
..Back Attack does more damage.
..Slide recovers 5 frames faster.
..Offense Special starts up 4 frames faster.
..Offense Special recovers 8 frames faster.
..Knife Attack's 2nd hit doesn't knockdown, but the 3rd hit
  still does.

Candra Minsky:
..Jab has a tiny bit more range.
..Jab does slightly more damage.
..3rd Hit does slightly more damage.
..Defense Special does more damage.
..Offense Special does WAY more damage.

Doppelganger Arle:
..Hurtbox is 8px shorter in height.
..Jab does slightly more damage.
..3rd Attack has slightly more range.
..3rd Attack does slightly more damage.
..Combo Finisher does more damage.
..Neutral Jump Attack starts up 2 frames faster.
..Neutral Jump Attack has slightly more range.
..Neutral Jump Attack does more damage.
..Forward Jump Attack does more damage.
..Jump Down Attack's animation has a shorter duration
  (40f -> 10f).
..Grab Knee is 2 frames shorter.
..Grab Knee does more damage.
..Grab Finisher starts up 5 frames faster.
..Grab Finisher does more damage.
..Defense Special does slightly more damage.
..Offense Special's 1st hit has more range.
..Offense Special does more damage.
..Back Attack does twice as much damage.
..Back Attack's 2nd hit has more range.
..Knife Attack reaches further.
..Knife Attack does twice as much damage.
..Pipe/Sword Attack recovers 2 frames faster.
..Pipe Attack has more range.

Donna:
..Fixed attempting a blitz attack with her playing an
  animation consisting of garbage data. It appears that in SW
  0.9, they forgot to set the correct index value for one of
  the Char ID checks.

Yvette:
..Backwards walk animates identically to her forward walk.

Alice:
..Corrected her weapon position on her 2nd hurt sprite.

Monami Ogura:
..High Kick has more horizontal reach.
..Genocide Cutter's 2nd hit reaches higher.
..AI for using her 1st punch has closer proximity.

Bernice Howell:
..Flame sprites are placed lower.

Suwako Moriya:
..Each hit of her Double Hit stays active for 2 frames less.
..Special starts up 6 frames faster.
..Special has only 30 frames of invincibility, instead of being
  invincible throughout the whole attack.

Princess Morbucks:
..She takes 4 more frames to start her charge punch.

Foofa:
..Replaced Zamza's replacement with a brand new character named
  Foofa, a UFO girl. She was by far my least favorite inclusion
  in this ROM Hack, as she heavily clashed with the other
  characters in terms of design.
..Foofa has a full second of invinciblity on wakeup, up from
  20 frames.
..Back Slam does more damage.
..Double slash's startup is increased from 8 to 12, since it's
  hard for me to edit the dimensions of those Hitboxes without
  affecting other things in the game in a buggy way. I don't
  know how to explain it.
..Slide does more damage.
..Reinstated the activation sound that plays during the Rolling
  Attack.
..Fixed her glitchy respawn.

Kurara/Clara Hananokoji:
..All hits of her run do the minimum amount of damage.
..Blitz's 2nd hit does less damage.

Hisoka Hosokawa:
..Slam voice clip is changed, as I felt the one I previously
  used didn't fit her.
..Slam damage is reduced to be on par with Axel's. It used to
  do as much damage as Max's Back Slam.

Enemy Group Changes:
..Vehelits has less HP.
..Princesses at Stages 4 and 6 have less HP and larger
  hurtboxes.
..Both Sissies have less HP.
..Eden's at Stage 6-1 have less HP.
..Several enemies in Stage 6-2 have less HP.
..A lot of enemies in Stage 7-2 have less HP.
..The Suwako in Stage 8 that appears in the same group as the
  2nd Clara has its spawn type changed to a distance
  activation.
---------------------------------------------------------------