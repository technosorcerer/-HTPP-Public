Hack Name: Karnov Rage

A Hack Of: Streets of Rage 2!

Hacked By: Metal64

Youtube channel: https://www.youtube.com/user/MetalOverlord64

                                              Sprites Used:
https://www.spriters-resource.com/neo_geo_ngcd/karnovsrevenge/sheet/33989/
https://www.spriters-resource.com/neo_geo_ngcd/karnovsrevenge/sheet/31020/
https://www.spriters-resource.com/neo_geo_ngcd/karnovsrevenge/sheet/38137/
https://www.spriters-resource.com/neo_geo_ngcd/karnovsrevenge/sheet/33988/
https://mugenarchive.com/forums/downloads.php?do=file&id=70020-jade-matlok-xinos
https://mugenarchive.com/forums/downloads.php?do=file&id=87674-lee-diendou-dhq-motomachi-dhq
https://mugenarchive.com/forums/downloads.php?do=file&id=40414-marstorius-y-y
https://mugenarchive.com/forums/downloads.php?do=file&id=1455-liu-feilin-177
https://mugenarchive.com/forums/downloads.php?do=file&id=1464-zazie-muhaba-tokinokuni-kei

                                                     Sounds Used
https://mugenarchive.com/forums/downloads.php?do=file&id=70020-jade-matlok-xinos
https://mugenarchive.com/forums/downloads.php?do=file&id=87674-lee-diendou-dhq-motomachi-dhq
https://mugenarchive.com/forums/downloads.php?do=file&id=40414-marstorius-y-y
https://mugenarchive.com/forums/downloads.php?do=file&id=1455-liu-feilin-177
https://mugenarchive.com/forums/downloads.php?do=file&id=1464-zazie-muhaba-tokinokuni-kei
https://mugenarchive.com/forums/downloads.php?do=file&id=1466-karnov-adamskie
https://mugenarchive.com/forums/downloads.php?do=file&id=1456-ryoko-kano-adamskie
https://mugenarchive.com/forums/downloads.php?do=file&id=84382-yungmie-zamtong-therealklowdey
https://mugenarchive.com/forums/downloads.php?do=file&id=25129-ray-mcdougal-xinos


                                       INSTRUCTIONS
Use programs like Lunar IPS to apply the IPS patch to your Streets of Rage 2 rom and you'll be ready to go.

                                             HACK DETAILS

I created this hack-ROM using Pancake2v16!

characters replaced: 
Axel
Max
Blaze
Skate
Jack
Shiva
Zamza
Abadede
R.bear

                                      Credits:

Gsaurus for creating the Pancake2v16 e MegaDrive Voice Editor.
Xinos for Ripped karnov, Ray, Liu and Ryoko sprites.