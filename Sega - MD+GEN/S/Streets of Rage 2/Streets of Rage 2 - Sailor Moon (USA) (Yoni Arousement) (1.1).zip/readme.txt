Streets of Rage 2: Sailor Moon

By Yoni Arousement
http://yonihq.blogspot.com
http://twitter.com/YoniArousement

To use, patch over a regular US Streets of Rage 2 ROM.

The Sailor Soldiers/Guardians fight in this ROM Hack of Streets
of Rage 2. Even Chibiusa is included (she replaces Shiva).

Everyone can safe land from slams in addition to throws, except
Chibiusa.