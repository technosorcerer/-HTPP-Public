************************************************************
*                                                          *
*                   Streets of Rage 2                      *
*            The Return of the Fighters 2019               *
*                                                          *
************************************************************

Overview:

  This hack allows the player to play as the modified SOR3 
  versions of Axel, Blaze, Skate, and Shiva in SOR2. The 
  game system has been completely upgraded.

  The story is the same as The Return of the Fighters 2018.
  Shiva, who had become a state witness after the event of 
  SOR3, joined Axel's team to fight Mr. X and save the city.
  
  This hack must be applied to "Streets of Rage 2 (USA)".

************************************************************

Features:

 * Shiva replaces Max as a playable character with portrait. 
 * All playable characters have SOR3 style appearances with
   some modifications.
 * All playable characters can run (with weapon animations).
 * All playable characters can change direction and circle
   around while running.
 * All playable characters can jump further while running.
 * The command to run (f, f) becomes more sensitive.
 * Players can still move after defeating each boss.
 * KO count of the players is displayed.
 * Defensive Special and Offensive Special will cost 10 KO
   count if the player's KO count is greater than or equal 
   to 10. Otherwise, they will cost 8 HP.
 * When the player's health is less than or equal to 30%, 
   Offensive Special becomes Desperate Super Combo, which is 
   50% more powerful with flexibility and/or invulnerability.
 * Axel, Blaze, and Shiva's blitz moves are more flexible.
 * Kickboxers cannot block weapon attacks.
 * Thugs' names are changed.
 * Mania difficulty is directly accessable.
 * Stage selection is available.

************************************************************

Move list:

  Shiva:
   * F, FB:   Final Crash
              Can use up and down to adjust the position
              before jumping up
              Invulnerable until landing
   * BC:      Roundhouse Kick
   * A:       Dragon Kick
   * FA:      Fire ball
   * FA:      Super fire ball
              Invulnerable, can only be performed 
              when health <= 30%

  Axel:
   * F, FB:   Tornado Grand Upper
              Can use up and down to adjust the position
              Invulnerable until the uppercut
   * BC:      Uppercut
   * Jump DB: Hurricane Kick
   * A:       Dragon Wing
   * FA:      Dragon Smash
   * FA:      Super Dragon Smash
              Invulnerable until landing, 
              can only be performed 
              when health <= 30%

  Blaze:
   * F, FB:   Somersault Slide
              Can use up and down to adjust the position
              when sliding
              Invulnerable until sliding
   * BC:      Backflip Kick
   * Jump DB: Terra Shield
   * A:       Super Backflip Kick
   * FA:      Soul Fire
   * FA:      Super Soul Fire
              Invulnerable, can only be performed 
              when health <= 30%

  Skate:
   * F, FB:   Flying Headbutt & Roll Kick
   * BC:      Reverse Flip Kick
   * Jump DB: Corkscrew Kick
   * A:       Forward Flip Kick
   * FA:      Double Spin Kick
              Can freely adjust the position
   * FA:      Super Double Spin Kick
              Can freely adjust the position
              Invulnerable, can only be performed 
              when health <= 30%

************************************************************

Known glitches:
 
  Shiva's fire ball may cause temporary graphical glitch in 
  two players mode.
  As a side effect of the improvement of running command, 
  running becomes very sensitive. Player can even run with
  half circle forward or half circle backward.

************************************************************

Credit:

  Hack by Da Lao Hu (Dha Lau Hoo)
  Special thanks to Huo Yan, Ivex, Lee Kuo-Chiang (LGQ), 
  and zyx for their advices.

************************************************************
*                                                          *
*                        Have fun!                         *
*                                                          *
************************************************************