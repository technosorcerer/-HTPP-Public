Streets of Rage 2: Doraemon

By Yoni Arousement

http://yonihq.blogspot.com

Doraemon teams up with his four friends to take on the
Streets of Rage. Most of the enemies have been customized.

To use, patch over a vanilla US Streets of Rage 2 ROM.