Streets of Rage 2: Girls' Paradise

By Yoni Arousement

http://yonihq.blogspot.com

First created in 2016, updated in 2018, then updated yet again in 2020!

To play, apply the IPS patch over a regular US Streets of Rage 2 ROM.