Sub-Terrania SRAM
Dec 6th, 2022
Billy Time! Games
--------------------------------
This patch is designed to add a simple saving mechanism to Sub-Terrania.

How to use
--------------------

Saving:
Game saves after every level.

Loading:
At the main menu, Hold B and press start. Continue to hold B and your game will load.

NOTE:
Game will produce a black screen if no prior save is detected.

How to Patch:
--------------------
1.Grab a copy of Sub-Terrania (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file