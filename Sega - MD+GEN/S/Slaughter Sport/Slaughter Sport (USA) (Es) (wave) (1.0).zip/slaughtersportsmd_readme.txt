Slaughter Sport (Mega Drive)
Traducción al Español v1.0 (16/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Slaughter Sport (USA).md
MD5: 998dcdf117ea63ba64ff37335a0719a4
SHA1: 9734c8a4e2beb6e6bb2d14ce0d332825537384e0
CRC32: af9f9d9c
655360 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --