Sonic 3 Complete - Emerald Safari
Nov. 20th 2023
BillyTime! Games
--------------------
This addenum patch is a gameplay overhaul for Sonic 3 Complete which gives each emerald unique abilities that stack.

How it Works:
--------------------
Each emerald will give the player new abilities before obtaining Super Sonic form.

These abilities are as follows:
*Chaos Emeralds
1.Start with Shield (Restores after death and between Acts.)
2.Longer Underwater Duration
3.Faster Acceleration (Effects nullified underwater)
4.Infinite Tails Flight/Swimming (Tails)
5.Slow Down Special Stages
6.Double Spheres
7.Super Sonic 

*Super Emeralds
8.Starting Shield Becomes Electric
9.Timer Runs At Half Speed
10.Jump slightly higher (Effects nullified underwater)
11.Start with 25 rings on New Act/Life
12.Timer Runs At Quarter Speed
13.Double Rings
14.Hyper Sonic


How to Patch:
--------------------
1.Grab a copy of Sonic 3 Complete here and follow instructions(https://www.romhacking.net/hacks/1056/)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the included IPS file