Super Hang-On SRAM
May. 14th 2023
BillyTime! Games
--------------------
This patch is designed to add a simple saving mechanism for High Scores in Super Hang-On as well as passwords 
for original mode.

How to use:
--------------------

High Scores:
--------------------
Saving:
Scores save after Initials are entered and player returns to the title screen. 
Score, Name, Stage and Time and Rank are all saved.

Loading:
Scores load upon boot. If checksum fails or it is your first time booting, default scores are loaded.

Original Mode:
--------------------
Saving:
Select End at the command menu and return to the Title Screen.

Loading:
Enter password screen, password will automatically load.

How to Patch:
--------------------
1.Grab a copy of Super Hang-On (World) (En,Ja).md *(REV00)* 
  OR Super Hang-On (World) (En,Ja) (Rev A).md *(REV01)*
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file