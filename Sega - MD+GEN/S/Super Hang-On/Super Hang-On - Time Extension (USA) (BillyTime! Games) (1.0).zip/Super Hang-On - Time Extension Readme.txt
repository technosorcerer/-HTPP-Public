Super Hang-On - Time Extension
Jan. 8th 2025
BillyTime! Games
--------------------
This simple patch is designed to add an static additional 45 seconds to the clock when passing checkpoints in the Arcade mode of Super Hang-On.


How to Patch:
--------------------
1.Grab a copy of Super Hang-On (World) (En,Ja).md *(REV00)* 
  OR Super Hang-On (World) (En,Ja) (Rev A).md *(REV01)*
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file