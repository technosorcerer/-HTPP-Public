SF2 Counteraction v1.2.1
(Jul 14 2019)

Table of Contents:
	Main Features
	Changelog
	Difficulty Setting
	Characters&Classes
	Alternate Promotions
	Spell Learning
	Items
	Spells
	Chest Changes
	Known Issues

===============
Main Features
===============

Counterattacks!
Instead of randomly triggering, counterattacks are now guaranteed to occur when possible. Double-attacks also are no longer based on chance and are class and/or weapon dependent instead. Pre-emptive attacks and double-counterattacks are also now possible with similar conditions.

Battle renovations!
All battles have been edited to some degree to be faster-paced, including player starting location, enemy entities, and enemy behavior.

Stats rehaul!
Player character, enemy, item, and spell stats have been heavily edited.

Weapons now function more as side-arms rather than outright upgrades, a bit like the lance&spear combo in vanilla.

Spell learning has been shuffled around and some more characters have been granted access to them. Most characters have their own spell specializations, rather than learning the maximum level in every spell, and lower levels of spells can remain useful.

Promotion level has been shifted to 25. Stat gains past pre-promoted level 25 have been drastically reduced and the pre-promotion level cap has been reduced to 30.

These changes were originally balanced around the Ouch! difficulty mode and grinding is not required to beat the game.

More parameters affected by the difficulty level!
The difficulty level selected at the beginning of the game also affects enemies' HP and DEF, in addition to ATK.
Normal: HP 100%, ATK 90%, DEF 90%
Hard: HP 100%, ATK 90%, DEF 100%
Super: HP 100%, ATK 100%, DEF 100%
Ouch!: HP 133%, ATK 100%, DEF 100%
(reduced ATK actually scales from 96% (early-game) to 90% (end-game) and increased HP from 118% to 133%)

Further promotion differentiation!
Branching promotions now differ slightly more:
-pegasus knights gain increased offense against low-defense targets in addition to flight
-sorcerers trade cost efficiency for higher spell range
-brass gunners can root themselves in place to greatly expand attack range
-master monks stop learning new spells

Attack and spell ranges extended!
Certain weapons and spells can target farther than 3 tiles away.

Other changes of note:
-damage is no longer randomized
-turn order is no longer randomized
-EXP gains are no longer randomized
-EXP gains have been reworked to help catching back up
--EXP cap per action is increased to 100
--combat EXP is increased more when falling behind
--healing, support, and debilitating spell EXP is affected by level difference
--as a trade-off, non-combat EXP no longer stacks up per target
-spells that inflict status ailments have a higher success rate (roughly double to triple)
-status spells overwrite their duration instead of failing when already in effect
-some status ailment effects have been changed
--Stun: guaranteed to run out after a single turn instead of 3
--Sleep: reduces ATK and MOV by 25% instead of disabling action
--Poison: deals 12.5% of remaining HP instead of flat 2
--Curse: no longer randomly causes paralysis or recoil damage
--Desoul: halves current HP instead of causing instant death
-DETOX is effective against all types of status ailments instead of only poison, stun, and curse
-PETER joins properly right away without being automatically controlled
-all four Creed characters can be recruited the first time
-FRAYJA doesn't force himself into the battle party
-the darkness effect in caves has been disabled

Boring changes:
-rare enemy drops' drop rate has been increased from 3% to 100%
-healing EXP can be gained regardless of class
-evasion has been lowered from 3% to 0.8%
-floating units no longer gain the evasion boost that flying units have (12%)
-land effect display changed to actually match their effect (10% and 20%)
-some physical attacks partially ignore the defense stat
-the physical attack effect that would inflict Muddle 2 inflicts Muddle 1 instead
-stat gains on level ups are calculated differently to deviate less in the long term
-item sell price has been lowered from 75% to 50%
-item repair fee has been lowered from 25% to 12.5%
-item break chance has been lowered from 25% to 10%
-priest uncurse fee has been lowered from 25% to 12.5%
-the dwarven blacksmith's pool of possible results has been reduced from 4 to 1 per weapon type
-the fairy woods time attack battle has been made inaccessible
-prism flowers deal more damage
-BURST ROCKs' on-death explosion has been disabled

Bug fixes:
-EXP is granted for ranged counterattacks
-chests can be opened during battle
-enemy "JAR"'s name properly displays as JARO


===============
Data&Info
===============

------------------------------
	Changelog
------------------------------

v.1.2.1 (Jul 14, 2019)
reverted enemy counterattack enhancement to double damage (the player version remains at 125%)

v1.2.0 (Jul 14, 2019)
doubled player counterattack damage (i.e. it's no longer halved)
changed the counterattack enhancing trait from double damage to 125% damage

v1.1.1 (Jul 14, 2019)
fixed battle 12 archer repeating his on-death dialogue at the end of every subsequent turn

v1.1.0 (Apr 17, 2019)
reduced enemy HP by 15% (early-end) to 25% (end-game)
reduced enemy ATK by 6% (early) to 10% (end)
reduced enemy DEF by 10%
implemented difficulty setting changes that restore the above stats

v1.0.4 (Mar 16 2019)
renamed hand axe to throw axe
renamed sturdy axe to guard axe
increased all warrior base DEF by 1
increased all gladiator&baron growth DEF by 2
increased red baron growth HP by 6
increased warrior Jaha growth HP by 1
increased knight rick growth DEF by 1
increased tortoise kiwi base&growth DEF by 1
increased monster kiwi growth DEF by 2
increased Zynk growth HP by 6
increased Claude growth DEF by 2
decreased Freeze Lv2 MP cost from 5 to 4
decreased Bolt Lv2-4 MP costs by 1 each
lowered demon rod resale value in line with other evil weapons
decreased galam soldier DEF by 1
decreased golem (enemy) ATK by 1

v1.0.3 (Mar 13 2019)
lowered BOOST MP cost from 3/6 to 2/5
lowered SLOW MP cost from 3/6 to 2/5
lowered ATTACK MP cost from 3 to 2
lowered MUDDLE1 MP cost from 3 to 2
increased mithril's ATT from -18 to -14
increased throw axe's ATT from -5 to -4
increased throw knife's ATT from -5 to -3
made mithril additionally usable by golem

v1.0.2 (Mar 13 2019)
fixed off-screen enemy in battle 15

v1.0.1(Mar 2 2019)
fixed FORCE SWORD's effect
changed prism flower battle chest content

v1.0.0 (Feb 28 2019)
battle changes
battle edits have been extended to the entire game instead of stopping at Zalbard

stat changes
HP<->DEF shift
-promo BOWIE CHESTER RICK RANDOLF GYAN KIWI: growth HP-3, growth DEF+1
-promo KAZIN: growth HP+10 growth DEF-3
-FRAYJA: growth HP-6, base DEF+3, growth DEF+2
-SHEELA: growth HP-17, growth MP -3, base DEF +2, growth DEF+3
BRN ideology change
-BRN JAHA RANDOLF: growth HP-7, growth ATK-2, DEF+7
MMNK defensive buff
-MMNK KAZIN KARNA: base DEF+2 growth DEF+3
ACHR stat shift
-BRGN JANET: fixed stats to actually apply BRGN differences
-SNIP ELRIC JANET: growth ATK+1, growth DEF-1
-BRGN ELRIC JANET: growth ATK-2, growth DEF+2
-RHODE: growth DEF-2
misc
-PGNT RICK: growth DEF+1
-JARO: starts with wing spear instead of bronze lance
-readjusted joining levels of post-Zalbard characters

spell changes
PETER: fixed to actually continue learning spells after promotion
SHEELA: stop at level 2 spells, 4th spell changed from SLOW to SLEEP
all SORC spells' level 2 costs reduced by 1

item changes
mithril weapons' resale value lowered to be more in line with the rest
IRON BALL gains stun effect
MITHRIL's ATT reduced from -12 to -18
GISARME changed to reducing remaining HP by 75% instead of 99%
cannon-type weapons' ATT increased by 1
QUICK RING changed from 6 to 8 AGI
EVIL RING equipability corrected
other minor tweaks to post-Cameela weapons

enemy changes
most enemies beyond Cameela had their durability slightly reduced
some enemies beyond Cameela had their stats and weapons further readjusted
DEMON MASTER spell changed from Apollo to Dao
MIST DEMON stats fixed
NECROMANCER's unintended ambush trait removed
JAR's name changed to JARO

technical or other changes
fixed sorcerer spells not dealing damage when cast by enemy
changed status spells to reset the duration to full instead of failing when already inflicted
fixed MUDDLE's infliction rates ignoring resistances and intended rates
added lifesteal effect to weapons
added spell range-extending weapon
added counter-from-any-range weapon
changed land effect text display to actually reflect their 10% and 20% effects
changed poison damage from flat 4 to 1/8 of current HP
changed evil damage from 1/5 of MAX HP to 1/4 of current HP
fixed BURST ROCKs not dealing damage when bursting
disabled BURST ROCKs bursting on death
made NINJ class ignore counterattacks
pushed Elis to the corner in the penultimate battle
added damage bonus against giant mouths to FORCE SWORD

v.0.2.1 (Dec 23 2018)
fixed equipability of some items (mainly latter half weapons)
added a makeshift visual indicator on the status screen for enemies with special abilities

v0.2 (Sep 30 2018)
extended demo to battle 30 (Mitula Shrine)
modified battle 28 (Tristan Bridge)
adjusted levels of enemies in battle 27 and 28
adjusted joining levels of last third of characters
adjusted power of mid-ranged weapons
changed Hyper Cannon's minimum range from 3 to 4

v0.1 (Sep 18 2018)
initial demo release

------------------------------
	Difficulty Settings
------------------------------

The v1.1.0 update has enemy stats reduced in difficulties below Ouch!.

Stat changes compared to 1.0.4 and earlier:
Normal: HP85~75%, ATK96~90%, DEF 90%
Hard: HP85~75%, ATK96~90%, DEF 100%
Super: HP85~75%, ATK 100%, DEF 100%
Ouch!: HP 100%, ATK 100%, DEF 100%

In other words:
Super and below cut down on enemy durability (-15% at start of game, -25% by end),
Hard and below cut down on enemy physical offense (eff. about 15% less dmg later), and
Normal weakens sturdy-type enemies' durability in particular (eff. about 40% more dmg).

Ouch! is the original difficulty (same stats as v1.0.4 and prior), but I'd recommend playing on Super for non-inflated enemy HP.

------------------------------
	Characters&Classes (short descriptions)
------------------------------

BOWIE:
Main character, forced in the party, sword-wielding swordsman. He starts off slightly on the weak side but gets relatively stronger as the game progresses and as he gains the use of exclusive story weapons.

Warrior:
Fighters with mediocre mobility and little access to ranged options that make up for it by being walls of stats.

JAHA: balanced approach, with an offensive penchant
GYAN: defense up the wazoo
LEMON: not a wall of stats, just a glass cannon
RANDOLF: learns DETOX, SLOW, and MUDDLE at the cost of some physical stats

Knights:
Fighters with superior movement and a ranged option in the spear, but weaker than warriors

CHESTER: balance
RICK: defense
ERIC: -physical +HEAL BOOST DISPEL
JARO: flight, offense

Archers:
MAY: mobility
ELRIC: balance
RHODE: offense
JANET: AURA ATTACK SLEEP

Birdmen:
Fighters with the maneuverability of flight and the ability to double attack. They can deal great damage to frail enemies, but are a bit on the frail side themselves.
Luke: balance, strong to magic
Screech: offense, weak to magic

Mages:
They ignore the counterattacking game and can hit multiple targets at once. Their spells at low levels are cost efficient while higher levels deal more immediate damage.

SARAH: AoE mage
TYRIN: long-range mage
CHAZ: close-range mage
TAYA: mid-range nuke
PETER: close-range flying mage
HIGINS: mounted mage, variety of spells

Healer:
Healing spells and support spells!
KAZIN: single-target healer
KARNA: AoE healer
FRAYJA: frontline tank-healer hybrid
SHEELA: +attack +mobility --magic

SLADE:
He is frail and seemingly has a low ATT score, but he partially ignores the opponent's DEF stat and, after promoting to ninja, does not trigger enemy counterattacks.

KIWI:
He has the ability to cast some support spells in addition to being fairly durable. He also has the ability to deal full damage on counterattacks.

GERHALT:
He can throw powerful punches or throw puny rocks at things. He can't handle being hit back very well at first, and still can't later on, but gets a bit better at it.

Robot&Golem:
Fighters that are even bigger walls of stats with even worse mobility. Golem also has the ability to deal full damage on counterattacks.


------------------------------
	Alternate Promotions
------------------------------

PGNT: growth ATT-2, growth DEF-1~2
Pegasus knights gain flight and the use of the WING SPEAR, a weapon that enables double attacking from range. In exchange, they lose some power with regular lances and physical durability.

BRN: growth HP-7, growth ATT-2, growth DEF+2, MOV+1
Barons expand their weapon options with swords. They lose some raw physical prowess in the process, but also gain some mobility.

SORC: growth HP+7, growth MP+10, growth ATT+2, growth DEF-10
Sorcerers leave behind the spells they learned as mages to learn new spells with high costs but also high range and damage. To slightly make up for the higher costs, they also eventually gain more MP.

MMNK: growth MP-10, base ATT+8, growth ATT+16, base DEF+2, growth DEF+3, MOV+1
Master monks cease learning new spells but gain the use of weapons more suited to fighting and greatly increased physical stats to put them nearly on par with regular fighters. At worst, they are healers with less MP but more mobility.

BRGN: growth HP-6, growth DEF+6, MOV-1
Brass gunners might just be archers with worse maneuverability at first, but by equipping weapons exclusive to their class, they gain greatly extended attack range at the cost of rooting themselves in place. Furthermore, regaining their mobility requires an entire turn. Luckily, they also have a tool that temporarily increases their mobility in exchange for their ability to attack. This tool also takes up a turn to remove.


------------------------------
	Spell Learning
------------------------------

    char    spell   LV1 LV2 LV3 LV4
    BOWIE   EGRESS   0
            BOLT    26

    SARAH   BLAZE    0   5  20  35
            FREEZE   8  16  32
            MUDDLE  12  28
            SLEEP   24

    TYRIN   FREEZE   0   5  20  35
            BLAST    8  16  32
            DISPEL  12
            MUDDLE  24

    CHAZ    BOLT     0   0   0   0
            BLAST    0   0   0
            SLEEP    0
            SLOW     0   0

    PETER   BLAST    0   5  20  35
            BOLT     8  16  32
            DISPEL  12
            DESOUL  24  40

    HIGINS  BLAZE    0  26  38
            FREEZE   0   0  42
            BOLT     0   0  30
            BLAST    0   0  34

    SARAH   DAO     25  35
            APOLLO  30  40
            ATLAS   45

    TYRIN   DAO     25  35
            NEPTUNE 30  40
            APOLLO  45

    TAYA    DAO     25  35
            ATLAS   30  40
            NEPTUNE 45

    KAZIN   HEAL     0   5  16  30
            DETOX    3   9  24  35
            ATTACK   7
            AURA    12  20  42

    KARNA   HEAL     0   0  36
            AURA     0   0   0  30
            ATTACK   0
            BOOST    0  32

    FRAYJA  HEAL     0   0  36
            DETOX    0  29  48
            BLAST    0   0  30
            SLOW     0   0

    SHEELA  HEAL     0   0
            AURA     0   0
            BOOST    0
            SLEEP    0

    KIWI    BOOST    0  16
            SLOW     8  24

    ERIC    HEAL     0  30
            BOOST    0  35
            DISPEL   0

    RANDOLF DETOX    0   0
            SLOW     0  30
            MUDDLE   0

    JANET   AURA     0  30
            ATTACK   0
            SLEEP    0

promoted characters are considered 24 levels higher
priests that promote to master monks cease learning spells


------------------------------
	Items
------------------------------

    name             ATK other
    Short Sword      3
    Power Sword      8   -5 DEF
    Ward Sword       0   +4 DEF
    Critical Sword   1   25% crit chance, 150% crit damage
    Counter Sword    1   double counterattack damage
    Mage Slayer      3   can also inflict MP damage
    Repel Sword      1   counterattack from any range, double counterattack damage
    Achilles Sword   5   +2 DEF, regen 4 HP/turn
    Taros Sword      6   1-2 range, -6 MOV, takes a turn to unequip

    Levanter         3   mithril, Blaze 2 on use
    Force Sword      0   1-2 range, +2 DEF, +40 effectiveness against Zeon
    Dark Sword       6   25% HP loss/turn, steals HP on hit, takes a turn to unequip

    Bronze Lance     3
    Power Lance      7   -4 DEF
    Guard Lance     -1   +5 DEF
    Killer Lance     0   25% crit chance, 150% crit damage
    Spear            0   1-2 range
    Wing Spear      -4   1-2 range, attack twice, pegasus knight-only
    Counter Spear   -1   1-2 range, double counterattack damage
    Holy Lance      -3   mithril, +7 DEF, heals 40 HP on self-use
    Evil Lance       6   25% HP loss/turn, steals HP on hit, takes a turn to unequip


    Short Axe        3
    Power Axe        9   -6 DEF
    Guard Axe        0   +4 DEF
    Killer Axe       0   25% crit chance, 150% crit damage
    Stun Axe         1   stun on-hit
    Hand Axe        -4   1-2 range
    Rune Axe         3   +1 MOV, ATTACK1 on use
    Evil Axe         6   25% HP loss/turn, steals HP on hit, takes a turn to unequip

    Dagger           3   ignore half DEF
    Thieves' Dagger  6   -3 DEF, ignore half DEF
    Sneak Dagger     0   +3 DEF, ignore half DEF, preemptive attack
    ArmorBreaker     2   can inflict slow, ignore half DEF
    Throw Knife     -3   1-2 range, ignore half DEF
    Gisarme          3   can reduce target's remaining HP by 75%

    Wooden Arrow     7   2-3 range
    Heavy Arrow     11   2 range, -2 DEF
    Robin Arrow      2   3-5 range
    Nullify Shell    6   2-3 range, MP damage on-hit
    Reprisal         0   1-3 range, +4 DEF, double counterattack damage
    Hyper Cannon     9   3-7 range, -4 MOV, takes a turn to unequip, gunner-only
    Focus Cannon    13   4-5 range, -4 MOV, takes a turn to unequip, gunner-only
    Booster          X   +2 MOV, cannot attack, takes a turn to unequip, gunner-only
    Grand Arrow      0   mithril, 4-6 range
    Evil Shot        6   25% HP loss/turn, steals HP on hit, takes a turn to unequip

    Wooden Rod       3
    Dispel Rod       3   dispel on-hit
    Haze Rod         3   muddle on-hit
    Sleep Rod        3   sleep on-hit
    Slow Rod         3   slow on-hit
    Flail            8   1-2 range, -5 DEF
    Guard Stick      1   +2 DEF
    Iron Ball        6   1-2 range, stun on-hit
    Mystery Staff    3   mithril, increases spell range by 1
    Demon Rod        6   -25% HP/turn, +2MP/turn, steals HP on hit, 1 turn uneqp

    Leather Glove    4
    Power Glove      8   -4 DEF
    Reflex Glove     0   +4 DEF, preemtive attack, double counterattack damage
    Mystic Glove    -3   1-2 range, silence on-hit
    Giant Knuckles   0   pre-emptive, muddle on-hit, MUDDLE1 on use

    Mithril        -14   1-2 range

    Power Ring          +3 ATT, -1 DEF
    Black Ring          +5 ATT, -2 DEF
    Protect Ring        -1 ATT, +2 DEF
    White Ring          -2 ATT, +4 DEF
    Chirrup Sandals     +1 ATT, +4 AGI
    Quick Ring          +8 AGI
    Running Ring        -2 ATT, +1 MOV
    Evil Ring           -6 ATT, +2 MOV, takes a turn to unequip

    Medical Herb         heal 20 HP, self use
    Healing Seed         heal 40 HP, self use
    Healing Drop         heal 60 HP, self use
    Healing Water        casts Aura 2
    Antidote             cure poison, 0-2 range
    Fairy Powder         cure everything but curse, 0-2 range


------------------------------
	Spells
------------------------------

    name            power (promo)                   aoe     range   cost
    Blaze           14/12/16/20 (17/15/20/25)       0/1     2       2/4/8/12
    Freeze          14/16/22/28 (17/20/27/35)       0       2/3     2/4/9/14
    Bolt            12/16/20/25 (16/20/25/31)       0       2/1     2/3/6/10
    Blast           10/08/11/14 (13/10/13/17)       1/2     2/2     2/4/8/12
    Heal            20/28/45/32 (25/35/56/40)       0       2/3/3/6 2/3/6/6
    Aura            15/20/26/22 (18/25/32/27)       1/1/2/X 2/3/3/X 4/5/9/14
    Dio             (23/41)                         1       5       7/17
    Apollo          (26/45)                         2       5       8/19
    Neptune         (21/37)                         1       7       7/17
    Atlas           (28/50)                         1       3       8/19
    Detox           cure poison/cure all/cure curse 1/0/1/2 2/2/3/4 2/3/5/7
    Attack          ATK +15.6% for 3 turns          0       3       2
    Boost           DEF +20.3% for 3 turns          0/1     2       2/5
    Sleep           ATK -25% & MOV -37.5% for 3t    1       3       4
    Slow            DEF -25% for 3 turns            0/1     3       2/5
    Muddle          HIT -50% and/or confusion       1/0     5/3     2/6
    Dispel          silence                         2       3       5
    Desoul          HP -50%                         0/1     2       4/8

    name      hit rate (depending on resistance)
    Sleep           100% to 25%
    Slow            100% to 25%
    Muddle1         75% to 0%
    Muddle2         50% to 0%
    Dispel          75% to 0%
    Desoul          50% to 0%


------------------------------
	Chest changes
------------------------------

Jewel Shrine
power water to medical herb

Ship
quick chicken to medical herb

New Granseal
cheerful bread to healing seed

Ribble
bright honey to healing seed

Polca Village
protect milk to fairy powder

Achilles Ruins
power water to healing seed

Hassan
running pimento to running ring

Ketto
bright honey to brave apple

Pacalon
cheerful bread to power ring

Tristan Caves
protect milk to protect ring

Mitula's Shrine (inner)
power water to fairy powder

Moun (underground)
running pimento to quick ring

Prism Flower Field
valkyrie to life ring

Yeel Revisited
quick chicken to healing seed


---------------------------
	Known Issues
---------------------------

DETOX 2 can display extraneous messages for untreated status ailments
enemy sorcerer spells work functionally, but are a visual mess
evil damage message immediately closes if followed by poison message
droppable items sometimes disappear without direct interaction under certain specific circumstances?
land effect for certain enemies displays 50% (functionally 20%)
enemy traits don't have their own icons and display as regular items


==============

copypasted from author's thread at
https://forums.shiningforcecentral.com/viewtopic.php?f=5&t=44356