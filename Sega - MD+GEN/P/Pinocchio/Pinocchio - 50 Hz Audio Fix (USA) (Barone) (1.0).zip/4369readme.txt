Disney's Pinocchio (MD) IPS patch version 1.00
17 FEB 2019
By Barone
Made using HxD, GEMS Tools 

==Purpose of the patch==
This patch fixes the audio tempo and pitch of the European Mega Drive release, which was wrongly adjusted to 60 Hz instead of 50 Hz.

==Usage==
Apply the included IPS file to the ROM (e.g. via Retron 5, Cybergadet Retrofreak, dedicated programs such as "StealthPatch IPS Patcher" and "Lunar IPS").
After applying the patch to its correct ROM version, the checksum will be the correct one already.
 
==Notes==
* Successfully tested on real hardware.

==Contact info==
Go to the AtariAge or Sega-16 forums and you'll find me there.
I also have this thread: http://www.sega-16.com/forum/showthread.php?30343-Barone-s-Hacking-Corner which is dedicated to hacking discussions and feedback.

