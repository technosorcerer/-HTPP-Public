Psycho Pinball Hi-Score SRAM
June. 6th 2024
BillyTime! Games
Spkleader
--------------------
This patch is designed to add a simple saving mechanism for High Scores in Psycho Pinball.


How to use
--------------------
Saving:
Scores save after player returns to the Title screen.

Loading:
Scores load at the after language select screen. If checksum fails or it is your first time booting, default scores are loaded.


How to Patch:
--------------------
1.Grab a copy of Psycho Pinball (Europe) (En,Fr,De,Es,It) (Rev 1).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file