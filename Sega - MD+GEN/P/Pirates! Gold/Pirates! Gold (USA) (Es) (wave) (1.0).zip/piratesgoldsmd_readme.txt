Pirates! Gold (Mega Drive)
Traducción al Español v1.0 (22/02/2025)
(C) 2025 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Hay varios gráficos sin traducir.
Algunos textos de estado de la tripulación en verde sin traducción.
Algunos textos sin traducir como Goods, Cannon o Food en la pantalla de mercadear.
Algunas palabras en inglés se usan en lugares donde en español tendrían diferente palabra, por ejemplo spanish puede ser español, española, españoles, por lo que en estos casos simplemente pone español.
Si encuentras algún otro fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Pirates! Gold (USA).md
MD5: 8689ffd6edad02bad1f74fe19fe25c9d
SHA1: ea597dbefc8f804524606af3c1c4fe6ba55e86e9
CRC32: ed50e75c
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --