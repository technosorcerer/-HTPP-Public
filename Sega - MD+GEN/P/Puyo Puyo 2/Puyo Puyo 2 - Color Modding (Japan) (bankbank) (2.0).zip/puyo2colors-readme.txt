the patch should be applied to "Puyo Puyo 2 (Japan) (v1.1).md"
CRC32=25B7B2AA

use a hex editor to change the colors of the puyos

the hex editor I recommend is HxD, you can download it here
https://mh-nexus.de/en/downloads.php?product=HxD20

or you can use a web-based hex editor like this
https://hexed.it/

modify the last 60 bytes of the file, beginning at 1FFFC4
each of the 5 colors has 12 bytes each
12 bytes X 5 colors = 60 bytes
changing the first 12 bytes at 1FFFC4 will change the colors for the first puyo

each puyo is made up of 6 colors
each color is 2 bytes long
each puyo's total color set is 12 bytes long

in the attached version, green is replaced with dark grey
I've put some examples in the /examples folder, please take a look

to generate mega drive colors, you can use this tool
http://elektropage.ru/programs/6_Palette.rar (direct download link)
http://elektropage.ru/publ/programmy_dlja_romkhakinga/dlja_raboty_s_grafikoj/sega_palette_podbor_palitry/40-1-0-125 web page
(I didn't make this tool)

email me if you have any questions
bank at bankbank.net