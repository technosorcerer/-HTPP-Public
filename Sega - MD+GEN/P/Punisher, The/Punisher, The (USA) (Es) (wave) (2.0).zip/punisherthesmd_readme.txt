The Punisher (Mega Drive)
Traducción al Español v2.0 (01/06/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres españoles a fuente principal
-Guion revisado
-Traducidos gráficos TIME-PAUSE-CONTINUE-GAME OVER

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Punisher, The (USA).md
MD5: 0711541847d139a7dae88958b68f92ee
SHA1: 4ef2675e728903925a7b865daa75ed66bbe24829
CRC32: 695cd8b8
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --