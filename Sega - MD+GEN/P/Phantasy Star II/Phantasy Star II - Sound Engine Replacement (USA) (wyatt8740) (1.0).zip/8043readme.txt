These patches work to change the sound engine and PCM samples of one region's
release of Phantasy Star II to the other's.

The original japanese release used a different sound engine than the west's.
I have been told by more knowledgeable people that it looks like it may have
been translated into 68K assembly from Z80 assembly.

Meanwhile, the western releases (English, Brazillian Portuguese) used a
rewritten 68K sound engine that (apparently) doesn't bear as much resemblance
to a Z80 program.

The western release also changed the drum samples to some much quieter ones.
In the original release, they were so loud that they got close to drowning out
the FM music.

The FM music also plays a little differently between releases; if I were to try
to describe it, I'd say that the various instruments' notes end less abruptly
in the Japanese release of the game. (Think of it like holding the leftmost
pedal for a moment after releasing a key while playing on a piano). Often this
barely makes a difference, but once in a while it is extremely noticeable. The
overworld tune is one such place. It's a "smoother" experience, in my opinion.

Some of the more noticeable tracks (when played on real hardware; note that
entering a battle seems to change some register that changes the timbre of a
lot of instruments in both the original English and Japanese games, so the
VGM's you'll find aren't quite accurate unless you go to the sound tester
(Ustvestia) without first entering a battle after loading your game):

* "Advanced"
* "Bracky News"
* "Pressure"
* "Death Place"
* "Violation"
* "Power"
* "Exclaim"
* "Never Dream"

It's noticeable at some point in pretty close to every tune, but those are
where I think I notice it most.

There are patches that simply convert a ROM to use the other region's engine,
and there are also bonus patches that reduce the volume of the drum samples
under the Japanese sound engine.

If anyone wants to mess around with the drum samples, in the disassembly
I referenced, 'zloc_299' is the loud snare drum PCM sample. Dividing those
values and then fixing the 'neutral/quiet' offset (since it's unsigned PCM)
will change the volume.

==============================================================================

The following files apply to the No-Intro 'Phantasy Star II (USA, Europe).md'
rom - that is to say, to the revision 1 ROM. It probably applies fine to either
revision of the English rom, though. The changes are minimal between them.

MD5 checksum '75ea42b49a65ceb0395480126f426c6a'
CRC32 checksum '0d07d0ef'


Descriptions of the various patches:

en_jpsound.ips:
  inserts the original Japanese release's sound engine into the english version
  ROM.
  It also brings the Japanese version's (louder) drum samples and slightly
  different instrumentation.

en_jpsound_quiet.ips:
  Inserts the original Japanese release's sound engine into the english version
  ROM.
  ...HOWEVER, while it also pulls in the Japanese PCM samples and
  instrumentation, it uses a modified (volume-reduced) version of the snare
  drum sample to make it sound closer to the volume we're used to in the
  western release of the game.

==============================================================================

The following files apply to the Japanese game, that is to say
'Phantasy Star II - Kaerazaru Toki no Owari ni (Japan).md' No-Intro,
MD5 checksum 'ad692c895d5c2cab7b616df2135ea3b4'
CRC32 checksum 'bec8eb5a'

Descriptions of the various patches:

jp_ensound.ips:
  converts the Japanese game to use the US sound engine and samples.

jp_quiet.ips:
  makes the 'snare drum' sample volume quieter in the Japanese game,
  but keeps the original Japanese sound otherwise.
