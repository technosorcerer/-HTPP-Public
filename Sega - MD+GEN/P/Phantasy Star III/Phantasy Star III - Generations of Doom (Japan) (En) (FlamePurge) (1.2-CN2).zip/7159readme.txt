                                   PHANTASY STAR III: RETRANSLATED
                                         CLASSIC-STYLE NAMES
                                        v1.2-CN2 (Jan 9 2024)

====================================================================================================
Disclaimer
==========
- Phantasy Star III: Generations of Doom (c) Sega. All rights reserved.


- No ownership is claimed by FlamePurge, Rebecca Capowski, Peaches, or lory1990 over Phantasy Star
  III or the franchise from which it originates. Commercial use of this patch, including but not
  limited to reproduction, sale, etc. is strictly prohibited.


- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   FlamePurge, Rebecca Capowski, Peaches, and lory1990 are not liable for damage incurred to the
   end-user, their OS, or their hardware while using this patch.


- Apply this patch only to "Phantasy Star III - Generations of Doom (UE).bin" with the following
   specifications.

     Prepatched with Rebecca Capowski, Peaches, and lory1990's English translation, v1.2.
     Hashes: CRC32 - 5288DB02
               MD5 - 025123D33BD5716D8508E6370CC39B85
              SHA1 - B00E10A0AFCE454BC1A95A0D377EC40B6DE2D615

----------------------------------------------------------------------------------------------------

Phantasy Star III's official localization is largely unfaithful at all to the Japanese version. I
tend to stick to the retranslation as a result, but as with the other games in this series, I prefer
the names used internationally. Thus, I decided to make this patch for myself and release it for
whomever felt the same.

This archive contains 4 patches.

1. PSIII_ClassicNames_v12-CN.ips
    After you have patched your unmodified PSIII ROM with Rebecca et al's retranslation, apply this
    to receive the base features of PSIII Classic-style Names.


When the above has been accomplished, choose as many of these as you'd like, in any combination.
 

2. PSIII-CN_NormalBattleThemes.ips
    Restore the tracks Battle (Begin), Battle (Winning), and Battle (Losing), which PSIII Classic-
    style Names removes as the author finds them hard to listen to.

3. PSIII-CN_RewardsDoubler.ips
    Every enemy will give double the experience and meseta rewards after battle.

4. PS3T-ParallaxPatch.ips (lory1990)
    In the Japanese release of PSIII, both the top and bottom of the battlefields scrolled at all
    times. The international release made it so only outdoor sky scrolls. This patch restores the
    Japanese behavior.
====================================================================================================

====================================================================================================
Changelog
=========
v1.2-CN2 (Jan 9 2024)

TEXT:

- Optimized several equipment names.

SorrowSlc -> MournSlcr
AncintVst -> RelicVest
DelghtBow -> DeliteBow
Protector -> ArmorSuit
Protector -> ArmorSuit
SteelPrtc -> SteelSuit
CeramPrtc -> CeramSuit
ForcePrtc -> CometSuit
LaconPrtc -> LaconSuit
RoyalPrtc -> MaximSuit



v1.2-CN1 (Jan 2 2024)

GENERAL:
- Includes the full retranslation and all enhancements from Phantasy Star III: Retranslated by
   Rebecca Capowski, Peaches, and lory1990.
   
   
- Removed the game's checksum routine to make the addendum patches possible.



GAMEPLAY:
- [Applied Patch] PS3 Translation Walk Speed Patch (lory1990)
   Your characters will walk at double the speed of the unmodified game.
   
   
- Included Rewards Doubler addendum, which increases EXP and MST rewards by 2x (final boss aside).
   If desired, apply after the main patch.



SOUND:
- Stopped Battle (Begin), Battle (Winning), and Battle (Losing) from playing at any point. Now
  Battle (Balanced) will play for every fight (final boss aside) and not change.


- Included Classic Battle Themes addendum to revert the above change. If desired, apply after the
  main patch.



GRAPHICS:
- Restored "Generations of Doom" subtitle to the title screen.


- Replaced the font of the opening credits with a fancier one to give the title screen more oomph.


- Included Parallax Patch addendum by lory1990, which restores Japanese battle background behavior.
   If desired, apply after the main patch.



TEXT:
- Fixed an error in the retranslation where Siren confuses Laya and Orakio.


- Gave one of Gwyn's lines in the ending to Wren, as in the official localization, since this
   particular line expects her to be named Laya.
   

- Changed the family name Sa Riik to Sa Liec, as I believe it's supposed to be a roundabout
  reference to La Shiec (Lassic).


- Changed the King of Liec's name from Saiki Sa Riik to Sykhe Sa Liec, just to localize the
  spelling a bit.
  

- Reverted the name of each person and city to their international equivalent. 3 exceptions were
  made.

   1. Liec -> Landen
       This would require changing the family name Sa Liec to Sa Landen, and I didn't want to
	   expend the effort. It would also diminish the potential La Shiec reference.
   2. Foundaury -> New Motavia
       There isn't enough space in the text files, and this village also has nothing to do with
	   Motavia.
   3. Alisa
       This not being changed to Alis in the official localization was always an oversight, which
	   Classic-style Names corrects.
   
   
- Many tech names have been changed. In some cases, not to match PSIII, but to match techs of
   similar effect in PSII and IV.
   
OFFICIAL  REBECCA'S  MINE         WHY?
Foi       Foie       (official)   Official name
Zan       <-	     <-           Official name
Gra       <-	     <-           Official name
Tsu       Barta      Wat          This is a water-elemental tech, not light-elemental like Thu
Res       SunForce   (official)   Matching similar tech from II/IV, backed by official name
Gires     StarForc   Sar          This is multi-target healing, like Sar; Gires is Heal 2
Rever     MoonForc   (official)   Matching similar tech from II/IV, backed by official name
Anti      SeaForce   (official)   Matching similar tech from II/IV, backed by official name
Fanbi     Law        Shift        This raises ATK, like Shift; Fanbi is Drain
Forsa     Unbalanc   Vol          This causes instant death, like Vol; Forsa is Robot DEX Down
Nasak     Balance    (official)   Matching similar tech from II/IV, backed by official name
Shu       Chaos      (official)   Matching similar tech from II/IV, backed by official name
Ner       Rising     (official)   Matching similar tech from II/IV, backed by official name
Rimit     Noon       Shinb        This makes it easier to escape battle; Rimit is Organic Paralyze
Shiza     Fall       Seals        Stops any foe type's techs, like Seals; Shiza is Organic Silence
Deban     Night      Gelun        Lowers any foe type's ATK, like Gelun; Deban is Damage Barrier


- Updated and optimized a plethora of equipment names for readability and presentation.

OFFICIAL   REBECCA'S   MINE
Monomate   <-          <-
Dimate     <-          <-
Trimate    <-          <-
Antidote   <-          <-
Star Mist  Star Atom   (official)
Moon Dew   Moon Atom   (official)
Escapipe   Ocarina     <-
Monitor    <-          <-
Short Swd  SoldirSwd   SoldrSwrd
Sword      KnightSwd   <-
Steel Swd  PaladnSwd   <-
Ceram Swd  <-          CeramSwrd
Laser Swd  <-          LaserSwrd
Force Swd  Anger Swd   AngerSwrd
Lacon Swd  <-          LaconSwrd
Royal Swd  Kings Swd   KingSword
PlanarSwd  DimensSwd   TimeSword
OrakioSwd  <-          <-
Nei Sword  <-          <-
Knife      <-          <-
Huntg Knf  Huntr Knf   HuntKnife
Steel Knf  ProtctKnf   GuardKnfe
Ceram Knf  <-          CeramKnfe
Laser Knf  <-          LaserKnfe
Force Knf  Pity Knf    PityKnfe
Lacon Knf  <-          LaconKnfe
Royal Knf  <-          RoyalKnfe
Huntg Stf  TravlrStf   TravlCane
Steel Stf  SorcerStf   Mage Cane
Ceram Stf  <-          CeramCane
Laser Stf  Poem Stf    PoemCane
Force Stf  Regal Stf   RegalCane
Lacon Stf  Lacon Stf   LaconCane
Ceram Slr  <-          CeramSlcr
Laser Slr  <-          LaserSlcr
Force Slr  SorrowSlr   MournSlcr
Lacon Slr  <-          LaconSlcr
Royal Slr  <-          RoyalSlcr
PlanarSlr  Time Slcr   TimeSlicr
Lune'sSlr  Lune Slcr   LuneSlicr
Nei Slicr  <-          NeiSlicer
Claw       <-          <-
Huntg Clw  BastetClw   Bast Claw
Steel Clw  Lynx Claw   <-
Ceram Clw  <-          CeramClaw
Laser Clw  <-          LaserClaw
Force Clw  Grief Clw   GriefClaw
Lacon Clw  <-          LaconClaw
Royal Clw  <-          RoyalClaw
PlanarClw  Chaos Clw   ChaosClaw
Miun'sClw  Miun Claw   <-
Nei Claw   <-          <-
Huntg Bow  Noble Bow   <-
Ceram Bow  Laser Bow   <-
Laser Bow  DelightBw   DeliteBow
Force Bow  ScorchBow   <-
Lacon Bow  <-          <-
Royal Bow  Order Bow   <-
Laya'sBow  Laia'sBow   (official)
Nei Bow    <-          <-
HuntgShot  Handgun     <-
CeramShot  Shotgun     <-
LaserShot  Cannon      <-
LaconShot  GrnLaunch   Launcher
Cannon     LaserShot   LaserShot
PulseCann  LsrCannon   <-
Vulcan     PulseShot   <-
PulseVlcn  <-          PulsVulcn
SirenShot  <-          <-
Nei Shot   <-          <-
HuntgHelm  Lthr Cap    Hide Cap
SteelHelm  KnightHlm   KnghtHelm
CeramHelm  <-          <-
ForceHelm  Dawn Helm   <-
LaconHelm  <-          <-
RoyalHelm  KingsHelm   King Helm
Bandanna   Headband    <-
HuntgBand  CeramBand   <-
SteelBand  <-          <-
CeramBand  <-          <-
ForceBand  SilvrBand   <-
LaconBand  LaconBand   <-
RoyalBand  PrismBand   <-
Staff      Staff       Cane
Garment    <-          Clothes
Slicer     <-          <-
CeramCrwn  SilvrCrwn   <-
ForceCrwn  Snow Crwn   SnowCrown
LaconCrwn  <-          <-
RoyalCrwn  QueenCrwn   <-
Ribbon     Ribbon      <-
HuntgRibn  NobleRibn   <-
CeramRibn  Dew Ribn    DewRibbn
ForceRibn  Wind Ribn   WindRibbn
LaconRibn  <-          <-
RoyalRibn  <-          <-
Head Gear  Headgear    <-
SteelGear  <-          <-
CeramGear  <-          <-
ForceGear  StormGear   StormGear
LaconGear  <-          <-
RoyalGear  MaximGear   <-
HuntgArmr  LthrArmor   HideArmor
SteelArmr  ChainMail   <-
CeramArmr  PlateArmr   <-
ForceArmr  CeramArmr   <-
LaconArmr  SolarArmr   <-
RoyalArmr  LaconArmr   <-
PlanarArm  KingsArmr   KingArmor
Cape       Mantle      Cape
SteelCape  SilvrMntl   SilvrCape
LaconCape  AmberMntl   AmberCape
RoyalCape  GalaxyMtl   GalaxCape
Robe       <-          <-
SteelRobe  LunarRobe   <-
LaconRobe  <-          <-
RoyalRobe  PrincssRb   Lady Robe
HuntgChst  LthrChest   HidePlate
SteelChst  SteelChst   SteelPlte
LaconChst  CeramChst   CeramPlte
RoyalChst  CometChst   CometPlte
Fiblira    Fiblira     Tunic
Steel Fib  Star Fibr   StarTunic
Lacon Fib  Lacon Fib   LaconTunc
Royal Fib  Queen Fib   QueenTunc
Vest       Wool Vest   <-
HuntgVest  Lthr Vest   Hide Vest
SteelVest  ChainVest   <-
CeramVest  <-          <-
ForceVest  Star Vest   <-
LaconVest  <-          <-
RoyalVest  AncintVst   RelicVest
Protector  <-          ArmorSuit
SteelPrtc  <-          SteelSuit
CeramPrtc  <-          CeramSuit
ForcePrtc  CometPrtc   CometSuit
LaconPrtc  <-          LaconSuit
RoyalPrtc  MaximPrtc   MaximSuit
Boots      LthrBoots   HideBoots
ForceBoot  LongBoots   <-
RoyalBoot  GuardBoot   <-
Shield     Lthr Shld   Hide Shld
SteelShld  KnghtShld   <-
CeramShld  <-          <-
ForceShld  SerenShld   Calm Shld
LaconShld  <-          <-
RoyalShld  KingsShld   King Shld
Emel       <-          <-
SteelEmel  Lthr Emel   Hide Emel
CeramEmel  <-          <-
ForceEmel  TruthSlvs   <-
LaconEmel  <-          <-
RoyalEmel  GrSleeves   GreenSlvs
Needle     Needle      Pin
Huntg Ndl  FowlngNdl   FowlngPin
Steel Ndl  Shuriken    Shuriken
Ceram Ndl  Thief Ndl   Thief Pin
Laser Ndl  AssasnNdl   KillerPin
Force Ndl  Ceram Ndl   CeramcPin
Lacon Ndl  Laser Ndl   Laser Pin
Royal Ndl  Lacon Ndl   Lacon Pin
Sapphire   <-          <-
MoonStone  <-          <-
Moon Tear  <-          <-
DragnTear  <-          <-
Snow       SnwCrystl   SnowCryst
TwinsRuby  <-          <-
PowrTopaz  <-          <-
MstryStar  <-          <-
AquaParts  MarinePts   <-
Sub Parts  <-          <-
AeroParts  Sky Parts   <-
LayaPndnt  LaiaPndnt   (official)
====================================================================================================

====================================================================================================
Credits
=======
- lory1990: Hacking, assistance

- Rebecca Capowski: Translation

- Peaches: Translation

- Sega

- Brandon: Testing

- Dezmancer: Testing

- Unknown User: Testing
(I apologize for not crediting you by name, but you seem to have deleted your Discord before I
 could note it in a readme.)

...and all you Phantasy Star fans out there! See you in the Algol system!
====================================================================================================