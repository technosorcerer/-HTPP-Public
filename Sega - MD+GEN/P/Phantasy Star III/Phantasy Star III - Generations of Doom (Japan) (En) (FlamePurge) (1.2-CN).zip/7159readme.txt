                                   PHANTASY STAR III: RETRANSLATED
                                         CLASSIC-STYLE NAMES
                                        v1.2-CN (Jan 2 2024)

====================================================================================================
Disclaimer
==========
- Phantasy Star III: Generations of Doom (c) Sega. All rights reserved.


- No ownership is claimed by FlamePurge, Rebecca Capowski, Peaches, or lory1990 over Phantasy Star
  III or the franchise from which it originates. Commercial use of this patch, including but not
  limited to reproduction, sale, etc. is strictly prohibited.


- This unofficial, fan-made patch is provided "as-is" on a voluntary (i.e. non-profit) basis.
   FlamePurge, Rebecca Capowski, Peaches, and lory1990 are not liable for damage incurred to the
   end-user, their OS, or their hardware while using this patch.


- Apply this patch only to "Phantasy Star III - Generations of Doom (UE).bin" with the following
   specifications.

     Prepatched with Rebecca Capowski, Peaches, and lory1990's English translation, v1.2.
     Hashes: CRC32 - 5288DB02
               MD5 - 025123D33BD5716D8508E6370CC39B85
              SHA1 - B00E10A0AFCE454BC1A95A0D377EC40B6DE2D615

----------------------------------------------------------------------------------------------------

Phantasy Star III's official localization is largely unfaithful at all to the Japanese version. I
tend to stick to the retranslation as a result, but as with the other games in this series, I prefer
the names used internationally. Thus, I decided to make this patch for myself and release it for
whomever felt the same.

This archive contains 4 patches.

1. PSIII_ClassicNames_v12-CN.ips
    After you have patched your unmodified PSIII ROM with Rebecca et al's retranslation, apply this
    to receive the base features of PSIII Classic-style Names.


When the above has been accomplished, choose as many of these as you'd like, in any combination.
 

2. PSIII-CN_NormalBattleThemes.ips
    Restore the tracks Battle (Begin), Battle (Winning), and Battle (Losing), which PSIII Classic-
    style Names removes as the author finds them hard to listen to.

3. PSIII-CN_RewardsDoubler.ips
    Every enemy will give double the experience and meseta rewards after battle.

4. PS3T-ParallaxPatch.ips (lory1990)
    In the Japanese release of PSIII, both the top and bottom of the battlefields scrolled at all
    times. The international release made it so only outdoor sky scrolls. This patch restores the
    Japanese behavior.
====================================================================================================

====================================================================================================
Overview
========
v1.2-CN (Jan 2 2024)


GENERAL:
- Includes the full retranslation and all enhancements from Phantasy Star III: Retranslated by
   Rebecca Capowski, Peaches, and lory1990.
   
   
- Removed the game's checksum routine to make the addendum patches viable.


TEXT:
- Reverted the name of each person and city to their international equivalent. An exception was
   made for Foundaury: A. Space issues regarding the name "New Motavia", B. This place has nothing
   to do with Motavia.
   
   
- Many tech names have been changed. In some cases, not to match PSIII, but to match techs of
   similar effect in PSII and IV.


- Updated and optimized a plethora of equipment names for readability.


- Fixed an error in the retranslation where Siren confuses Laya and Orakio.


- Gave one of Gwyn's lines in the ending to Wren, as in the official localization, since this
   particular line expects her to be named Laya.



GAMEPLAY:
- [Applied Patch] PS3 Translation Walk Speed Patch (lory1990)
   Your characters will walk at double the speed of the unmodified game.
   
   
- Included Rewards Doubler addendum, which increases EXP and MST rewards by 2x (final boss aside).
   Apply after the main patch.



SOUND:
- Stopped Battle (Begin), Battle (Winning), and Battle (Losing) from playing at any point. Now
  Battle (Balanced) will play for every fight (final boss aside) and not change.


- Included Classic Battle Themes addendum to remove the above change. Apply after the main patch.



GRAPHICS:
- Restored "Generations of Doom" subtitle to the title screen.


- Replaced the font of the opening credits with a fancier one to give the title screen more oomph.


- Included Parallax Patch addendum by lory1990, which restores Japanese battle background behavior.
  Apply after the main patch.
====================================================================================================

====================================================================================================
Credits
=======
- lory1990: Hacking, assistance

- Rebecca Capowski: Translation

- Peaches: Translation

- Sega

...and all you Phantasy Star fans out there! See you in the Algol system!
====================================================================================================