Pit Fighter Upgrade
Sept. 8th, 2023
BillyTime! Games
--------------------
This patch for Pit Fighter on Sega Genesis adds Hi-Score SRAM in addition to refilling player's health after each bout in single player mode.

Hi-Score SRAM:
Saving:
Scores save after entering initals.

Loading:
Scores upon boot up. Default scores will load if checksum fails.  

How to Patch:
--------------------
1.Grab a copy of Pit-Fighter (World) (Rev A).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

