/************************************
 * Info:
 ***********************************/

Name: Pulseman Trainer Hack
Date: 14.07.2024
Version: 3.1
Original ROM: Pulseman (J) [c][!].bin
Code: Segaman

/************************************
 * Information:
 ***********************************/
 
This hack provide all features to practice for speedrunners.

/************************************
 * Features:
 ***********************************/

-Custom main menu
-Built-in 'help' section
-Stage select

In-game:
-Restore hp: heal player
-Navigate: activate free movement
-Inf volt: unlimited power
-Inf life: unlimited hp
-Repeat stage: replay stage forever (for practice)

Note: Use gamepad buttons to navigate in-game pause menu in hotkey style

-'Score' is replaced with player coordinates
-If you somehow stuck just hold 'Start' button for 3 seconds. The game will reset
-'Navigate' will turn player into custom made object. To exit this form just press 'A'

/************************************
 * Known issues:
 ***********************************/
 
'Navigate' doesn't allow you to to fly thru walls.

To fix it:
>Gain power charge (or activate 'inf volt' feature)
>Activate pulseman's voltecker (press 'A')
>Go to pause menu
>Activate 'Navigate'

From now on you will be able to navigate stage with no collision

/************************************
 * How to patch:
 ***********************************/
 
Patch (J) [c][!] version of the game with provided ips-patch file

