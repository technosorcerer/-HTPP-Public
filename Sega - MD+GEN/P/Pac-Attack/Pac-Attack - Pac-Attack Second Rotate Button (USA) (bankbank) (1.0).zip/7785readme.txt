Pac-Attack Sega Genesis second rotate button hack by bankbank in May 2023

This is a wonderful falling-block puzzle game by NAMCO, but unfortunately it only has one rotation button. The Genesis hardware obviously has support for more buttons, so it was feasible to take advantage of that and add in a second, opposite-direction rotate button.

A button: original function
B button: new, opposite rotation
C button: same A button

Puzzle mode is no longer selectable in this mod, because it utilizes B to turn Pac-Man around. If you want to play the puzzle mode, just use the vanilla ROM.

Note that there are two sizes of ROM available: 1MB and 256KB. You must patch the 1MB ROM.

any questions? bank@bankbank.net
