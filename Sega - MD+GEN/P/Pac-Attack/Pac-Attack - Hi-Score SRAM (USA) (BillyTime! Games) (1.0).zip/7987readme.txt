Pac-Attack Hi-Score SRAM
Aug. 7th 2023
BillyTime! Games
--------------------
This patch is designed to add a simple saving mechanism for High Scores in Pac-Attack.


How to use
--------------------
Saving:
Scores save after Initials are entered and player leaves the Records Screen and player returns to the main menu. 

Loading:
Scores load upon boot. If checksum fails or it is your first time booting, default scores are loaded.


How to Patch:
--------------------
1.Grab a copy of Pac-Attack (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file