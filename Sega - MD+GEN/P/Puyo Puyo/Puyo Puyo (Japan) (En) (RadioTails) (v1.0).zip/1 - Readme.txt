Translation Information:

               Game: Puyo Puyo (ぷよぷよ)
            Console: Sega Mega Drive/Sega Genesis
           Language: English USA or English UK
            Version: 1.0
  Author's Username: RadioTails
    Author's E-mail: radiotailspuyo@outlook.com

     To ensure you have the correct and latest version, please make sure you
have downloaded the "Puyo Puyo (Mega Drive - English - V1,0).7z" file from
this website: https://romhackplaza.org/

-------------------------------------------------------------------------------------------------

Original ROM Information:

    -  Name: Puyo Puyo (Japan).md
    -   MD5: C723D1079157AB78E160B26AC5091D74
    - SHA-1: 02656B5707CF9452D4CF48378FFD3A95DC84E9C5
    - CRC32: 7F26614E
    -  Size: 512 KB

-------------------------------------------------------------------------------------------------

Translation Details:

     This is a complete English translation for the Sega Mega Drive/Sega Genesis version
of Puyo Puyo (ぷよぷよ).

     The spoken dialog from the STORY MODE has been translated to maintain the original
humorous tone when possible. Where Japanese jokes/slang are used, these have been localized
to make sense in English, while keeping to the original context. 

     The three Japanese voice clips have not been changed. This is to preserve the original
voice clips from the original game.

-------------------------------------------------------------------------------------------------

Patching Instructions:

     1: Obtain a copy of the "Puyo Puyo (Japan)" ROM (.md or .bin) by using one of
        the following methods: 
	   Method 1 - Download the ROM from the Internet. 
	   Method 2 - Backup the ROM from the original cartridge.

     2: Rename the ROM to: Puyo Puyo (English).bin

     3: Use MD5-SHA-Checksum-Utility (https://github.com/oop7/MD5-SHA-Checksum-Utility/releases)
        to check the "MD5" and "SHA-1" match the following:
           -   MD5: C723D1079157AB78E160B26AC5091D74
           - SHA-1: 02656B5707CF9452D4CF48378FFD3A95DC84E9C5

     4: Use Lunar IPS (https://www.romhacking.net/utilities/240/) to apply one of the following
        IPS patches to the ROM:
           - Puyo Puyo (English USA).ips
	   - Puyo Puyo (English UK).ips

        Note: Check the "English USA and English UK Differences" section below for more
              information on which IPS patch to apply.

     5: Use MD5-SHA-Checksum-Utility to check the "MD5" and SHA-1" match the following:

	English USA version:
           -   MD5: E242D9ECB5B31D050171FC4B3CA555D2
           - SHA-1: 48637EA9B34F018D200DA5CD3B1E878B73D3F713

	English UK version:
           -   MD5: CF30982FEE29722DED371A7BCC436534
           - SHA-1: C0B0357B06F91458552A50E9E0193C7398E0FF91

-------------------------------------------------------------------------------------------------

English USA and English UK Differences:

     The "English USA" translation is aimed at people who live in countries that use
the American English vocabulary.

     The "English UK" translation is aimed at people who live in countries that use
the British English vocabulary.

     Using the "English UK" translation will have the following minor changes:
        -  Title Screen: ENG-US > ENG-UK
        -       Stage 5: git > get
        -   How To Play: color > colour
        -    ROM Header: SEGA GENESIS > SEGA MEGA DRIVE    
        - Staff Credits: KIRBY'S AVALANCHE™ > KIRBY'S GHOST TRAP™

     The word "git" in the UK is slang for "someone who is foolish, worthless, or
unpleasant". So to prevent Sasori-Man from sounding like he is insulting Arle, this
was changed to "get".

     The SNES game "KIRBY'S AVALANCHE™" name was changed to "KIRBY'S GHOST TRAP™ in
PAL territories.

-------------------------------------------------------------------------------------------------

Bug Fixes:

     The following bug has been fixed:
        - In STORY MODE, the AI won't lose their ability to manually drop Puyo if the
          other player is holding left or right on their controller.

-------------------------------------------------------------------------------------------------

Improvements:

     The following improvements have been made:
        - When entering your initials for a HIGH SCORE, the . character can be selected.
        - The CREDITS scroll faster (the same speed as in "Dr. Robotnik's Mean Bean Machine").
        - BGM 13 can now be selected in SOUND TEST (this is the victory tune when you win a
          match in STORY MODE).

-------------------------------------------------------------------------------------------------
