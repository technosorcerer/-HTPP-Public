Pac-Man 2 - The Arcade Games - (Arcade Level Randomizer)
May. 22th 2025
BillyTime! Games
--------------------
This fun patch is designed for Pac-Man 2 for the Sega Genesis. 
It is designed to randomize levels for both Pac-Man and Pac Jr.

How It Works:
--------------------
After the first stage, Level will be randomized. This will continue until game over.

Pac-Man and Pac Jr. are available from the main menu.

How to Patch:
--------------------
1.Grab a copy of Pac-Man 2 - The New Adventures (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file