Pac-Man 2 - The Arcade Games
Jan 7th, 2021
SEGAMAN, FUTURA, Double Z & BillyTime! Games
--------------------

Pac-Man 2 - The Arcade Games is a collaboration patch designed to allow you to play both Pac-Man and Genesis exclusive Pac Jr.
without the need to play the base game or use a password.

Changes:
--------------------
v1.0:
*Opening cutscene is skipped (Credit to Tony H)
*Text changes on the main menu to note both Pac-man and Pac Jr. (Credit to eskayelle/Double Z)
*Hex editing to repoint Start Game to Pac-Man (Credit to eskayelle/Double Z) 
*Custom code utilized when selecting Pac Jr. to automatically load the game from the password screen! (Code by BillyTime! Games)

v1.1:
*Palette hex editing to revise title screen to look more similar to the arcade games (Credit to Futura)
*Palette hex editing to black out the password screen background (Credit to Futura)

v1.2
*Palette hex editing to black out password screen sprites and "The New Adventures" sprites (Credit to eskayelle/Double Z)

v1.3:
*Hex edits to certain LEA $00A0FF00, etc. calls to register A3 to silence password screen music (Pause Toon) and exit chime (Credit to eskayelle/Double Z)
*Extraneous password text in arcade games removed (Credit to eskayelle/Double Z)
*Hex edit to remove attract mode demos (Credit to BillyTime! Games)
*Checksum fix by eskayelle/Double Z

v1.4:
*20,000 high score fixed for Pac-Man along with high score leaderboard names and scores.
*Reduced wait time on SEGA and Namco logos.
*Pac-Man themed SEGA logo palette applied.

How to Patch:
--------------------
1.Grab a copy of Pac-Man 2 - The New Adventures (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file