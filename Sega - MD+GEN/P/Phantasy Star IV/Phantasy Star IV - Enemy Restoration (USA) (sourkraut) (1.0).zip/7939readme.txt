		------------------------------------
		|Phantasy Star IV Enemy Restoration|
		------------------------------------


Restores the two missing enemies that were removed from localizations outside of Japan, namely
Acacia and Shadmirage.

Optionally included is another patch that, in addition to restoring these two enemies, also
contains lory1990's bugfixes.


		--------------
		|Instructions|
		--------------


Patch is in BPS format, and is patchable with Floating IPS.


Phantasy Star IV (USA)

CRC32: FE236442

SHA1:  BC7FF6D6A8408F38562BC610F24645CAD6C42629
