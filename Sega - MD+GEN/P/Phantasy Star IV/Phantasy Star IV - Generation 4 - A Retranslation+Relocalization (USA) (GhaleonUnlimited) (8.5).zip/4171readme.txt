Phantasy Star Generation 4 - PSIV Retranslation/Relocalization
Version 8.5 Final-ish - Jan. 1, 2024 

______________________________

NEW in Version 8.5:

Completed playthrough of 8.0, fixed a few typos/grammar choices/updated wording
Compressed about 20-25 lines to create better line breaks
Edited a few end-game items to subtly tie them to PSII and PSIII.
Fixed a few awkward sentences and mistakes still remaining in the original script. (Deseart Leach --> Desert Leech)

______________________________________

NEW in Version 8.0:

Added small pieces of PS lore gleaned after completing recent replays of PS1, PSII text adventures, PSGen1 and PSGen2 ("metalball" is a sport mentioned in Huey's Adventure, for instance)
Main Party-Villain encounters dialog slightly edited
Le Rouf dialog slightly edited
Entire script checked over for first time since 2019, small phrasings changed here and there
Honestly some of my newest dramatic dialog sounded corny when I read it on the screen during an actual playthrough, so I toned a couple passeges down. Mainly I just wanted dialog to be in-character for everyone, and I also eliminated some redundant dialog.
Fixed a few remaining typos
Made a few sentences flow better with better line breaks
Further refined Purist version 
_________________________________________

Project website + Podcast: https://gamesdonelegit.com/phantasy-star-iv-generation-4-psiv-romhack-relocalization/
Let's Play Creator's Commentary: https://youtube.com/playlist?list=PL2LS83hGJuPZ975VAposdWyeXoD_aaMVt

NOTE: Working Designs and Purist scripts are 99% the same. The WD patch does not have pop-cuture references or anything, it simply contains a few additional lines or word changes with additional color during NPC/searches/intra-party dialog. 

Almost all the story dialog is the same. Both versions follow the dramatic beats of the game -- the WD version doesn't insert jokes into serious moments or anything like that at all. I simply really like Working Designs' dramatic and comedic writing styles in their SEGA CD games (though I did not put in any toilet humor or pop-cuture jokes even in the WD version).

___________________________________
For THANK-YOUs - please review me!
___________________________________

If you enjoy this, in lieu of a donation, please just write an honest review of your thoughts on whatever platform you DL'd this (Romhacking.net, CDromance, romhacks.org, archive.org, wherever), even if it's like one sentence. I really appreciate it! I have a couple, um, odd reviews (see the few negative ones on RHDN and decide for yourself the validity of their criticisms) so I honestly just want people to have a honest, fair idea of what to expect from the project. 

I don't do any Patreon or accept donations because this is straight hobby -- I have no rights to Phantasy Star or SEGA or anything, and I just really love Phantasy Star and SEGA. I just wanted to help PSIV to shine as brightly as it could/should.


NOTE on PS character names/proper noucs: In the English-speaking world of Phantasy Star, there is not one "absolutely right" version of character names and proper nouns (items, spells, etc.). In English, some proper nouns changed names in different installments. Some consider the original Japanese names to be "correct".

___________________________________
Your Patch Preferences
____________________________________

If you prefer different character / spell names / etc. than what I used (like if you prefer all Japanese names) send me an email and I can send you a custom patch if you give me the time to create it and send it to you.

I have a couple templates pre-made; I don't include them in this zip because the amount of choice can be overwhelming for some people -- which I understand! I downloaded the FFIV Ultima translation and there were like 7 options. I read up on the differences a bunch, and I never ending up being able to decide, so I still haven't played FFIV.

Almost every English-speaking PS fan has different preferences for their preferred universe of PS, so let me know and I can probably provide. I've made versions with all English names, Japanese names, custom names for a single person, and one with terms to best match English PS1's names and spells.

************Credits************

Coded/Written/Edited/Extra Programming/Direted: Chris Hatala -- "GhaleonUnlimited" -- hatalawriting at gmail dot com

Co-editor: Squirrel2
Original programming and programming assistance: lory1990 
Custom Gen4 Title Screen Graphics, additional programming help: BGE (French PSIV fan translator)
Bulk of story retranslation: The Cutting Room Floor PSIV Proto section
Additional PS Lore/Background Translation: Rebecca Capowski, scenaryrecalled.com

These patches include PSIV bugfix by lory1990. 

My version of the disassembly has been so heavily modified by me that I can't just cut and paste the latest lory one in. So if you find any glitches in my patches that you believe should be fixed, just let me know and I'll take care of it!

________________________________
Additional Phantasy Star Resources
__________________________________

Please send bugs/glitches/comments to me at:
hatalawriting at gmail dot com

Project URL (pics, PS resources): https://gamesdonelegit.com/phantasy-star-iv-generation-4-psiv-romhack-relocalization/

Also located there: "Found in Fanslation" podcast interviewing people translating PS and SEGA games and resources into Western languages.

YouTube Let's Play Creator's Commentary, finished Nov. 2021.
Full Playlist: https://youtu.be/EVMWscqAY8Q

First RHDN posting in Aug. 2018, Ver 8.0 posted to Romhacking.net Oct. 2022.

NOTICE TO ALL WHO CREATE THEIR OWN GAME CARTRIDGES
**Please do not burn this to a Genesis/MD cartridge AND sell it for personal profit. Please respect the spirit this work was done in, as well as SEGA's copyrights.
I will include instructions on how to burn this to an actual copy of Phantasy Star IV on the project website (I recommend getting a Japanese copy cheap on eBay to do so).
**Please see below for more details.

New in Version 7.7
-Enhanced "There's nothing here" character lines
-Extremely minor typos/script enhancements

New in Version 7.5
-Minor script revisions, mainly for Purist version. 

New in Version 7.0
-"Generation 4" appears on the title screen, courtesy of BGE, master programmer and creator of the French PSIV fan translation!
-Minor typo fixes

New in Version 6.1
-Fixed about 10 line breaks / typos I found during my YouTube Let's Play Creator Commentary series.
-Small changes to some end-game dialog (Demi's "huge hole" line and Rune and Rika's subsequent lines; Rudy's speech about Alys after his ragequit and Rune's subsequent reply).

New in Version 6.01
-Changed Alys's first line about hearing Zio's name because of a wording issue
-Fixed typo in Purist version during a key sad cutscene

New in Version 6.0
Exciting new PSIV plot details unearthed in an English translation of the PHANTA! Phantasy Star 30th Anniversary Cosplay Book + Developer Interview. 
A simple 2 sentences or so in here explain the background and motivation of a major character, as well as connect them to another -- which in turn sets up THEIR motivation.
In my opinion, this truly ties together the story of PSIV, which was already a high-water mark of 16-bit RPGs. So added additional dialog in 3 scenes to reflect this, as well as revise a few NPC lines in the Mansion.

New in Version 5.2
-Removed a few lines deemed a bit out there for the Purist patch
-New automated edit+compare of all versions of the script checked against default script. Fixed more small typos.
-Thanks to RHDN user Red Soul, made a few minor dialog changes to both patches.
-Including a "how to ROMhack classic PS games" doc on doing your own edits even if you have no programming skills.

New in Version 5.0
I realize I might have inadvertently caused some confusion to users by way of my preferences as a localizer. So I'm renaming the patches so you can most easily choose which suits your tastes. 
-"Purist" patch now has almost no added NPC color and levity beyond what's in the original game.
If you tried the patch and found script to have too much editorializing for your taste, now you can enjoy the project's added story/lore/dialog, along with the fixed grammar and awkward lines from the original game.
-"Recommended" patch renamed to "Working Designs" (but it's still preferred to the author)
-"No Joke" patch renamed to "Purist"
-Added patch edition: "Purist + Japanese character names" (Lyla, Fal, Pyke, etc.) (Available upon request!)
-Including a technique/skills guide for those new to Phantasy Star, since in-game descriptions are not possible to add
-Including a map of Motavia, translated into English, since the in-game map I've re-added to the game isn't that helpful.

New in Version 4.6 - Final-ishish
*Capitalized "Algol Solar System"
*Changed one of Rudy/Chaz's earliest lines
*Very minor edits

New in Version 4.5 - Final-ish
*Rewrote characters' opening conversation. Some of Alys's dialog is straight from one of my mentors, but it's hard to convery loving sarcasm in text, so I made Rudy's/Chaz's interactions with Alys a bit less harsh.
*Reworked a few pieces of dialog in story moments.
*A couple linebreak fixes
*A couple typo fixes

New in Version 4.4 - Final-ish

-Added "NO JOKE" edition patch, which varies as follows:
*Removed most color/editorialization added to NPC lines
*Softened/blanded a few Alys lines at the beginning
*Removed a few added/colored character moments
I feel differently than some do about what the writing in videogames and also localizations should be strive for, and have felt this way since the '90s. 
I did this project for personal amusement, but when I released it and got more feedback, I respect that not everyone has to share my viewpoint.
I don't want people to miss out on the enhancements to the PS universe and story because they didn't like a few jokes at the beginning, so I figured giving players both options is best.
If you try the recommended and don't like some of the writing, play this to still get all the fixed PS references, more accurate translation, and improved story dialog.

In all patches:
-Allowed Raja & Rune to equip a few more shields (Plasma Field, Power Shield). Most players will never make use of these items in normal play, and there's no in-game reason these two cannot equip them
-Changed music for Anger Tower to "Pain"
-Changed music for Sacred Sword Cave to "Mystery-Planet Field"
-Added addtional "Guard Robe" to one of the final towers
-An optional boss fight at the end of the game was made slightly harder (but it's still super easy).
-Added overworld "Map" item, stored in 1st chest of the game, which was removed from final version of game but remained in the code
-Added "Spiral Slicer" weapon that was deleted from final version of game but remained in the code
-Very minor line-break & typo fixes


New in Version 4.2 - Final(?)
-By request, made last solar Ring equippable for your extra party member (but it isn't required to wear)
-Changed Gryz's job from "Motavian" to "Agent". Your race isn't a job, and he obviously has a connection with Grandfather Dorin. "Agent" calls back to Rolf/Eusis in PSII, too.
-Made Guard Shield equippable by all non-Android party members to make it useful for the endgame
-Fixed bug that screwed up all the dialog at the end of "Man with a Twist"
-Slightly upped stat boost of all Rings. (One character's was much upgraded to make them more useful for endgame)
-Made long dash character replace all double hyphens (--)
-Very minor grammar changes
-Tweaked some monster skill names "Bdl Slash-->DoublSlash"
-Added "Phantasy Star Generation:4" to intro so you know what you're playing. The Title Screen is all encrypted graphics, so I can't figure out how to mod them correctly
-Edited intro so last line isn't cut off before you can read it

New in Version 4.0 - Final(?)
-100+ more typo/line break fixes after playing through the game yet again
-Fixed Sound Test text glitch that screwed up item names
-Tweaked Gyuna dialog to make him more readable
-Tweaked ending/key story dialog
-Tweaked some punctuation to more accurately convey the character's emotion.
-Tweaked ending text to match music as well as possible.
-Tweaked a few jokes (changed "emo" to "goth", for instance, to better describe the character in question)
-Long dash (--) implemented as single character that's still longer than a hyphen (-) thanks to Squirrel2. 
(Yes, they are different puntuation marks with different uses.)
-Fixed typos in intro that were in the original ("spiralling") and rearranged a few lines in the intro, too.
-I forget what version this was from, but all end-game items that read "NOTHING IS KNOWN ABOUT THIS ITEM" now have a brand-new description.
e.g. 
Palma Ring: Emanates with the regal blue-sapphire of Palma.
Silver Fang: Ancient claw with the power to destroy evil.
"Guard"-class stuff is described as made of "planar" (which was end-game equipment in PSIII).
-Fixed typos in spell names
-By request, added patch option to use classic spell name with "Gen 4 Recommended" patch
There's no one right way to represent the spells in English because of the original English translation being so random.
The "SEGA AGES" follows the spell names from the fan-translated Playstation 2 remakes as well as possible (characters permitting).
The default is mostly original English spell names with minor editing for only the worst-translated ones (e.g. Arows--> Arose, Rimit--> Limit, Regen-->Revrs , short for Reverser)
In the default patch, NaThu is changed to "Glanz". "Grants" (a mistranslation of the spell) is featured in PSIII's ending as a powerful technique, and it's also in Phantasy Star Online. "Glanz" is the proper translation of the Japanese katakana. So I did the best of both worlds (I thought), making the three techs Tsu/GiThu/Glanz. Again's there's no good way to reconcile all the different ways PS technique names have been translated into English in different games.

New in Version 3.5
-More typo fixes
-A few glitch fixes (jailbird girls' dialog being messed up)
-A few lines not displaying properly
-Squirrel2 finished comprehensive edit of whole script

New in Version 3.21
-Bugfix in 2nd TALK party conversation of the game, reintroduced from an old version.
-" " character added for "fianc , fianc e, and prot g  thanks to Squirrel2 !
-A few more typos/linebreaks fixed. Hopefully a "final", played-through-by-multiple-people patch will be available in the next month.


New in Version 3.1
-Ton of typo fixes
-Tons of new NPC dialog
-Revised ending text-speed scroll thanks to BGE and Squirrel2
-Revised story cutscenes
-Added project credits to ending thanks to BGE & Squirrel2
-Added new lory bugfixes
-Added asterisk (*), double quotes (   ), and colon (:)
thanks to Squirrel2
TO DO:
Not much else I can think of.
Need to replay whole game again to catch linebreaks/typos


New in 2.0
-Author played through entire game and fixed many typos/line breaks, made many small script edits.
-New ending script (it had been written but not implemented in-game by accident, until now).

KNOWN ISSUES/TO DO: 
-Add individualized dialog depending who is in your party for the final "TALK" menu converstation
-Add title-screen & credits text to reflect "Generation 4" romhack.
-Accompanying Word doc of new script / editor's notes is no longer totally up to date with final game script


New in 1.48
Fixed a textbox break on a Raja pun, fixed minor typos, and fixed some item descriptions.

New in 1.45 
Added Acacia and ShadMirage monsters back into the game
Very minor text fixes.

New in 1.40
Did a comprehensive edit over entire script. Cleaned up grammar, punctuation, some missing words, and added/adjusted a few lines.
Did more comparison to Japanese text and adjusted script accordingly.
Hopefully got rid of all instances where text boxes cut off.
Restored Raja's "punchline" delivery to how the Japanese version handled it.
Restored a few minor PS series references (cats not being able to open bottles, for one instance).

New in 1.30
Fixed a game-breaking glitch in which the player couldn't advance the story past Meese.
Fixed "Torndagger" not appearing properly
Fixed glitch in which two-word weapons and items didn't display the second word when object was found in battle. 
(e.g. "Laser Found!" instead of "Laser Claw Found!")
Many typo fixes
Some new story dialog, many toward the end of the game.

New in 1.20 

-The game has been played through by me and lory1990 (PSIV bugfix & disassembly creator) up to when you arrive at the next planet. So text should be pretty clean to that point.

-Fixed glitch where change arrow after "Attack" and "Defense" weren't appearing in status menu.

-Many more typo fixes.
-A few additional dialog lines and editing.
-Fixed the glitch (I think) after Raja's pun that was present in the original English version, when he first talks about Garuberk Tower.

1.10
Fixed many typos and conversation boxes.

Also, The Gen 4 version of the patch now already includes the bugfix patch by lory1990 in a better way. There should be no risk of our patches interfering with each other.

The SMS/Classic version does not include the bugfix patch to keep with the "stock" version of the game.



Part 1: How to get the Phantasy Star Generation 4 patch to work

This only works on the final U.S. version of the game.

There are 2 patches depending on your preference! See project page http://PSIV.GamesDoneLegit.com or RHDN project page (just search for "Phantasy Star Generation" to find it)

How to patch:

1 Download LunarIPS (https://www.romhacking.net/utilities/240/)
2 Download my PSIV patch ZIP file (all apart of this readme!)
3 Open LunarIPS and click APPLY PATCH
4 Select the IPS file labeled PS GEN4.IPS
5 Select the Phantasy Star IV file that you obviously have made from your own Genesis cartridge or digitally purchased legally.
6 Play!


Part 2: Which version of Phantasy Star Generation 4 should I play? (THIS IS OUTDATED -- see RHDN Page)

   Gen4  best matches the SEGA AGES Playstation 2 remakes, and also is the recommended version of this patch regardless
   SMS  was made for posterity, to best tie PSIV to the original English versions of PSI - III on Master System and Genesis/Mega Drive.

They re both mostly the same, but the SMS patch links some things back to SMS PSI, such as the Rune & Kyra s magic spells are the same as the super-boring magic spells in PSI (Flaeli is  Fire , Binda is  Rope , etc.).

When I first played PSIV, I had no idea that Rune was supposed to be using the same spells as in PSI, because the names are so different. 

Flaeli is the  correct  translation, but it didn t link up with an English-speaker s PSI experience.

The names of past PSI characters keep their English SMS PSI names in that patch, as well as a few items/weapons (Star Dew ? Star Mist to be consistent w/ Gensis PSII, etc.)

The SMS patch also maintains ALL CAPS for the items, monsters, menus and messages, because it matches the other SMS/Gen/MD PS games.

The main Gen4 patch uses Proper Casing (vivify93 s Proper-Caser mod was the springboard for this project) everywhere, and has a few extra connections that match the original Japanese versions & English fan-made Generation 1 & 2 translations.

I ve been playing videogames since Atari, and I mostly just play retrogames now - despite being such a big fan of videogame history, I think the Gen 1 & 2 remakes are the better games to play now. They have much better characterization, the 2-D artwork is great, and I think they re the definitive way to play Phantasy Star.

So because a real PS Gen 4 is never coming it seems, I wanted to finally polish PSIV to be the best bookend to what I consider the best story in classic gaming.

Obviously it isn t perfect, and we won't agree on every interpretation of the universe, naturally! But if it makes you play through PSIV again, or for the first time, and basically enhances your love of PS at all, then I m happy!

I hope you find some enjoyment out of it.



Part 3: Credits 

Thanks to Apathetic Aardvark for releasing the English script dump.

Thanks to The Cutting Room Floor PSIV Translation comparison btw May/Aug '94 & Final English, with commentary on the original Japanese.

Thanks to kahran042 for releasing Japanese phoenetic translations of proper nouns in PSIV.

Biggest thank you of all to lory1990 for creating the Disassembly of the classic PS games, which was the only way I could even begin this project in the first place.

And thanks to Squirrel2, who put dozens and dozens of hours into in-depth editing and bugtesting. This wouldn't be nearly what it is today without him.

Thanks to vivify93 for being the first to get back to me when I was trying how the heck to get this started, and for being a limitless resource of PS knowledge and good will!

And thanks to SEGA for making the best games ever and for being cool to the fan community about stuff like this. 

Thank you for downloading this, or at least reading the readme!

If you enjoy the classic PS games, please please please try the Playstation 2 SEGA AGES remakes now that they're in English! Thank you to all the folks who worked so long and hard to make that a reality!

And also, if you like PS, remix the music, draw art, write fan fiction, mod the games, or just tell people about them. They're so underappreciated!

Copyright stuff

This is my first hack, so I don't really know what I'm supposed to put here other than I have no affiliation with SEGA (outside of being an unpaid brand ambassador!) or Phantasy Star and do not own any of the content in the game, etc. You can do whatever you want with this hack. Just link to the romhacking.net patch page if you want to share this or share the new script or talk about the changes. Do not distribute ROMs. This hack only contains an IPS file to be applied to a legally obtained ROM.

NOTICE TO ALL WHO CREATE THEIR OWN GAME CARTRIDGES
Please do not sell this content in any form, especially in the form of burning this to a Genesis/MD cartridge and selling it.
This is illegal: You're making money off of both the hard work of the devs who made the game and also me. This project was explicitly meant to be enjoyed for no greater cost than owning a real or digital copy of Phantasy Star IV.
We are allowed legally I believe to burn it onto a cartridge for personal, non-commercial use only if you already own the game. Get a friend's or use YouTube to learn how. You'll have fun and it's very rewarding, and once you have the equipment and learn how to do one, you can put all your favorite hacks on real cartridges!

If I see this being sold anywhere, I will kindly ask you to respect the author's wishes and remove it from your store. 

If you choose not to, I will report you to whatever authority (etsy, ebay, SEGA, whoever) can convince you not to.

Thanks!

-- Chris Hatala ,  GhaleonUnlimited  -- hatalawriting at gmail dot com
http://PSIV.GamesDoneLEgit for more info!