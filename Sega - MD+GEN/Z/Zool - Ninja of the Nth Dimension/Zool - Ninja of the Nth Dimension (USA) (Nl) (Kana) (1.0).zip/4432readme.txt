Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 11-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.
N.B. De Europese cartridge (dump) bevat nog enkele Japanse tekststrings,
deze zijn ongewijzigd gebleven.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Zool - Ninja of the 'Nth' Dimension.md (No-Intro Romset)
Platform: PC Engine/Turbografx-16
Database match: Zool - Ninja of the 'Nth' Dimension (USA)
Database: No-Intro: Genesis (v. 20180824-045026)

MD5:   2D28DDB5BE02A3B3612BA73CA064EDB5
SHA1:  EE016F127B81F1CA25657E8FA47FAC0C4ED15C97
CRC32: CB2939F1
Bytes: 1048576

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --