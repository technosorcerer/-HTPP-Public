Zombies Ate My Rougelike v4.0
Aug. 1st, 2024
BillyTime! Games, Spkleader
--------------------
Inspired by The Binding of Issac, this patch aims to turn Zombies Ate My Neighbors into a Roguelike!

High Score SRAM: (v4.0 Only)
--------------------
Saving:
Enter High Score and return to the sega screen.

Loading:
Scores load at boot, default scores will load if no save detected.

How it works:
--------------------
The game randomizes levels across five tiers before ending at the level, Monsters Among Us.
The game start you at a random level in tier 1 and advances a tier each time you complete a level.
You have one life to complete all five tiers with only one life to start with.
Good Luck!

Tier 1
01 - Zombies Panic
02 - Evening of The Undead
03 - Terror in Aisle Five
04 - Chainsaw Hedgemaze Mayhem
05 - Weird Kids on The Block
06 - Pyramid of Fear
07 - Dr. Tongue's Castle of Terror

Tier 2
09 - Toxic Terrors
0A - No Assembly Required
0B - Weeds Gone Bad
0C - Mars Needs Cheerleaders (Aliens)
0D - Chopping Mall
0E - Seven Meals For Seven Zombies
0F - Dinner on Monster Island
10 - Ants
11 - Office Of The Doomed

Tier 3
12 - Squidmen Of The Deep
13 - Nightmare On Terror Street
15 - The Day The Earth Ran Away (Aliens)
16 - Revenge Of Dr. Tongnue
17 - The Caves of Mystery
18 - Warehouse Of The Evil Dolls
1A - Where The Red Fern Growls
1B - Dances With Werewolves
1C - Mark of the Vampire

Tier 4
1D - Zombie House Party
1E - The Horror Of Floor Thirteen
1F - Look Who's Coming To Dinner
20 - Giant Ant Farm
21 - Fish and Crypts
22 - I Was A Chainsaw Maniac
23 - Boardwalk Of Terrors
25 - Labyrinth of Horrors
26 - Monsters of the Blue Lagoon
27 - Destroy All Vampires
29 - Martians Go Home (Aliens)
2A - Spikes
2B - Super Fund Cleanup Site
2C - The Curse Of Dr Tongue
2D - Danger In Picnic Park
2E - Day Of the Chainsaw

Tier 5 - (Boss Tier)
08 - Titanic Toddler (Boss)
14 - Invasion Of The Snakeoids (Boss)
19 - Look Who's Shopping (Boss)
24 - Monster Phobia (Boss)
28 - Pyranmid Of Fear 2 (Boss)
2F - Grid Iron Terror (Boss)
30 - Curse Of The Monster (Boss)

v3.0 New Feature - Mania Mode!

How it Works:
--------------------
Press B at the Sega screen to activate Mania Mode. After the first tier, every level is completely randomized. The game also becomes endless with failure being the only option. 

This new feature can syngergize with the password function to fully randomize all levels! 

Mania Mode deactivated by pressing start at the Sega Screen.

Additional Changes:
--------------------
*Boss health has been modified.
*Squirtgun Deals Additional damage
*Purple Ants have slightly reduced health (From 09 to 08)
*Key pickups doubled
*Players start with only one life.

Notes:
--------------------
*Grabbing a bonus level pickup will allow you to play the bonus level a skip a tier, even tier 5!
*Extra lives can be found depending on your luck and or skill.
*Entering a password will give you a completely random starting level for your first stage! All levels including bonus levels can appear if you are feeling lucky!


How to Patch:
--------------------
1.Grab a copy of Zombies Ate My Neighbors (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

