Zero Tolerance (Mega Drive)
Traducción al Español v1.1 (07/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V1.1: Cambio de "superad" por "superada".

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Zero Tolerance (USA, Europe).md
MD5: 54427136beee5a270232445bbfd0341f
SHA1: d6d9733a619ba6be0dd76591d8dec621e4fdc17e
CRC32: 23f603f5
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --