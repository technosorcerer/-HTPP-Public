Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 11-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.
N.B. De Europese cartridge (dump) bevat nog enkele Japanse tekststrings,
deze zijn ongewijzigd gebleven.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: ero Wing (Europe).md (No-Intro Romset)
Platform: Sega Mega Drive / Genesis
Database match: Zero Wing (Europe)
Database: No-Intro: Genesis (v. 20180824-045026)

MD5:   5F4F2FB8C7B8C50EFBC6EED57CE3DAE3
SHA1:  98335B97C5E21F7F8C5436427621836660B91075
CRC32: CB2939F1
Bytes: 89B744A3

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --