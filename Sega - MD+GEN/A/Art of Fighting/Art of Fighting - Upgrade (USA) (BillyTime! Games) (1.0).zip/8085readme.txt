Art of Fighting Upgrade
Sept. 18th, 2023
BillyTime! Games
--------------------
This patch for Art of Fighting on Sega Genesis adds Hi-Score SRAM in addition to a few tweaks.

Features
--------------------
Region Free
Controls defaulted to Config-D if Six Button controllers are present
Restored Very Easy and Easy Difficulties from JP Version
Infinite Continues (All Modes)
Stage Cycling during Versus Mode
Increased meter gain (1.5x Multiplier) in Ice Break bonus game (Story Mode)
Increased timer from 18 to 25 seconds for Death Blow bonus Game (Story Mode)

New Cheat code: 
Hold P2 and P1 Start at title screen while highlighting 1 Player. Continue to hold until
character select appears to immediately unlock the Haoh Shoukou Ken Death Blow in story mode.
Cheat needs to be re-entered when returning to the title screen.


Hi-Score SRAM:
Saving:
Scores save after entering initals. Both Story Mode and Versus Scores are saved.

Loading:
Scores upon boot up. Default scores will load if checksum fails.  

How to Patch:
--------------------
1.Grab a copy of Art of Fighting (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

