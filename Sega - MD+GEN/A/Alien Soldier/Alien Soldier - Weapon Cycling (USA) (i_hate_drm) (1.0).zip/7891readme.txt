DOCUMENTATION:

68000 Processor
All Genesis assembly instructions are 2 bytes long
Brackets around numbers are pointers
FF0000 to FFFFFF is RAM
SP = Stack (return address for bsr and jsr)
I used HxD for Hex Editing the ROM.
Red Screen Error = Sega's Checksum ROM Protection
- Use a program like Patchinator to fix.
- Might need to apply a Game Genie Master Code.

Alien Soldier Master Code:
AJBT-AA5N

Alien Soldier Region Bypass Codes:
REBT-A6XN
REBT-A6XR
RECA-A60R



MAME Debugging:
mame genesis -cart roms\alien.md -debug
mame megadrij -cart roms\alien.md -debug	(For Japanese Roms)
mame megadriv -cart roms\alien.md -debug	(For European Roms)

bpset 123456		breakpoint on line 123456
wpset FF0000,1,w	watchpoint on address FF0000 (write)
trace tracename.txt
trace off

MAME Debugger Help: https://docs.mamedev.org/debugger/index.html
68000 Instructions: http://wpage.unina.it/rcanonic/didattica/ce1/docs/68000.pdf



BUTTON PRESSES (Standing - No Menu Open):
UP = 	btst    #$0, $826c.w
DOWN = 	btst    #$1, ($69,A5)
LEFT =	btst    #$2, ($69,A5)
RIGHT = btst    #$3, ($69,A5)
SHOOT = btst    #$4, ($69,A5)
JUMP =	btst    #$5, ($6a,A5)
MENU =	btst    #$6, ($6a,A5)

// ($69,A5) = [(A5) + 69] = (FFA400 + 69) = Value stored in FFA469
// FFA46B seems to be the same. FFA46A holds it temporarily - For button presses instead of button hold.
// FFF706 & FFF708 get the values first. 00A10003 is the original data source (CTRL_1_DATA).
// Value gets copied sometimes - so don't rely on text searches for just ($69,A5).


SELECTED GUN = FFA24E
1st = 0 | 2nd = 2 | 3rd = 4 | 4th = 6

CURRENT GUNS:
1st = FFA250 | 2nd = FFA252 | 3rd = FFA254 | 4th = FFA256
Buster = 0 | Ranger = 2 | Flame = 4 | Homing = 6 | Sword = 8 | Lancer = A

CHANGE GUN = FFA21C & FFA21E (sprite)

	FFA21C
	Buster = 2 | Ranger = 4 | Flame = 6 | Homing = 8 | Sword = A | Lancer = C | Menu = 12/14

	FFA21E (sprite)
	Buster = 4 | Ranger = 8 | Flame = C | Homing = 10 | Sword = 14 | Lancer = 18

	// FFA21C is current selected gun value plus 2.
	// FFA21E is just FFA21C bit-shifted left. It gets zeroed after sprite change.


STATES = FFA404
00 = Standing Idle (and in space)	02 = Walking (and moving in space)	0E Crouching			
18 = Upside-Down			1A = Upside-Down Walking		22 Upside-Down Crouching
46 = Hover

// This is just a few relevant states.
// It's worth mentioning that the first bit of FF8144 determines if we are in space (1) or not (0).



HEX CODE

MENU OPEN:	0155B8 - 0155C7		KEEP (Shoot Mode Change)
		0155C8 - 0155CB		CANT EDIT - return to sender if in a level transition (black screen)
		0155CC - 01560F		FREE (Weapon Menu Transition)
		0179C2 - 017A9B		FREE (More Weapon Menu Stuff)

MENU RIGHT:	017AD0 - 017ADF		WEAPON CYCLE CODE
		017AE0 - 017AE9		IGNORE (FFF80A = A8 SOUND EFFECT)

MENU CLOSE:	017BEC - 017BF5		ALTER (FFF80A = A7 SOUND EFFECT)
		017BF6 - 017BFB		FF8038 = 8 (prevents weapon-changing for 8 counts)
		017BFC - 017C15		CHANGE WEAPON CODE
					(After this, it zeroes a bunch of values)
					(These are important - like clearing bullet sprites on-screen)



THE PLAN

Move WEAPON CYCLE CODE to free space in 0155CC and then jump to 017BEC (CHANGE WEAPON CODE).
Make all other menu press states jump to 0155CC. Keep all Shoot Mode Change code as is.



THE CODE

// Weapon cycle while standing
0155CC - 0155DD:					ORIGINAL:
	addq.w 	#2, $a24e.w	5478 A24E	|	31F8 A24E A220		// WEAPON CYCLE CODE (0, 2, 4, 6, 0...)
	andi.w 	#6, $a24e.w	0278 0006 A24E	|	31FC 0012 A21C
	jmp 	$17bec.l	4EF9 0001 7BEC	|	11FC 007F 830F		// Jump to CHANGE WEAPON CODE
	nop			4E71		|

// Weapon cycle while hovering
01617E - 016183:					ORIGINAL:
	jmp 	$155cc.l	4EF9 0001 55CC	|	31F8 A24E A220

// Weapon cycle while upside-down
016706 - 01670B:					ORIGINAL:
	jmp 	$155cc.l	4EF9 0001 55CC	|	31F8 A24E A220

// Weapon cycle while floating in space
019EB6 - 019EBB:					ORIGINAL:
	jmp 	$155cc.l	4EF9 0001 55CC	|	31F8 A24E A220

// Change Sound Effect
017BEC - 017BEF:					ORIGINAL:
	move.b  #$a8, D0	103C 00A8	|	103C 00A7		// A7 = close menu sfx, A8 = cycle weapon sfx


// Weapon cycle FOR ALL OTHER CASES

// Part 1: Migrate some code
014F98 - 014F9B:					ORIGINAL:
	bsr 	$179c2.l	6100 2A28	|	3A7C A400		// ORIGINAL: movea.w #$a400, A5

// Part 2: Branch to 155CC if menu pressed and 
// not crouching, hovering, or moving in space
0179C2 - 0179FB:					ORIGINAL:
	movea.w #$a400, A5	3A7C A400	|	307C A258
	cmpi.w  #$0, $a02a.w	0C78 0000 A02A	|	3038 A24E		// on weapon setup screen? (double-select bugfix)
	bne	$179fa		662C		|	31BC 0258 0000
	btst    #$6, $f708.w	0838 0006 F708	|	3038 A24E		// was menu button pressed?
	beq     $179fa		6724		|	31C0 803C
	cmpi.w  #$2, $a404.w	0C78 0002 A404	|	5478 A21C		// in walking / moving-in-space state?
	beq     $179fa		671C		|	6100 0180
	cmpi.w  #$e, $a404.w	0C78 000E A404	|	31FC 0014 A21E		// in crouch state?
	beq     $179fa		6714		|	41FA 00BC
	cmpi.w  #$22, $a404.w	0C78 0022 A404	|	4E71			// in upside-down crouch state?
	beq     $179fa		670C		|	3238 803C
	cmpi.w  #$46, $a404.w	0C78 0046 A404	|	3230 1000		// in hover state?
	beq     $179fa		6704		|	0641 0100
	bra 	$155cc		6000 DBD4	|	0241 01FF
179FA:	rts			4E75		|
