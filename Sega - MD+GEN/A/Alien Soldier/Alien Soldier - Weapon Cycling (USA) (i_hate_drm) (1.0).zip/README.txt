Alien Soldier - Weapon Cycling Hack

This hack replaces the Weapon Selector wheel with weapon cycling.
Pressing "A" will cycle through the weapons at the top of the screen.

This hack is compatible with the Japanese ROM of Alien Soldier.
It is also compatible with NaOH's 6-Button Controller Support hack.

You can apply this patch using Lunar IPS.

Documentation has been included.

Hope you enjoy.