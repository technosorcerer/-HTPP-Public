Alien Soldier Password SRAM
June. 21st, 2023
BillyTime! Games
--------------------
This is a simple patch a saving mechanism to Alien Soldier for the Sega Genesis.

How it works:
--------------------

Saving:
--------------------
*Game saves only on Supereasy difficulty at the continue screen

Loading:
--------------------
*Enter password screen upon boot, your password will be automatically loaded.

Notes:
--------------------
Compatible with the following patches:
Alien Soldier - Weapon Cycling by i_hate_drm
https://www.romhacking.net/hacks/7891/

Alien Soldier: 6-Button Controller Support by NaOH
https://www.romhacking.net/hacks/7846/

Alien Soldier Ammo Regen by BillyTime! Games
https://www.romhacking.net/hacks/6959/

How to Patch:
--------------------
1.Grab a copy of Alien Soldier (Europe).md or Alien Soldier (Japan).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

