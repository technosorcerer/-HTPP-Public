The Addams Family - Afterlife MD
Sept 29th, 2022
BillyTime! Games
--------------------

The Addams Family - Afterlife MD is a patch designed to add several new mechanics to the Sega Genesis version of The Addams Family

Weapon Select:
--------------------
*Press A+Left for the Golf Ball weapon
*Press A+Right for the Sword weapon


Restart and Quit Functions:
--------------------
*Press A+Down to respawn with no life penalty
*Press A+C+UP to quit to the continue screen


Password SRAM:
--------------------
*Game saves after Gomez respawns
*Current password will be saved
*Select load game to automatically load saved game

This hack is compatible with The Addams Family - Improved Controls
https://www.romhacking.net/hacks/5441/


How to Patch:
--------------------
1.Grab a copy of Addams Family, The (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file