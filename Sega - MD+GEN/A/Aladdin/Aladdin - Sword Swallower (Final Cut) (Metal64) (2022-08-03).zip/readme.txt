Aladdin (Final Cut) - sword swallower

About this hack
This is a simple patch that replace the knife juggler to the sword swallower (cut enemy)

hack made By: Metal64

To apply this patch, use Lunar IPS in a Aladdin (USA) (Final Cut) rom in .MD format


contact
Youtube channel: https://www.youtube.com/user/MetalOverlord64

2 Youtube channel: https://www.youtube.com/channel/UCPVhjP2tmdRVpqfD5TOymKA

twitter: https://twitter.com/Metal641


ROM / ISO Information:
Aladdin Remix (2019) (USA)
Database match: not found
ROM not found in Database: No-Intro
ROM/File SHA-1: 7398BD6DC7AED3F1D819F70360593FE50491DAC8
File/ROM CRC32: DD66B3FA

Note
This patch is compatible with the "Aladdin (USA) (Final Cut) - rolling snakes",  "Aladdin (USA) (Final Cut) - golden monkey statue" and "Aladdin (USA) (Final Cut) - prisoner"