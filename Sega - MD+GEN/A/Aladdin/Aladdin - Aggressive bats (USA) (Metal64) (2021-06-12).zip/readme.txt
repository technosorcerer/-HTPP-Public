About this patch:

this is a simple patch for the game "Disney's Aladdin" for sega genesis.
This patch makes all the bats behave like bats in Abu Cave, they follow you instead of flying in random directions. 

Due to the fact that bats follow you, they can go in certain places where their pallets are not programmed, so I had to do a little pallet editing in this patch. This is the reason of why the sub boss in the cave stage and the flamingos are with different pallets

patch made By: Metal64

To apply this patch, use Lunar IPS in a Disney's Aladdin (USA) rom in bin format

contact
Youtube channel: https://www.youtube.com/user/MetalOverlord64

2 Youtube channel: https://www.youtube.com/channel/UCPVhjP2tmdRVpqfD5TOymKA

twitter: https://twitter.com/Metal641