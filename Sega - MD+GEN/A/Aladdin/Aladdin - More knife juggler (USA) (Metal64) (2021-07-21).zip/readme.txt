Aladdin - more knife juggler

About this hack
This is a simple hack that replace some entities for the knife juggler

hack made By: Metal64

To apply this patch, use Lunar IPS in a Disney's Aladdin (USA) rom in bin format


contact
Youtube channel: https://www.youtube.com/user/MetalOverlord64

2 Youtube channel: https://www.youtube.com/channel/UCPVhjP2tmdRVpqfD5TOymKA

twitter: https://twitter.com/Metal641