About this patch
this is a simple patch for the game "Disney's Aladdin" for sega genesis.
In the original game the apple and gem hud disappear from the screen when they reach zero, this patch make the apple and gem hud stay in the screen even if reach to zero

patch made By: Metal64

To apply this patch, use Lunar IPS in a Disney's Aladdin (USA) rom in bin format


contact
Youtube channel: https://www.youtube.com/user/MetalOverlord64

2 Youtube channel: https://www.youtube.com/channel/UCPVhjP2tmdRVpqfD5TOymKA

twitter: https://twitter.com/Metal641