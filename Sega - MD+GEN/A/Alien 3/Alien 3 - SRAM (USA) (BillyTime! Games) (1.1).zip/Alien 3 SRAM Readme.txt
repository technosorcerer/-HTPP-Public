Alien 3 SRAM
Mar. 6th, 2021
BillyTime! Games
--------------------

This patch is designed to add a simple saving mechanism to Double Dragon 3.

How to use:
--------------------

Saving:
Game saves after every level past the first stage.

Loading:
Pause while in game and press C, A, B, Start. 

NOTE:
Game will produce a black screen if no prior save is detected.

How to Patch:
--------------------
1.Grab a copy of Alien 3 (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file