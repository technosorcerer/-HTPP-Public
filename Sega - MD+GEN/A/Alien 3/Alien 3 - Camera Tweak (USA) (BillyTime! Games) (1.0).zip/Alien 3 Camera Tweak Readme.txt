Alien 3 Camera Tweak
Apr. 3rd, 2025
BillyTime! Games
--------------------
This patch is designed to Tweak the camera in Alien 3. Now the camera will not wait for Ripley to move past a certain threshold before scrolling.


How to Patch:
--------------------
1.Grab a copy of Alien 3 (USA, Europe).md
OR
Alien 3 (USA, Europe) (REV A).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file