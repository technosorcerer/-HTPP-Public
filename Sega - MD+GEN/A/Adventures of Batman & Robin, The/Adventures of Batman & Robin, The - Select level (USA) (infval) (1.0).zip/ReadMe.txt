﻿--------------------------Info---------------------------
Game name: The Adventures of Batman and Robin
Console: Sega Genesis
Game region JAP, USA: (JU)
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
 Windows: https://romhackplaza.org/utilities/solid-patcher-utility/
 Linux: https://romhackplaza.org/utilities/solid-patcher-utility-2/
 https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
The patch adds the following change:

 Select level in the options menu.
 *The sound number of "Sound test" item is equivalent to the starting level of the game.

----------------------------------------------------------
Author by: infval