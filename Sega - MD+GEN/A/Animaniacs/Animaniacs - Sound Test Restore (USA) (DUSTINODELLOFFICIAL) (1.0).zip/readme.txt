This patch adds a sound test to Konami's Animaniacs on Genesis,
a game which was notably missing it--every other Konami Genesis
game I can think of has one, so its absence is more notable.

Interestingly, the code for it was actually already there,
($3E07C in the ROM if you're curious) unreferenced, suggesting
that it was removed rather than not finished. All this hack does
is reformat the options menu, adding text, and fixes some code,
indexes and pointer tables so that the previously unreferenced
code is used. There was even a space in the menu for where it was
supposed to go, so it looks pretty "factory."

There are two versions of the patch. AnimaniacsSoundTestRestore.ips
is what it says and restores the original sound test code as found in the ROM
to functional. The other patch, AnimaniacsSoundTestCustom.ips, I tweaked
for my own use and is the same thing other than it lets you stop the music
by pressing the C button.

Songs start at $68 and before that are various sound effects.
Press A to play, B to advance the number by $10, and C to decrease
it by $10. If you are using the 'custom' patch, C button will stop the music.

Apply one of the patches to the USA ROM, "Animaniacs (USA)" in No-Intro.
MD5: ce0a42a75a9e374cf5092f34bf6927b7

- Dustin

https://www.youtube.com/user/DUSTINODELLOFFICIAL
https://twitter.com/DustinOfcYT
