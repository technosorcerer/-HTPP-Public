Questa patch traduce in italiano il gioco identificato dal No-Intro come: 
Alex Kidd in Miracle World (USA, Europe) (v1.1)

Ecco a voi un altro gioco tradotto in italiano. Per la traduzione mi sono servito dell'ottimo editor KiddEd di Calindro (https://www.romhacking.net/utilities/1111/). Per alcuni fix ho comunque dovuto usare le maniere forti con hack asm e spostamento puntatori. 
Di questa traduzione ne fornir� 2 versioni. Una come l'originale del 1986 in cui Alex mangia una palla di riso ed un'altra come la versione incorporata del 1990 in cui Alex mangia un hamburger.

Comunque ecco le caratteristiche:
* Spostamento di tutte le vignette della schermata del titolo per far posto ad altra grafica.
* Aggiunta una linea sul bordo sinistro delle 2 vignette del titolo a sinistra mancante anche sull'originale. 
* Fixata la cifra 0 finale dei soldi mostrati nella schermata di pausa che era colorata leggermente giallognola.
* Fixata anche la cifra delle vite sempre nella schermata di pausa (in questo caso l'errore appariva solo la prima volta che si richiamava pausa), che veniva mostrata sempre giallognola.
* Fixata la grafica del sacco dei soldi sempre nella schermata di pausa che appariva leggermente sfasata.
* Uniformata la grafica dei sacchi dei soldi gi� presenti in gioco da quelli che trovi rompendo i blocchi. Adesso il simbolo in basso � sempre arrotondato.
* Fixata la posizione della palla di riso (o hamburger) alla fine di alcuni livelli perch� appariva leggermente sfasata.
* Fixata la grafica di Janken pietrificato che appariva corrotta sul lato destro.
* Invertiti i controlli di salto e pugno ma lasciando inalterato la funzione del tasto 2 per la modalit� segreta continua. L'editor Kidded spostava anche questa sul tasto 1.
* Aggiunto il supporto per il pad megadrive e la comodit� del tasto pausa sul joypad.
* Tradotti tutti i testi compresa l'insegna dei negozi e la grafica dei punti nella schermata di pausa.
* Per la versione con l'hamburger ricopiata a mano un pixel alla volta la grafica dalla versione del 1990.
* Altri fix vari che non ricordo.

(C) 2024 Di Somma Michele
mike.1983@libero.it