Kid Chameleon SRAM - Helmet Select
July 29th, 2024
BillyTime! Games
--------------------
This Addenum patch designed to allow players to purchase helmets when loading a game in Kid Chameleon SRAM

How it Works:
--------------------
When pausing the game, Highlight Restart Round and hit the following button combination.
A + Start - Sky Cutter
B + Start - Cyclone
C + Start - Red Stealth
A + Left + Start - Eyeclops
B + Left + Start - Juggernaut
C + Left + Start - Iron Knight
A + Right + Start - Berzerker
B + Right + Start - Miniaxe
C + Right + Start - Fly

If the player has at least 5 diamonds, players can load into their existing game with their newly purchased helmet.


How to Patch:
--------------------
1.Grab a copy of Kid Chameleon SRAM.md (https://www.romhacking.net/hacks/5672/)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file (Use only one patch.)