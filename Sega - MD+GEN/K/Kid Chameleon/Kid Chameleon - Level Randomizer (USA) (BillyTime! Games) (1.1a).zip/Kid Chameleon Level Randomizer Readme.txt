Kid Chameleon Level Randomizer
Jan. 25th 2023
BillyTime! Games
--------------------
This patch is designed to Randomize all levels in Kid Chameleon.

How it works:
*Upon pressing start, you are given three lives and no continues.
*Your player will be given a random level, including boss levels.
*Levels are constantly randomized during gameplay.

v1.1 Update
--------------------
*Restart round life penalty removed.
*Randomizer modified to prevent duplicate levels during gameplay.

NOTE:
*Two Player mode is disabled with this patch
*Patch is NOT compatible with any other Kid Chameleon hack


How to Patch:
--------------------
1.Grab a copy of Kid Chameleon (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file