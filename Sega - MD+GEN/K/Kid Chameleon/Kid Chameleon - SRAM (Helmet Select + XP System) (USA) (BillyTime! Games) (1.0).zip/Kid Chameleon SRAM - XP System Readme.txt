Kid Chameleon SRAM - XP System
Dec 6th, 2024
BillyTime! Games
--------------------
This Addenum Combination patch designed to add a XP level system to Kid Chameleon SRAM for the Sega Genesis.

How it Works:
----------------------------
At the end of each level, your score is tallied. Every point milestone grants you an extra advantage. Levels are lost upon continuing. 

XP GAINS:
Extra Time - 1 Minute (20,000)
Added health for masks (30,000)*
Extra Gems per level (40,000)
Extra Time - 1 Minute (50,000)
Added health for masks (60,000)*
Extra Gems per level (70,000)
Extra Time - 1 Minute (80,000)
2X Damage to Bosses  (100,000)
Extra Life every level  (200,000)
3X Damage to Bosses  (300,000)

*NOTE: Extra mask health only works when picking up a new mask in game. Does not apply to Helmet Select. Losing a mask will give Kid Chameleon an extra two health for a total of four.

Helmet Select:
--------------------
When pausing the game, Highlight Restart Round and hit the following button combination.
A + Start - Sky Cutter
B + Start - Cyclone
C + Start - Red Stealth
A + Left + Start - Eyeclops
B + Left + Start - Juggernaut
C + Left + Start - Iron Knight
A + Right + Start - Berzerker
B + Right + Start - Miniaxe
C + Right + Start - Fly

If the player has at least 5 diamonds, players can load into their existing game with their newly purchased helmet.

SRAM
--------------------
Saving:
The Game saves after every subsequent level. Score is saved along with current level.*
Loading:
Pause and select restart level. Life penalty has been removed.

*NOTE: In the rare event that XP Bonuses disappear, you can load your game and restore XP in this method.


How to Patch:
--------------------
1.Grab a copy of Kid Chameleon SRAM.md 
(https://romhackplaza.org/romhacks/kid-chameleon-sram-genesis/)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file (Use only one patch.)