Klondike - Random Card Back
Nov. 19th 2024
BillyTime! Games
--------------------
This is a simple patch for Klondike which randomizes the color of the back of the cards each time the game boots up.

How to Patch:
--------------------
1.Grab a copy of Klondike.bin
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file