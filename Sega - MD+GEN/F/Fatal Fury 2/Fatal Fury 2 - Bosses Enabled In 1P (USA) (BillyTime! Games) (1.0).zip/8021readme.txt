Fatal Fury 2 - Bosses Enabled In 1P
Aug. 20th 2023
BillyTime! Games
--------------------
This patch enables players to select the final four bosses in the single player portion of Fatal Fury 2 on Sega Genesis without the need for any extra codes.

This patch also enables Infinite credits.


How to Patch:
--------------------
1.Grab a copy of Fatal Fury 2 (USA, Korea).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file