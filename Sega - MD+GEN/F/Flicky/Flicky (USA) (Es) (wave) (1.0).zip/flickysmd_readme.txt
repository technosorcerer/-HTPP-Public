Flicky
Traducci�n al Espa�ol v1.0 (08/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Flicky
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Flicky
-----------------
Port del arcade para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking es completamente original.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Puedes contactar conmigo y ver mis traducciones en traduccioneswave.blogspot.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Flicky (UE) [!].gen
131.072	bytes
CRC32: 4291c8ab
MD5: 805cc0b3724f041126a57a4d956fd251
SHA1: 83d8bbf0a9b38c42a0bf492d105cc3abe9644a96

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

-- END OF README --