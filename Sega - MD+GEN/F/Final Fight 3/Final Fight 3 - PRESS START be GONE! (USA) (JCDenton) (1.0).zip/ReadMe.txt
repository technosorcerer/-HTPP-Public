A ROMHACK by JCDenton!

A simple mod that removes the constantly blinking "PRESS START" when in single player. It works with the USA, EUROPE and JAPAN (Fight Guy Though) release of the game.


ROM / ISO Information:
No-Intro Name: Final Fight 3 (USA)
(No-Intro version  20130701-030720)
ROM/File SHA-1: 09D542FBB06DCAFEC26602BDC626BCDAF56B23CB
Patched ROM/File SHA-1: D25D2F54134A3B3BACFAA5077C5806B7A4989A4F

