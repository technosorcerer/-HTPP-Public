Fire Mustang (J) Dolsilwa's hack

Fire Mustang is a simple but fun shoot-em-up. Original Genesis colors are a bit bland. This color hack makes everything a bit more colorful.    

v. 1.0 changes:
* tweaked colors for all stages,
* tweaked colors for some spites,

Just apply .ips patch on original rom. 

Hope you'll like it.

Dol.