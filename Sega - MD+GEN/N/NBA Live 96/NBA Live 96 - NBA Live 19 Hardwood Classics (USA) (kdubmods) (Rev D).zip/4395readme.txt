Updated for NBA 2018-2019 Season:
=================================
*NBA Live 19 Hardwood Classics (USA, Europe, Asia).md			CRC-32: 7da4da07	# Original Season Start Data (as of 10/15/2018)
*NBA Live 19 Hardwood Classics (USA, Europe, Asia) (Rev A).md	CRC-32: 83096550	# Thanksgiving Weekend Season Data (as of 11/25/2018)
    --> Includes Jimmy Butler (et al.) Trade to PHI
    --> Includes Tyson Chandler Signing to LAL
    --> Includes Jamal Crawford Signing to PHX
    --> Includes other minor starting lineup changes within teams (Kevin Huerter @ ATL, Ryan Arcidiacono @ CHI, etc.)
*NBA Live 19 Hardwood Classics (USA, Europe, Asia) (Rev B).md	CRC-32: ee9a9aa1	# End of Year Weekend Season Data (as of 12/30/2018)
    --> Includes Kyle Korver (from CLE to UTA) Trade for Alec Burks (from UTA to CLE)
    --> Includes Matthew Dellavedova (from MIL to CLE) for George Hill (from CLE to MIL)
    --> Includes John Henson (from MIL to CLE) as part of George Hill Trade
    --> Includes Jason Smith (from WAS to MIL)
    --> Includes Sam Dekker (from CLE to WAS)
    --> Includes Ron Baker Signing to WAS
    --> Includes zKelly Oubre Jr. (from WAS to PHX) Trade for Trevor Ariza (from PHX to WAS)
    --> Includes Austin Rivers Signing to HOU
    --> Includes Nene Removal from HOU (to make room on roster; he's still around as an extra player)
    --> Includes minor lineup change (Marcus Morris starts over Gordon Hayward in BOS)
*NBA Live 19 Hardwood Classics (USA, Europe, Asia) (Rev C).md	CRC-32: 2073a472	# NBA Trade Deadline Updates (as of 02/07/2019)
    --> Fix wrong height for Donte DiVizenco (MIL): was 5'4", now 6'4" (NOTE: changes back ported to previous revisions)
	--> Fix wrong last name for Wayne Selden Jr. (CHI):  was Sheldon, now Selden Jr. (NOTE: changes back ported to previous revisions)
	--> Includes latest trading/free agemcy/waiver activities for 2019, up to NBA trade deadline (02-07-2019), such as...
		>> Justin Holiday (MEM) related 3-player trade
		>> Kristap Porzingis (DAL) related 7-player trade
		>> Rodney Hood (POR) related 3-player trade
		>> Tobias Harris (PHI) related 6-player
		>> Otto Porter (CHI) related 3-player trade
		>> Ryan Anderon (MIA) related 3-player trade
		>> Nikola Mirotic (MIL) related 3-team trade
		>> Alex Burks (SAC) related 3-team trade
		>> Harrion Barnes (SAC) related 3-team trade
		>> Markelle Fultz (ORL) related 3-team trade
		>> Marc Gasol (TOR) related 3-team trade
*NBA Live 19 Hardwood Classics (USA, Europe, Asia) (Rev D).md	CRC-32: 96529459	# Post-NBA Trade Deadline Updates (as of 02/28/2019)
	--> Includes latest post trading/free agemcy/waiver activities for 2019, such as...
	    >> Enes Kanter signing to POR
		>> Markieff Morris signing to OKC
		>> Jeremy Lin signing to TOR
		>> Corey Brewer signing to SAC
		>> Wayne Ellington signing to DET
		>> Nik Stauskis signing to CLE
		>> Harless back in as starting SF for POR
		>> NOTE: Pau Gasol signing to MIL (since his SAS buyout was announced around this time)

The setup is similar to NBA Live 18 Hardwood Classics, so I have included that information below...

Sega Genesis - Directions:
==========================
when you start the game there are a few things you need to do because there are limitations with the editor i used. 
1. go to roster setup
2. draft both teams
3. press start to forfeit draft, you will get an error message 
4. restart rom Toronto and Memphis will are drafted correctly this way.
5. you need to set up New Orleans I have set it up so that the 1st team thru the Lakers (minus Cavs) have a 
player at the end of their roster that needs traded to the FA list. Once you do that start the game and 
select New Orleans from the exhibition menu and everyone will be in the FA list in order for you.