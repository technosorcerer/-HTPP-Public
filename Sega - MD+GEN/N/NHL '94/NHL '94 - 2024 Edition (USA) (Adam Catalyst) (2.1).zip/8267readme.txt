NHL 94: 2024 Edition by Adam Catalyst
------------------------------------------------
2024 01 04 - Version 2.1



Hello there friendly strangers,

Here is the latest version of my 2024 ROM. The goal is to try to provide the most refined and realistic up-to-date versions of this all-time classic game. I'm thrilled to be able to share this with you. Here are the top reasons you might want to give it a try...

New in ’24
800 players obsessively rated, up-to-date rosters, and realistic lines, based on even more extensive 2020-2024 regular season data. Logos, Colours, Uniforms, Arena names… everything up-to-date for the 2024 season. The Bench area has been completely re-designed, new puck design & animation, re-designed graphic overlays for Shoot-Outs, Penalty-Shots, Goal, Injuries, Stars of the Game, etc. and numerous other refinements.

Gameplay Revisioned
The gameplay has been adjusted for a more realistic modern hockey feel, with harder to score goals, easier to hit crossbars and posts, more realistic speed burst, fewer penalty calls, custom energy depletion and recovery rates (balanced for more realistic line rolling and shift length), and player rating distribution curves that have been carefully calibrated for more realistic gameplay on the ice.

Graphical Refinements
Hundreds of other refinements have been made including title screens, banners, player photos, scoreboard, audience, face-offs, bench area, player sprites, nets, ice markings, scorekeepers, Zamboni driver, and more. The goal is to bring the most graphically refined version of NHL 94 ever made, while remaining faithful to the spirit of the original art direction.

And so much more
Of course there is the weight bug fix, but also a custom weight scale, less variance in Hot/Cold rating randomization, immediate goalie control by pressing the (Y) button with a six-button controller, a custom 3-Stars of the Game rating formula, a Vegas / Washington / Winnipeg Menu & Player Cards crash fix, and…

Every single change is documented below. I would love it if you would give it a try, and leave me any feedback!

cheers,

-Adam



p.s. If you are interested in anything NHL 94 related, check out nhl94.com for the best classic EA Hockey ROM hacks, leagues, tutorials, and just about everything you could think of.



----------------------------------------------------------------

About Me

----------------------------------------------------------------

I've been discreetly creating an eclectic array of professional-quality media content for the Internet for decades. Whenever possible, I make sure that everything I produce is available for free, no strings attached. If you ever see anything with the tag "-AC" or my handle "Adam Catalyst" being bought, sold, or traded, please let me know at adam.catalyst@proton.me. Also feel free to just say hi anytime! And if you ever want to leave me a tip to help with my living expenses, I'd greatly appreciate it. https://www.buymeacoffee.com/adamcatalyst





----------------------------------------------------------------

Features & Modifications

----------------------------------------------------------------


Under the Hood
------------------------------------------------
- ROM Header: Updated to indicate support for Japan region, 6-Button Controller, both domestic & foreign ROM names, and updated checksum.


Title Screens
------------------------------------------------
- Title Screen: Opening Logo screens display time reduced by 30%.
- Graphics: EA logo screen heavily modified and updated to reflect current Stanley Cup winner.
- Graphics: High Score Production screen slightly modified.
- Graphics: Splash image updated with EA's NHL24 image.
- Graphics: Masthead re-drawn to match EA’s current NHL24 lettering.
- Graphics: Title screen Logos removed.
- Text: Credits re-coloured & edited.


Main Menu
------------------------------------------------
- Settings: Default teams set for the 2023 Stanley Cup finals.
- Settings: Playoff brackets updated to the 2023 seedings.
- Settings: 7-minute period length option added.
- Settings: Line Changes & Penalties defaults set to on "On," because that's how I roll.
- Graphics: Team Banners & Logos updated and refined.
- Graphics: Team Banner names removed, and replaced with "VISITORS" and "HOME" for clarity.
- Graphics: Player Photos all updated with official NHL headshot images, custom cropped & colour graded.
- Graphics: Error removed from the selection box.
- Hack: Player Photo carousel cycling order modified.
- Hack: Bug that would causes crashes upon cycling through the Player Photos for Vegas, Washington, and Winnipeg has been eliminated. Please note, this comes at the cost of preventing saved stats from showing under player names.
- Text: Re-wording of a couple menu options for greater clarity.
- Typesetting: Player names centred vertically.


Pre-Game
------------------------------------------------
- Graphics: Banners typesetting improved, and colours improved for greater clarity and consistency with the team colours used throughout.
- Graphics: The Pre-Game Announcer's picture frame has been altered to be more consistent with the design of similar elements throughout the game.
- Arena Names: All up-to-date as of December 2023.
- Pre-Game: Match-up position names have been simplified to "Forward," "Defence," & "Goaltender."


Rink
------------------------------------------------
- Graphics: Colour Palette has been altered to improve the audience affect with more uniform tonal contrast, improve the accuracy of the team banner colours, and to give the nets more realistic colouring.
- Sprites: Audience members design and animations have been refined.
- Graphics: Goal light & animation revised.
- Graphics: Instant Replay reverse view inconsistencies fixed.
- Graphics: Minor refinements throughout the arena.


Rink - On the Ice
------------------------------------------------
- Graphics: Ice Colour lightened slightly. The darker colour was giving me eye strain.
- Graphics: Centre ice logos updated, adapted from NHL Rewind designs.
- Graphics: Face-off circles modification. (author unknown)
- Graphics: Net re-drawn to the most recent (2013) NHL proportions, with an updated goalie crease.
- Graphics: Trapezoid area lines drawn to NHL scale.
- Graphics: Glass & stanchions behind bottom net revised to be symmetrical and parallel to glass & stanchions at the top, horizontal seam in top glass has been removed, and on-ice reflections of stanchions have been fixed throughout.


Rink - On the Sidelines
------------------------------------------------
- Graphics: Bench area completely re-designed, including refined animations, and the addition of animated coaches and backup goaltenders inspired by slapshot67. 
- Graphics: Time-keepers added in, and time-keeper area Stanchion misalignment fixed.
- Graphics: Bench, Penalty Box, & Time-keepers area Stanchions modified to be consistent with the Sideboards view.
- Sprites: Bug fixed that would stack multiple Visitors players in the Penalty box incorrectly.


Rink - Sideboards view
------------------------------------------------
- Graphics: Sideboards Bench, Boards, Glass, Ice, Stanchions, etc. revised. 
- Graphics: Scoreboard Banners refined to improve typesetting, and colours modified for clarity and consistency throughout.
- Graphics: Sideboard Scoreboard has custom drawn NHL logo.
- Graphics: Side-boards Score-Keepers added. (Based on the SNES version)
- Sprites: Zamboni driver revised to better match the perspective of the side-boards.
- Sprites: Player in Penalty box refined, and placement revised.


In-Play
------------------------------------------------
- Sprites: Player design was revised to more accurately accommodate the wide range of uniform colourations for all 32 NHL teams. Tests were done with demo play, and final colour decisions were made to give the most accurate impression in motion, and not necessarily what looked the best in stills.
- Sprites: Face-off animations revised.
- Sprites: Players given composite sticks, because grey pixels have better puck feel, more flex, and are lighter weight.
- Sprites: Goaltenders masks revised to reveal their faces.
- Sprites: Player Helmet colour patch. (Clockwise)
- Sprites: Player Eye, Boots & Gloves, and Stick Tape patches. (Clockwise)
- Sprites: Improved Checking animations patch. (Clockwise)
- Sprites: Player stick animations refined.
- Sprites: Puck design & animation revised.
- Graphics: On-Ice Player Numbers changed to white for better legibility against the ice.
- Graphics: On-Ice Player indicator (star) for Player 1 lightened to be less conspicuous and increase relative on-ice contrast for the Player 2 indicator.
- Graphics: Penalty box player colour error fixed. (Slapshot67)


Rosters
------------------------------------------------
- Rosters & Lines: Updated based on extensive 2020–2024 regular season player usage data.
- Rosters & Lines: 800 total players have been included, covering the 25 players (14F, 8D, & 3G) with the most ice-time in 2023-2024 on each team. 


Ratings
------------------------------------------------
- Team Ratings: Team attribute & overall ratings updated as per Dec 19, 2023 regular season data.
- Player Ratings: Underlying system has been changed from the default 1-6 scale to a 0-15 scale for more accurate differentiation of players. (smozoma)
- Player Ratings: Custom player ratings based on a mix of real-world data and gameplay oriented parameters. The goal is to make gameplay more contemporary, and individual player performance more realistic.
- Player Ratings: Custom overall rating formula.
- Player Ratings: More parity between the best and the worst of the league, with all players having a minimum 52 rating before Hot/Cold variance.
- Player Ratings: Weight scale modification patch. (smozoma)
- Player Ratings: Edit lines bug fix patch. (smozoma)
- Player Ratings: Hot & Cold variance is hidden from the menus, so you will have to feel which players are hot or cold through gameplay. (smozoma)


Gameplay
------------------------------------------------
- Controls: Goalie control can now be accessed immediately by pressing the (Y) button with a six-button controller. (clockwise)
- Gameplay: Goalies without the puck can move slightly farther towards centre ice. (smozoma)
- Gameplay: Goalies can hold the puck very slightly longer before the play is whistled dead. (smozoma)
- Gameplay: Body Checking and Aggressiveness have been balanced to reduce the penalty rate from the original, and approximate the real body checking and penalty rates of each team in the 2023–2024 season.
- Gameplay: Hot & Cold range of variance has been reduced by ~25%, and the frequency of variance has been reduced by ~50%.
- Gameplay: The "goal" area of the net has been reduced slightly, making it more difficult to score, and more likely that you will hit the post.
- Gameplay: Player Speed Burst set to 25% of the original, for a more realistic feel and higher difficulty.
- Gameplay: Custom Stamina Depletion & Recovery rates.
- Gameplay: Weight / Checking bug fix patch. (smozoma)
- Gameplay: Second-Assist bug fix patch. (smozoma)
- Gameplay: Overtime set to 5 minutes, Penalty Shots set to 20 seconds.
- Player Ratings: Attribute rating distributions have been careful set and thoroughly tested to produce a faster more contemporary feel to puck movement & gameplay, with better goaltending.
- Stars of the Game: New custom formula.


In-Game Overlays
------------------------------------------------
- Graphics: Referee & Linesmen pop-overs refined.
- Graphics: In-Game Timer logo has been re-drawn. (based on Sauce's design)
- Graphics: Score Clock and Line Change overlays relocated.
- Graphics: Line Change Energy bars have been re-drawn to have inverse quasi-logarithmic gradation.
- Graphics: Overlays for Shoot-Outs, Penalty Shots, Goals, and Injuries revised.
- Graphics: Instant Replay controls graphic revised.
- Graphics: Stars of the Game overlay re-designed.
- Text: "Cross Check," "Face-Off," and "Fight Instigator" renamed to "Cross-checking," "Face-off," and "Instigator" as per the official NHL rulebook.


In-Game Menus
------------------------------------------------
- Graphics: NHL & NHLPA Logos re-drawn.
- Graphics: "Hockey Night" Banner slightly re-coloured.
- Hack: Player Cards bugs that would causes crashes upon cycling through Cards for WSH (and possibly also VGK & WPG) have been eliminated.
- Hack: Player Stats now showing Checks instead of Penalty Minutes.  (smozoma)
- Text: The "Change Goalie" option for "no goalie" is now in ALL-CAPS for greater visibility.


Extras
------------------------------------------------
- Box Art: Matching box art was made! The artwork is high resolution, print quality, and stays very close to the original North American box design. You can view and download them from here:
https://forum.nhl94.com/index.php?/topic/28056-nhl-94-2024-edition-by-adam-catalyst/
- Player Ratings: The distribution now includes a CSV with all the player ratings.
- Thumbnails Art: The distribution now includes thumbnail artwork for popular emulators.



----------------------------------------------------------------

Known Issues

----------------------------------------------------------------

1. The Main Menu and Player Cards do not show saved User Records, in order to prevent crashes that on these pages with Vegas / Washington / Winnipeg.

2. User Records may incorrectly store user data if playing with Vegas / Washington / Winnipeg.

Builds are tested with Genesis Plus 1.7.4.15 and Genesis Plus GX 1.7.5-RC1 r24-10-2021. If you are having any technical issues, you may want to try one of these emulators. If you are reporting a technical issue, please note the exact console or emulator version that you are using for me.



----------------------------------------------------------------

Future Wish-List

----------------------------------------------------------------

I'm not sure how much time I will have to work on this in the future, but if I did find more time, here is what I would like to focus on next...

- Interface: Alter the range of displayed values for player ratings.
- Gameplay: Increase the wrist shot speed.
- Gameplay: Increase the puck ice friction slightly.
- Gameplay: Reduce the force with which pucks rebounds off the boards, etc.
- CPU play: Increase the goaltenders lateral stopping abilities, reduce five-hole stopping effectiveness. - Gameplay: Enable line changes to be initiated without possession of the puck, preferably with a dedicated button.
- CPU play: Prevent the goaltenders from skating into the trapezoid areas.
- Gameplay: Decrease accuracy of One-Timers.
- Gameplay: Reduce the passing speed slightly.
- Gameplay: Reduce the energy cost for each time a speed boost is used.
- Gameplay: Enable players in the Penalty Box to re-generate energy as if they were on the bench.
- Gameplay: Improve logic for how icings and offsides are calculated to use puck position instead of player position.
- CPU play: Program the CPU to pull the goalie when trailing by 1 - 2 goals (currently only pulls with a two goal deficit).
- Graphics: Redraw Sideboards Referee to better match the art style of everything else (requires "de-compressing" shared tiles.)
- Graphics: Improve the comparatively low visual quality of the on-ice officials throughout (requires "de-compressing" shared tiles.)
- User Records: Restore system to be as fully functional as possible.

If you are able to help me with any of these changes, please let me know!

----------------------------------------------------------------

Credits

----------------------------------------------------------------

This project was built decades of work by the NHL94.com community, and never would have been possible without them. I'm sure there are more contributors than I could ever possibly know, let alone acknowledge, but I will do my best...



Contributors

------------------------------------------------

This ROM contains contributions from the following individuals...

Brodeur30
- Rink & Net collision geometry logic.

chaos
- Hot/Cold variation logic.

Clockwise
- Goalie Control with a six-button controller.
- Player sprites boots & gloves colour patch.
- Player sprites eye colour patch.
- Player sprites helmet colour patch.
- Player sprites hockey stick tape patch.
- Player sprites improved checking animations patch.

Dervin10
- Roster extractor & importer tool development.

Drezz
- Team uniforms Yoke colour isolated.

kingraph
- Animation block logic.
- Sideboards modification logic.
- Stars of the Game modification logic.

slapshot67
- 30 to 32 team ROM re-structuring.
- Bench backup goalie hack & original design.
- Penalty Box player sprite colouring fix.

smozoma
- 0 - 15 Player Rating scale patch.
- Checking / Weight bug fix patch.
- Credits editing logic.
- Displayed Ratings bug fix patch.
- Goalie range of motion.
- Goalie puck hold time before whistle.
- Period lengths logic.
- Player Overall rating formula logic.
- Player Stats Checking patch.
- Player Weight scale modification patch.
- Second-Assist bug fix patch.
- Stars of the Game formula logic.

Tony H.
- Stopping & Crossover Rate logic.

wboy
- 28 to 30 team ROM re-structuring.
- Default settings logic.
- Player photo logic.
- Player energy depletion & recovery rates logic.
- Rink modification logic.
- Speed burst rate logic.
- NOSE tool development.

Author unknown
- Face-off circles graphic modification.
- Team uniforms colour restructuring.



Special Thanks to...

------------------------------------------------

Drezz - selflessly sharing original work & resources.
JKline3 - tips, resources, & candor.
kingraph - tips, resources, & encouragement.
​​​​​​​naples39 & Sauce - inspiration.
Sean - tips, encouragement, and inspiration. 
smozoma - utterly invaluable tips, resources, tools, & support.
von Ozbourne - brainstorming, resources, wit & wisdom.


...and everyone at nhl94.com who tested Betas or provided feedback.



Extra Special Thanks to...

------------------------------------------------

Ena - for nothing less than everything.



----------------------------------------------------------------

Version Change-Log

----------------------------------------------------------------


2024 01 04 - Version 2.1

New Years Refinements Edition.

This revision contains cumulative roster updates, and numerous minor visual refinements to existing revisions.


Title Screens
------------------------------------------------
- Graphics: Splash image (& masthead) dithering and anti-aliasing improved.


Rink - Sidelines
------------------------------------------------
- Graphics: Players in Penalty Box have been further refined.


Rosters, Ratings, & Lines
------------------------------------------------
- Team Ratings: Weighting formula adjusted for PP, PK, Home, and Away.
- Team Ratings: Team attribute & ratings updated as per Jan 4, 2024 regular season data.
- Rosters: Up-to-date as for 2024 01 04 (updates to CHI, TOR, SEA, WSH).
- Lines: Updates to CHI, SEA, MIN, TOR, WSH.
- Goalie: Updates to ARI, EDM, SJS.
- Player Names: Condensed to 19 characters max (affected 3 players).
- Player Photos: Minor updates as needed.


In-Game Overlays
------------------------------------------------
- Graphics: Face-Off animation overlays have been refined to match newer revisions to the player design.
- Graphics: Overlays for Shoot-Out and Penalty Shot revised.


Extras
------------------------------------------------
- Box Art: Box Art revised with a minuscule change to one screen-cap.
- Thumbnail Art: Thumbnail Art for emulators now included in the distribution.


----------------------------------------------------------------


2023 12 20 - Version 2.0

Holiday Roster-Freeze Edition.

This revision is exclusively dedicated to visual refinement, focusing on re-designing the bench area, along with revisions to the associated graphics and animation.


Title Screens
------------------------------------------------
- Graphics: Splash image (& masthead) dithering and anti-aliasing improved.


Rink - Sidelines
------------------------------------------------
- Graphics: Benches area completely re-designed.
- Graphics: Players on Bench have been revised.
- Graphics: Players on Bench have missing animation restored, alongside the newer Goalie animation.
- Graphics: Coaches now have (slight) animation.
- Graphics: Players in Penalty Box have been re-designed.


Rosters, Ratings, & Lines
------------------------------------------------
- Team Ratings: Team attribute & overall ratings updated as per Dec 19, 2023 regular season data.
- Rosters: All up-to-date as of the roster freeze at midnight 2023 12 19.
- Player Ratings: Minor changes to a few players.
- Lines: Updates to BUF, CHI, COL, DET, PHI, SEA, SJS, TOR.


Gameplay
------------------------------------------------
- Gameplay: Goalies can hold the puck very slightly longer before play is whistled dead.


In-Game Overlays
------------------------------------------------
- Graphics: Overlays for Shoot-Out Winner, Goal, PP-Goal, Hat Trick, and Injuries revised.


Extras
------------------------------------------------
- Downloadable: Box Art released, with custom screenshots that mimic the original.


----------------------------------------------------------------


2023 12 01 - Version 1.0

Public Beta Edition.

The biggest change this year is be invisible to you as a user. I restructured parts of the ROM, and re-built my tools in order to be able to deliver roster and rating updates much faster this year. The goal will be to have an update out within a day of any traded players having their jersey number confirmed.


Title Screens
------------------------------------------------
- Graphics: EA logo screen updated to reflect VGK Stanley Cup win.
- Graphics: Splash image (& masthead) updated with EA's NHL24 image.
- Text: Credits re-coloured & edited.


Main Menu
------------------------------------------------
- Settings: Default teams set for the 2023 Stanley Cup finals.
- Graphics: Team Banners & Logos updated for BOS & PHI.
- Graphics: Player Photos updated as needed.


Pre-Game
------------------------------------------------
- Graphics: Banners colours updated for BOS & PHI.
- Arena Names: FLA updated.


Rink - On the Ice
------------------------------------------------
- Graphics: Centre ice logo for BOS updated with their real centennial genre ice logo. PHI logo colours updated.


Rink - Sidelines & Sideboards
------------------------------------------------
- Sprites: Bug fixed that would stack multiple Visitors players in the Penalty box incorrectly. Now Visitors players in the Penalty box are seated top-to-bottom (Rink view) and left-to-right (Sideboards view) like in ’92.
- Sprites: Players in the Penalty box have had their placement slightly modified in both Rink & Sideboards view.


In-Play
------------------------------------------------
- Sprites: Uniforms updated for BOS, PHI, & PIT.
- Graphics: Puck design & animation revised.
- Sprites: Stick animations refined.


Rosters
------------------------------------------------
- Rosters & Lines: Updated based on extensive 2020–2024 regular season player usage data.
- Rosters & Lines: 800 total players have been included, covering the 25 players (14F, 8D, & 3G) with the most ice-time in 2023-2024 on each team. 


Ratings
------------------------------------------------
- Team Ratings: Team attribute & overall ratings updated as per Nov 30, 2023 regular season data.
- Team Ratings: New rating system, every player re-rated for this season.
- Player Ratings: New overall rating formula.
- Player Ratings: Hot & Cold variance is now hidden from the menus and displayed ratings are static, so you will have to feel which players are hot or cold through gameplay. (smozoma)


Gameplay
------------------------------------------------
- Gameplay: Goalies without the puck can move slightly farther towards centre ice.


In-Game Overlays
------------------------------------------------
- Graphics: Score Clock and Line Change overlays relocated.
- Graphics: Overlays for Shoot-Outs, Penalty Shots, Goals, and Injuries revised.
- Text: “Cross Check” renamed “Cross-checking” as per official NHL rules.
- Graphics: Stars of the Game overlay re-designed.


Extras
------------------------------------------------
- Player Ratings: A CSV with all player ratings is now included in the standard distribution.


----------------------------------------------------------------

I sincerely hope that you enjoy it!

-a




