/************************************
 * Info:
 ***********************************/

Name: Ninja Gaiden Control Hack by SEGAMAN
Date: 22.12.2020
Version: 1.0
Original ROM: Ninja Gaiden (Beta).bin
Code: Segaman

/************************************
 * Features:
 ***********************************/
 
-Rewritten player controls

/************************************
 * Known issues:
 ***********************************/

/************************************
 * How to patch:
 ***********************************/
 
Patch (Beta) version of the game with provided ips-patch file

