The New Zealand Story (Mega Drive)
Traducci�n al Espa�ol v1.0 (23/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
New Zealand Story, The (J) [!].gen
MD5: 4738aa21d4c239fbbd01a25d378b91d3
SHA1: 07b75c12667c6c5620aa9143b4c5f35b76b15418
CRC32: 1c77ad21
524.288 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --