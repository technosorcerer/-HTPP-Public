Ecco The Dolphin SRAM
Feb. 23rd, 2021
BillyTime! Games
--------------------

This patch is designed to add a simple saving mechanism to Ecco The Dolphin.

How to use:
--------------------

Saving:
Game saves after every level starting at the Undercaves.

Loading:
Enter the Password screen and press start. 

NOTE:
Game will produce a crash if no prior save is detected.

How to Patch:
--------------------
1.Grab a copy of Ecco the Dolphin (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file