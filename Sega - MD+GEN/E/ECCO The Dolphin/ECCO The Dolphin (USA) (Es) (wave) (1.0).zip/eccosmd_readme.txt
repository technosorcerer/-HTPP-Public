Ecco the Dolphin (Mega Drive)
Traducci�n al Espa�ol v1.0 (28/09/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
ECCO The Dolphin (UE) [!].gen
MD5: 18b49fe6ad55975b6021b40b193035f5
SHA1: 2cad130f3118c189d39fd1d46c5c31a5060ce894
CRC32: 45547390
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --