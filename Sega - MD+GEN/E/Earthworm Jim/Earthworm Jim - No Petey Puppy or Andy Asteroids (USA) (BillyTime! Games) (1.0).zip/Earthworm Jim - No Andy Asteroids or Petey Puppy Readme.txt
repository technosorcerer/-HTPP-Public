Earthworm Jim - No Andy Asteroids or Petey Puppy 
Dec. 25th 2024
BillyTime! Games
--------------------
This patch is designed to remove some of the more annoying levels in Earthworm Jim.
Comes in Two Flavors/


Patch 1:
--------------------
*Removes "For Pete's Sake" from level rotation

Patch 2:
--------------------
*Removes "For Pete's Sake" and "Andy Asteroids" from level rotation

How to Patch:
--------------------
1.Grab a copy of Earthworm Jim (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file