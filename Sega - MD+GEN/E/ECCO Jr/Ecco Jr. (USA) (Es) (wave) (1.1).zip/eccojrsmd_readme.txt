Ecco Jr. (Mega Drive)
Traducción al Español v1.1 (07/11/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1: Revisado script y eliminada expresión repetida.

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Ecco Jr. (USA, Australia).md
MD5: ca7fa198e67d77b348111d57a6ad9df1
SHA1: 0b493ef23874f82606d4fd22c2380b289247aa9f
CRC32: 6c6f4b89
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --