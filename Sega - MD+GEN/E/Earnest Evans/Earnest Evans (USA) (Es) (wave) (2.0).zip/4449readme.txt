Earnest Evans (Mega Drive)
Traducción al Español v2.0 (10/07/2022)
(C) 2022 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com
V2.0:
-Traducido STAGE CLEAR
-Traducido GAME OVER
-Añadidos Acentos en menú y créditos


------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Earnest Evans (USA).md
MD5: 6a2d2ac410a424fcb66a72ec0dff9484
SHA1: cb5a2a928e2c2016f915e07e1d148672563183f0
CRC32: a243816d
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --