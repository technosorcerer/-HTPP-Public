




                                 El Viento
                              Enhancement Hack




 History
-----------------------------------------------------------------------------

101010 Initial release




 Overview
-----------------------------------------------------------------------------

This is patch for the American release of El Viento for the Sega Genesis.
It makes numerous enhancements to the game and even includes "dual-language"
support, meaning that it can be played in either Japanese or English. The
script has also been refurbished, with some new strings translated from the
Japanese text.

The genesis of this project was a simple experiment to see what the ending
sounded like with the second theme removed. It turns out that the original
ending music matches the length of the Japanese ending perfectly, leading
me to believe that it was initially the only piece composed for the ending
and that the other song that interrupts it was a last-minute change, perhaps
because they wanted the game to end a little more upbeat.

Speculation notwithstanding, I find the addition of the second ending theme
to be a poor artistic choice. Removing it (with some timing adjustments for
the English ending) soon led to many other changes, the result being this
much-improved edition of a fantastic game. Please read the list of changes
to see all the improvements.




 Applying the Patch
-----------------------------------------------------------------------------

Hopefully included with this document is a patch file in the IPS format.
You can use any program that fully supports that file format to apply this
translation patch to your ROM file.

Make sure you are patching the American version of the game.




 Playing the Game
-----------------------------------------------------------------------------

Once you've patched the ROM file, simply load it up in your favorite
Genesis / Mega Drive emulator, console copier, or flash cartridge.

The game will detect the country code of your machine (real or emulated)
and switch to English or Japanese mode accordingly.

To override the default, hold down the following until the SEGA logo appears:

Up & Left      Force Japanese mode
Down & Right   Force English mode


The controls in the sound test have changed slightly:

A        Play song once
B or C   Play song looped (when appropriate)


To access "Stage 0", hold down all three triggers when starting a new game.
I.e. with the cursor on "Start Game", hold down A, B, & C, then press Start.

Note that there is no music for Stage 0 so it will keep playing the title
screen tune unless you select a different song in the sound test (or turn
the music off) before starting the game. You should only have to do this
once; subsequent attempts at Stage 0 should play the last sound test song
you selected.




 Q & A
-----------------------------------------------------------------------------

Q: This patch doesn't work! What do I do?

A: Make sure that your ROM file is not in an interleaved format. It's also
   possible that there is more than one version of the game, or that your
   copy is corrupt.

   Some emulators may also fail to run the program. Please make sure you try
   several of the most up-to-date emulators available.

   Are you using the correct version of the game? Despite all the talk of
   translation and dual-language support, this patch is designed for the
   USA version of El Viento.


Q: It doesn't work with my copier / flash cartridge! Why not?

   This was tested on a real Genesis so you shouldn't have any problems in
   that respect. The most likely reason is that something went wrong during
   the patching process. See the previous question and try it in an emulator
   to see if that works.

   Another possibility is that you are using a PAL Mega Drive. This game was
   designed for NTSC systems and I didn't make any changes in that respect.
   It should still run (probably at the wrong speed), but you never know...


Q: Why is the text in Japanese?!?

A: This is a dual-language patch. If it detects that it is running on a
   Japanese system, it will use the original game script. If you are using
   an emulator, make sure that the country code is set to USA.


Q: Is this a retranslation?

A: More of a hybrid. Some sentences were retranslated, some were edited,
   and some were left as-is.

   Despite being done by native speakers (of Japanese), the original script
   wasn't an exact translation, but it's still a good script and many aspects
   of it were retained, including several fan favorites like "A young girl
   comes to smash their terrible ambition!"


Q: How do I access the hidden stage?

A: See the section above.




 Translation Notes
-----------------------------------------------------------------------------

As stated above, this is a fusion of the original English script and a
translation of the Japanese script. Some sentences were retranslated,
some were edited, and some were left as-is.

The few localized names (such as the less-common / irregular spelling of
Annette) were kept, and Zigfried's nickname was added in a few places.

The original translation had several sentences removed, possibly for brevity,
but nothing significant was missing. Most of them have been reintroduced.

A few droll phrases like "mess of trouble" were retained. Part of the cloth.




 Hacking Notes
-----------------------------------------------------------------------------

This patch has the admittedly dubious feature of restoring Japanese support
to the English edition of a game. I noticed that the original code/data was
still intact and, after a few proof-of-concept tests, decided to reimplement
the Japanese text as a dual-language feature.


The most difficult improvement to this game was the removal of dozens of
graphical glitches, almost all of which can only be seen when the game is
run on a real Genesis.

The most widespread disease the game suffered stemmed from updating the color
palette while the screen is being drawn. Apparently this can cause visual
distortions even during blanking. The effect is most obvious in the intro
when New York fades into view -- you can see lots of random white flicker at
the top of the screen. Note that this garbage is not caused by the palette
being in a wrong state; simply writing to the palette seems to be enough to
trigger it. For example, any time the screen fades in or out when switching
stages you can see similar flicker at the very bottom of the screen in the
blanking area (may not be visible on all displays.)

Aside from that, there were many other aberrations that needed to be fixed,
most of which can also be attributed to making VDP updates during display.
Most of them are only visible for a split second and are easy to miss if you
aren't paying attention. I won't bother cataloging them all, but as far as
I know they have all been corrected. Since the programmers did very little
V-Blank synchronization, fixing one glitch often pushed a later VDP update
past the retrace period and caused a new problem. Further compounding the
issue was the music timing in the intro and ending -- valuable text display
periods were getting cut short with all the extra frames. The fact that the
only way to test the fixes involved reprogramming a dying flash cart was
especially irritating.


One of the rewarding aspects of hacking a game in-depth is that you are more
likely to find interesting things about it. For example, El Viento contains
a fully playable stage that is not normally accessible.

Stage 0, as I refer to it, appears to have been initially designed as a
testing ground for many of the game's features. It contains "programmer art"
and lacks any enemies.

The Stage 0 background had some crude katakana text drawn on it which has
been translated. And yes, the background translation is dual-language,
as ridiculous as that may sound.




 List of Changes (not exhaustive)
-----------------------------------------------------------------------------
Dozens of graphical glitches alleviated (only visible on real systems)
Script rewritten/retranslated
Dual-language feature added
Font changed
Text reformatted to avoid screen edges (better visibility on some displays)
Disabled musical transition in ending (first theme plays all the way through)
Fixed a bug in the intro (missing text when intro interrupted in some places)
Fixed a bug in the ending (text truncated if Scene 7 skipped)
Text printing routines enhanced
Mouth animations in the intro tweaked and reverted to a more natural speed
Tweaked credits slightly
Sound test reordered
Most songs in the sound test will now loop (override with the A Button)
Menus are now slightly easier to navigate (top/bottom wrap around)
Fixed a minor typo in the Japanese script I happened to notice
Removed a (probably) unintentional delay after skipping Japanese scenes
Stage 0 now accessible and with translated background (dual-language!)
