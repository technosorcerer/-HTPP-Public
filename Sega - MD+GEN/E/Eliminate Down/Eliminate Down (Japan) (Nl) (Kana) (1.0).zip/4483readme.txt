Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 30-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.
Deze vertaling kan nog enkele resten van de
oorspronkelijke taal bevatten.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling,
en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Eliminate Down (Japan).md
Platform: Sega Mega Drive / Sega Genesis
Database: No-Intro: Genesis (v. 20180824-045026)
MD5:   06AA841B8773DE52CD7CCC9D4F907468
SHA1:  53B418BDE065011E161E703DD7C175AA48A04FE5
CRC32: 48467542
Bytes: 1048576

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --