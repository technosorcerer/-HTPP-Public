This is a reduced set of improvements made by BillyTime! on its "Eternal Champions - Special Edition".

It contains only few tweaks to the original difficulty (no changes to Inner Strength, combos, etc).

Version 1.1
- Default difficulty for Contest is now 4 (instead of 7 from original game, 2 from BillyTime! hack)
- Easier overkills
- Single player now restores health bar on final boss fight after each "form"
