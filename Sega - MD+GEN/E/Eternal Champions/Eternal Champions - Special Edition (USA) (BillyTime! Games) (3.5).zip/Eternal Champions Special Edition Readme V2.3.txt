Eternal Champions Special Edition v2
July 26th, 2020
Billy Time! Games

Eternal Champions Special Edition is an improvement patch to Eternal Champions on the Sega Genesis/Mega Drive.
The following changes have been made to the game

How to Patch:
1.Grab a copy of Eternal Champions (U)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the included IPS file

Version 2.3 Changes: (7/28/2020)
--------------------------------
*Easy Overkills have been added to all stages
Blade - Player needs to land a Heavy Attack near fan or throw while on P2 side
Shadow - Player needs to land a Heavy Attack or throw In between the fence and the sign on P1 side 
Jetta - Player needs to land a Heavy Attack under the arches to the right of center while on P2 side
Midnight - Player needs to land a Heavy Attack or throw while on P1 side
Xavier - Player needs to land a Heavy Attack or throw while on P2 side
Larcen - Player needs to land a Heavy Attack or throw while on P1 side
Slash - Player needs to land a Heavy Attack or throw while on P2 side
RAX - Player needs to land a Heavy Attack or throw while on ANY side
Trident - Player needs to land a Heavy Attack or throw while on P2 side

Version 2.2 Changes: (7/26/2020)
--------------------------------
*Block routine has been slightly nerfed to allow for more fluid combos against computer opponents

Version 2.1a Changes: (7/7/2020)
--------------------------------
*Removed Easy Overkill in Jetta's stage to prevent a potential soft lock

Version 2.1 Changes: (6/16/2020)
--------------------------------
*Certain moves have been nerfed
-Trident's Red Shield uses ALL Inner Strength
-Trident's Green Shield uses ALL Inner Strength
-Trident's Blue Shield uses ALL Inner Strength
-Trident's Yellow Shield uses ALL Inner Strength
-Xaiver's Confusion Spell Uses HALF Inner Strength
-Xaiver's Swap Spell Uses HALF Inner Strength
-Xaiver's Identity Change Spell Uses HALF Inner Strength
*Optional Patches Included for original Overkill System

Version 2 changes: (6/15/2020)
--------------------------------
*Certain moves have been nerfed
-Shadow's Shadow Mode uses All Inner Strength
-Jetta's Phase uses All Inner Strength
-Trident's Mist Teleport uses Half Inner Strength
*Modified Hitstun and Pushback to address potential infinites
*Easier Overkill on Jetta's Stage


Version 1 Changes: (6/11/2020)
--------------------------------
*Retooled Inner Strength System (Alternate patch removes limitations alltogether)
-Basic Specials use no inner strength
-Specials that can be abused use Inner Strength and can lock you out of specials until your meter recharges
Blade's Protective Shield
Blade's Wild Fury Attack
Shadow's Shadow Mode
Shadow's Smoke Screen
Trident's Force Fields
Trident's Mist Teleport
Trident's Spinning Trident
Jetta's Phase
Jetta's Spin Attack
Larcen's Machine Gun Punch
Larcen's Grapple Hook Swing
Midknight's Bedazzle
Midknight's Mist Attack
RAX's Lock and Load
RAX's Spin Dodge
Xavier's Confusion Spell
Xavier's Teleport Swap
Xavier's Character Swap
Slash's Ground Slam Stun

*Taunts no longer use nor take Inner Strength from opponent
*Easier Overkills on the following stages
-Larcen
-Midknight
-Trident
-RAX
*Eternal Champion Boss restores Health in full between forms
*Slightly longer Hitstun to allow for combos

*Character Changes:
-Spinning Trident does half damage
-Tracking and straight blade does slightly more damage
-Blade's LP does less damage 

*Easier Overkills on the following Stages
-Midknight
-Larcen
-Trident
-RAX

*Contest AI level set to 2 (Default was 7)

Special Thanks to:
Tony H - for helping make the transition from 65816 to 68000 Assembly with his insights and patience