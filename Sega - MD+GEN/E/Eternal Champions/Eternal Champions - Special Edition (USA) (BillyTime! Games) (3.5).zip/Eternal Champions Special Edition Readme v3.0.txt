Eternal Champions Special Edition v3.5
Nov 27th, 2024
Billy Time! Games
--------------------------------
Eternal Champions Special Edition is an improvement/Enhancement patch to Eternal Champions on the Sega Genesis/Mega Drive.
The following changes have been made to the game

Version 3.5 Changes: (11/22/2024)
--------------------------------
*New mechanic added to randomize colors on certain stages. These colors match the Sega CD Version.
-Blade
-Larcen
-Trident

*Infinite Inner Strength Cheat
--------------------------------
How to use:
When first selecting a character in contest mode, Hold Z then press and hold start. 
Hold these two buttons until your first match starts. Hold B and C to use with Hard mode and Difficulty Randomizer.

*Difficulty Randomizer
--------------------------------
How to use:
When first selecting a character in contest mode, Hold C then press and hold start. 
Hold these two buttons until your first match starts. At the start of each round, CPU difficulty will change between level 1-8.

Version 3.0 Changes: (12/1/2022)
--------------------------------
*Taunts drain a small amount of Inner Strength as opposed to none at all.
*Rax's lock and load now uses 1/2 Inner Strength as opposed to 1/4.
*Rax's Overload now uses 1/4 inner strength as opposed to none at all.
*Futher tweaks made to Inner Strength system to ensure most moves require Inner Strength
*Timer speed has been adjusted to cown down slightly slower

*Hard Mode Contest Difficulty!
--------------------------------
How to use:
When first selecting a character in contest mode, Hold B then press and hold start. 
Hold these two buttons until your first match starts. Every match for the rest of your current playthrough will be at Difficulty 7 as opposed to 2.
 
*Playable Eternal Champion in VS mode!
--------------------------------
How to use:
--------------------------------
When in Two Player mode at the character select screen, hold Y and press start. When in game your character will become the Eternal Champion.

Additional Rules:
--------------------------------
*Eternal Champion cannot resurrect in this mode.
*Battles with Eternal Champion are contested in 1 out of 1 win conditions.

How to Patch:
--------------------------------
1.Grab a copy of Eternal Champions (U)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the included IPS file

Special Thanks to:
Tony H - for helping make the transition from 65816 to 68000 Assembly with his insights and patience