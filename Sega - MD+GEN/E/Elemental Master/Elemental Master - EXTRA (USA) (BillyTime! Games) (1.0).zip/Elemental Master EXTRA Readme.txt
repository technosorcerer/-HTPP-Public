Elemental Master EXTRA
Aug 19th, 2024
BillyTime! Games
--------------------
This patch tweaks gameplay and adds new functions for Elemental Master on Sega Genesis 

Features:
-----------------------
*2X Invincibility
*2X Charge when Health Cap Is Maxed
*Keep Health cap inbetween credits
*Can play through the entire game on  Practice mode
 
HI-Score SRAM:
Saving:
-----------------------
Score saves when starting a new level or using a continue.

Loading:
-----------------------
Score loads at boot, default scores will be loaded if checksum fails.

CHEATS: (Enter these button combos during the opening cutscene.)
-----------------------
A+C+START - Max Health Cap / Unlock 2x Charge Time
A+B+START - Unlock All Weapons
B+C+START - 99 Credits
A+B+C+START - ALL CHEATS!

How to Patch:
--------------------
1.Grab a copy of Elemental Master (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

