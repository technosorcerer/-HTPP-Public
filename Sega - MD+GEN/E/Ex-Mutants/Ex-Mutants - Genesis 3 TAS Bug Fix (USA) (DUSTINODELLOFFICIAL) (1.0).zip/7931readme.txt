This simple patch allows the game to function correctly on a Genesis 3 VA2 or
any other clone or emulator that has an "incorrect" implementation of the 68K
TAS instruction. It replaces the TAS instruction with TST.B which is likely what
the programmer intended to do. This is the same "bug" that causes Gargoyles to
not work on a Genesis 3 VA2 and it is present in at least 2 other games Chris
Shrigley programmed (this one and Cliffhanger).

Apply patch to "Ex-Mutants (USA, Europe).md" from the No-Intro set, or if you
are using a Mega Everdrive Pro, you can rename the patch to match the ROM name
(with an .ips extension) and put it alongside the ROM in a directory.

MD5
699fdbc714dd0f1c65b91505b6e3c1d4  Ex-Mutants (USA, Europe).md
