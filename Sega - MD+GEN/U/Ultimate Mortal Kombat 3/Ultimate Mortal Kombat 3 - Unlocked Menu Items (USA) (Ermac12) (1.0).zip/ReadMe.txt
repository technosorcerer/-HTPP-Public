﻿--------------------------Info---------------------------
Game name: Ultimate Mortal Kombat 3
Console: Sega Genesis
Game region USA: (U)
Patch: SP (Solid patch)
Patcher: Solid patcher
Patcher download link:
 Windows: https://romhackplaza.org/utilities/solid-patcher-utility/
 Linux: https://romhackplaza.org/utilities/solid-patcher-utility-2/
 https://rgcorp.ucoz.net/load/console_soft/solid_patcher/2-1-0-97
----------------------------------------------------------
--------------------------patch------------------------
The patch adds the following change:
 
 Unlocked all main menu items.

----------------------------------------------------------
Author by: Ermac12