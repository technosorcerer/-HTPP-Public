Ultimate Mortal Kombat 3 AI Nerf
Sept. 12th 2022
BillyTime! Games
--------------------
Ultimate Mortal Kombat 3 AI Nerf is a patch designed to rebalance the CPU AI in Ultimate Mortal Kombat 3.

How It Works:
--------------------
Inital AI is decided by which ladder you chose in Arcade mode. Difficulty will no longer scale when on a winning streak.

Novice - Easy
Warrior - Medium
Master - Hard
Master II - Hardest

Motaro and Shao Kahn AI has been nerfed and will retain the same difficulty regardless of what ladder you chose.

How to Patch:
--------------------
1.Grab a copy of Ultimate Mortal Kombat 3 (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file