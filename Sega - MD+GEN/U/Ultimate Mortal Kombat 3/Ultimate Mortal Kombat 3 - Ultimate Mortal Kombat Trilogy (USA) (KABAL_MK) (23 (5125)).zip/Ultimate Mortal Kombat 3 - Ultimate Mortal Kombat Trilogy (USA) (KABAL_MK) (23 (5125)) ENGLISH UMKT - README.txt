This is a hack by KABAL_MK of Ultimate Mortal Kombat 3 for the Sega Genesis. It adds nearly all playable characters from the Genesis/MegaDrive versions of Mortal Kombat 1, 2, and 3 -including the absent Sheeva, and also adds new backgrounds, specials, combos, finishing moves, and missing audio samples.

==New in v23 (5125)==
-Added more arena backgrounds
-Improved computer AI
-Bug Fixes
-Added more specials, combos, finishing moves.

==Compatibility==
The following is a list of emulators that work with the hack:

Computer & Retroarch (all platforms using these cores):
-GenesisPlus-GX
-Picodrive

Other systems:
-NeoGenesis version 22+ (Xbox).
-PicoDrive version 1.51+ (PSP).
-GenesisPlus-GX Wii v080716+
-MD Emu (Android, iOS)

Some older, but compatible emulators can be found [url=http://umk3.hacking-cult.org/eng/download.htm]here[/url].

The patch(s) are in XDelta format, and need to be applied to a ROM in "BIN" format. A "+Tracks" patch is also included which changes some music. It is recommend to use Delta Patcher: http://www.romhacking.net/utilities/704/

NOTE: The "+Tracks" patch must be applied AFTER the main patch.
Apply to:
Ultimate Mortal Kombat 3 (USA).bin
CRC32: 7290770d
MD5: 5a129779699f8b388e97c9c0d703d503
SHA-1: bf2da4a7ae7aa428b0b316581f65b280dc3ba356
