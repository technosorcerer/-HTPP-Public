Combat Cars Redux
Sep. 11th 2024
BillyTime! Games
--------------------

This patch is an complete overhaul to Combat Cars for Sega Genesis.

Features:
*Nerfed difficulty for AI racers across all modes
*Increased weaponry when completing a lap
*Driving on terrain won't affect acceleration
*Ranking 4th place and higher gets you to the next race
*Can continue after losing a race. (Start new game by resetting console or by Soft Reset.)
*Soft Reset by pressing A+B+C+START while race timer is active (Clears current 1P progress.)


How to Patch:
--------------------
1.Grab a copy of Combat Cars (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file