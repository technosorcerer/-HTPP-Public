Castlevania Bloodlines - Alt Control v1.1
April 17th, 2024
BillyTime! Games
---------------------------

This patch is designed to allow John Morris to whip straight and Diagonally while standing. 

How To Use:
John whips straight when pressing the Y
Button while standing, Moving while pressing the Y button makes John whip diagonally.


Note: Patch does not affect Eric Lecarde.

How to Patch:
---------------------------
1.Grab a copy of Castlevania - Bloodlines (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file