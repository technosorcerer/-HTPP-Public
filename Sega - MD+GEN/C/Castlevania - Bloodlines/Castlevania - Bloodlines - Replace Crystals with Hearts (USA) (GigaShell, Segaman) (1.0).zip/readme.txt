/************************************
 * Info:
 ***********************************/

Name: Castlevania Bloodlines - Replace Crystals with Hearts
Date: 02.03.2025
Version: 1.0
Original Castlevania - Bloodlines (U) [!].bin
Code: GigaShell
Checksum and minor fixes: Segaman

/************************************
 * Features:
 ***********************************/
 
-Replaced crystals with hearts
-Added floating heart animation/behavior

/************************************
 * How to patch:
 ***********************************/
 
Patch (U) version of the game with provided ips-patch file

