Castlevania - Bloodlines SRAM
Nov. 13th 2022
BillyTime! Games
--------------------
This patch is designed to add a simple saving mechanism to Castlevania - Bloodlines.

How to use:
--------------------
Saving:
Game saves when starting a new life or new level.

Game saves:
Current Level/Sub-Level
Current Difficulty

Game does not save:
Current lives or continues 

Loading:
At the title Screen Hold B and Press start. Continue to Hold B until the character select screen. Pick your character and your game will continue where you left off.

NOTE:
Game will not save at first room of opening stage to prevent accidental overwrites.
Game will not save during demo mode.

How to Patch:
--------------------
1.Grab a copy of Castlevania - Bloodlines (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file