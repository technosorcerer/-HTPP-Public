Cliffhanger - No Enemy Invincibility Frames
May. 10th 2025
BillyTime! Games
--------------------
This simple patch is designed to remove invincibility frames from enemies in Cliffhanger for Sega Genesis.

How to Patch:
--------------------
1.Grab a copy of Cliffhanger (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file