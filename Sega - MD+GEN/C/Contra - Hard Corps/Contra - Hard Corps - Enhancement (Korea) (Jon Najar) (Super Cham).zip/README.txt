




                             Contra: Hard Corps
                              Enhancement Hack




 History
-----------------------------------------------------------------------------

080924 Initial release
120527 Special Champion Edition release




 Overview
-----------------------------------------------------------------------------

This is a patch for the Genesis game "Contra: Hard Corps" which makes
numerous minor enhancements. It started out as a simple hack to permit
the user to skip the mission briefings, which get annoying when one has
played the game dozens of times.

Since that hack was implemented by manipulating the text-printing state
machine, it eventually led to a full script replacement to enhance and
correct the original. Quite a few other minor fixes/enhancements were
added as well. See the complete list of changes in this file for details.

As far as the script corrections go, this patch should take care of the
agreement-in-number problems and also improves the phrasing here and there.
Some minor errors were also fixed, such as the misspelling of "Noiman".




 Applying the Patch
-----------------------------------------------------------------------------

Hopefully included with this document is a patch file in the IPS format.
You can use any program that supports that file format to apply this
patch to your ROM file.

Remember to use the USA version of the game; other editions will not work.




 Playing the Game
-----------------------------------------------------------------------------

Once you've patched the ROM file, simply load it up in your favorite
Genesis / Mega Drive emulator, console copier, or flash cartridge.

You can perform a soft reset by pressing A, B, C, and Start any time after
the game has finished initializing (once it starts displaying graphics).

Holding down B & C will allow you to skip through text faster.

You can toggle the in-game font by holding down A & C for at least one full
second any time after the game has initialized. This won't take effect until
the next time the font is loaded, so you won't see an immediate difference if
you enter this code while text is printing. Enter the code again to switch
back to the other font. A sound effect will play whenever the swap occurs.

Another new feature is the ability to select the same character in two-player
games. This changes the gameplay and destroys an element of realism, which
Konami probably would not have approved of. Therefore it must be activated
at the title screen by entering a code: the already overused Konami Code. (*)
You will hear a sound effect if you entered it correctly.

Note that the above assumes you are using the default button configuration.

Another caveat is that soft reset doesn't work as well in some emulators.
As a result, it may end up doing a full reset, wasting several seconds
of your life. Soft reset works properly on a real Genesis.


(*) Konami Code: Up, Up, Down, Down, Left, Right, Left, Right, B, A




 Q & A
-----------------------------------------------------------------------------

Q: This patch doesn't work! What do I do?

A: Make sure that your ROM file is not in an interleaved format. It's also
   possible that you are using the wrong version of the game, or that your
   copy is corrupt.


Q: It doesn't work with my copier / flash cartridge! Why not?

   This was tested on a real Genesis so you shouldn't have any problems in
   that respect. The most likely reason is that something went wrong during
   the patching process. See the previous question and try it in an emulator
   to see if that works.

   Another possibility is that you are using a PAL Mega Drive. This game was
   designed for NTSC systems and I didn't make any changes in that respect.
   It should still run (probably at the wrong speed), but you never know...


Q: How do I activate the new "Special Champion Edition" feature?

A: Enter the Konami Code at the title screen. Either controller will work.
   Both players will then be able to select the same character.


Q: What is the Konami Code?

A: Up, Up, Down, Down, Left, Right, Left, Right, B, A.


Q: Is this game subtitled "Hardcorps" or "Hard Corps"?

A: Well, first let's look at some data:

   USA credits: HARD / CORPS
   USA ROM header: ZA*HAADOKOA & HARDCORPS
   USA music test: THE HARD CORPS (2x)
   USA title screen: HARD / CORPS
   USA copyright screen: HARDCORPS
   USA cartridge label (top): Hard Corps

   Japanese credits: HARD / CORPS (no 'the')
   Japanese ROM header: ZA*HAADOKOA & HARDCORPS
   Japanese music test: THE HARD CORPS (2x)
   Japanese title screen: ZA*HAADOKOA
   Japanese copyright screen: THE HARDCORPS

   The Japanese authors didn't sort this out properly, but they seemed to
   have intended the two-word version. The copyright screen and ROM header
   can be excused since typical Japanese rarely marks the separation in
   compound words/phrases derived from Western languages.

   Despite the copyright screen, the evidence strongly suggests "Hard Corps"
   is the proper way to write it, and so I recommend using "Hard Corps" for
   the American version and "The Hard Corps" for the Japanese version. This
   patch adjusts the copyright screen to reflect that. The ROM header hasn't
   been changed because it's not meant to be seen by the user and I frown
   on the practice of editing the title part of headers; there are too many
   worthless hacked versions of ROMs floating around because of it.


Q: What's with the subtitle anyway? Is it some kind of play on words?

A: For those not familiar with the word, 'corps' is pronounced like 'core'.

   Technically, "hard core" is a noun, while hard-core (or hardcore) is an
   adjective. Therefore "Contra: Hardcorps" would have made more sense for
   the American version, at least from a grammatical standpoint. On the
   other hand, "The Hard Corps" works just fine for the Japanese version.


Q: How do you pronounce "Neumann"?

A: Written phonetically, it's "Noiman" or "Noyman". Same sound as 'oyster'.


Q: Why is the font a bit hard to read?

A: If you're playing on a real Genesis, you may find the game's default font
   difficult to read because it is so thin. See the relevant section above
   for information on how to switch the font during play.

   The default font is a modified version of the font that the game uses
   normally, which is why it is used by default, even though I don't like it.


Q: Why is this game so hard?

A: Because it's "hard-core". But in case _you_ aren't, you can now increase
   the starting number of lives in the options menu.

   Aside from training/practice sessions, you should stick with the default
   of 3 lives.

   The Japanese version, on the other hand, is decidedly NOT hard-core,
   with unlimited continues and 3 hits per life. The life bars alone are
   roughly equivalent to tripling the number of lives you start with in the
   USA version. This is compounded every time you gain extra lives from
   points (normally this happens for the first time after beating the giant
   robot in the first stage). The fact that you only lose your weapon every
   third time you are hit makes it even EASIER. What's so hard-core about
   a game that can be easily beaten with extremely sloppy play? Where's the
   rush when you can only lose if you give up and quit playing?




 List of Changes
-----------------------------------------------------------------------------

Soft reset added.
Copyright screen edited slightly.
Copyright screen can now be skipped by pressing the start button.
Minor rewording in options menus.
Maximum number of lives in options menu increased to 5 (default is still 3).
Got rid of the annoying "press start to exit" feature in some menus.
Start button can now be used to confirm some options.
Start button can now be used to select your character.
Entering a code permits the same character to be selected by both players.
Mission briefings can now be skipped by pressing the start button.
You can now hold buttons B & C to skip through text faster.
The hide-pause-banner feature now requires a certain debugging mode.
In-game font fixed such that lower-case characters are now usable.
Added an alternate font (activated with a code).
Added 'e accent aigu' to font for 'coup d'�tat'.
Script corrected, edited, and optimized.
Fixed a display bug if your bomb stock exceeds 99.
