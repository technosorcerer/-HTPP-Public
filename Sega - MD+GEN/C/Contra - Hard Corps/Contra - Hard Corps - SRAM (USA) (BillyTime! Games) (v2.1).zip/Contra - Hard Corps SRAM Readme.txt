Contra Hard Corps SRAM v2
June 12th 2021
BillyTime! Games
--------------------

This patch is designed to add a simple saving mechanism to Contra Hard Corps.

v2 is designed for greater compatibility with the following Improvement patches.

Contra: Hard Corps Enhancement Hack
https://www.romhacking.net/hacks/450/

Contra Hard Corps Hit Points Restoration Hack
https://www.romhacking.net/hacks/797/

Contra Hard Corps: Stationary Fire+
https://www.romhacking.net/hacks/4665/

How to use:
--------------------
Saving:
Game saves every time you continue.

Loading:
Enter options, press up and select Exit. Then start your game.

NOTE:
Game will produce a black screen if no prior save is detected.

Optional Patch: 7/3/2025
--------------------
An additional patch has been added to feature player dealt double damage to enemies and bosses. It is tied to SRAM for easier compatibility with other patches from different authors.

How to Patch:
--------------------
1.Grab a copy of Contra - Hard Corps (USA, Korea).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file