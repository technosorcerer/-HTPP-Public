Crack Down Hi-Score SRAM
Oct. 6th 2023
BillyTime! Games
--------------------
This patch is designed to add a simple saving mechanism for High Scores in Crack Down.


How to use
--------------------
Saving:
Scores save after Initials are entered at the continue screen. 

Loading:
Scores load upon boot. If checksum fails or it is your first time booting, default scores are loaded.


How to Patch:
--------------------
1.Grab a copy of Crack Down (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file