Crack Down (2x Time)
Sep. 15th 2025
BillyTime! Games
--------------------
This is a simple patch for Crack Down on Sega Genesis that increases the amount of miliseconds required before one second ticks by. Effectively slowing down the timer. Comes with patches for 2x, 3x, and 4x.

Note:
Compatible with Crackdown Hi-Score SRAM
https://romhackplaza.org/romhacks/crack-down-hi-score-sram-genesis/

How to Patch:
--------------------
1.Grab a copy of Crack Down (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file