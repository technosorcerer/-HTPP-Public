Chakan - The Forever Man (Mega Drive)
Traducci�n al Espa�ol v1.0 (06/03/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Chakan - The Forever Man (UE) [!].gen
MD5: 8844a97b65994de94cf398cf4a3217c3
SHA1: 7eae088f0b15e4bcd9a6a38849df5a20446be548
CRC32: 046a48de
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --