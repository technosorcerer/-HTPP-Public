Comix Zone (2x Strength)
Jan. 12th 2025
BillyTime! Games
--------------------
This is a simple patch designed for Comix Zone that increases the amount of damage inflicted on enemies. Comes with a 2x Strength and 3x Strength patch.

How to Patch:
--------------------
1.Grab a copy of Comix Zone (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file