Comix Zone - No Damage Taken From Attacking Solid Objects & Ice Tea Fully Heals Player Version 1.0
14/07/2024

A simple patch to decrease the difficulty of the game and make it more enjoyable. 
The Patch apply Game Genie codes:
AJDV-4A4L No damage from attacking solid objects 
963B-4JAC Ice Tea fully heals player .

  
No-Intro Name: Comix Zone (USA)
No-Intro: Genesis (v. 20180824-045026)
SHA-1: E8747EEFDF61172BE9DA8787BA5BE447EC73180F
CRC32: 17DA0354

Enjoy :)

Lemongrwab