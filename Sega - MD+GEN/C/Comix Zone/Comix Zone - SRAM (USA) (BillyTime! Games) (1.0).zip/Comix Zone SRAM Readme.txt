Comix Zone SRAM
Feb. 10th, 2021
BillyTime! Games
--------------------

This patch is designed to add a simple saving mechanism to X-Men 2 - Clone Wars.

How to use:
--------------------

Saving:
Game saves after every level past the first stage.

Loading:
Enter the options menu, select load and press C. Back out and select start at the title screen.

NOTE:
Game will produce a black screen if no prior save is detected.

How to Patch:
--------------------
1.Grab a copy of Comix Zone (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file