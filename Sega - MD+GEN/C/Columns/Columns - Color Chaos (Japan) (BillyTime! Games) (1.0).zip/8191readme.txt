Columns - Color Chaos
Nov. 2nd 2023
BillyTime! Games
--------------------
This patch is designed to randomize gem colors in Columns for an extra challenge.

*How it works:
--------------------
Gem colors are randomized across all modes with a total possibility of 18 different sets of colors. Colors reset when returning to the title screen.


*Included - Hi-Score SRAM
--------------------
*Saving:
Scores save after Initials are entered. 

*Loading:
Scores load upon boot. If checksum fails or it is your first time booting, default scores are loaded.

How to Patch:
--------------------
1.Grab a copy of Columns (World).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file