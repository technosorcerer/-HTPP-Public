Columns - Always Hints
Aug. 5th 2024
BillyTime! Games
--------------------
This patch is designed to continue giving hints past level three in Columns.

*How it works:
--------------------
Hints now have a level cap of 255, compatible with Hi-Score SRAM and Color Chaos.


How to Patch:
--------------------
1.Grab a copy of Columns (World).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file