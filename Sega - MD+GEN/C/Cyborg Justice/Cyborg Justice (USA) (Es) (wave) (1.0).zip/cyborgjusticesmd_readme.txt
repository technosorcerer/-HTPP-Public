Cyborg Justice (Mega Drive)
Traducción al Español v1.0 (06/09/2020)
(C) 2020 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Cyborg Justice (USA, Europe).md
MD5: d2d8c19c67e14a0d509a454bd880bbdd
SHA1: 6d0c72fa5e53d897390707eb4c6d3e86e6772215
CRC32: ab0d1269
524288 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --