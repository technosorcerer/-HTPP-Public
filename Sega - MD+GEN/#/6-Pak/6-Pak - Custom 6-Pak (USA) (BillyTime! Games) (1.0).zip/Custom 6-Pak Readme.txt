Custom 6-Pak
Jan. 5th 2025
BillyTime! Games
--------------------
This is a simple compilation patch which modifies every single game featured in 6-Pak. Some offer little changes and other offer much more.

The following is a list of changes included across all games.
------------------------------------------------------------------------------------------------------------------------
Streets of Rage - Bad End 1P
Aug. 1st 2024
BillyTime! Games
--------------------
This patch allows players to reach the bad ending in Streets of Rage when playing Single Player.

How it Works
--------------------
When Confronting Mr.X in Stage 8, Say yes to become his right hand man. After returning to Stage 8, Mr.X will confront you. Defeat him to become the new boss. 

------------------------------------------------------------------------------------------------------------------------
Sonic 1 - Emerald Safari
Apr. 13th 2023
BillyTime! Games
--------------------
This patch is a gameplay overhaul for Sonic The Hedgehog which gives each Chaos Emerald unique abilities that stack.

How it Works:
--------------------
Each emerald you obtain from bonus stages will give the player new abilities.

These abilities are as follows:
First Emerald
Player 1 Gets one extra hit point per life before losing rings. (Does not stack with shields)
Second Emerald
Special stages are now always open regardless of ring count.
Third Emerald
Player 1 now has faster acceleration.
Fourth Emerald
Player 1 can stay underwater for extremely long periods of time.
Fifth Emerald
Player 1 now earns double rings in normal stages.
Sixth Emerald
Player 1 can now jump higher.

Differences in this version:
--------------------
*No SRAM saving
*No Spindash
*No Fixed Speed Cap
------------------------------------------------------------------------------------------------------------------------
Golden Axe - Stronger Attacks
Dec. 26th 2024
BillyTime! Games
--------------------
This patch is designed to attack damage for players in Golden Axe for the Sega Genesis.
------------------------------------------------------------------------------------------------------------------------
Columns - Always Hints
Aug. 5th 2024
BillyTime! Games
--------------------
This patch is designed to continue giving hints past level three in Columns.

*How it works:
--------------------
Hints now have a level cap of 255.
------------------------------------------------------------------------------------------------------------------------
Revenge of Shinobi - Better Jumping
December 6th, 2020
BillyTime! Games
--------------------
This patch Modifies jumping physics for better control. Changes include:
*Easier Double Jump
*Slightly Higher jump height
------------------------------------------------------------------------------------------------------------------------
Super Hang On 
Jan. 5th 2025
BillyTime! Games
--------------------
*Players recieve 45 seconds of the clock when hitting a check point.

How to Patch:
--------------------
1.Grab a copy of 6-Pak (USA).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file
