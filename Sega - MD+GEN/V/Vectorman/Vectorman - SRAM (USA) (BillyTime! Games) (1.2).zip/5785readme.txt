Vectorman SRAM
Mar. 2nd 2021
BillyTime! Games
--------------------

This patch is designed to add a simple saving mechanism to Vectorman.

How to use
--------------------

Saving:
Game saves after every life lost.

Loading:
Enter options menu and press right while highlighting Restore Game.

NOTE:
Game will produce a black screen if no prior save is detected.

v1.2 Changelog:
Final levels now load and save properly.

How to Patch:
--------------------
1.Grab a copy of Vectorman (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file