Vixen 357 - Armored Warrior

February 2019 by Vikfield.

This hack, Changes the next aspects of the original game:

- all weapons have been modified (damage, range, ammunition, etc); Also, they have been renamed.
- some attributes of the player's mechs have been slightly changed (mainly defenses and hp), and some mech�s arsenal has been   modified as well.
- Several NPC allied and enemy mechs have been modified.
- the status words have been replaced by more common RPG genre abbreviations; for example AP = ATK, DP = DEF, etc.

This hack is compatible with the translation patches; to work properly, you must first install the translation patch and then the Armored Warrior hack.

NOTE: some abbreviations are lost when a translation patch is installed.

Enjoy your game, and thanks for downloading!