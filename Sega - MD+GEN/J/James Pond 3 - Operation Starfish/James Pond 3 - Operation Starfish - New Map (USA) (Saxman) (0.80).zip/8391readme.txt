==============================================================================
NEW MAP FOR JAMES POND 3 -- VERSION 0.80
Created by Saxman
January 20, 2024
==============================================================================

This is a brand new map I created while testing my upcoming level editor for
the game. I don't actually consider it "finished" yet, but it is fully
playable. My challenge to you is to see if you can find all four teacups, as
well as the micro map. There is a strategy you will have to employ to collect
everything without getting hurt.

- Saxman
