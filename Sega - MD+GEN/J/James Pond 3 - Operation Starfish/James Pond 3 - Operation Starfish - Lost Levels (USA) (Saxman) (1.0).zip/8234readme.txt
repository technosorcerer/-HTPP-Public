==============================================================================
JAMES POND 3: LOST LEVELS!
Patch created by Saxman
November 17, 2023
==============================================================================

The Amiga AGA version of James Pond 3 includes a lot of 'LVL' files. As you
might guess, these are the maps for the game. The foreground and background
are created individually, increasing the number of LVL files found in the
directory. However, doing a count of how many maps are referenced by the game
versus how many LVL files there are reveals seven additional files that go
unused!

Many of these are actually early revisions of maps that are used by the game.
But two of the files are completely different from anything else used by the
game. These are SLIMEP06.LVL and SCAVEJ02.LVL. The existence of special
trigger functions (e.g. data describing what will happen when a switch is
activated) assigned to Lair of the Mush-Beast that match perfectly with the
SLIMEP06 map suggests the latter was swapped out for the boss battle. The
SCAVEJ02 map remains a mystery as to where it was going to be used.

I have imported both of these maps into the Genesis version of the game with
no modifications made to them. For convenience purposes, they replace Garden
of Edam and East of Edam so you can access them quickly.

If you like this, be sure to check out my other James Pond 3 content on
Romhacking.net. There, I have ROM hacking notes, as well as an experimental
level viewer called "CHEESE!". And at the time of writing this, I am working
on a proper level editor for the game which I hope to get released soon.

Enjoy!


-- Saxman
