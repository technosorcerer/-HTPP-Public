James Pond 3 Password SRAM
December 29th 2021
BillyTime! Games
--------------------

This patch is designed to add a simple saving mechanism to James Pond 3 - Operation Starfish.

How to use
--------------------

Saving:
Game saves when new password becomes available.

Loading:
Password loads at boot up before the title screen.

How to Patch:
--------------------
1.Grab a copy of James Pond 3 (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file