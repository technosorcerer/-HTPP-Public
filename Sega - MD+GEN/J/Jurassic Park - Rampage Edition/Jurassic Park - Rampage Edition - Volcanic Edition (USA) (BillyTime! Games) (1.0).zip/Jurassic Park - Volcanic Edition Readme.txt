Jurassic Park - Volcanic Edition
Aug. 10th, 2024
BillyTime! Games
--------------------
This patch for is an overhaul for Jurassic Park - Rampage Edition on Sega Genesis 

Features
--------------------
*Sega Screen can now be skipped
*Grant now jumps higher
*Grant now recieves health from checkpoints (Easy Mode Only)
*Grant recieves double ammunition from weapon pickups
*Grant and raptor now have variable armor (Higher armor on Easy Difficulty, No Armor and More Damage on Hard Difficulty.)
*Tranquilizer Gun can now fire three times as fast 
*Several New endings!
*New Game Over screens for Grant and Raptor
*New cheat codes!
*Raptor retains lysine levels between stages and lives
*New error handler courtesy of Vladikcomper 
(https://sonicresearch.org/community/index.php?threads/advanced-error-handler-and-debugger.4442/)

*SRAM:
--------------------
Saving:
Game saves whenever progress is made on the map.

Game Saves:
*Progress
*Character
*Difficulty
*DNA Samples saved
*Character Ending when all levels are completed

Loading:
Hold B and start game, continue to hold B and the text "Game Loaded" will appear.
All game progress will be restored


How to Patch:
--------------------
1.Grab a copy of Jurassic Park - Rampage Edition (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

