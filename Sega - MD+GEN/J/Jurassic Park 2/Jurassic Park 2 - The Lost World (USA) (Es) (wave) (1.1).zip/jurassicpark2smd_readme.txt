Jurassic Park 2 - The Lost World (Mega Drive)
Traducci�n al Espa�ol v1.1 (08/11/2018)
(C) 2018 Wave Translations

------------------------
Notas y Fallos Conocidos
------------------------
v1.1: Correcci�n del final y un par de textos.
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Jurassic Park 2 - The Lost World (U) [!].bin
MD5: faa6c4be300016843000cbbed8e94553
SHA1: 25a93bbcfbbe286a36f0b973adf86b0f0f3cfa3f
CRC32: 140a284c
4.194.304 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --