Jewel Master SRAM
June 7th 2021
BillyTime! Games
--------------------

This patch is designed to add a simple saving mechanism to Jewel Master.

How to use
--------------------

Saving:
Game saves after every level past stage 1.

Loading:
Enter options, press up and select Exit. Then start your game.

NOTE:
Game will produce a black screen if no prior save is detected.

How to Patch:
--------------------
1.Grab a copy of Jewel Master (USA, Europe) (Rev A).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file