Jewel Master - Ring Expansion
July 25th, 2024
BillyTime! Games
--------------------

Jewel Master - Ring Expansion is a patch designed to allow players to stack the same type of elemental rings for new abilities in Jewel Master for the Sega genesis

New Abilities:
--------------------
Two Fire Gems = Increased Damage Dealt 
Two Water Gems = Increased Barrier Time
Two Earth Gems = Health Recovery (Can only be used once per Level/Health Upgrade)
Two Wind Gems = Grants High Jump and Speed Up at once

SRAM Compatible Patch:
--------------------
Saving:
Game saves after every level past stage 1.

Loading:
Enter options, press up and select Exit. Then start your game.

NOTE:
Game will produce a black screen if no prior save is detected.


How to Patch:
--------------------
1.Grab a copy of Jewel Master (USA, Europe) (Rev A).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file (Use only one patch.)