=============================================================================
Assault Suit Leynos - English Translation by Tryphon & GoodLuckTrying
=============================================================================

Changes:
- Full re-translation based on the source material.
- Custom backgrounds for 7 of the 8 Stages.

Alternate patch (Leynos (No BGs, no VWF).bps) only provides the translation (Lacks Variable Width Font and Custom Backgrounds)

Original Rom:
Filename: Juusou Kihei Leynos (Japan)
Database: No-Intro: Genesis (v. 20210226-213851)
File/ROM SHA-1: 332886D9FE7823092FED6530781269B60F24D792
File/ROM CRC32: 81A2C800