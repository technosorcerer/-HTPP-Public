Outrun Hi-Score SRAM
May. 9th 2023
BillyTime! Games
--------------------
This patch is designed to add a simple saving mechanism for High Scores in Outrun.


How to use
--------------------
Saving:
Scores save after Initials are entered and player returns to the title screen. 
Score, Name, Route and Time and difficulty played are all saved.

Loading:
Scores load upon boot. If checksum fails or it is your first time booting, default scores are loaded.


How to Patch:
--------------------
1.Grab a copy of OutRun (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file