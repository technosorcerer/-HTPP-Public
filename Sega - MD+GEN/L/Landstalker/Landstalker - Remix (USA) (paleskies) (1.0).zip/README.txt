#### LANDSTALKER REMIX V1.0 ####

#### OVERVIEW ####
Thank you so much for downloading my ROM hack of Landstalker, Landstalker Remix!
This is a ROM hack of Landstalker that polishes the game's text strings, improves various sprites, 
changes all character names to their Japanese variants, restores content from the Japanese version of the game that was 
censored in the US release (mainly the items and Mercator Castle bath scene), and more!

#### SETUP ####
To play, you will need to apply the "LandstalkerRemix.bps" patch to a US Landstalker ROM.
The hash of the ROM is listed below:
Filename: Landstalker (USA).md
CRC-32: fbbb5b97
SHA-1: 24345e29427b000b90df778965dd8834300a9dde
I reccomend using the Flips ROM patcher to apply the patch, but you can use any other tool if you want.
To apply the patch in Flips, click "Apply Patch", select the "LandstalkerRemix.bps" patch, and then select your Landstalker ROM to apply the patch.
Afterwards, you can play on an emulator or real hardware. (Tested on a Genesis Model II MK-1631 with a Mega Everdrive X3)

#### FUTURE ####
In the future, I hope to add the following features to Landstalker Remix:
- Run button
- Translation for Madame Yard's Pink Palace
- Player and sprite shadows
- Rebalanced enemy placement and stats, and restoration of unused enemies
- New room traps and objects
- Room design tweaks
- More dungeon theme variety
And more!

#### OTHER ####
If you find any bugs or glitches, or want to suggest anything for the hack, let me know at paleskies120@gmail.com.
I hope you enjoy Landstalker Remix! I had a lot of fun creating it!

#### CREDITS ####
-Original Game by Climax Entertainment-
The original creators of the game!
-Landstalker Disassembly and Landstalker Editor by LordMir- (https://github.com/lordmir/landstalker_disasm), (https://github.com/lordmir/landstalker_editor)
This project would not be possible without these tools! Please go check out these amazing projects!