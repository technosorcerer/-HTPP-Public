LEMMINGS Colour Palette & Level Title Fix Hack v1.2 (Europe)
for Sega MegaDrive

This ROM has had a lot of work on to improve the colour palette to make the colours match to the Amiga version.
==============================================================

NOTE: This hack was hacked from the European PAL Version of Lemmings on the Sega MegaDrive. Not a NTSC ROM Hack.

==============================================================


===============================================================
VERSION HISTORY:
CHANGES for Patch 1.3

Refixed the Colour Palette for Special Levels for Taxing and Mayhem as I wasn't satisfied with how it looks, Now fixed and looks better.

ROM Header now show as v1.3

===============================================================

CHANGES for Patch v1.2
Altered the Colour Palettes for the Special Levels for
A Beast of a level
MENACING !!
What an AWESOME level!
& A BeastII of a level

fixed the colour palette for the purple text.

Removed the Extra space from Level 16 Title "Luvly Jubly"

Updated the header of the ROM

===============================================================
CHANGES FOR PATCH V1.1

Big thanks goes out to Adrian Gauna on YouTube for fixing up some of the Level Title names to match the Amiga version.

Adrian's Level Fixes
?   Fun Level 10: Smile if you love Lemmings
? Fun Level 26: Nightmare on Lem street
? Tricky Level 4: Been there, seen it, done it.
? Tricky Level 6: Lemmings in the basement
? Tricky Level 16: Luvly Jubly
? Tricky Level 17: Diet Lemmingade
? Taxing Level 16: Mary Poppin's land.
? Mayhem Level 20: No added colours or Lemmings

? Along with Fixing a typo in the ending credits from "GRAPICHS"  to "GRAPHICS"

Josho's Level Fix
?   Fun Level 1: Just Dig!

?   Perfect Percentage message now says "SPOT ON." rather than "Right on."

?   Changed the palettes for the Next rating animation scenes.

?   Change colour palettes for the ending credits to make it more pop out.

?    Changed the Lemming Colour Palette on the Title Screen sprite

================================================================

CHANGES For Patch v1.0
Dirt Level tile Yellow Hills on the Entry and Exit have been re-coloured to green to make it identical to the Amiga Version than the 0.5 version did.

================================================================
SETUP:


1. Download the ZIP file that contains the IPS patches and apply it to the MegaDrive ROM named "Lemmings (E) [!].smd" 

And Enjoy the hack.

Works on Fusion 3.6 Emulator. And I can guarentee this will work on real hardware as I tested on my Sega MegaDrive II console using the Mega Everdrive x7 cartridge for those wanting to play this hack on real hardware.

URL to the YouTube video showing on hardware capture:
https://www.youtube.com/watch?v=1s6GYRXtGe4

Hack by JRussellRetroGaming & Adrian Gauna