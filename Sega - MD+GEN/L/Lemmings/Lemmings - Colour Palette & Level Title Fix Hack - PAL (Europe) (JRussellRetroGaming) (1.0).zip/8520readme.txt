LEMMINGS Colour Palette Hack 1.0 for Sega MegaDrive

This ROM has had a lot of work on to improve the colour palette to make the colouyrs match to the Amiga version.


CHANGES For Patch v1.0
Dirt Level tile Yellow Hills on the Entry and Exit have been re-coloured to green to make it identical to the Amiga Version than the 0.5 version did.


SETUP:

Download the ZIP file that contains the IPS patches and apply it to the MegaDrive ROM named "Lemmings (E) [!].smd" 

And Enjoy the hack.

Works on Fusion 3.6 Emulator. And I can guarentee this will work on real hardware as I tested on my Sega MegaDrive II console using the Mega Everdrive x7 cartridge for those wanting to play this hack on real hardware.

URL to the YouTube video showing on hardware capture:
https://www.youtube.com/watch?v=1s6GYRXtGe4

Hack by JRussellRetroGaming