Lemmings Color Palette Hack v1.0
Changed the colors to be more like the original Amiga game.

Instructions:
- Get this Genesis/Mega Drive rom in bin format: Lemmings (JU) (REV 01) [!]
- Apply the ips patch to the bin file using LunarIPS

Hack by slogra