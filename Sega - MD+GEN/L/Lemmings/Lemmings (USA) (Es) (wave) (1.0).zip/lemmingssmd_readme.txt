Lemmings (Mega Drive)
Traducción al Español v1.0 (19/03/2023)
(C) 2023 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Lemmings (Japan, USA) (v1.1).md
MD5: 03af74df7f90f5bd7286ef3b48f0a6ae
SHA1: 61d468378c06a3d1044a8e11255294b46d0c094d
CRC32: 68c70362
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --