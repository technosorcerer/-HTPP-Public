LEMMINGS Colour Palette Hack 0.5 for Sega MegaDrive

This ROM has had a lot of work on to improve the colour palette to make the colouyrs match to the Amiga version.

SETUP:

Download the ZIP file that contains the IPS patches and apply it to the MegaDrive ROM named "Lemmings (E) [!].smd" 

And Enjoy the hack.
Works on Fusion 3.6 Emulator. And I can guarentee this will work on real hardware as I tested on my Sega MegaDrive II console using the Mega Everdrive x7 cartridge for those wanting to play on real hardware.

URL to the YouTube video showing on hardware capture:
https://www.youtube.com/watch?v=1s6GYRXtGe4

Hack by JRussellRetroGaming