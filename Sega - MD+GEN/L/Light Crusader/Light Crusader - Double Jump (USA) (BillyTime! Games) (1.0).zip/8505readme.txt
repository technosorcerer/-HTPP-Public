Light Crusader Double Jump
Mar 15th, 2024
BillyTime! Games
--------------------
This is a simple patch that adds a double jump in Light Crusader on Sega Genesis.

How it works:
--------------------
David is allowed a second jump by default to help him navigate dungeons and puzzles.

How to Patch:
--------------------
1.Grab a copy of Light Crusader (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

