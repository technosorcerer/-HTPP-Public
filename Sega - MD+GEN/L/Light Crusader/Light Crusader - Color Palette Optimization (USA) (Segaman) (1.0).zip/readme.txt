/************************************
 * Info:
 ***********************************/

Name: Light Crusader Color Palette Optimization Hack
Date: 06.07.2024
Version: 1.0
Original ROM: Light Crusader (U) [!].bin
Code: Segaman

/************************************
 * Features:
 ***********************************/
 
-Rewritten pallette routine from scratch
-Added color tables for fade effects both to dark and light
-Optimized palette routines provided faster loading times

/************************************
 * Known issues:
 ***********************************/

/************************************
 * How to patch:
 ***********************************/
 
Patch (E) version of the game with provided ips-patch file

