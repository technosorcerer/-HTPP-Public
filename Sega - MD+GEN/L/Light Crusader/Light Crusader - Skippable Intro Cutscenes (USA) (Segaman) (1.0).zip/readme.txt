/************************************
 * Info:
 ***********************************/

Name: Light Crusader Skipable Intro Cutsene Hack
Date: 11.07.2024
Version: 1.0
Original ROM: Light Crusader (U) [!].bin
Code: Segaman

/************************************
 * Features:
 ***********************************/
 
-Allows to skip intro cutsene by pressing start
-Fixed end credits skip
-Fixed color fade animation glitches

/************************************
 * Known issues:
 ***********************************/
 
-This hack does not allow to skip "arriving to town" and "talk to king" sequences

/************************************
 * How to patch:
 ***********************************/
 
Patch (U) version of the game with provided ips-patch file

