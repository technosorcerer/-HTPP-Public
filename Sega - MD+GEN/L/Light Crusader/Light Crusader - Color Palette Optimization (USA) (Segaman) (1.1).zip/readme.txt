/************************************
 * Info:
 ***********************************/

Name: Light Crusader Color Palette Optimization Hack
Date: 11.07.2024
Version: 1.1
Original ROM: Light Crusader (U) [!].bin
Code: Segaman

/************************************
 * Features:
 ***********************************/
 
v1.0
-Rewritten pallette routine from scratch
-Added color tables for fade effects both to dark and light
-Optimized palette routines provided faster loading times

v1.1
-Fixed fade to white effect on boss defeat or event
-Fixed fade effects on final boss

/************************************
 * Known issues:
 ***********************************/

/************************************
 * How to patch:
 ***********************************/
 
Patch (U) version of the game with provided ips-patch file

