Language patch (text only)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 11-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.
N.B. De Europese cartridge (dump) bevat nog enkele Japanse tekststrings,
deze zijn ongewijzigd gebleven.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Heavy Unit - Mega Drive Special (Japan).md (No-Intro Romset)
Platform: Sega Mega Drive / Genesis
Database: No-Intro: Genesis (v. 20180824-045026)

MD5:   6B60E70252280B1CC22D80CB4C70D54A
SHA1:  198E243CC21E4AEA97E2C6ACA376CB2AE70BC1C9
CRC32: 1ACBE608
Bytes: 524288

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --

Tips and tricks for Heavy Unit - Mega Drive Special

The Password option is used to enable cheats:

Password	Effect
TOMOYO		Credit increase 99.
OGOSHI		DEMO-REC mode
OHNUKI		Invincible
LOCATE		Display stage scroll position
SOSITE		Stage select

    Hidden Message: In option menu, [B]x100