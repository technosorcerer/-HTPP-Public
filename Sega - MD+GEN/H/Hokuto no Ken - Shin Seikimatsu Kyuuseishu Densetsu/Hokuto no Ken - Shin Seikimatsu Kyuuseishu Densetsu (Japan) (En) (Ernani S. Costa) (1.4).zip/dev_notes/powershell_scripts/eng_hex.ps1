	# Define the character replacement table
	$replacementTable = @{
	" " = "A780"
	"A#" = "A100"
	"B#" = "A101"
	"C#" = "A102"
	"D#" = "A103"
	"E#" = "A104"
	"F#" = "A105"
	"G" = "A106"
	"H" = "A107"
	"I" = "A108"
	"J" = "A109"
	"K" = "A10A"
	"L" = "A10B"
	"M" = "A10C"
	"N" = "A10D"
	"O" = "A10E"
	"P" = "A10F"
	"Q" = "A110"
	"R" = "A111"
	"S" = "A112"
	"T" = "A113"
	"U" = "A114"
	"V" = "A115"
	"W" = "A116"
	"X" = "A117"
	"Y" = "A118"
	"Z" = "A119"
#	"0" = "A7D5"
#	"1" = "A7D6"
#	"2" = "A7D7"
#	"3" = "A7D8"
#	"4" = "A7D9"
#	"5" = "A7DA"
#	"6" = "A7DB"
#	"7" = "A7DC"
#	"8" = "A7DD"
#	"9" = "A7DE"
	"199" = "A7D6A7DEA7DE"
	"'" = "A7DF"
	"！" = "A7E6"
	"," = "A7EA"
	"." = "A7EB"
	"/" = "FFFF"
	}

	# Define the file path
	$file = "C:\Users\Nani\Desktop\fist_intro_v1.txt"

	# Read the content of the file
	$content = Get-Content -Path $file -Raw

	# Iterate through each replacement and replace it in the content
	foreach ($key in $replacementTable.Keys) {
	$content = $content -replace [regex]::Escape($key), $replacementTable[$key]
	}

	# Write the updated content back to the file
	$content | Set-Content -Path $file