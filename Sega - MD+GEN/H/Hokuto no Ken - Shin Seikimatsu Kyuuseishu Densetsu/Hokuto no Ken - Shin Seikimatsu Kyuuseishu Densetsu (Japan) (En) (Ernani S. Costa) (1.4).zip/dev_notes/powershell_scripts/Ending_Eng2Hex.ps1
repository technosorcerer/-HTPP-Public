	# Define the character replacement table
	$prepareTable1 = @{
	"'S" = "$"
	"'V" = "%"
	"'D" = "&"
	"'L" = "*"
	"'R" = "£"
	"'T" = "^"
	}
	$prepareTable2 = @{
	"A" = "A#"
	"B" = "B#"
	"C" = "C#"
	"D" = "D#"
	"E" = "E#"
	"F" = "F#"
	"0" = "0#"
	"1" = "1#"
	"2" = "2#"
	"3" = "3#"
	"4" = "4#"
	"5" = "5#"
	"6" = "6#"
	"7" = "7#"
	"8" = "8#"
	"9" = "9#"
	}
	
	$replacementTable = @{
	" " = "002A"
	"A#" = "002B"
	"B#" = "002C"
	"C#" = "002D"
	"D#" = "002E"
	"E#" = "002F"
	"F#" = "0030"
	"G" = "0031"
	"H" = "0032"
	"I" = "0033"
	"J" = "0034"
	"K" = "0035"
	"L" = "0036"
	"M" = "0037"
	"N" = "0038"
	"O" = "0039"
	"P" = "003A"
	"Q" = "003B"
	"R" = "003C"
	"S" = "003D"
	"T" = "003E"
	"U" = "003F"
	"V" = "0040"
	"W" = "0041"
	"X" = "0042"
	"Y" = "0043"
	"Z" = "0044"
	"$" = "0045"
	"%" = "0046"
	"&" = "0047"
	"*" = "0048"
	"£" = "0049"
	"^" = "004A"
	"0#" = "007D"
	"1#" = "007E"
	"2#" = "007F"
	"3#" = "0080"
	"4#" = "0081"
	"5#" = "0082"
	"6#" = "0083"
	"7#" = "0084"
	"8#" = "0085"
	"9#" = "0086"
	"!" = "008E"
	"?" = "008F"
	"," = "0092"
	"." = "0093"
	"/" = "0091"
	}

	# Define the file path
	$file = "C:\hextranscript.txt"

	# Read the content of the file
	$content = Get-Content -Path $file -Raw

	# Iterate through each replacement and replace it in the content
	foreach ($key in $prepareTable1.Keys) {
	$content = $content -replace [regex]::Escape($key), $prepareTable1[$key]
	}
	# Iterate through each replacement and replace it in the content
	foreach ($key in $prepareTable2.Keys) {
	$content = $content -replace [regex]::Escape($key), $prepareTable2[$key]
	}
	# Iterate through each replacement and replace it in the content
	foreach ($key in $replacementTable.Keys) {
	$content = $content -replace [regex]::Escape($key), $replacementTable[$key]
	}

	# Write the updated content back to the file
	$content | Set-Content -Path $file