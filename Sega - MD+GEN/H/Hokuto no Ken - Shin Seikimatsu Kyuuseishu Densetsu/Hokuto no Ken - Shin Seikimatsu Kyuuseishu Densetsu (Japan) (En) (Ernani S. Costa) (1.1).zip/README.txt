patch by Ernani da S. Costa
apply
*FONTS_ENG:
 + original japanese to english translation
 + dialog text box size increased

*FONTS_REVISITED (latest version of the hack)
 v1.0
 + stage order rearranged and text curated to reflect the anime more closelly
 + graphic changes to the map and its locations to reflect the stages more closelly
 + air enemy bounce physics
 + boss health and damage inflicted to kenshiro rebalanced
 + some stages had enemy placement adjusted
 + kenshiro attacks, jump and enemy hit and enemy hitting kenshiro sound fxs changed
 + walking speed increased
 + stage scroll when kenshiro is at the center of screen
 v1.1
 + Kaioh name in intro fixed
 + dungeon flying axe enviroment collision fixed
 + chapter 2 dungeon skip bug fixed
 + black line in front of arrow head removed

BOTH PATCHES INCLUDE:
 + graphic fixes (broken mouth sprites/ arrow head sprite/ wrong max def value)
 + graphic translations to pre-logo, pre-chapter text and ending background text
 + logo fist of the north star subtext
 + intro scrolling speed decreased,
 + intro text shifted left to fit more characters per line