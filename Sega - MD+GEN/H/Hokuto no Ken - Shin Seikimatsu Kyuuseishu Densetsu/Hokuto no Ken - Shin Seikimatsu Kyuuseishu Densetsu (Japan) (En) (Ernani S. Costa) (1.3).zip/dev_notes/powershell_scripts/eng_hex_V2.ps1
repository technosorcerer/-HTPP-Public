	# Define the character replacement table
	$prepareTable1 = @{
	"'S" = "$"
	"'V" = "%"
	"'D" = "&"
	"'L" = "*"
	"'R" = "£"
	"'T" = "^"
	}
	$prepareTable2 = @{
	"A" = "A#"
	"B" = "B#"
	"C" = "C#"
	"D" = "D#"
	"E" = "E#"
	"F" = "F#"
	"0" = "0#"
	"1" = "1#"
	"2" = "2#"
	"3" = "3#"
	"4" = "4#"
	"5" = "5#"
	"6" = "6#"
	"7" = "7#"
	"8" = "8#"
	"9" = "9#"
	}
	
	$replacementTable = @{
	" " = "A780"
	"A#" = "A781"
	"B#" = "A782"
	"C#" = "A783"
	"D#" = "A784"
	"E#" = "A785"
	"F#" = "A786"
	"G" = "A787"
	"H" = "A788"
	"I" = "A789"
	"J" = "A78A"
	"K" = "A78B"
	"L" = "A78C"
	"M" = "A78D"
	"N" = "A78E"
	"O" = "A78F"
	"P" = "A790"
	"Q" = "A791"
	"R" = "A792"
	"S" = "A793"
	"T" = "A794"
	"U" = "A795"
	"V" = "A796"
	"W" = "A797"
	"X" = "A798"
	"Y" = "A799"
	"Z" = "A79A"
	"$" = "A79B"
	"%" = "A79C"
	"&" = "A79D"
	"*" = "A79E"
	"£" = "A79F"
	"^" = "A7A0"
	"0#" = "A7D3"
	"1#" = "A7D4"
	"2#" = "A7D5"
	"3#" = "A7D6"
	"4#" = "A7D7"
	"5#" = "A7D8"
	"6#" = "A7D9"
	"7#" = "A7DA"
	"8#" = "A7DB"
	"9#" = "A7DC"
	"!" = "A7E4"
	"?" = "A7E5"
	"-" = "A7E6"
	"," = "A7E8"
	"." = "A7E9"
	"/" = "FFFF"
	}

	# Define the file path
	$file = "C:\hextranscript.txt"

	# Read the content of the file
	$content = Get-Content -Path $file -Raw

	# Iterate through each replacement and replace it in the content
	foreach ($key in $prepareTable1.Keys) {
	$content = $content -replace [regex]::Escape($key), $prepareTable1[$key]
	}
	# Iterate through each replacement and replace it in the content
	foreach ($key in $prepareTable2.Keys) {
	$content = $content -replace [regex]::Escape($key), $prepareTable2[$key]
	}
	# Iterate through each replacement and replace it in the content
	foreach ($key in $replacementTable.Keys) {
	$content = $content -replace [regex]::Escape($key), $replacementTable[$key]
	}

	# Write the updated content back to the file
	$content | Set-Content -Path $file