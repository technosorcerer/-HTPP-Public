Home Alone (2x Items)
Sep. 15th 2025
BillyTime! Games
--------------------
This is a simple patch for Home Alone on Sega Genesis that doubles the amount of items earned per pickup. These items are used to craft weapons.

How to Patch:
--------------------
1.Grab a copy of Home Alone (USA, Europe).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding BPS file