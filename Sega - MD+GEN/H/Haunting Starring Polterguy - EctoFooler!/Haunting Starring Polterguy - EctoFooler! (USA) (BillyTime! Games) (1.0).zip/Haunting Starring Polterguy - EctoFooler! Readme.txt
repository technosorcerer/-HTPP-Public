Haunting Starring Polterguy - EctoFooler!
Jun. 21st 2025
BillyTime! Games
--------------------
This small patch is designed to give Polterguy more ecto when starting a game in The Haunting for Sega Genesis. 

Changes:
--------------------
*Instant Master Code.
*Start with More Ecto on new game.
*Boo Doo is slightly stronger.
*Start with all spells on new game.


How to Patch:
--------------------
1.Grab a copy of Haunting Starring Polterguy (USA, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file