Teenage Mutant Ninja Turtles - Tournament Fighters (Mega Drive)
Traducción al Español v2.1 (16/03/2024)
(C) 2024 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V2.0:
-Añadidos caracteres españoles
-Mejorado título y opciones
-Traducida licencia
-Traducidos nombres de escenarios
-Traducidos créditos
-Letras grandes parcialmente traducidas

V2.1:
-Arreglado TMOP por TMPO al terminar un combate

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Teenage Mutant Ninja Turtles - Tournament Fighters (USA).md
MD5: 4cabf79a9e4783ff4e5c1294bcb6129c
SHA1: 1a27be1e7f8f47eb539b874eaa48586fe2dab9c0
CRC32: 95b5484d
2097152 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --