This is just a simple color hack, nothinng fancy.
Just use this patch with any .ips patcher and rom file with CRC32: C661369

This is version 1.0 - car, title screen and all stages were recolored.

Enjoy.