Turbo OutRun Hi-Score SRAM 
May. 1st 2024
BillyTime! Games
Spkleader
--------------------
This patch is designed to add a simple saving mechanism for High Scores in Turbo OutRun.


How to use
--------------------
Saving:
Scores save after Initials are entered and player returns to the Sega screen. 

Loading:
Scores load upon boot. If checksum fails or it is your first time booting, default scores are loaded.


How to Patch:
--------------------
1.Grab a copy of Turbo OutRun (Japan, Europe).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file