Turbo Outrun (Japan, Europe) Dolsilwa Color Hack 2.0

This is just a simple color hack.
Just use this patch with any .ips patcher and rom file with CRC32: C661369

v. 1.0 changes:
* car, title screen and all stages were recolored.

v. 2.0 changes:
* car, title screen and all stages were recolored or tweaked.

Just apply .ips patch on original rom. 

Hope you'll like it.

Dol.