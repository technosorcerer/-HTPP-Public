Terminator 2 - Cyberdyne Redux
Dec. 24th 2024
BillyTime! Games
--------------------
This patch is designed to remove a good chunk of fake difficulty in Terminator 2 - Judgement Day for the Sega Genesis.


Changes
--------------------
*Game can continue if John Connor is critically injured
*Collisions in driving stages deal 1% of damage
*Only 1 future object needed per level
*T-800 moves much faster

*NOTE:
Compatible with Terminator 2 - Judgment Day (UE) [!] - Music & Sound Hack by Segaman & VLD

How to Patch:
--------------------
1.Grab a copy of T2 - Terminator 2 - Judgment Day (USA, Europe).md (No-Intro)
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file