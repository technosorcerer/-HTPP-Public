/************************************
 * Info:
 ***********************************/

Name: Terminator2: Judgement Day Music & Sound Hack
Date: 17.09.2023
Version: 1.0
Original ROM: Terminator 2 - Judgment Day (UE) [!].bin
Code: Segaman
Music & SFX: VLD
Sound Engine: Ian Karlsson

/************************************
 * Features:
 ***********************************/
 
-Replaced sound engine with MDSDRV
-Added 11 brand new Music Tracks
-Added new Sound Effects
-Added some missing sounds
-Fixed pistol sounds
-Added extra music and sirene on T1000 arrival

/************************************
 * Known issues:
 ***********************************/

-Music and sounds hanging while game is loading
-Some explosions play Shotgun sound
-Last stage has missing sound for falling lava
-Dyson scream sound is missing

/************************************
 * How to patch:
 ***********************************/
 
Patch (UE) version of the game with provided ips-patch file

