Taz-Mania SRAM
Sept. 20th 2023
BillyTime! Games
--------------------
This patch is designed to add a simple saving mechanism to Taz-Mania.


How to use
--------------------
Saving:
Game saves at the map screen, every level after level 1. (Easy and Hard Difficulty only)

Loading:
Press and Hold A when highlighting Start Game at the title screen until the Intro appears.
Game will default to level 1 if no save is found.


How to Patch:
--------------------
1.Grab a copy of Taz-Mania (World).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file