Toki - Double Jump
Jun 20th, 2023
BillyTime! Games
--------------------
This is a simple patch that adds a double jump in Toki - Going Ape Spit on Sega Genesis.

How it works:
--------------------
Toki is allowed to double jump before reaching the peak of his first jump for extended height.
Patch works for both players 

How to Patch:
--------------------
1.Grab a copy of JuJu Densetsu ~ Toki - Going Ape Spit (World) (Rev A).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

