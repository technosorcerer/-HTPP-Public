Task Force Harrier EX (Mega Drive)
Traducci�n al Espa�ol v1.0 (07/05/2019)
(C) 2019 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducci�n y hacking es completamente original.
Si encuentras alg�n fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
Task Force Harrier EX (U) [!].bin
MD5: d5b0add1252ac8fd1ecec8b02cf51718
SHA1: 1d36bd69e356f276c582fee247af2f71af1f3bf4
CRC32: c8bb0257
1.048.576 bytes

--------
Cr�ditos
--------
Wave - Hacking, traducci�n y pruebas.

-- FIN --