Toejam and Earl - Funkotronic Remix
Aug 19th, 2024
BillyTime! Games
--------------------
This patch for is an overhaul for Toejam and Earl on Sega Genesis 

*Changes
--------------------
*3x duration for Items
*Faster start up - Skip the Flying Ship at the sega logo
*Earl starts with less presents
*Santa is easier to sneak up on
*Starting Items can be randomized!


*CHEATS!
At "WHAT" menu press and hold these buttons for new effects!

*A+C - Item Select
--------------------
At the map screen, Press and hold the following button combos and press B for specific items
Up + Start - Hi-Tops
Down + Start - Tomatoes
Left + Start - Floatation Device
Right + Start - Spring Shoes
Up + Left + Start - Wings
Up + Right + Start - Rocket Skates (Reduced time for this item compared to others.)
Down + Left + Start - Slingshot
Down + Right + Start - Rosebushes

*NOTE:Items have an extended active time, Item select works for both players.


*B+C - Indentifier
--------------------
All presents are now identified for the whole game!

*Left+A+C - Faster Movement Speed!
*Right+A+C - Uncover All Maps!

*A+B+C - ALL CHEATS ACTIVE! (Expect the enemy randomizer)

*Left + A+B+C - Enemy Randomizer
--------------------
Special randomized enemy sets for an extra challenge! Enemies change each time you change floors, even if you have already been there! 

*Right + A+B+C - ALL CHEATS ACTIVE plus Enemy Randomizer!!!
--------------------
The craziest available option, all rules go out the window.

GAME GENIE CODES:
  Game Genie /     HEX    /  Description
-------------------------------------------------
(Codes 1-5 cannot be combined)
1.AEBB-AADC - 100262:0001 - Item Select
2.AJBB-AADC - 100262:0002 - Always Identify
3.ANBB-AADC - 100262:0003 - Faster Movement Speed
4.ATBB-AADC - 100262:0004 - Uncover All Maps
5.AYBB-AADC - 100262:0005 - All Cheats
6.AEBB-AADL - 10026A:0001 - Enemy Randomizer
7.CTDV-AA48 + BJGV-AA2R - 10075E:6014 + 100D0E:600A - Always Identify (Alternate Code)
8.C2GV-AA42 - 100D58:6016 - Uncover All Maps
9.DAHB-AA2J - 100E08:6018 - Faster Movement Speed

(Codes 10-13 cannot be combined, semi works in two player.)
10.REBB-A618 - 1002FE:4E71 - Toejam Always Starts with Hi-Tops
11.REBV-A6VN - 10032C:4E71 - Toejam Always Starts with Unfall, Spring Shoes, Rosebushes and Hi-Tops
12.REBV-A6W4 - 10035A:4E71 - Toejam Always starts with Total Bummer
13.REBV-A6Z0 - 1003B6:4E71 - Toejam Always starts with Extra Life/Jackpot


How to Patch:
--------------------
1.Grab a copy of ToeJam & Earl (World) (Rev A).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file

