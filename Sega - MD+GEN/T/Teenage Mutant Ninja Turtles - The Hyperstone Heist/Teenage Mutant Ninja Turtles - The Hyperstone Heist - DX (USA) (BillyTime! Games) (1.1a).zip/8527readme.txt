Teenage Mutant Ninja Turtles - The Hyperstone Heist DX
Mar. 28th 2024
BillyTime! Games
--------------------
This patch adds several addition features to Teenage Mutant Ninja Turtles - The Hyperstone Heist for Sega Genesis.

Features:
Super Difficulty (Selected within the options menu.)
--------------------
*Enemies are more aggressive and deal double damage.

Difficulty Randomizer (Selected within the options menu.)
--------------------
*At the character select screen, difficulty randomizes between Easy and Super Difficulty.

Survival Mode (Hold B when selecting One or Two players, continue to hold until the character select screen appears.)
--------------------
*Game defaults to hard difficulty or Super Difficulty if selected
*Players are reduced to one life and no continues
*Enemies have increased aggression.
 
*Classic Mirage Comics colors (Selected within the options menu.)
--------------------
All turtles sport red gear and comic colors!

Hi-Score SRAM
--------------------
*Saving:
Scores save after Game Over and player returns to the sega logo. 

*Loading:
Scores load upon boot. If checksum fails or it is your first time booting, default scores are loaded.


How to Patch:
--------------------
1.Grab a copy of Teenage Mutant Ninja Turtles - The Hyperstone Heist (USA).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Patch your rom with the corresponding IPS file