True Lies - Realism Edition
Nov 14th 2025
BillyTime! Games
--------------------
This is a challenge patch for True Lies on Sega Genesis. 
It tweaks the gameplay to make the game more tactical in approach. 

Changes:
-----------------------------------
Harry can only take two hits before dying.
Harry has on life.
Harry's invincibility frames are reduced by 1/2
Enemies die in One Hit.

How to Patch:
--------------------
1.Grab a copy of True Lies (World).md
2.Grab Floating IPS (https://www.romhacking.net/utilities/1040/)
3.Apply patch to rom