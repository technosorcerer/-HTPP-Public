Twinkle Tale
Traducci�n al Espa�ol v1.1 (03/06/2018)
(C) 2018 Wave Translations

---
TdC
---

1. Sobre Twinkle Tale
2. Notas del Proyecto
3. Fallos Conocidos (o: Bugs que no son bugs)
4. Instrucciones de Parcheo
5. Cr�ditos del Parche

-----------------
1. Sobre Twinkle Tale
-----------------
Shooter m�gico para Mega Drive.

---------------------
2. Notas del Proyecto
---------------------
Esta traducci�n y hacking est� basada en la traducci�n de MIJET.
v1.1:Corregida estrella fugaz.

--------------------------------------------
3. Fallos Conocidos (o: Bugs que no son bugs)
--------------------------------------------
Ninguno que yo sepa, si encuentras alguno puedes mandar un correo a sewave@gmail.com

---------------------------
4. Instrucciones de Parcheo
---------------------------
El parche est� en formato IPS, recomiendo usar LunarIPS.
Archivo utilizado:
Twinkle Tale (J) [!].bin
1.048.576 bytes
CRC32: d757f924
MD5: 809887a9535753ee7a13c8a2d365f0eb
SHA1: 5377e96b4cb14038675c41d165f1d92ae067cd9b

----------------------
5. Cr�ditos del Parche
----------------------
Wave - Hacking y traducci�n

Original:
Contributor	Type of contribution	Listed credit
M.I.J.E.T.	Hacking	Full Hacking & Translation

-- END OF README --