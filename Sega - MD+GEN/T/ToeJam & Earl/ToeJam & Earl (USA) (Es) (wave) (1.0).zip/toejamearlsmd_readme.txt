ToeJam & Earl (Mega Drive)
Traducción al Español v1.1 (25/03/2021)
(C) 2021 Traducciones Wave

------------------------
Notas y Fallos Conocidos
------------------------
Esta traducción y hacking es completamente original.
Si encuentras algún fallo puedes contactar conmigo y ver mis traducciones en
traduccioneswave.blogspot.com

V1.1:
-Traducido INNER TUBE por FLOTADOR
-Traducidas HITOPS por ZAPAS
-Pasado a ROM REV A

------------------------
Instrucciones de Parcheo
------------------------
En formato IPS, puedes usar LunarIPS o Floating IPS.
Archivo utilizado:
ToeJam & Earl (Japan, Europe) (Rev A).md
MD5: 72dc91fd2c5528b384f082a38db9ddda
SHA1: 85e8d0a4fac591b25b77c35680ac4175976f251b
CRC32: 7a588f4b
1048576 bytes

--------
Créditos
--------
Wave - Hacking, traducción y pruebas.

-- FIN --