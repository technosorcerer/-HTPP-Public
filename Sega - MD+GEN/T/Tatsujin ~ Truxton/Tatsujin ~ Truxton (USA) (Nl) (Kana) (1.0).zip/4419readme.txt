Language patch (text + and a few tiles)
Language: Dutch
--------------------------

Vertaling naar het Nederlands
Versie: 1.0
Datum: 11-04-2019
(c) 2019 Kana Translations

--------------------------
Opmerkingen bij deze patch
--------------------------
Deze vertaling en hack is geheel oorspronkelijk.
N.B. De Europese cartridge (dump) bevat nog enkele Japanse tekststrings,
deze zijn ongewijzigd gebleven.

--------------------------
Patch-instructies
--------------------------
De patch heeft de IPS-indeling, en kan worden gebruikt met LunarIPS of Floating IPS.

--------------------------
Spelinformatie
--------------------------
Gebruikt oorspronkelijk bronbestand:

Titel: Tatsujin ~ Truxton (World).md (No-Intro Romset)
Platform: Sega Mega Drive / Genesis
Database: No-Intro: Genesis (v. 20180824-045026)

MD5:   75A42B19E5503C72B21018699314DB0B
SHA1:  90039844478E7CB99951FDFF1979C3BDA04D080A
CRC32: 5BD0882D
Bytes: 524288

--------------------------
Dankwoord/Credits
--------------------------
Kana - Nederlandse vertaling en hack

--------------------------
Very special thanks
--------------------------
Wave - voor het briljante programma Hextractor, website:
traduccioneswave.blogspot.com

-- EINDE --